# Onboarding stability fix

The final access-plan picker must not redefine the user's personalization path.

This branch hardens `AccountViewModel.completeOnboarding` so older/current UI flows that accidentally pass the selected paid plan as `selectedPath` recover the actual profile path from the onboarding data before validation. This prevents a completed professional/student/business profile from being rejected simply because the customer selected a different access plan on the final step.

Regression coverage is included under `OnboardingPathRegressionTest`.
