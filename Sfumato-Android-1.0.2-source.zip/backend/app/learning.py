from enum import IntEnum, StrEnum

from pydantic import BaseModel, Field


class TutorMode(StrEnum):
    DIAGNOSTIC = "diagnostic"
    LESSON = "lesson"
    PRACTICE = "practice"
    REVISION = "revision"


class TutorProgress(BaseModel):
    subject: str
    topic: str
    mastery: int = Field(default=0, ge=0, le=100)
    questions_attempted: int = Field(default=0, ge=0)
    questions_correct: int = Field(default=0, ge=0)


class DebateStage(IntEnum):
    FOUNDATION = 1
    CHALLENGER = 2
    ADVANCED = 3
    EXPERT = 4
    GRANDMASTER = 5


class DebateScore(BaseModel):
    reasoning: int = Field(ge=0, le=25)
    evidence: int = Field(ge=0, le=20)
    rebuttal: int = Field(ge=0, le=15)
    opposing_view: int = Field(ge=0, le=15)
    clarity: int = Field(ge=0, le=10)
    cross_examination: int = Field(ge=0, le=10)
    civility: int = Field(ge=0, le=5)

    @property
    def total(self) -> int:
        return sum(
            (
                self.reasoning,
                self.evidence,
                self.rebuttal,
                self.opposing_view,
                self.clarity,
                self.cross_examination,
                self.civility,
            )
        )


class OverallScoreInputs(BaseModel):
    debate_mastery: int = Field(ge=0, le=100)
    tutor_mastery: int = Field(ge=0, le=100)
    scholarship_readiness: int = Field(ge=0, le=100)
    completed_goals: int = Field(ge=0, le=100)
    research_quality: int = Field(ge=0, le=100)
    responsible_participation: int = Field(ge=0, le=100)


def overall_higuru_score(inputs: OverallScoreInputs) -> int:
    weighted = (
        inputs.debate_mastery * 0.40
        + inputs.tutor_mastery * 0.20
        + inputs.scholarship_readiness * 0.15
        + inputs.completed_goals * 0.10
        + inputs.research_quality * 0.10
        + inputs.responsible_participation * 0.05
    )
    return round(weighted)


STAGE_MINIMUMS: dict[DebateStage, tuple[int, int]] = {
    DebateStage.FOUNDATION: (0, 0),
    DebateStage.CHALLENGER: (60, 35),
    DebateStage.ADVANCED: (70, 50),
    DebateStage.EXPERT: (80, 65),
    DebateStage.GRANDMASTER: (90, 80),
}


def stage_unlocked(stage: DebateStage, prior_debate_score: int, overall_score: int) -> bool:
    debate_minimum, overall_minimum = STAGE_MINIMUMS[stage]
    return prior_debate_score >= debate_minimum and overall_score >= overall_minimum


STAGE_PASS_SCORES: dict[int, int] = {
    1: 60,
    2: 70,
    3: 80,
    4: 90,
    5: 95,
}


def highest_unlocked_stage(results: list[dict]) -> DebateStage:
    """Return durable Arena progress from saved, verified stage passes."""
    highest = DebateStage.FOUNDATION
    for item in results:
        stage_value = int(item.get("stage", 0))
        if stage_value not in STAGE_PASS_SCORES or stage_value >= int(DebateStage.GRANDMASTER):
            continue
        passed = item.get("passed") is True or (
            "passed" not in item
            and int(item.get("total", 0)) >= STAGE_PASS_SCORES[stage_value]
        )
        if passed:
            highest = max(highest, DebateStage(stage_value + 1))
    return highest
