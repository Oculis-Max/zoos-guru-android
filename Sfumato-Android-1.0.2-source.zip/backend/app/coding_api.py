from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time
from typing import Annotated, Any
from pathlib import PurePosixPath
from urllib.parse import quote, urlencode

import httpx
from cryptography.fernet import Fernet, InvalidToken
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from app.config import Settings, get_settings
from app.learning_store import LearningStore, learning_store
from app.billing_api import require_autonomous_entitlement

router = APIRouter(prefix="/v1/coding", tags=["coding"])
CONNECTIONS = "github_connections"
OAUTH_STATES = "github_oauth_states"

class GitHubConnectionStatus(BaseModel):
    connected: bool
    login: str | None = None

class GitHubRepository(BaseModel):
    full_name: str
    private: bool
    default_branch: str
    permissions: dict[str, bool] = Field(default_factory=dict)

class RepositoryFile(BaseModel):
    path: str
    size: int
    sha: str

class RepositoryFileContent(BaseModel):
    path: str
    content: str
    sha: str
    truncated: bool = False

READABLE_SUFFIXES = {".kt", ".kts", ".java", ".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".swift", ".c", ".cc", ".cpp", ".h", ".hpp", ".cs", ".rb", ".php", ".html", ".css", ".scss", ".sql", ".md", ".txt", ".json", ".xml", ".toml"}
PROTECTED_PATH_WORDS = {".env", "secret", "credential", "service-account", "google-services.json", "id_rsa", "id_ed25519", ".pem", ".key", ".jks", "keystore"}
MAX_BROWSE_FILE_BYTES = 100_000
MAX_TREE_FILES = 500

def _repository(owner: str, repository: str) -> str:
    values = (owner.strip(), repository.strip())
    if not all(value and value.replace("-", "").replace("_", "").replace(".", "").isalnum() for value in values):
        raise HTTPException(422, detail={"code": "invalid_repository"})
    return "/".join(values)

def _readable_path(value: str) -> str:
    raw = value.strip(); path = PurePosixPath(raw); lowered = raw.lower()
    if (not raw or raw.startswith("/") or "\\" in raw or any(part in {"", ".", "..", ".git", ".github"} for part in path.parts) or any(word in lowered for word in PROTECTED_PATH_WORDS) or path.suffix.lower() not in READABLE_SUFFIXES):
        raise HTTPException(422, detail={"code": "protected_file_path"})
    return str(path)

def _github_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}

def get_learning_store() -> LearningStore: return learning_store

def _uid(claims: dict[str, Any]) -> str: return str(claims.get("uid") or claims["sub"])

def _require_oauth(settings: Settings) -> tuple[str, str, str]:
    client_id = settings.github_client_id; client_secret = settings.github_client_secret; encryption_secret = settings.github_token_encryption_secret
    if client_id is None or client_secret is None or encryption_secret is None:
        raise HTTPException(status_code=503, detail={"code": "github_connection_not_configured"})
    return client_id, client_secret.get_secret_value(), encryption_secret.get_secret_value()

def _new_state(uid: str, secret: str) -> tuple[str, str, int]:
    expires = int(time.time()) + 600; nonce = secrets.token_urlsafe(24); payload = f"{uid}:{expires}:{nonce}"; signature = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest(); value = base64.urlsafe_b64encode(f"{payload}:{signature}".encode()).decode()
    return value, hashlib.sha256(value.encode()).hexdigest(), expires

def _verify_state(value: str, secret: str) -> tuple[str, str]:
    try:
        decoded = base64.urlsafe_b64decode(value.encode()).decode(); uid, expires_text, nonce, signature = decoded.rsplit(":", 3); payload = f"{uid}:{expires_text}:{nonce}"; expected = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected) or int(expires_text) < int(time.time()) or len(nonce) < 20: raise ValueError("Expired or invalid state")
        return uid, hashlib.sha256(value.encode()).hexdigest()
    except (ValueError, UnicodeDecodeError, base64.binascii.Error) as exc:
        raise HTTPException(status_code=400, detail={"code": "invalid_oauth_state"}) from exc

def _consume_state(uid: str, state_hash: str, store: LearningStore) -> None:
    matching = next((record for record in store.list(uid, OAUTH_STATES) if hmac.compare_digest(str(record.get("state_hash", "")), state_hash)), None)
    if matching is None: raise HTTPException(status_code=400, detail={"code": "oauth_state_reused_or_unknown"})
    expires = matching.get("expires_epoch")
    store.delete(uid, OAUTH_STATES, str(matching["id"]))
    if not isinstance(expires, int) or expires < int(time.time()): raise HTTPException(status_code=400, detail={"code": "invalid_oauth_state"})

def _fernet(secret: str) -> Fernet: return Fernet(base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest()))

def _connection(uid: str, store: LearningStore) -> dict[str, Any] | None:
    records = store.list(uid, CONNECTIONS); return records[0] if records else None

def _token(uid: str, store: LearningStore, settings: Settings) -> str:
    connection = _connection(uid, store); _, _, secret = _require_oauth(settings)
    if connection is None: raise HTTPException(status_code=409, detail={"code": "github_not_connected"})
    try: return _fernet(secret).decrypt(connection["encrypted_token"].encode()).decode()
    except (InvalidToken, KeyError) as exc: raise HTTPException(status_code=503, detail={"code": "github_token_unavailable"}) from exc

@router.get("/github/connect")
def connect_github(claims: Annotated[dict[str, Any], Depends(require_autonomous_entitlement)], settings: Annotated[Settings, Depends(get_settings)], store: Annotated[LearningStore, Depends(get_learning_store)]) -> dict[str, str]:
    client_id, _, secret = _require_oauth(settings); uid = _uid(claims); state_value, state_hash, expires = _new_state(uid, secret); store.create(uid, OAUTH_STATES, {"state_hash": state_hash, "expires_epoch": expires})
    query = urlencode({"client_id": client_id, "redirect_uri": settings.github_oauth_callback_url, "scope": "repo read:user", "state": state_value})
    return {"authorize_url": f"https://github.com/login/oauth/authorize?{query}"}

@router.get("/github/callback", response_class=HTMLResponse)
async def github_callback(code: Annotated[str | None, Query()] = None, state_value: Annotated[str | None, Query(alias="state")] = None, error: Annotated[str | None, Query()] = None, error_description: Annotated[str | None, Query()] = None, settings: Settings = Depends(get_settings), store: LearningStore = Depends(get_learning_store)) -> HTMLResponse:
    if error:
        return HTMLResponse("<html><body style='font-family:sans-serif;background:#111;color:#fff;padding:32px'><h2>GitHub connection cancelled</h2><p>No repository access was granted. You can safely return to Sfumato and try again.</p></body></html>", status_code=400)
    if not code or not state_value: raise HTTPException(400, detail={"code": "github_oauth_missing_parameters"})
    client_id, client_secret, secret = _require_oauth(settings); uid, state_hash = _verify_state(state_value, secret); _consume_state(uid, state_hash, store)
    try:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            token_response = await client.post("https://github.com/login/oauth/access_token", headers={"Accept": "application/json"}, data={"client_id": client_id,"client_secret": client_secret,"code": code,"redirect_uri": settings.github_oauth_callback_url})
            if token_response.status_code != 200: raise HTTPException(502, detail={"code": "github_oauth_failed"})
            token_data = token_response.json(); access_token = token_data.get("access_token")
            if not access_token: raise HTTPException(502, detail={"code": "github_oauth_failed"})
            user_response = await client.get("https://api.github.com/user", headers={"Authorization": f"Bearer {access_token}", "Accept": "application/vnd.github+json"})
            if user_response.status_code != 200: raise HTTPException(502, detail={"code": "github_identity_failed"})
            login = str(user_response.json()["login"])
    except httpx.RequestError as exc: raise HTTPException(503, detail={"code": "github_temporarily_unavailable"}) from exc
    store.delete_all(uid, CONNECTIONS); store.create(uid, CONNECTIONS, {"login": login, "encrypted_token": _fernet(secret).encrypt(access_token.encode()).decode()}); store.audit(uid, "coding.github.connected", {"login": login})
    return HTMLResponse("<html><body style='font-family:sans-serif;background:#111;color:#fff;padding:32px'><h2>GitHub connected to Sfumato</h2><p>You can return to the app.</p></body></html>")

@router.get("/github/status", response_model=GitHubConnectionStatus)
def github_status(claims: Annotated[dict[str, Any], Depends(require_autonomous_entitlement)], store: Annotated[LearningStore, Depends(get_learning_store)]) -> GitHubConnectionStatus:
    connection = _connection(_uid(claims), store); return GitHubConnectionStatus(connected=connection is not None, login=str(connection.get("login")) if connection else None)

@router.delete("/github/connection", response_model=GitHubConnectionStatus)
async def disconnect_github(claims: Annotated[dict[str, Any], Depends(require_autonomous_entitlement)], settings: Annotated[Settings, Depends(get_settings)], store: Annotated[LearningStore, Depends(get_learning_store)]) -> GitHubConnectionStatus:
    uid = _uid(claims); connection = _connection(uid, store)
    if connection is not None:
        try:
            token = _token(uid, store, settings); client_id, client_secret, _ = _require_oauth(settings)
            async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client: await client.request("DELETE", f"https://api.github.com/applications/{client_id}/token", auth=(client_id, client_secret), headers={"Accept": "application/vnd.github+json"}, json={"access_token": token})
        except (httpx.RequestError, HTTPException): pass
    store.delete_all(uid, CONNECTIONS); store.delete_all(uid, OAUTH_STATES); store.audit(uid, "coding.github.disconnected", {})
    return GitHubConnectionStatus(connected=False)

@router.get("/github/repos", response_model=list[GitHubRepository])
async def list_repositories(claims: Annotated[dict[str, Any], Depends(require_autonomous_entitlement)], settings: Annotated[Settings, Depends(get_settings)], store: Annotated[LearningStore, Depends(get_learning_store)]) -> list[GitHubRepository]:
    token = _token(_uid(claims), store, settings); results=[]; page=1
    async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
        while page <= 10:
            try: response = await client.get("https://api.github.com/user/repos", params={"sort":"updated","per_page":100,"page":page,"affiliation":"owner,collaborator,organization_member"}, headers=_github_headers(token))
            except httpx.RequestError as exc: raise HTTPException(503, detail={"code":"github_temporarily_unavailable"}) from exc
            if response.status_code == 401: raise HTTPException(401, detail={"code":"github_reconnect_required"})
            if response.status_code >= 400: raise HTTPException(502, detail={"code":"github_repository_list_failed"})
            batch=response.json(); results.extend(batch)
            if len(batch)<100: break
            page+=1
    return [GitHubRepository(full_name=item["full_name"], private=bool(item["private"]), default_branch=item["default_branch"], permissions=item.get("permissions") or {}) for item in results if bool((item.get("permissions") or {}).get("push"))]

@router.get("/github/repos/{owner}/{repository}/tree", response_model=list[RepositoryFile])
async def repository_tree(owner: str, repository: str, claims: Annotated[dict[str, Any], Depends(require_autonomous_entitlement)], settings: Annotated[Settings, Depends(get_settings)], store: Annotated[LearningStore, Depends(get_learning_store)], ref: Annotated[str | None, Query(max_length=200)] = None) -> list[RepositoryFile]:
    repo=_repository(owner,repository); token=_token(_uid(claims),store,settings); headers=_github_headers(token)
    async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
        info=await client.get(f"https://api.github.com/repos/{repo}",headers=headers)
        if info.status_code!=200: raise HTTPException(404,detail={"code":"repository_not_accessible"})
        if not bool((info.json().get("permissions") or {}).get("push")): raise HTTPException(403,detail={"code":"repository_write_permission_required"})
        revision=ref or str(info.json()["default_branch"]); response=await client.get(f"https://api.github.com/repos/{repo}/git/trees/{quote(revision,safe='')}",params={"recursive":"1"},headers=headers)
    if response.status_code!=200: raise HTTPException(404,detail={"code":"repository_revision_not_found"})
    files=[]
    for item in response.json().get("tree",[]):
        path=str(item.get("path") or "")
        try: safe_path=_readable_path(path)
        except HTTPException: continue
        size=int(item.get("size") or 0)
        if item.get("type")=="blob" and size<=MAX_BROWSE_FILE_BYTES: files.append(RepositoryFile(path=safe_path,size=size,sha=str(item.get("sha") or "")))
        if len(files)>=MAX_TREE_FILES: break
    return files

@router.get("/github/repos/{owner}/{repository}/file", response_model=RepositoryFileContent)
async def repository_file(owner: str, repository: str, path: Annotated[str, Query(min_length=1,max_length=500)], claims: Annotated[dict[str,Any],Depends(require_autonomous_entitlement)], settings: Annotated[Settings,Depends(get_settings)], store: Annotated[LearningStore,Depends(get_learning_store)], ref: Annotated[str|None,Query(max_length=200)]=None) -> RepositoryFileContent:
    repo=_repository(owner,repository); safe_path=_readable_path(path); token=_token(_uid(claims),store,settings); headers=_github_headers(token)
    async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
        info=await client.get(f"https://api.github.com/repos/{repo}",headers=headers)
        if info.status_code!=200: raise HTTPException(404,detail={"code":"repository_not_accessible"})
        revision=ref or str(info.json()["default_branch"]); response=await client.get(f"https://api.github.com/repos/{repo}/contents/{quote(safe_path,safe='/')}",params={"ref":revision},headers=headers)
    if response.status_code!=200: raise HTTPException(404,detail={"code":"repository_file_not_found"})
    payload=response.json()
    if int(payload.get("size") or 0)>MAX_BROWSE_FILE_BYTES: raise HTTPException(413,detail={"code":"repository_file_too_large"})
    try: decoded=base64.b64decode(str(payload["content"]),validate=True).decode("utf-8")
    except (KeyError,UnicodeDecodeError,ValueError,base64.binascii.Error) as exc: raise HTTPException(422,detail={"code":"repository_file_not_text"}) from exc
    limit=30_000; return RepositoryFileContent(path=safe_path,content=decoded[:limit],sha=str(payload.get("sha") or ""),truncated=len(decoded)>limit)
