from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Literal, Protocol

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from app.advanced_assistant_store import AssistantStore, assistant_store
from app.channel_connectors import OfficialOutboundConnector
from app.config import Settings, get_settings
from app.google_oauth import GoogleOAuthService, OAuthConfigurationError
from app.models import ChatMessage
from app.provider import ProviderError, build_provider
from app.billing_api import require_business_entitlement

router = APIRouter(prefix="/v1/advanced-assistant", tags=["advanced-assistant"])

Channel = Literal["email", "sms", "whatsapp", "facebook", "instagram"]
ActionStatus = Literal["awaiting_approval", "approved", "sent", "cancelled", "failed"]


class DraftRequest(BaseModel):
    channel: Channel
    instruction: str = Field(min_length=3, max_length=4000)
    recipient: str | None = Field(default=None, max_length=320)
    context: str | None = Field(default=None, max_length=12000)


class ActionResponse(BaseModel):
    id: str
    owner_uid: str
    channel: Channel
    recipient: str | None = None
    subject: str | None = None
    content: str
    instruction: str
    status: ActionStatus
    approved_by: str | None = None
    approved_at: datetime | None = None
    sent_at: datetime | None = None
    provider_message_id: str | None = None
    error: str | None = None
    created_at: datetime
    updated_at: datetime | None = None


class ActionEdit(BaseModel):
    recipient: str | None = Field(default=None, max_length=320)
    subject: str | None = Field(default=None, max_length=240)
    content: str = Field(min_length=1, max_length=20000)


class EmailAlertResponse(BaseModel):
    id: str
    owner_uid: str
    message_id: str
    thread_id: str
    sender: str
    sender_email: str = ""
    subject: str
    snippet: str
    received_at: str = ""
    priority: Literal["high", "normal"]
    reason: str
    suggested_action: str
    status: Literal["new", "reviewed"] = "new"
    created_at: datetime
    updated_at: datetime | None = None


class ReportRequest(BaseModel):
    title: str = Field(min_length=2, max_length=240)
    objective: str = Field(min_length=5, max_length=4000)
    source_material: str = Field(min_length=1, max_length=30000)
    report_type: Literal["business", "academic", "operations", "incident", "progress", "custom"] = "custom"


class ReportResponse(BaseModel):
    id: str
    owner_uid: str
    title: str
    objective: str
    report_type: str
    content: str
    status: Literal["draft", "approved"]
    created_at: datetime
    updated_at: datetime | None = None


class AdminTaskCreate(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    description: str = Field(min_length=2, max_length=4000)
    due_at: datetime | None = None


class AdminTaskUpdate(BaseModel):
    status: Literal["planned", "approved", "in_progress", "completed", "cancelled"]


class AdminTaskResponse(BaseModel):
    id: str
    owner_uid: str
    title: str
    description: str
    status: str
    due_at: datetime | None = None
    created_at: datetime
    updated_at: datetime | None = None


class OutboundConnector(Protocol):
    async def send(self, action: dict[str, Any]) -> str: ...


class UnconfiguredOutboundConnector:
    async def send(self, action: dict[str, Any]) -> str:
        raise RuntimeError(f"{action['channel']}_connection_required")


def get_assistant_store() -> AssistantStore:
    return assistant_store


def get_outbound_connector(
    settings: Annotated[Settings, Depends(get_settings)],
) -> OutboundConnector:
    return OfficialOutboundConnector(settings)


def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims.get("sub") or "")


def _owned(
    collection: str,
    record_id: str,
    claims: dict[str, Any],
    store: AssistantStore,
) -> dict[str, Any]:
    value = store.get(collection, record_id)
    if value is None:
        raise HTTPException(404, detail={"code": "record_not_found"})
    if value.get("owner_uid") != _uid(claims):
        raise HTTPException(403, detail={"code": "assistant_record_access_denied"})
    return value


@router.get("/oauth/google/start")
def start_google_oauth(
    settings: Annotated[Settings, Depends(get_settings)],
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, str]:
    try:
        service = GoogleOAuthService(settings, store)
    except OAuthConfigurationError as exc:
        raise HTTPException(503, detail={"code": str(exc)}) from exc
    return {
        "authorization_url": service.authorization_url(
            _uid(claims),
            str(claims.get("email") or "") or None,
        )
    }


@router.get("/oauth/google/callback", response_class=HTMLResponse)
async def complete_google_oauth(
    code: str,
    state: str,
    settings: Annotated[Settings, Depends(get_settings)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> HTMLResponse:
    try:
        await GoogleOAuthService(settings, store).complete(code, state)
    except (OAuthConfigurationError, RuntimeError):
        return HTMLResponse(
            "<h1>Gmail connection failed</h1><p>Return to Sfumato and try again.</p>",
            status_code=400,
        )
    return HTMLResponse(
        "<h1>Gmail connected to Sfumato</h1>"
        "<p>You can close this page and return to the Advanced Assistant.</p>"
    )


@router.get("/connections")
def connection_status(
    settings: Annotated[Settings, Depends(get_settings)],
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> list[dict[str, str | bool]]:
    return OfficialOutboundConnector(settings, store=store).connection_status(_uid(claims))


def _email_attention(email: dict[str, str]) -> tuple[str, str, str] | None:
    text = (email.get("subject", "") + " " + email.get("snippet", "")).lower()
    high_signals = (
        "urgent", "asap", "deadline", "overdue", "payment failed", "security alert",
        "account suspended", "action required", "immediately",
    )
    normal_signals = (
        "please reply", "can you", "could you", "confirm", "approval", "review",
        "meeting", "appointment", "invoice", "application", "request", "?",
    )
    if any(signal in text for signal in high_signals):
        return (
            "high",
            "This unread email contains an urgent, deadline, payment, or security signal.",
            "Review it now. Sfumato can prepare a reply for your approval.",
        )
    if any(signal in text for signal in normal_signals):
        return (
            "normal",
            "This unread email appears to request a reply, review, confirmation, or decision.",
            "Review the request and ask Sfumato to draft the response.",
        )
    return None


@router.post("/inbox/scan", response_model=list[EmailAlertResponse])
async def scan_gmail_inbox(
    settings: Annotated[Settings, Depends(get_settings)],
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> list[dict[str, Any]]:
    uid = _uid(claims)
    connector = OfficialOutboundConnector(settings, store=store)
    try:
        emails = await connector.read_inbox(uid)
    except RuntimeError as exc:
        raise HTTPException(503, detail={"code": str(exc)}) from exc
    existing = {
        str(item.get("message_id")): item
        for item in store.list_for_user("email_alerts", uid)
    }
    for email in emails:
        attention = _email_attention(email)
        if attention is None or email["message_id"] in existing:
            continue
        priority, reason, suggested_action = attention
        alert = store.create("email_alerts", {
            **email,
            "owner_uid": uid,
            "priority": priority,
            "reason": reason,
            "suggested_action": suggested_action,
            "status": "new",
        })
        existing[email["message_id"]] = alert
    return list(existing.values())


@router.get("/notifications", response_model=list[EmailAlertResponse])
def list_email_alerts(
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> list[dict[str, Any]]:
    return store.list_for_user("email_alerts", _uid(claims))


@router.post("/notifications/{alert_id}/reviewed", response_model=EmailAlertResponse)
def mark_email_alert_reviewed(
    alert_id: str,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    _owned("email_alerts", alert_id, claims, store)
    return store.update("email_alerts", alert_id, {"status": "reviewed"})


@router.post("/actions/draft", response_model=ActionResponse)
async def generate_action_draft(
    request: DraftRequest,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    settings: Annotated[Settings, Depends(get_settings)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    prompt = (
        f"Prepare a {request.channel} draft. Follow the instruction precisely. "
        "Return only the message body; never claim it was sent.\n"
        f"Instruction: {request.instruction}\n"
        f"Recipient: {request.recipient or 'not selected'}\n"
        f"Context: {request.context or 'none'}"
    )
    try:
        content, _ = await build_provider(settings).complete([
            ChatMessage(
                role="system",
                content=(
                    "You are Sfumato Advanced Assistant. Draft clear, accurate communications for user review. "
                    "Do not send, publish, invent facts, or add unsupported commitments."
                ),
            ),
            ChatMessage(role="user", content=prompt[:16000]),
        ])
    except ProviderError as exc:
        raise HTTPException(503, detail={"code": "assistant_ai_unavailable"}) from exc
    return store.create("actions", {
        "owner_uid": _uid(claims),
        "channel": request.channel,
        "recipient": request.recipient,
        "subject": None,
        "content": content.strip(),
        "instruction": request.instruction,
        "status": "awaiting_approval",
        "approved_by": None,
        "approved_at": None,
        "sent_at": None,
        "provider_message_id": None,
        "error": None,
    })


@router.get("/actions", response_model=list[ActionResponse])
def list_actions(
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> list[dict[str, Any]]:
    return store.list_for_user("actions", _uid(claims))


@router.put("/actions/{action_id}", response_model=ActionResponse)
def edit_action(
    action_id: str,
    request: ActionEdit,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    action = _owned("actions", action_id, claims, store)
    if action["status"] not in {"awaiting_approval", "approved", "failed"}:
        raise HTTPException(409, detail={"code": "sent_action_cannot_be_edited"})
    return store.update("actions", action_id, {
        **request.model_dump(),
        "status": "awaiting_approval",
        "approved_by": None,
        "approved_at": None,
        "error": None,
    })


@router.post("/actions/{action_id}/approve", response_model=ActionResponse)
def approve_action(
    action_id: str,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    action = _owned("actions", action_id, claims, store)
    if action["status"] != "awaiting_approval":
        raise HTTPException(409, detail={"code": "action_not_awaiting_approval"})
    return store.update("actions", action_id, {
        "status": "approved",
        "approved_by": _uid(claims),
        "approved_at": datetime.now().astimezone(),
    })


@router.post("/actions/{action_id}/cancel", response_model=ActionResponse)
def cancel_action(
    action_id: str,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    action = _owned("actions", action_id, claims, store)
    if action["status"] == "sent":
        raise HTTPException(409, detail={"code": "sent_action_cannot_be_cancelled"})
    return store.update("actions", action_id, {"status": "cancelled"})


@router.post("/actions/{action_id}/dispatch", response_model=ActionResponse)
async def dispatch_action(
    action_id: str,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
    connector: Annotated[OutboundConnector, Depends(get_outbound_connector)],
) -> dict[str, Any]:
    action = _owned("actions", action_id, claims, store)
    if action["status"] != "approved" or action.get("approved_by") != _uid(claims):
        raise HTTPException(409, detail={"code": "user_approval_required"})
    try:
        provider_message_id = await connector.send(action)
    except RuntimeError as exc:
        store.update("actions", action_id, {"status": "failed", "error": str(exc)})
        raise HTTPException(503, detail={"code": str(exc)}) from exc
    return store.update("actions", action_id, {
        "status": "sent",
        "sent_at": datetime.now().astimezone(),
        "provider_message_id": provider_message_id,
        "error": None,
    })


@router.post("/reports", response_model=ReportResponse)
async def generate_report(
    request: ReportRequest,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    settings: Annotated[Settings, Depends(get_settings)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    try:
        content, _ = await build_provider(settings).complete([
            ChatMessage(
                role="system",
                content=(
                    "Write a structured long-form report using only the supplied material. Include an executive "
                    "summary, clear headings, findings, limitations and recommendations where appropriate. "
                    "Never invent sources, evidence, figures or citations. Mark missing information clearly."
                ),
            ),
            ChatMessage(
                role="user",
                content=(
                    f"Title: {request.title}\nType: {request.report_type}\n"
                    f"Objective: {request.objective}\nSource material:\n{request.source_material}"
                )[:32000],
            ),
        ])
    except ProviderError as exc:
        raise HTTPException(503, detail={"code": "report_ai_unavailable"}) from exc
    return store.create("reports", {
        "owner_uid": _uid(claims),
        "title": request.title,
        "objective": request.objective,
        "report_type": request.report_type,
        "content": content.strip(),
        "status": "draft",
    })


@router.get("/reports", response_model=list[ReportResponse])
def list_reports(
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> list[dict[str, Any]]:
    return store.list_for_user("reports", _uid(claims))


@router.post("/reports/{report_id}/approve", response_model=ReportResponse)
def approve_report(
    report_id: str,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    _owned("reports", report_id, claims, store)
    return store.update("reports", report_id, {"status": "approved"})


@router.post("/admin-tasks", response_model=AdminTaskResponse)
def create_admin_task(
    request: AdminTaskCreate,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    return store.create("admin_tasks", {
        **request.model_dump(),
        "owner_uid": _uid(claims),
        "status": "planned",
    })


@router.get("/admin-tasks", response_model=list[AdminTaskResponse])
def list_admin_tasks(
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> list[dict[str, Any]]:
    return store.list_for_user("admin_tasks", _uid(claims))


@router.patch("/admin-tasks/{task_id}", response_model=AdminTaskResponse)
def update_admin_task(
    task_id: str,
    request: AdminTaskUpdate,
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    store: Annotated[AssistantStore, Depends(get_assistant_store)],
) -> dict[str, Any]:
    _owned("admin_tasks", task_id, claims, store)
    return store.update("admin_tasks", task_id, {"status": request.status})

