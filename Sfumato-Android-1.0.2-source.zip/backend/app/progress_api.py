from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field

from app.billing_api import require_student_entitlement
from app.learning_store import LearningStore, learning_store
from app.progress_store import ProgressStore, progress_store

router = APIRouter(prefix="/v1/progress", tags=["progress"])


class ShareRequest(BaseModel):
    viewer_email: str = Field(
        min_length=3,
        max_length=254,
        pattern=r"^[^@ ]+@[^@ ]+[.][^@ ]+$",
    )
    viewer_role: Literal["parent", "teacher", "professor", "employer"]
    subject_name: str = Field(min_length=1, max_length=100)
    categories: list[
        Literal["learning", "debate", "scholarships", "coding", "business"]
    ] = Field(default_factory=lambda: ["learning"], min_length=1)


class ShareResponse(ShareRequest):
    id: str
    subject_uid: str
    status: str
    created_at: datetime


class ProgressMetric(BaseModel):
    key: str
    label: str
    count: int


class ProgressSummary(BaseModel):
    subject_name: str
    total_activities: int
    metrics: list[ProgressMetric]
    recent_activity: list[dict[str, str]]
    engagement_status: str
    alerts: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    privacy_notice: str = (
        "Only approved activity totals and timestamps are shared. Private chats, "
        "answers, prompts and document contents are never included."
    )


class FeedbackRequest(BaseModel):
    message: str = Field(min_length=3, max_length=1000)
    action: str | None = Field(default=None, max_length=300)


class FeedbackResponse(BaseModel):
    id: str
    share_id: str
    author_email: str
    author_role: str
    subject_uid: str
    message: str
    action: str | None = None
    created_at: datetime


def get_progress_store() -> ProgressStore:
    return progress_store


def get_learning_store() -> LearningStore:
    return learning_store


def uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims.get("sub") or "")


def email(claims: dict[str, Any]) -> str:
    return str(claims.get("email") or "").strip().lower()


COLLECTIONS = {
    "learning": (("tutor_sessions", "Tutor sessions"),),
    "debate": (("debate_sessions", "Debates completed"),),
    "scholarships": (("scholarship_applications", "Scholarships tracked"),),
    "coding": (("coding_runs", "Coding runs"),),
    "business": (("business_runs", "Business tasks"),),
}


def build_summary(
    subject_uid: str,
    subject_name: str,
    categories: list[str],
    store: LearningStore,
) -> ProgressSummary:
    metrics: list[ProgressMetric] = []
    recent: list[dict[str, str]] = []
    for category in categories:
        for collection, label in COLLECTIONS.get(category, ()):
            records = store.list(subject_uid, collection)
            metrics.append(
                ProgressMetric(key=collection, label=label, count=len(records))
            )
            for record in records[:3]:
                created = record.get("created_at")
                recent.append(
                    {
                        "type": label,
                        "at": created.isoformat()
                        if hasattr(created, "isoformat")
                        else str(created or ""),
                    }
                )
    recent.sort(key=lambda item: item["at"], reverse=True)
    total = sum(item.count for item in metrics)
    alerts = []
    if total == 0:
        alerts.append("No learning activity has been recorded yet.")
    inactive = [item.label for item in metrics if item.count == 0]
    if inactive and total > 0:
        alerts.append("No recent activity in: " + ", ".join(inactive[:3]))
    recommendations = [
        "Review the learner's recent Tutor activity and agree on one weekly goal.",
        "Celebrate consistent effort before focusing on weaker areas.",
    ]
    engagement = "Getting started" if total < 3 else ("Active" if total < 12 else "Highly engaged")
    return ProgressSummary(
        subject_name=subject_name,
        total_activities=total,
        metrics=metrics,
        recent_activity=recent[:8],
        engagement_status=engagement,
        alerts=alerts,
        recommendations=recommendations,
    )


@router.get("/summary", response_model=ProgressSummary)
def my_summary(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
) -> ProgressSummary:
    name = str(claims.get("name") or claims.get("email") or "Sfumato member")
    return build_summary(uid(claims), name, list(COLLECTIONS), store)


@router.post("/shares", response_model=ShareResponse)
def create_share(
    request: ShareRequest,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[ProgressStore, Depends(get_progress_store)],
) -> dict[str, Any]:
    viewer = request.viewer_email.strip().lower()
    if viewer == email(claims):
        raise HTTPException(400, detail={"code": "viewer_must_be_another_account"})
    for existing in store.list_subject(uid(claims)):
        if (
            existing.get("viewer_email") == viewer
            and existing.get("viewer_role") == request.viewer_role
        ):
            raise HTTPException(409, detail={"code": "progress_share_already_exists"})
    data = request.model_dump(mode="json")
    data["viewer_email"] = viewer
    data["categories"] = list(dict.fromkeys(request.categories))
    return store.create(uid(claims), data)


@router.get("/shares", response_model=list[ShareResponse])
def list_shares(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[ProgressStore, Depends(get_progress_store)],
) -> list[dict[str, Any]]:
    return store.list_subject(uid(claims))


@router.delete(
    "/shares/{share_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
def revoke_share(
    share_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[ProgressStore, Depends(get_progress_store)],
) -> Response:
    if not store.revoke(uid(claims), share_id):
        raise HTTPException(404, detail={"code": "share_not_found"})
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/viewer", response_model=list[ShareResponse])
def viewer_access(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[ProgressStore, Depends(get_progress_store)],
) -> list[dict[str, Any]]:
    viewer_email = email(claims)
    if not viewer_email:
        raise HTTPException(400, detail={"code": "verified_email_required"})
    return store.list_viewer(viewer_email)


def _viewer_share(
    share_id: str,
    claims: dict[str, Any],
    shares: ProgressStore,
) -> dict[str, Any]:
    share = shares.get(share_id)
    if (
        share is None
        or share.get("status") != "active"
        or share.get("viewer_email") != email(claims)
    ):
        raise HTTPException(403, detail={"code": "progress_access_denied"})
    return share


@router.get("/viewer/{share_id}/summary", response_model=ProgressSummary)
def shared_summary(
    share_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    shares: Annotated[ProgressStore, Depends(get_progress_store)],
    activities: Annotated[LearningStore, Depends(get_learning_store)],
) -> ProgressSummary:
    share = _viewer_share(share_id, claims, shares)
    return build_summary(
        str(share["subject_uid"]),
        str(share["subject_name"]),
        list(share["categories"]),
        activities,
    )


@router.post("/viewer/{share_id}/feedback", response_model=FeedbackResponse)
def create_feedback(
    share_id: str,
    request: FeedbackRequest,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    shares: Annotated[ProgressStore, Depends(get_progress_store)],
    activities: Annotated[LearningStore, Depends(get_learning_store)],
) -> dict[str, Any]:
    share = _viewer_share(share_id, claims, shares)
    role = str(share.get("viewer_role") or "")
    if role not in {"teacher", "professor"}:
        raise HTTPException(403, detail={"code": "educator_role_required"})
    return activities.create(
        str(share["subject_uid"]),
        "education_feedback",
        {
            "share_id": share_id,
            "author_email": email(claims),
            "author_role": role,
            "subject_uid": str(share["subject_uid"]),
            "message": request.message.strip(),
            "action": request.action.strip() if request.action else None,
        },
    )


@router.get("/viewer/{share_id}/feedback", response_model=list[FeedbackResponse])
def viewer_feedback(
    share_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    shares: Annotated[ProgressStore, Depends(get_progress_store)],
    activities: Annotated[LearningStore, Depends(get_learning_store)],
) -> list[dict[str, Any]]:
    share = _viewer_share(share_id, claims, shares)
    return [
        item
        for item in activities.list(str(share["subject_uid"]), "education_feedback")
        if item.get("share_id") == share_id
    ][:30]


@router.get("/feedback", response_model=list[FeedbackResponse])
def learner_feedback(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    activities: Annotated[LearningStore, Depends(get_learning_store)],
) -> list[dict[str, Any]]:
    return activities.list(uid(claims), "education_feedback")[:30]
