from functools import lru_cache

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="HIGURU_",
        env_file=".env",
        extra="ignore",
    )

    firebase_project_id: str | None = None
    firebase_service_account_json: SecretStr | None = None
    gemini_api_key: SecretStr | None = None
    gemini_base_url: str = "https://generativelanguage.googleapis.com/v1beta/openai"
    gemini_model: str = "gemini-3.6-flash"
    allow_demo_provider: bool = False
    journalist_audio_enabled: bool = False
    qwen_api_key: SecretStr | None = None
    qwen_base_url: str | None = None
    qwen_model: str = "qwen3.7-plus"
    kimi_api_key: SecretStr | None = None
    kimi_model: str = "kimi-k3"
    kimi_base_url: str = "https://api.moonshot.ai/v1"
    openrouter_api_key: SecretStr | None = None
    openrouter_model: str = "openrouter/free"
    learning_judge_token: SecretStr | None = None
    github_client_id: str | None = None
    github_client_secret: SecretStr | None = None
    github_token_encryption_secret: SecretStr | None = None
    github_oauth_callback_url: str = "https://higuru-api-beta.onrender.com/v1/coding/github/callback"
    paystack_secret_key: SecretStr | None = None
    paystack_student_plan_code: str = "PLN_am3as0bhdydqddf"
    paystack_developer_plan_code: str = "PLN_lkpqa22f20gt3py"
    paystack_business_plan_code: str = "PLN_zj80tecdw74vnp8"
    paystack_student_checkout_url: str = "https://paystack.shop/pay/7r8d2viwyq"
    paystack_developer_checkout_url: str = "https://paystack.shop/pay/5c-r79m8p9"
    paystack_business_checkout_url: str = "https://paystack.shop/pay/0uxqz0od9e"
    gmail_access_token: SecretStr | None = None
    google_oauth_client_id: str | None = None
    google_oauth_client_secret: SecretStr | None = None
    google_oauth_callback_url: str = "https://higuru-api-beta.onrender.com/v1/advanced-assistant/oauth/google/callback"
    assistant_token_encryption_secret: SecretStr | None = None
    twilio_account_sid: str | None = None
    twilio_auth_token: SecretStr | None = None
    twilio_from_number: str | None = None
    meta_access_token: SecretStr | None = None
    meta_graph_version: str = "v23.0"
    whatsapp_phone_number_id: str | None = None
    facebook_page_id: str | None = None
    request_timeout_seconds: float = 45.0
    max_history_messages: int = 30
    max_message_characters: int = 8000

    # Hard server-side AI cost guards. These cannot be bypassed by a modified APK.
    ai_max_output_tokens: int = 2048
    ai_max_input_characters: int = 50000
    ai_daily_token_limit_free: int = 60000
    ai_daily_token_limit_student: int = 300000
    ai_daily_token_limit_developer: int = 1000000
    ai_daily_token_limit_business: int = 1500000


@lru_cache
def get_settings() -> Settings:
    return Settings()
