import logging
from typing import Protocol

import httpx

from app.config import Settings
from app.models import ChatMessage, TokenUsage

logger = logging.getLogger(__name__)


class ProviderError(Exception):
    pass


class ProviderUnavailableError(ProviderError):
    pass


class ProviderRateLimitError(ProviderError):
    pass


class AiProvider(Protocol):
    async def complete(self, messages: list[ChatMessage]) -> tuple[str, TokenUsage]: ...


def build_provider(settings: Settings) -> AiProvider:
    providers: list[AiProvider] = []
    if settings.gemini_api_key is not None:
        providers.append(GeminiProvider(settings))
    if settings.qwen_api_key is not None and settings.qwen_base_url:
        providers.append(QwenProvider(settings))
    if settings.kimi_api_key is not None:
        providers.append(KimiProvider(settings))
    if settings.openrouter_api_key is not None:
        providers.append(OpenRouterProvider(settings))
    if not providers:
        return DemoProvider() if settings.allow_demo_provider else UnavailableProvider()
    return providers[0] if len(providers) == 1 else FailoverProvider(providers)


class FailoverProvider:
    def __init__(self, providers: list[AiProvider]) -> None:
        self.providers = providers

    async def complete(self, messages: list[ChatMessage]) -> tuple[str, TokenUsage]:
        last_error: ProviderError | None = None
        for provider in self.providers:
            try:
                return await provider.complete(messages)
            except ProviderError as exc:
                last_error = exc
                logger.warning(
                    "AI provider failed; trying fallback: provider=%s error=%s",
                    type(provider).__name__,
                    type(exc).__name__,
                )
        if last_error is not None:
            raise last_error
        raise ProviderUnavailableError("No AI provider is configured")


def _parse_completion(response: httpx.Response) -> tuple[str, TokenUsage]:
    try:
        data = response.json()
        content = data["choices"][0]["message"]["content"]
        raw_usage = data.get("usage", {})
        if not isinstance(content, str) or not content.strip():
            raise ValueError("Empty provider response")
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        raise ProviderError("Malformed provider response") from exc

    return content.strip(), TokenUsage(
        prompt_tokens=raw_usage.get("prompt_tokens", 0),
        completion_tokens=raw_usage.get("completion_tokens", 0),
        total_tokens=raw_usage.get("total_tokens", 0),
    )


def _raise_for_provider_status(response: httpx.Response, provider_name: str) -> None:
    if response.status_code == 429:
        raise ProviderRateLimitError(f"{provider_name} rate limit reached")
    if response.status_code >= 500:
        raise ProviderUnavailableError(f"{provider_name} unavailable")
    if response.status_code >= 400:
        logger.warning(
            "%s rejected a request: status=%s", provider_name, response.status_code
        )
        raise ProviderError(
            f"{provider_name} rejected the request ({response.status_code})"
        )


def _payload(
    settings: Settings, model: str, messages: list[ChatMessage]
) -> dict[str, object]:
    return {
        "model": model.strip(),
        "messages": [message.model_dump() for message in messages],
        "max_tokens": settings.ai_max_output_tokens,
    }


class UnavailableProvider:
    async def complete(self, messages: list[ChatMessage]) -> tuple[str, TokenUsage]:
        raise ProviderUnavailableError("No production AI provider is configured")


class DemoProvider:
    async def complete(self, messages: list[ChatMessage]) -> tuple[str, TokenUsage]:
        latest = next(
            (message.content for message in reversed(messages) if message.role == "user"),
            "",
        )
        return f"Sfumato demo mode received: {latest}", TokenUsage()


class OpenAICompatibleProvider:
    provider_name = "AI provider"

    def __init__(self, settings: Settings, api_key, base_url: str, model: str) -> None:
        self.settings = settings
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model

    async def complete(self, messages: list[ChatMessage]) -> tuple[str, TokenUsage]:
        if self.api_key is None:
            raise ProviderUnavailableError(f"{self.provider_name} is not configured")
        try:
            async with httpx.AsyncClient(
                timeout=self.settings.request_timeout_seconds
            ) as client:
                response = await client.post(
                    f"{self.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.api_key.get_secret_value()}",
                        "Content-Type": "application/json",
                    },
                    json=_payload(self.settings, self.model, messages),
                )
        except httpx.TimeoutException as exc:
            raise ProviderUnavailableError(f"{self.provider_name} timed out") from exc
        except httpx.HTTPError as exc:
            raise ProviderUnavailableError(
                f"{self.provider_name} connection failed"
            ) from exc
        _raise_for_provider_status(response, self.provider_name)
        return _parse_completion(response)


class GeminiProvider(OpenAICompatibleProvider):
    provider_name = "Gemini"

    def __init__(self, settings: Settings) -> None:
        super().__init__(
            settings,
            settings.gemini_api_key,
            settings.gemini_base_url,
            settings.gemini_model,
        )


class QwenProvider(OpenAICompatibleProvider):
    provider_name = "Qwen"

    def __init__(self, settings: Settings) -> None:
        super().__init__(
            settings,
            settings.qwen_api_key,
            settings.qwen_base_url or "",
            settings.qwen_model,
        )


class KimiProvider(OpenAICompatibleProvider):
    provider_name = "Kimi"

    def __init__(self, settings: Settings) -> None:
        super().__init__(
            settings,
            settings.kimi_api_key,
            settings.kimi_base_url,
            settings.kimi_model,
        )


class OpenRouterProvider:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def complete(self, messages: list[ChatMessage]) -> tuple[str, TokenUsage]:
        api_key = self.settings.openrouter_api_key
        if api_key is None:
            raise ProviderUnavailableError("OpenRouter is not configured")

        models = list(
            dict.fromkeys([self.settings.openrouter_model.strip(), "openrouter/free"])
        )
        # Cost guard: at most one attempt per model; web search is not automatically invoked.
        async with httpx.AsyncClient(
            timeout=self.settings.request_timeout_seconds
        ) as client:
            for index, model in enumerate(models):
                try:
                    response = await client.post(
                        "https://openrouter.ai/api/v1/chat/completions",
                        headers={
                            "Authorization": f"Bearer {api_key.get_secret_value()}",
                            "Content-Type": "application/json",
                            "HTTP-Referer": "https://higuru.co.za",
                            "X-Title": "Sfumato",
                        },
                        json=_payload(self.settings, model, messages),
                    )
                except httpx.TimeoutException as exc:
                    raise ProviderUnavailableError("Provider timed out") from exc
                except httpx.HTTPError as exc:
                    raise ProviderUnavailableError("Provider connection failed") from exc

                if response.status_code >= 400 and index < len(models) - 1:
                    logger.warning(
                        "OpenRouter attempt failed: status=%s model=%s",
                        response.status_code,
                        model,
                    )
                    continue
                _raise_for_provider_status(response, "OpenRouter")
                return _parse_completion(response)

        raise ProviderError("No AI model completed the request")
