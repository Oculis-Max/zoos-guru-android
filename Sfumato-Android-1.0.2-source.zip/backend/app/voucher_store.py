from __future__ import annotations

import hashlib
from copy import deepcopy
from datetime import UTC, datetime
from threading import RLock
from typing import Any, Protocol

import firebase_admin
from firebase_admin import firestore


def normalise_voucher_code(code: str) -> str:
    return "".join(character for character in code.upper().strip() if character.isalnum())


def voucher_hash(code: str) -> str:
    return hashlib.sha256(normalise_voucher_code(code).encode()).hexdigest()


class VoucherStore(Protocol):
    def redeem(self, code: str, uid: str, profile: dict[str, Any]) -> dict[str, Any]: ...


class VoucherError(RuntimeError):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class FirestoreVoucherStore:
    def _client(self):
        firebase_admin.get_app()
        return firestore.client()

    def redeem(self, code: str, uid: str, profile: dict[str, Any]) -> dict[str, Any]:
        client = self._client()
        code_digest = voucher_hash(code)
        voucher_ref = client.collection("sponsored_vouchers").document(code_digest)
        user_ref = client.collection("users").document(uid)
        entitlement_ref = user_ref.collection("billing").document("entitlement")
        transaction = client.transaction()

        @firestore.transactional
        def apply_redemption(txn):
            snapshot = voucher_ref.get(transaction=txn)
            if not snapshot.exists:
                raise VoucherError("invalid_voucher")
            voucher = snapshot.to_dict() or {}
            redeemed_by = str(voucher.get("redeemed_by") or "")
            if redeemed_by and redeemed_by != uid:
                raise VoucherError("voucher_already_redeemed")
            now = datetime.now(UTC)
            redemption_expires_at = voucher.get("redemption_expires_at")
            if redemption_expires_at is not None and redemption_expires_at <= now:
                raise VoucherError("voucher_expired")
            access_ends_at = voucher.get("access_ends_at")
            if access_ends_at is not None and access_ends_at <= now:
                raise VoucherError("campaign_access_expired")
            entitlement = {
                "user_id": uid,
                "tier": "student",
                "status": "active",
                "source": "sponsored_voucher",
                "campaign_id": voucher.get("campaign_id"),
                "sponsor": voucher.get("sponsor"),
                "funding_source": voucher.get("funding_source"),
                "sponsored_until": access_ends_at,
                "updated_at": now,
            }
            txn.set(entitlement_ref, entitlement, merge=True)
            txn.set(user_ref, {**profile, "onboardingComplete": True, "updatedAt": now}, merge=True)
            if not redeemed_by:
                txn.update(voucher_ref, {"redeemed_by": uid, "redeemed_at": now})
            return entitlement

        entitlement = apply_redemption(transaction)
        client.collection("billing_audit").add(
            {
                "event_type": "billing.voucher.activated",
                "data": {
                    "user_id": uid,
                    "campaign_id": entitlement.get("campaign_id"),
                    "voucher_hash_prefix": code_digest[:12],
                },
                "created_at": datetime.now(UTC),
            }
        )
        return entitlement


class InMemoryVoucherStore:
    def __init__(self) -> None:
        self.vouchers: dict[str, dict[str, Any]] = {}
        self.entitlements: dict[str, dict[str, Any]] = {}
        self.profiles: dict[str, dict[str, Any]] = {}
        self._lock = RLock()

    def add(self, code: str, **data: Any) -> None:
        with self._lock:
            self.vouchers[voucher_hash(code)] = deepcopy(data)

    def redeem(self, code: str, uid: str, profile: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            voucher = self.vouchers.get(voucher_hash(code))
            if voucher is None:
                raise VoucherError("invalid_voucher")
            redeemed_by = str(voucher.get("redeemed_by") or "")
            if redeemed_by and redeemed_by != uid:
                raise VoucherError("voucher_already_redeemed")
            now = datetime.now(UTC)
            if voucher.get("redemption_expires_at") and voucher["redemption_expires_at"] <= now:
                raise VoucherError("voucher_expired")
            if voucher.get("access_ends_at") and voucher["access_ends_at"] <= now:
                raise VoucherError("campaign_access_expired")
            voucher["redeemed_by"] = uid
            voucher["redeemed_at"] = now
            entitlement = {
                "user_id": uid,
                "tier": "student",
                "status": "active",
                "source": "sponsored_voucher",
                "campaign_id": voucher.get("campaign_id"),
                "sponsor": voucher.get("sponsor"),
                "funding_source": voucher.get("funding_source"),
                "sponsored_until": voucher.get("access_ends_at"),
                "updated_at": now,
            }
            self.entitlements[uid] = entitlement
            self.profiles[uid] = {**deepcopy(profile), "onboardingComplete": True}
            return deepcopy(entitlement)


voucher_store: VoucherStore = FirestoreVoucherStore()
