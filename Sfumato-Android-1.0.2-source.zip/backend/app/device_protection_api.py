from __future__ import annotations

import hashlib
import hmac
import secrets
from datetime import UTC, datetime, timedelta
from typing import Annotated, Any
from uuid import uuid4

from fastapi import APIRouter, Depends, Header, HTTPException, Response, status
from firebase_admin import firestore, messaging
from pydantic import BaseModel, Field

from app.billing_api import require_security_entitlement

router = APIRouter(prefix="/v1/device-protection", tags=["device-protection"])
COMMAND_LIFETIME = timedelta(minutes=15)
RECENT_AUTH_WINDOW = timedelta(minutes=5)


class RegisterDeviceRequest(BaseModel):
    device_id: str = Field(min_length=16, max_length=128, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=80)
    platform: str = Field(default="android", pattern="^android$")
    fcm_token: str = Field(min_length=20, max_length=4096)
    remote_lock_enabled: bool


class RegisteredDevice(BaseModel):
    id: str
    name: str
    platform: str
    remote_lock_enabled: bool
    last_seen_at: datetime
    this_device: bool = False


class RegistrationResponse(RegisteredDevice):
    device_secret: str


class LockRequest(BaseModel):
    reason: str = Field(default="Owner reported this phone lost or stolen", min_length=3, max_length=160)


class LockCommand(BaseModel):
    id: str
    device_id: str
    status: str
    reason: str
    created_at: datetime
    expires_at: datetime
    executed_at: datetime | None = None


def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims.get("sub") or "")


def _db():
    return firestore.client()


def _device_ref(uid: str, device_id: str):
    return _db().collection("users").document(uid).collection("protected_devices").document(device_id)


def _command_ref(uid: str, command_id: str):
    return _db().collection("users").document(uid).collection("device_lock_commands").document(command_id)


def _hash_secret(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _require_recent_auth(claims: dict[str, Any]) -> None:
    authenticated_at = datetime.fromtimestamp(int(claims.get("auth_time") or 0), tz=UTC)
    if datetime.now(UTC) - authenticated_at > RECENT_AUTH_WINDOW:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "recent_authentication_required", "message": "Sign in again before locking a device."},
        )


@router.post("/devices", response_model=RegistrationResponse)
def register_device(
    request: RegisterDeviceRequest,
    claims: Annotated[dict[str, Any], Depends(require_security_entitlement)],
) -> dict[str, Any]:
    uid = _uid(claims)
    now = datetime.now(UTC)
    secret = secrets.token_urlsafe(32)
    record = {
        "id": request.device_id,
        "user_id": uid,
        "name": request.name.strip(),
        "platform": request.platform,
        "fcm_token": request.fcm_token,
        "device_secret_hash": _hash_secret(secret),
        "remote_lock_enabled": request.remote_lock_enabled,
        "last_seen_at": now,
        "updated_at": now,
    }
    reference = _device_ref(uid, request.device_id)
    previous = reference.get()
    if previous.exists:
        old = previous.to_dict() or {}
        record["created_at"] = old.get("created_at", now)
    else:
        record["created_at"] = now
    reference.set(record)
    return {**record, "device_secret": secret, "this_device": True}


@router.get("/devices", response_model=list[RegisteredDevice])
def list_devices(
    claims: Annotated[dict[str, Any], Depends(require_security_entitlement)],
    x_higuru_device_id: Annotated[str | None, Header()] = None,
) -> list[dict[str, Any]]:
    snapshots = _db().collection("users").document(_uid(claims)).collection("protected_devices").stream()
    devices = []
    for snapshot in snapshots:
        item = snapshot.to_dict() or {}
        item.pop("fcm_token", None)
        item.pop("device_secret_hash", None)
        item["this_device"] = item.get("id") == x_higuru_device_id
        devices.append(item)
    return sorted(devices, key=lambda item: item.get("last_seen_at") or datetime.min.replace(tzinfo=UTC), reverse=True)


@router.delete("/devices/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_device(
    device_id: str,
    claims: Annotated[dict[str, Any], Depends(require_security_entitlement)],
) -> Response:
    _require_recent_auth(claims)
    uid = _uid(claims)
    reference = _device_ref(uid, device_id)
    if not reference.get().exists:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail={"code": "device_not_found"})
    reference.delete()
    commands = (
        _db().collection("users").document(uid).collection("device_lock_commands")
        .where("device_id", "==", device_id)
        .stream()
    )
    for command in commands:
        command.reference.delete()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/devices/{device_id}/lock", response_model=LockCommand)
def request_lock(
    device_id: str,
    request: LockRequest,
    claims: Annotated[dict[str, Any], Depends(require_security_entitlement)],
) -> dict[str, Any]:
    _require_recent_auth(claims)
    uid = _uid(claims)
    device = _device_ref(uid, device_id).get()
    if not device.exists:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail={"code": "device_not_found"})
    device_data = device.to_dict() or {}
    if not device_data.get("remote_lock_enabled"):
        raise HTTPException(status.HTTP_409_CONFLICT, detail={"code": "remote_lock_not_enabled"})

    now = datetime.now(UTC)
    command = {
        "id": str(uuid4()),
        "user_id": uid,
        "device_id": device_id,
        "status": "pending",
        "reason": request.reason.strip(),
        "created_at": now,
        "expires_at": now + COMMAND_LIFETIME,
        "executed_at": None,
    }
    _command_ref(uid, command["id"]).set(command)
    try:
        messaging.send(
            messaging.Message(
                token=str(device_data["fcm_token"]),
                data={
                    "type": "HIGURU_REMOTE_LOCK",
                    "command_id": command["id"],
                    "device_id": device_id,
                },
                android=messaging.AndroidConfig(priority="high", ttl=COMMAND_LIFETIME),
            )
        )
    except Exception:
        # The command remains pending for authenticated polling when the device reconnects.
        pass
    return command


def _authenticate_device(uid: str, device_id: str, secret: str) -> dict[str, Any]:
    snapshot = _device_ref(uid, device_id).get()
    if not snapshot.exists:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail={"code": "device_not_found"})
    device = snapshot.to_dict() or {}
    if not hmac.compare_digest(str(device.get("device_secret_hash") or ""), _hash_secret(secret)):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, detail={"code": "invalid_device_secret"})
    if not device.get("remote_lock_enabled"):
        raise HTTPException(status.HTTP_409_CONFLICT, detail={"code": "remote_lock_not_enabled"})
    return device


@router.get("/devices/{device_id}/commands/pending", response_model=list[LockCommand])
def pending_commands(
    device_id: str,
    claims: Annotated[dict[str, Any], Depends(require_security_entitlement)],
    x_higuru_device_secret: Annotated[str, Header()],
) -> list[dict[str, Any]]:
    uid = _uid(claims)
    _authenticate_device(uid, device_id, x_higuru_device_secret)
    now = datetime.now(UTC)
    snapshots = (
        _db().collection("users").document(uid).collection("device_lock_commands")
        .where("device_id", "==", device_id)
        .stream()
    )
    commands = []
    for snapshot in snapshots:
        item = snapshot.to_dict() or {}
        if item.get("status") != "pending":
            continue
        if item.get("expires_at") and item["expires_at"] > now:
            commands.append(item)
        else:
            snapshot.reference.set({"status": "expired", "updated_at": now}, merge=True)
    return sorted(commands, key=lambda item: item["created_at"])


@router.post("/devices/{device_id}/commands/{command_id}/executed", response_model=LockCommand)
def acknowledge_command(
    device_id: str,
    command_id: str,
    claims: Annotated[dict[str, Any], Depends(require_security_entitlement)],
    x_higuru_device_secret: Annotated[str, Header()],
) -> dict[str, Any]:
    uid = _uid(claims)
    _authenticate_device(uid, device_id, x_higuru_device_secret)
    reference = _command_ref(uid, command_id)
    snapshot = reference.get()
    command = snapshot.to_dict() if snapshot.exists else None
    if not command or command.get("device_id") != device_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail={"code": "command_not_found"})
    now = datetime.now(UTC)
    if command.get("expires_at") <= now:
        reference.set({"status": "expired", "updated_at": now}, merge=True)
        raise HTTPException(status.HTTP_410_GONE, detail={"code": "command_expired"})
    patch = {"status": "executed", "executed_at": now, "updated_at": now}
    reference.set(patch, merge=True)
    return {**command, **patch}
