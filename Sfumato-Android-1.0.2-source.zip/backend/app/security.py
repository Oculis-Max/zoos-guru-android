import json
import logging
from typing import Annotated, Any

import firebase_admin
from fastapi import Header, HTTPException, status
from firebase_admin import auth, credentials

from app.config import get_settings

logger = logging.getLogger(__name__)


def _initialize_firebase() -> None:
    try:
        firebase_admin.get_app()
        return
    except ValueError:
        pass

    settings = get_settings()
    options = (
        {"projectId": settings.firebase_project_id}
        if settings.firebase_project_id
        else None
    )
    credential = None
    if settings.firebase_service_account_json is not None:
        service_account = json.loads(
            settings.firebase_service_account_json.get_secret_value()
        )
        credential = credentials.Certificate(service_account)
    firebase_admin.initialize_app(credential=credential, options=options)


def verify_firebase_id_token(token: str) -> dict[str, Any]:
    """Verify a client ID token with Firebase Admin and return its claims."""
    return auth.verify_id_token(token, check_revoked=True)


async def require_firebase_user(
    authorization: Annotated[str | None, Header(alias="Authorization")] = None,
) -> dict[str, Any]:
    if authorization is None:
        raise _unauthorized()

    scheme, separator, token = authorization.partition(" ")
    if not separator or scheme.lower() != "bearer" or not token.strip():
        raise _unauthorized()

    try:
        _initialize_firebase()
    except (json.JSONDecodeError, ValueError, KeyError, TypeError) as exc:
        logger.error("Firebase Admin configuration rejected: %s", type(exc).__name__)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "code": "firebase_configuration_invalid",
                "message": "Firebase server credentials are invalid.",
            },
        ) from exc

    try:
        claims = verify_firebase_id_token(token.strip())
    except (
        ValueError,
        auth.InvalidIdTokenError,
        auth.ExpiredIdTokenError,
        auth.RevokedIdTokenError,
        auth.UserDisabledError,
    ) as exc:
        logger.warning("Firebase ID token rejected: %s", type(exc).__name__)
        raise _unauthorized() from exc
    except auth.CertificateFetchError as exc:
        logger.error("Firebase certificate fetch failed")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "code": "auth_unavailable",
                "message": "Authentication is temporarily unavailable.",
            },
        ) from exc

    if not claims.get("uid") and not claims.get("sub"):
        logger.warning("Firebase token is missing a user identifier")
        raise _unauthorized()
    return claims


def _unauthorized() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        headers={"WWW-Authenticate": "Bearer"},
        detail={
            "code": "unauthorized",
            "message": "A valid Firebase ID token is required.",
        },
    )
