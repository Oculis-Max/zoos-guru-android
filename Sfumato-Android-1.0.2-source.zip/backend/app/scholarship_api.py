from __future__ import annotations

from datetime import date
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field, HttpUrl

from app.billing_api import require_scholarship_entitlement
from app.learning_store import LearningStore, learning_store

router = APIRouter(prefix="/v1/scholarships", tags=["scholarships"])


class ScholarshipOpportunity(BaseModel):
    id: str
    name: str
    provider: str
    provider_type: str
    countries: list[str]
    levels: list[str]
    fields: list[str]
    deadline: date | None
    status: str
    official_url: HttpUrl
    eligibility_summary: str
    last_verified: date


OPPORTUNITIES = [
    ScholarshipOpportunity(
        id="nsfas-2026",
        name="NSFAS Funding",
        provider="National Student Financial Aid Scheme",
        provider_type="government",
        countries=["ZA"],
        levels=["undergraduate", "tvet"],
        fields=["all"],
        deadline=date(2026, 7, 17),
        status="closed",
        official_url="https://www.nsfas.org.za/",
        eligibility_summary="South African citizens studying or planning to study at a public university or TVET college; official income and eligibility rules apply.",
        last_verified=date(2026, 7, 29),
    ),
    ScholarshipOpportunity(
        id="funza-lushaka-2026",
        name="Funza Lushaka Bursary",
        provider="South African Department of Basic Education",
        provider_type="government",
        countries=["ZA"],
        levels=["undergraduate", "postgraduate_certificate"],
        fields=["education", "teaching"],
        deadline=date(2026, 1, 24),
        status="closed",
        official_url="https://www.education.gov.za/Programmes/FunzaLushaka.aspx",
        eligibility_summary="Teaching qualifications in national priority areas; age, admission, service and annual programme rules apply.",
        last_verified=date(2026, 7, 29),
    ),
    ScholarshipOpportunity(
        id="mandela-rhodes-2028",
        name="Mandela Rhodes Scholarship 2028",
        provider="The Mandela Rhodes Foundation",
        provider_type="foundation",
        countries=["AFRICA"],
        levels=["honours", "masters"],
        fields=["all_except_mba"],
        deadline=date(2027, 4, 14),
        status="opens_2027_03_09",
        official_url="https://www.mandelarhodes.org/scholarship/apply/",
        eligibility_summary="African citizens aged 19–29 pursuing eligible postgraduate study in South Africa; academic excellence and leadership criteria apply.",
        last_verified=date(2026, 7, 29),
    ),
    ScholarshipOpportunity(
        id="allan-gray-high-school-2026",
        name="Allan Gray High School Scholarship Opportunity",
        provider="Allan Gray Orbis Foundation",
        provider_type="foundation",
        countries=["ZA"],
        levels=["high_school"],
        fields=["all"],
        deadline=date(2026, 9, 15),
        status="open",
        official_url="https://allangrayorbis.org/",
        eligibility_summary="Official grade, age, citizenship and entrepreneurial-potential requirements apply.",
        last_verified=date(2026, 7, 29),
    ),
    ScholarshipOpportunity(
        id="allan-gray-fellowship-2026",
        name="Allan Gray Fellowship Programme",
        provider="Allan Gray Orbis Foundation",
        provider_type="foundation",
        countries=["ZA"],
        levels=["undergraduate"],
        fields=["commerce", "science", "engineering", "law", "humanities", "arts", "health_science"],
        deadline=date(2026, 4, 30),
        status="closed",
        official_url="https://allangrayorbis.org/programmes/fellowship/",
        eligibility_summary="Grade 12 South African applicants meeting official academic, age, university and field requirements.",
        last_verified=date(2026, 7, 29),
    ),
]


class ReadinessRequest(BaseModel):
    grades: int = Field(ge=0, le=100)
    study_consistency: int = Field(ge=0, le=100)
    leadership: int = Field(ge=0, le=100)
    community_service: int = Field(ge=0, le=100)
    digital_skills: int = Field(ge=0, le=100)
    certificates: int = Field(ge=0, le=100)
    career_goal: int = Field(ge=0, le=100)
    personal_statement: int = Field(ge=0, le=100)


class ReadinessResponse(BaseModel):
    score: int
    label: str
    improvements: list[str]
    disclaimer: str = "This readiness estimate is guidance, not a scholarship guarantee."


class ApplicationRequest(BaseModel):
    scholarship_id: str = Field(min_length=2, max_length=120)
    status: str = Field(default="saved", pattern="^(saved|preparing|submitted|interview|awarded|unsuccessful)$")
    next_step: str = Field(default="", max_length=500)
    deadline: date | None = None


class ApplicationResponse(ApplicationRequest):
    id: str
    user_id: str


def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims["sub"])


@router.get("", response_model=list[ScholarshipOpportunity])
def finder(
    _claims: Annotated[dict[str, Any], Depends(require_scholarship_entitlement)],
    country: Annotated[str | None, Query(max_length=20)] = None,
    level: Annotated[str | None, Query(max_length=50)] = None,
    field: Annotated[str | None, Query(max_length=80)] = None,
    include_closed: bool = False,
) -> list[ScholarshipOpportunity]:
    today = date.today()
    results = []
    for item in OPPORTUNITIES:
        if not include_closed and (item.status == "closed" or (item.deadline and item.deadline < today)):
            continue
        if country and country.upper() not in item.countries and "AFRICA" not in item.countries:
            continue
        if level and level.lower() not in item.levels:
            continue
        if field and field.lower() not in item.fields and "all" not in item.fields:
            continue
        results.append(item)
    return results


@router.post("/readiness", response_model=ReadinessResponse)
def readiness(
    request: ReadinessRequest,
    _claims: Annotated[dict[str, Any], Depends(require_scholarship_entitlement)],
) -> ReadinessResponse:
    values = {
        "Grades": (request.grades, 0.25),
        "Study consistency": (request.study_consistency, 0.15),
        "Leadership": (request.leadership, 0.15),
        "Community service": (request.community_service, 0.10),
        "Digital skills": (request.digital_skills, 0.10),
        "Certificates": (request.certificates, 0.05),
        "Career goal": (request.career_goal, 0.10),
        "Personal statement": (request.personal_statement, 0.10),
    }
    score = round(sum(value * weight for value, weight in values.values()))
    improvements = [
        name for name, (value, _weight) in sorted(values.items(), key=lambda item: item[1][0])[:3]
        if value < 80
    ]
    label = "Strong readiness" if score >= 80 else "Developing readiness" if score >= 55 else "Build your profile"
    return ReadinessResponse(score=score, label=label, improvements=improvements)


@router.get("/applications", response_model=list[dict[str, Any]])
def list_applications(
    claims: Annotated[dict[str, Any], Depends(require_scholarship_entitlement)],
    store: Annotated[LearningStore, Depends(lambda: learning_store)],
) -> list[dict[str, Any]]:
    return store.list(_uid(claims), "scholarship_applications")


@router.post("/applications", response_model=dict[str, Any])
def save_application(
    request: ApplicationRequest,
    claims: Annotated[dict[str, Any], Depends(require_scholarship_entitlement)],
    store: Annotated[LearningStore, Depends(lambda: learning_store)],
) -> dict[str, Any]:
    official_ids = {item.id for item in OPPORTUNITIES}
    if request.scholarship_id not in official_ids:
        from fastapi import HTTPException
        raise HTTPException(422, detail={"code": "unverified_scholarship_rejected"})
    opportunity = next(item for item in OPPORTUNITIES if item.id == request.scholarship_id)
    payload = {
        **request.model_dump(mode="json"),
        "scholarship_name": opportunity.name,
        "provider": opportunity.provider,
        "official_url": str(opportunity.official_url),
    }
    uid = _uid(claims)
    existing = next(
        (
            item
            for item in store.list(uid, "scholarship_applications")
            if item.get("scholarship_id") == request.scholarship_id
        ),
        None,
    )
    if existing is not None:
        record = store.update(
            uid,
            "scholarship_applications",
            str(existing["id"]),
            payload,
        )
        store.audit(
            uid,
            "scholarship.application.updated",
            {"id": record["id"], "scholarship_id": request.scholarship_id},
        )
        return record
    record = store.create(
        uid,
        "scholarship_applications",
        payload,
    )
    store.audit(
        uid,
        "scholarship.application.saved",
        {"id": record["id"], "scholarship_id": request.scholarship_id},
    )
    return record
