from uuid import UUID

from fastapi import APIRouter, HTTPException, status

from app.accounts import GuestIdentity, StudentProfile, account_store
from app.analytics import AnalyticsEvent, analytics_sink
from app.entitlements import Entitlement, free_entitlement
from app.scholarships import (
    ApplicationRecord,
    MatchScore,
    Scholarship,
    ScholarshipSearch,
    calculate_match,
    scholarship_store,
)

router = APIRouter(prefix="/v1", tags=["student-platform"])


@router.post("/identities/guest", response_model=GuestIdentity, status_code=201)
def create_guest() -> GuestIdentity:
    return account_store.create_guest()


@router.put("/profiles/{identity_id}", response_model=StudentProfile)
def save_profile(identity_id: UUID, profile: StudentProfile) -> StudentProfile:
    if identity_id != profile.identity_id:
        raise HTTPException(status_code=400, detail={"code": "identity_mismatch"})
    try:
        return account_store.save_profile(profile)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail={"code": "identity_not_found"}) from exc


@router.get("/profiles/{identity_id}", response_model=StudentProfile)
def get_profile(identity_id: UUID) -> StudentProfile:
    profile = account_store.get_profile(identity_id)
    if profile is None:
        raise HTTPException(status_code=404, detail={"code": "profile_not_found"})
    return profile


@router.post("/scholarships/search", response_model=list[Scholarship])
def search_scholarships(filters: ScholarshipSearch) -> list[Scholarship]:
    return scholarship_store.search(filters)


@router.get("/scholarships/{scholarship_id}/match/{identity_id}", response_model=MatchScore)
def scholarship_match(scholarship_id: UUID, identity_id: UUID) -> MatchScore:
    scholarship = scholarship_store.scholarships.get(scholarship_id)
    profile = account_store.get_profile(identity_id)
    if scholarship is None or profile is None:
        raise HTTPException(status_code=404, detail={"code": "match_input_not_found"})
    return calculate_match(profile, scholarship)


@router.put("/applications", response_model=ApplicationRecord)
def save_application(record: ApplicationRecord) -> ApplicationRecord:
    if account_store.get_profile(record.identity_id) is None:
        raise HTTPException(status_code=404, detail={"code": "profile_not_found"})
    try:
        return scholarship_store.save_application(record)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail={"code": "scholarship_not_found"}) from exc


@router.post("/analytics/events", status_code=status.HTTP_202_ACCEPTED)
def record_analytics(event: AnalyticsEvent) -> dict[str, bool]:
    analytics_sink.record(event)
    return {"accepted": True}


@router.get("/entitlements/{identity_id}", response_model=Entitlement)
def get_entitlement(identity_id: UUID) -> Entitlement:
    return free_entitlement(identity_id)
