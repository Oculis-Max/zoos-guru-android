from datetime import UTC, datetime
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, status

from app.advanced_assistant_api import router as advanced_assistant_router
from app.billing_api import enforce_chat_access, get_billing_store, router as billing_router
from app.billing_catalog import SubscriptionTier
from app.billing_store import BillingStore
from app.business_api import router as business_router
from app.coding_agent_api import router as coding_agent_router
from app.coding_api import router as coding_router
from app.github_oauth_fix_api import router as github_oauth_fix_router
from app.config import get_settings
from app.design_api import router as design_router
from app.device_protection_api import router as device_protection_router
from app.education_api import router as education_router
from app.engineering_api import router as engineering_router
from app.enoch_api import router as enoch_router
from app.journalist_api import router as journalist_router
from app.learning_ai_api import router as learning_ai_router
from app.learning_api import router as learning_router
from app.models import ChatMessage, ChatRequest, ChatResponse
from app.product_api import router as product_router
from app.progress_api import router as progress_router
from app.provider import (
    AiProvider,
    ProviderError,
    ProviderRateLimitError,
    ProviderUnavailableError,
    build_provider,
)
from app.scholarship_api import router as scholarship_router

app = FastAPI(
    title="Sfumato API",
    description="Secure backend for the Sfumato Android application.",
    version="0.8.1",
)

for router in [
    advanced_assistant_router,
    product_router,
    learning_router,
    learning_ai_router,
    billing_router,
    business_router,
    github_oauth_fix_router,
    coding_router,
    coding_agent_router,
    design_router,
    device_protection_router,
    engineering_router,
    enoch_router,
    education_router,
    scholarship_router,
    progress_router,
    journalist_router,
]:
    app.include_router(router)


@app.get("/health", tags=["system"])
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "higuru-backend"}


def get_provider() -> AiProvider:
    return build_provider(get_settings())


def _tier(record: dict | None) -> SubscriptionTier:
    if not record or record.get("status") != "active":
        return SubscriptionTier.FREE
    try:
        return SubscriptionTier(record.get("tier", "free"))
    except ValueError:
        return SubscriptionTier.FREE


def _daily_limit(tier: SubscriptionTier) -> int:
    settings = get_settings()
    return {
        SubscriptionTier.FREE: settings.ai_daily_token_limit_free,
        SubscriptionTier.STUDENT: settings.ai_daily_token_limit_student,
        SubscriptionTier.DEVELOPER: settings.ai_daily_token_limit_developer,
        SubscriptionTier.BUSINESS: settings.ai_daily_token_limit_business,
    }.get(tier, settings.ai_daily_token_limit_free)


@app.post("/chat", response_model=ChatResponse, tags=["chat"])
async def chat(
    request: ChatRequest,
    claims: Annotated[dict, Depends(enforce_chat_access)],
    provider: AiProvider = Depends(get_provider),
    store: BillingStore = Depends(get_billing_store),
) -> ChatResponse:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    day = datetime.now(UTC).date().isoformat()
    tier = _tier(store.get(uid))
    limit = _daily_limit(tier)
    used = store.get_daily_tokens(uid, day)

    if used >= limit:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "code": "daily_token_limit",
                "message": "Your daily AI allowance has been reached. Please try again tomorrow.",
                "limit": limit,
                "used": used,
            },
        )

    settings = get_settings()
    input_chars = sum(len(message.content) for message in request.messages)
    if input_chars > settings.ai_max_input_characters:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail={
                "code": "ai_input_too_large",
                "message": "This conversation is too large. Start a new chat or shorten the attached material.",
            },
        )

    try:
        content, usage = await provider.complete(request.messages)
    except ProviderRateLimitError as exc:
        raise HTTPException(
            status_code=429,
            detail={"code": "rate_limited", "message": "Please try again later."},
        ) from exc
    except ProviderUnavailableError as exc:
        raise HTTPException(
            status_code=503,
            detail={
                "code": "provider_unavailable",
                "message": "AI is temporarily unavailable.",
            },
        ) from exc
    except ProviderError as exc:
        raise HTTPException(
            status_code=502,
            detail={
                "code": "provider_error",
                "message": "AI response could not be processed.",
            },
        ) from exc

    actual = max(0, int(usage.total_tokens or (usage.prompt_tokens + usage.completion_tokens)))
    if actual:
        store.record_daily_tokens(uid, day, actual)

    return ChatResponse(
        message=ChatMessage(role="assistant", content=content),
        usage=usage,
    )
