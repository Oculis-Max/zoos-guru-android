from datetime import UTC, date, datetime
from enum import StrEnum
from urllib.parse import urlparse
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

from app.accounts import StudentProfile


class ApplicationStatus(StrEnum):
    DISCOVERED = "discovered"
    ELIGIBLE = "eligible"
    PREPARING = "preparing"
    SUBMITTED = "submitted"
    RESULT = "result"


class VerificationStatus(StrEnum):
    VERIFIED = "verified"
    NEEDS_REVIEW = "needs_review"


OFFICIAL_SOURCE_DOMAINS = {
    "www.nsfas.org.za",
    "nsfas.org.za",
    "www.funzalushaka.doe.gov.za",
    "funzalushaka.doe.gov.za",
    "www.nrf.ac.za",
    "nrf.ac.za",
    "www.isfap.org.za",
    "isfap.org.za",
    "applyonline.isfap.org.za",
}


class Scholarship(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    title: str
    provider: str
    country_codes: list[str]
    citizenship_country_codes: list[str] = Field(default_factory=list)
    school_levels: list[str]
    subjects: list[str] = Field(default_factory=list)
    deadline: date
    financial_need_supported: bool = False
    required_documents: list[str] = Field(default_factory=list)
    source_url: str
    application_url: str | None = None
    verification_status: VerificationStatus = VerificationStatus.NEEDS_REVIEW
    source_verified_at: datetime | None = None

    @property
    def is_expired(self) -> bool:
        return self.deadline < date.today()


class MatchFactor(BaseModel):
    key: str
    label: str
    weight: int
    earned: int
    explanation: str


class MatchScore(BaseModel):
    score: int = Field(ge=0, le=100)
    factors: list[MatchFactor]
    disclaimer: str = "This score estimates fit only and never guarantees acceptance."


class ScholarshipSearch(BaseModel):
    country_code: str | None = None
    school_level: str | None = None
    subject: str | None = None
    closing_before: date | None = None
    closing_after: date | None = None
    include_expired: bool = False
    verified_only: bool = True


class ApplicationRecord(BaseModel):
    identity_id: UUID
    scholarship_id: UUID
    status: ApplicationStatus = ApplicationStatus.DISCOVERED
    bookmarked: bool = False


def _normalise(values: list[str]) -> set[str]:
    return {value.strip().lower() for value in values if value.strip()}


def calculate_match(profile: StudentProfile, scholarship: Scholarship) -> MatchScore:
    country_ok = profile.country_code.upper() in {c.upper() for c in scholarship.country_codes}
    citizenships = {c.upper() for c in profile.citizenship_country_codes}
    citizenship_ok = not scholarship.citizenship_country_codes or bool(
        citizenships & {c.upper() for c in scholarship.citizenship_country_codes}
    )
    level_ok = profile.school_level.value in scholarship.school_levels
    subject_overlap = _normalise(profile.subjects) & _normalise(scholarship.subjects)
    interest_overlap = _normalise(profile.career_interests) & _normalise(scholarship.subjects)
    days_left = (scholarship.deadline - date.today()).days
    factors = [
        MatchFactor(key="academic", label="Academic eligibility", weight=30, earned=30 if level_ok else 0, explanation="Study level matches." if level_ok else "Study level does not match."),
        MatchFactor(key="residency", label="Country and citizenship eligibility", weight=20, earned=20 if country_ok and citizenship_ok else 0, explanation="Country rules appear to match." if country_ok and citizenship_ok else "Country or citizenship rules need review."),
        MatchFactor(key="subject", label="Subject alignment", weight=20, earned=20 if subject_overlap else 10 if interest_overlap else 0, explanation="Subjects align." if subject_overlap else "Career interests partially align." if interest_overlap else "No subject alignment found."),
        MatchFactor(key="financial_need", label="Financial-need alignment", weight=15, earned=15 if scholarship.financial_need_supported else 5, explanation="Financial-need support is listed." if scholarship.financial_need_supported else "Financial-need support is not specified."),
        MatchFactor(key="readiness", label="Profile readiness", weight=10, earned=10 if profile.profile_complete else 0, explanation="Student profile is complete." if profile.profile_complete else "Complete the student profile."),
        MatchFactor(key="deadline", label="Deadline feasibility", weight=5, earned=5 if days_left >= 30 else 3 if days_left >= 7 else 0, explanation=f"{max(days_left, 0)} days remain."),
    ]
    return MatchScore(score=sum(factor.earned for factor in factors), factors=factors)


class ScholarshipStore:
    def __init__(self) -> None:
        self.scholarships: dict[UUID, Scholarship] = {}
        self.applications: dict[tuple[UUID, UUID], ApplicationRecord] = {}

    def search(self, filters: ScholarshipSearch) -> list[Scholarship]:
        results = list(self.scholarships.values())
        if not filters.include_expired:
            results = [s for s in results if not s.is_expired]
        if filters.verified_only:
            results = [
                s
                for s in results
                if s.verification_status is VerificationStatus.VERIFIED
                and s.source_verified_at is not None
            ]
        if filters.country_code:
            results = [s for s in results if filters.country_code.upper() in {c.upper() for c in s.country_codes}]
        if filters.school_level:
            results = [s for s in results if filters.school_level in s.school_levels]
        if filters.subject:
            subject = filters.subject.lower()
            results = [s for s in results if subject in _normalise(s.subjects)]
        if filters.closing_before:
            results = [s for s in results if s.deadline <= filters.closing_before]
        if filters.closing_after:
            results = [s for s in results if s.deadline >= filters.closing_after]
        return sorted(results, key=lambda item: item.deadline)

    def upsert_verified(self, scholarship: Scholarship) -> Scholarship:
        hostname = (urlparse(scholarship.source_url).hostname or "").lower()
        if hostname not in OFFICIAL_SOURCE_DOMAINS:
            raise ValueError("Scholarship source must use an approved official domain")
        if scholarship.source_verified_at is None:
            raise ValueError("Verified scholarships require source_verified_at")
        if scholarship.source_verified_at > datetime.now(UTC):
            raise ValueError("source_verified_at cannot be in the future")
        verified = scholarship.model_copy(
            update={"verification_status": VerificationStatus.VERIFIED}
        )
        self.scholarships[verified.id] = verified
        return verified

    def save_application(self, record: ApplicationRecord) -> ApplicationRecord:
        if record.scholarship_id not in self.scholarships:
            raise KeyError("scholarship_not_found")
        self.applications[(record.identity_id, record.scholarship_id)] = record
        return record


scholarship_store = ScholarshipStore()
