from typing import Annotated, Any

from fastapi import APIRouter, Depends

from app.billing_api import require_enoch_entitlement

router = APIRouter(prefix="/v1/enoch", tags=["enoch"])


@router.post("/session")
def authorize_enoch_session(
    claims: Annotated[dict[str, Any], Depends(require_enoch_entitlement)],
) -> dict[str, int | bool]:
    return {"authorized": True, "max_seconds": 360}
