from __future__ import annotations

import base64
from email.message import EmailMessage
from email.utils import parseaddr
from typing import Any

import httpx

from app.advanced_assistant_store import AssistantStore, assistant_store
from app.config import Settings
from app.google_oauth import GMAIL_READONLY_SCOPE, GoogleOAuthService, OAuthConfigurationError


class OfficialOutboundConnector:
    """Routes approved actions to official provider APIs.

    Credentials stay on the backend. This class never drafts, approves, or changes
    an action; it only dispatches an action that the API already verified.
    """

    def __init__(
        self,
        settings: Settings,
        client: httpx.AsyncClient | None = None,
        store: AssistantStore = assistant_store,
    ) -> None:
        self.settings = settings
        self.client = client or httpx.AsyncClient(timeout=settings.request_timeout_seconds)
        self.store = store
        try:
            self.google_oauth: GoogleOAuthService | None = GoogleOAuthService(settings, store, self.client)
        except OAuthConfigurationError:
            self.google_oauth = None

    def connection_status(self, uid: str | None = None) -> list[dict[str, str | bool]]:
        user_gmail = bool(uid and any(
            item.get("provider") == "google"
            and item.get("status") == "connected"
            and GMAIL_READONLY_SCOPE in str(item.get("scope") or "")
            for item in self.store.list_for_user("connections", uid)
        ))
        return [
            self._status("email", user_gmail or bool(self.settings.gmail_access_token), "Google OAuth access required"),
            self._status(
                "sms",
                bool(self.settings.twilio_account_sid and self.settings.twilio_auth_token and self.settings.twilio_from_number),
                "Twilio sender credentials required",
            ),
            self._status(
                "whatsapp",
                bool(self.settings.meta_access_token and self.settings.whatsapp_phone_number_id),
                "WhatsApp Business Cloud credentials required",
            ),
            self._status(
                "facebook",
                bool(self.settings.meta_access_token and self.settings.facebook_page_id),
                "Facebook Page credentials required",
            ),
            {
                "channel": "instagram",
                "connected": False,
                "detail": "Media upload and Instagram Business account connection required",
            },
        ]

    @staticmethod
    def _status(channel: str, connected: bool, missing: str) -> dict[str, str | bool]:
        return {"channel": channel, "connected": connected, "detail": "Connected" if connected else missing}

    async def send(self, action: dict[str, Any]) -> str:
        channel = str(action["channel"])
        if channel == "email":
            return await self._gmail(action)
        if channel == "sms":
            return await self._twilio_sms(action)
        if channel == "whatsapp":
            return await self._whatsapp(action)
        if channel == "facebook":
            return await self._facebook(action)
        if channel == "instagram":
            raise RuntimeError("instagram_media_required")
        raise RuntimeError("unsupported_channel")

    async def read_inbox(self, uid: str, max_results: int = 15) -> list[dict[str, str]]:
        if self.google_oauth is None:
            raise RuntimeError("email_connection_required")
        token = await self.google_oauth.access_token(uid)
        if not token:
            raise RuntimeError("email_connection_required")
        response = await self.client.get(
            "https://gmail.googleapis.com/gmail/v1/users/me/messages",
            headers={"Authorization": f"Bearer {token}"},
            params={
                "q": "is:unread newer_than:14d -category:promotions",
                "maxResults": max(1, min(max_results, 30)),
            },
        )
        if response.is_error:
            raise RuntimeError("email_inbox_read_failed")
        messages = response.json().get("messages") or []
        result: list[dict[str, str]] = []
        for item in messages:
            message_id = str(item.get("id") or "")
            if not message_id:
                continue
            detail = await self.client.get(
                f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{message_id}",
                headers={"Authorization": f"Bearer {token}"},
                params={
                    "format": "metadata",
                    "metadataHeaders": ["From", "Subject", "Date"],
                },
            )
            if detail.is_error:
                continue
            payload = detail.json()
            headers = {
                str(header.get("name") or "").lower(): str(header.get("value") or "")
                for header in payload.get("payload", {}).get("headers", [])
            }
            sender_name, sender_email = parseaddr(headers.get("from", ""))
            result.append({
                "message_id": message_id,
                "thread_id": str(payload.get("threadId") or ""),
                "sender": sender_name or sender_email or headers.get("from", "Unknown sender"),
                "sender_email": sender_email,
                "subject": headers.get("subject", "(No subject)"),
                "received_at": headers.get("date", ""),
                "snippet": str(payload.get("snippet") or "").strip(),
            })
        return result

    async def _gmail(self, action: dict[str, Any]) -> str:
        token: str | None = None
        if self.google_oauth is not None and action.get("owner_uid"):
            token = await self.google_oauth.access_token(str(action["owner_uid"]))
        if not token:
            token = self._secret(self.settings.gmail_access_token, "email_connection_required")
        recipient = self._required(action.get("recipient"), "email_recipient_required")
        message = EmailMessage()
        message["To"] = recipient
        message["Subject"] = str(action.get("subject") or "Sfumato message")
        message.set_content(str(action["content"]))
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode().rstrip("=")
        response = await self.client.post(
            "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
            headers={"Authorization": f"Bearer {token}"},
            json={"raw": raw},
        )
        return self._provider_id(response, "email_dispatch_failed")

    async def _twilio_sms(self, action: dict[str, Any]) -> str:
        sid = self._required(self.settings.twilio_account_sid, "sms_connection_required")
        token = self._secret(self.settings.twilio_auth_token, "sms_connection_required")
        sender = self._required(self.settings.twilio_from_number, "sms_sender_required")
        recipient = self._required(action.get("recipient"), "sms_recipient_required")
        response = await self.client.post(
            f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
            auth=(sid, token),
            data={"To": recipient, "From": sender, "Body": str(action["content"])},
        )
        return self._provider_id(response, "sms_dispatch_failed", "sid")

    async def _whatsapp(self, action: dict[str, Any]) -> str:
        token = self._secret(self.settings.meta_access_token, "whatsapp_connection_required")
        phone_id = self._required(self.settings.whatsapp_phone_number_id, "whatsapp_connection_required")
        recipient = self._required(action.get("recipient"), "whatsapp_recipient_required")
        response = await self.client.post(
            f"https://graph.facebook.com/{self.settings.meta_graph_version}/{phone_id}/messages",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "messaging_product": "whatsapp",
                "to": recipient,
                "type": "text",
                "text": {"preview_url": False, "body": str(action["content"])},
            },
        )
        response_id = self._provider_id(response, "whatsapp_dispatch_failed", "messages")
        return response_id

    async def _facebook(self, action: dict[str, Any]) -> str:
        token = self._secret(self.settings.meta_access_token, "facebook_connection_required")
        page_id = self._required(self.settings.facebook_page_id, "facebook_connection_required")
        response = await self.client.post(
            f"https://graph.facebook.com/{self.settings.meta_graph_version}/{page_id}/feed",
            data={"message": str(action["content"]), "access_token": token},
        )
        return self._provider_id(response, "facebook_dispatch_failed")

    @staticmethod
    def _required(value: Any, code: str) -> str:
        result = str(value or "").strip()
        if not result:
            raise RuntimeError(code)
        return result

    @staticmethod
    def _secret(value: Any, code: str) -> str:
        if value is None:
            raise RuntimeError(code)
        return OfficialOutboundConnector._required(value.get_secret_value(), code)

    @staticmethod
    def _provider_id(response: httpx.Response, code: str, field: str = "id") -> str:
        if response.is_error:
            raise RuntimeError(code)
        payload = response.json()
        value: Any = payload.get(field)
        if field == "messages" and isinstance(value, list) and value:
            value = value[0].get("id")
        if not value:
            raise RuntimeError(code)
        return str(value)
