from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from threading import RLock
from typing import Any, Protocol
from uuid import uuid4

import firebase_admin
from firebase_admin import firestore


class EducationStore(Protocol):
    def create(self, collection: str, data: dict[str, Any]) -> dict[str, Any]: ...
    def get(self, collection: str, record_id: str) -> dict[str, Any] | None: ...
    def list_where(self, collection: str, field: str, value: str) -> list[dict[str, Any]]: ...
    def list_all(self, collection: str) -> list[dict[str, Any]]: ...
    def update(self, collection: str, record_id: str, data: dict[str, Any]) -> dict[str, Any]: ...


class FirestoreEducationStore:
    prefix = "education_"

    def _client(self):
        firebase_admin.get_app()
        return firestore.client()

    def _collection(self, name: str):
        return self._client().collection(self.prefix + name)

    def create(self, collection: str, data: dict[str, Any]) -> dict[str, Any]:
        record = {**data, "id": str(uuid4()), "created_at": datetime.now(UTC)}
        self._collection(collection).document(record["id"]).set(record)
        return record

    def get(self, collection: str, record_id: str) -> dict[str, Any] | None:
        snapshot = self._collection(collection).document(record_id).get()
        return snapshot.to_dict() if snapshot.exists else None

    def list_where(self, collection: str, field: str, value: str) -> list[dict[str, Any]]:
        query = self._collection(collection).where(field, "==", value)
        return sorted(
            (item.to_dict() for item in query.stream()),
            key=lambda item: item.get("created_at", datetime.min.replace(tzinfo=UTC)),
            reverse=True,
        )

    def list_all(self, collection: str) -> list[dict[str, Any]]:
        return [item.to_dict() for item in self._collection(collection).stream()]

    def update(self, collection: str, record_id: str, data: dict[str, Any]) -> dict[str, Any]:
        reference = self._collection(collection).document(record_id)
        snapshot = reference.get()
        if not snapshot.exists:
            raise KeyError(record_id)
        patch = {**data, "updated_at": datetime.now(UTC)}
        reference.set(patch, merge=True)
        return {**(snapshot.to_dict() or {}), **patch}


class InMemoryEducationStore:
    def __init__(self) -> None:
        self.records: dict[str, dict[str, dict[str, Any]]] = {}
        self._lock = RLock()

    def create(self, collection: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            record = {**deepcopy(data), "id": str(uuid4()), "created_at": datetime.now(UTC)}
            self.records.setdefault(collection, {})[record["id"]] = record
            return deepcopy(record)

    def get(self, collection: str, record_id: str) -> dict[str, Any] | None:
        with self._lock:
            value = self.records.get(collection, {}).get(record_id)
            return deepcopy(value) if value else None

    def list_where(self, collection: str, field: str, value: str) -> list[dict[str, Any]]:
        with self._lock:
            return [
                deepcopy(item)
                for item in reversed(list(self.records.get(collection, {}).values()))
                if item.get(field) == value
            ]

    def list_all(self, collection: str) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(list(reversed(list(self.records.get(collection, {}).values()))))

    def update(self, collection: str, record_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            current = self.records.get(collection, {}).get(record_id)
            if current is None:
                raise KeyError(record_id)
            updated = {**current, **deepcopy(data), "updated_at": datetime.now(UTC)}
            self.records[collection][record_id] = updated
            return deepcopy(updated)


education_store: EducationStore = FirestoreEducationStore()
