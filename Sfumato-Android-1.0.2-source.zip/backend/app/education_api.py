from __future__ import annotations

import secrets
from datetime import datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.config import Settings, get_settings
from app.education_store import EducationStore, education_store
from app.models import ChatMessage
from app.provider import ProviderError, build_provider
from app.billing_api import require_student_entitlement

router = APIRouter(prefix="/v1/education", tags=["education"])


class ClassCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    institution: str = Field(min_length=2, max_length=160)
    level: str = Field(min_length=1, max_length=80)
    educator_role: Literal["teacher", "professor"]


class ClassResponse(ClassCreate):
    id: str
    join_code: str
    owner_uid: str
    educator_email: str
    created_at: datetime


class JoinRequest(BaseModel):
    join_code: str = Field(min_length=6, max_length=12)


class MemberResponse(BaseModel):
    id: str
    class_id: str
    student_uid: str
    student_email: str
    display_name: str
    created_at: datetime


class AssignmentCreate(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    instructions: str = Field(min_length=3, max_length=4000)
    due_at: datetime | None = None
    max_score: int = Field(default=100, ge=1, le=1000)


class AssignmentResponse(AssignmentCreate):
    id: str
    class_id: str
    owner_uid: str
    created_at: datetime


class SubmissionCreate(BaseModel):
    content: str = Field(min_length=1, max_length=12000)


class SubmissionResponse(BaseModel):
    id: str
    assignment_id: str
    class_id: str
    student_uid: str
    student_email: str
    content: str
    status: str
    score: int | None = None
    feedback: str | None = None
    ai_suggestion: str | None = None
    created_at: datetime


class MarkRequest(BaseModel):
    score: int = Field(ge=0, le=1000)
    feedback: str = Field(min_length=2, max_length=2000)


class AnnouncementCreate(BaseModel):
    message: str = Field(min_length=2, max_length=2000)


class AnnouncementResponse(BaseModel):
    id: str
    class_id: str
    author_email: str
    message: str
    created_at: datetime


def get_education_store() -> EducationStore:
    return education_store


def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims.get("sub") or "")


def _email(claims: dict[str, Any]) -> str:
    return str(claims.get("email") or "").strip().lower()


def _name(claims: dict[str, Any]) -> str:
    return str(claims.get("name") or claims.get("email") or "Learner")


def _class_or_404(class_id: str, store: EducationStore) -> dict[str, Any]:
    value = store.get("classes", class_id)
    if value is None:
        raise HTTPException(404, detail={"code": "class_not_found"})
    return value


def _require_owner(class_id: str, claims: dict[str, Any], store: EducationStore) -> dict[str, Any]:
    value = _class_or_404(class_id, store)
    if value.get("owner_uid") != _uid(claims):
        raise HTTPException(403, detail={"code": "educator_owner_required"})
    return value


def _membership(class_id: str, claims: dict[str, Any], store: EducationStore) -> dict[str, Any] | None:
    return next(
        (
            item for item in store.list_where("members", "class_id", class_id)
            if item.get("student_uid") == _uid(claims)
        ),
        None,
    )


def _require_access(class_id: str, claims: dict[str, Any], store: EducationStore) -> dict[str, Any]:
    value = _class_or_404(class_id, store)
    if value.get("owner_uid") == _uid(claims) or _membership(class_id, claims, store):
        return value
    raise HTTPException(403, detail={"code": "class_access_denied"})


@router.post("/classes", response_model=ClassResponse)
def create_class(
    request: ClassCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    return store.create("classes", {
        **request.model_dump(),
        "owner_uid": _uid(claims),
        "educator_email": _email(claims),
        "join_code": secrets.token_hex(3).upper(),
    })


@router.get("/classes", response_model=list[ClassResponse])
def list_classes(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> list[dict[str, Any]]:
    owned = store.list_where("classes", "owner_uid", _uid(claims))
    memberships = store.list_where("members", "student_uid", _uid(claims))
    joined = [
        item for membership in memberships
        if (item := store.get("classes", str(membership["class_id"]))) is not None
    ]
    seen: set[str] = set()
    return [item for item in owned + joined if not (item["id"] in seen or seen.add(item["id"]))]


@router.post("/classes/join", response_model=MemberResponse)
def join_class(
    request: JoinRequest,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    classroom = next(
        (item for item in store.list_all("classes") if item.get("join_code") == request.join_code.upper()),
        None,
    )
    if classroom is None:
        raise HTTPException(404, detail={"code": "join_code_not_found"})
    existing = _membership(str(classroom["id"]), claims, store)
    if existing:
        return existing
    return store.create("members", {
        "class_id": classroom["id"],
        "student_uid": _uid(claims),
        "student_email": _email(claims),
        "display_name": _name(claims),
    })


@router.get("/classes/{class_id}/members", response_model=list[MemberResponse])
def class_members(
    class_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> list[dict[str, Any]]:
    _require_owner(class_id, claims, store)
    return store.list_where("members", "class_id", class_id)


@router.post("/classes/{class_id}/assignments", response_model=AssignmentResponse)
def create_assignment(
    class_id: str,
    request: AssignmentCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    _require_owner(class_id, claims, store)
    return store.create("assignments", {
        **request.model_dump(),
        "class_id": class_id,
        "owner_uid": _uid(claims),
    })


@router.get("/classes/{class_id}/assignments", response_model=list[AssignmentResponse])
def assignments(
    class_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> list[dict[str, Any]]:
    _require_access(class_id, claims, store)
    return store.list_where("assignments", "class_id", class_id)


@router.post("/assignments/{assignment_id}/submit", response_model=SubmissionResponse)
def submit_assignment(
    assignment_id: str,
    request: SubmissionCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    assignment = store.get("assignments", assignment_id)
    if assignment is None:
        raise HTTPException(404, detail={"code": "assignment_not_found"})
    class_id = str(assignment["class_id"])
    if _membership(class_id, claims, store) is None:
        raise HTTPException(403, detail={"code": "student_membership_required"})
    return store.create("submissions", {
        "assignment_id": assignment_id,
        "class_id": class_id,
        "student_uid": _uid(claims),
        "student_email": _email(claims),
        "content": request.content.strip(),
        "status": "submitted",
        "score": None,
        "feedback": None,
        "ai_suggestion": None,
    })


@router.get("/assignments/{assignment_id}/submissions", response_model=list[SubmissionResponse])
def submissions(
    assignment_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> list[dict[str, Any]]:
    assignment = store.get("assignments", assignment_id)
    if assignment is None:
        raise HTTPException(404, detail={"code": "assignment_not_found"})
    _require_owner(str(assignment["class_id"]), claims, store)
    return store.list_where("submissions", "assignment_id", assignment_id)


@router.post("/submissions/{submission_id}/suggest-mark", response_model=SubmissionResponse)
async def suggest_mark(
    submission_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    settings: Annotated[Settings, Depends(get_settings)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    submission = store.get("submissions", submission_id)
    if submission is None:
        raise HTTPException(404, detail={"code": "submission_not_found"})
    assignment = store.get("assignments", str(submission["assignment_id"]))
    if assignment is None:
        raise HTTPException(404, detail={"code": "assignment_not_found"})
    _require_owner(str(submission["class_id"]), claims, store)
    try:
        suggestion, _ = await build_provider(settings).complete([
            ChatMessage(
                role="system",
                content=(
                    "You assist an educator with formative marking. Give concise rubric-based feedback, "
                    "strengths, errors and next steps. Do not assign a final grade; the educator decides."
                ),
            ),
            ChatMessage(
                role="user",
                content=(
                    f"Assignment: {assignment['title']}\nInstructions: {assignment['instructions']}\n"
                    f"Maximum score: {assignment['max_score']}\nSubmission:\n{submission['content']}"
                )[:8000],
            ),
        ])
    except ProviderError as exc:
        raise HTTPException(503, detail={"code": "marking_ai_unavailable"}) from exc
    return store.update("submissions", submission_id, {"ai_suggestion": suggestion, "status": "reviewing"})


@router.post("/submissions/{submission_id}/mark", response_model=SubmissionResponse)
def approve_mark(
    submission_id: str,
    request: MarkRequest,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    submission = store.get("submissions", submission_id)
    if submission is None:
        raise HTTPException(404, detail={"code": "submission_not_found"})
    assignment = store.get("assignments", str(submission["assignment_id"]))
    if assignment is None:
        raise HTTPException(404, detail={"code": "assignment_not_found"})
    _require_owner(str(submission["class_id"]), claims, store)
    if request.score > int(assignment["max_score"]):
        raise HTTPException(422, detail={"code": "score_above_maximum"})
    return store.update("submissions", submission_id, {
        "score": request.score,
        "feedback": request.feedback.strip(),
        "status": "marked",
        "marked_by": _uid(claims),
    })


@router.post("/classes/{class_id}/announcements", response_model=AnnouncementResponse)
def create_announcement(
    class_id: str,
    request: AnnouncementCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> dict[str, Any]:
    _require_owner(class_id, claims, store)
    return store.create("announcements", {
        "class_id": class_id,
        "author_email": _email(claims),
        "message": request.message.strip(),
    })


@router.get("/classes/{class_id}/announcements", response_model=list[AnnouncementResponse])
def announcements(
    class_id: str,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[EducationStore, Depends(get_education_store)],
) -> list[dict[str, Any]]:
    _require_access(class_id, claims, store)
    return store.list_where("announcements", "class_id", class_id)


