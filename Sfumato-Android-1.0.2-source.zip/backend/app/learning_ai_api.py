from datetime import UTC, datetime
import re
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.billing_api import enforce_chat_access, get_billing_store
from app.billing_catalog import SubscriptionTier
from app.billing_store import BillingStore
from app.config import get_settings
from app.learning import TutorMode, highest_unlocked_stage
from app.learning_api import DebateAttemptCreate, TutorSessionCreate
from app.learning_store import LearningStore, learning_store
from app.models import ChatMessage
from app.provider import ProviderError, ProviderRateLimitError, ProviderUnavailableError, build_provider

router = APIRouter(prefix="/v1/learning-ai", tags=["learning-ai"])


class GeneratedLearningResponse(BaseModel):
    content: str
    score: int | None = None
    passed: bool | None = None
    highest_unlocked_stage: int | None = None


class TutorFollowUpRequest(BaseModel):
    mode: TutorMode
    subject: str = Field(min_length=1, max_length=100)
    topic: str = Field(min_length=1, max_length=160)
    grade: str | None = Field(default=None, max_length=40)
    curriculum: str | None = Field(default=None, max_length=60)
    lesson_context: str = Field(min_length=1, max_length=16000)
    learner_message: str = Field(min_length=1, max_length=4000)


class TutorFinishRequest(BaseModel):
    mode: TutorMode
    subject: str = Field(min_length=1, max_length=100)
    topic: str = Field(min_length=1, max_length=160)
    grade: str | None = Field(default=None, max_length=40)
    curriculum: str | None = Field(default=None, max_length=60)
    lesson_context: str = Field(min_length=1, max_length=20000)


class DebateFollowUpRequest(BaseModel):
    topic: str
    stage: int
    user_position: str
    debate_context: str
    learner_argument: str


class DebateFinishRequest(BaseModel):
    topic: str
    stage: int
    user_position: str
    debate_context: str


def _tier(record: dict | None) -> SubscriptionTier:
    if not record or record.get("status") != "active":
        return SubscriptionTier.FREE
    try:
        return SubscriptionTier(record.get("tier", "free"))
    except ValueError:
        return SubscriptionTier.FREE


def _daily_limit(tier: SubscriptionTier) -> int:
    settings = get_settings()
    return {
        SubscriptionTier.FREE: settings.ai_daily_token_limit_free,
        SubscriptionTier.STUDENT: settings.ai_daily_token_limit_student,
        SubscriptionTier.DEVELOPER: settings.ai_daily_token_limit_developer,
        SubscriptionTier.BUSINESS: settings.ai_daily_token_limit_business,
    }.get(tier, settings.ai_daily_token_limit_free)


async def _generate(messages: list[ChatMessage], claims: dict[str, Any], store: BillingStore) -> str:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if not uid:
        raise HTTPException(status_code=401, detail={"code": "authentication_required"})
    day = datetime.now(UTC).date().isoformat()
    limit = _daily_limit(_tier(store.get(uid)))
    used = store.get_daily_tokens(uid, day)
    if used >= limit:
        raise HTTPException(status_code=429, detail={"code": "daily_token_limit", "message": "Your daily AI allowance has been reached. Please try again tomorrow.", "limit": limit, "used": used})
    if sum(len(message.content) for message in messages) > get_settings().ai_max_input_characters:
        raise HTTPException(status_code=413, detail={"code": "ai_input_too_large", "message": "This learning session is too large. Start a new session or shorten the material."})
    provider = build_provider(get_settings())
    try:
        content, usage = await provider.complete(messages)
        actual = max(0, int(usage.total_tokens or (usage.prompt_tokens + usage.completion_tokens)))
        if actual:
            store.record_daily_tokens(uid, day, actual)
        return content
    except ProviderRateLimitError as exc:
        raise HTTPException(status_code=429, detail={"code": "learning_ai_busy"}) from exc
    except (ProviderUnavailableError, ProviderError) as exc:
        raise HTTPException(status_code=503, detail={"code": "learning_ai_unavailable"}) from exc


@router.post("/tutor", response_model=GeneratedLearningResponse)
async def generate_tutor_session(request: TutorSessionCreate, claims: Annotated[dict[str, Any], Depends(enforce_chat_access)], store: Annotated[BillingStore, Depends(get_billing_store)]) -> GeneratedLearningResponse:
    grade = request.grade or "the learner's stated level"
    curriculum = request.curriculum or "the learner's stated curriculum"
    mode_instruction = {
        "diagnostic": "Begin with five diagnostic questions. Do not reveal all answers immediately.",
        "lesson": "Teach the concept step by step, then give one worked example and three check questions.",
        "practice": "Give five progressively harder practice questions. Present one question at a time when interaction is possible; do not reveal the answer before the learner attempts it.",
        "revision": "Create a concise revision sheet with key ideas, common mistakes, and a short quiz without revealing quiz answers until attempted.",
    }[request.mode.value]
    content = await _generate([
        ChatMessage(role="system", content="You are the Sfumato AI Tutor. Be encouraging, precise, age-appropriate, interactive and curriculum-aware. Teach rather than simply giving answers. Never claim a learner understands something without evidence from their responses. Use clean plain text only."),
        ChatMessage(role="user", content=f"Create a {request.mode.value} session for {grade} using {curriculum}. Subject: {request.subject}. Topic: {request.topic}. {mode_instruction}"),
    ], claims, store)
    return GeneratedLearningResponse(content=content)


@router.post("/tutor/respond", response_model=GeneratedLearningResponse)
async def continue_tutor_session(request: TutorFollowUpRequest, claims: Annotated[dict[str, Any], Depends(enforce_chat_access)], store: Annotated[BillingStore, Depends(get_billing_store)]) -> GeneratedLearningResponse:
    grade = request.grade or "the learner's stated level"
    curriculum = request.curriculum or "the learner's stated curriculum"
    content = await _generate([
        ChatMessage(role="system", content="You are the Sfumato AI Tutor continuing an active tutoring session. Respond to the learner's newest message, correct mistakes kindly, explain the reasoning, adapt difficulty to demonstrated understanding, and end with exactly one useful next question. Do not reveal an exercise answer before a genuine attempt unless the learner explicitly asks for an explanation. Use clean plain text only."),
        ChatMessage(role="user", content=f"Subject: {request.subject}. Topic: {request.topic}. Level: {grade}. Curriculum: {curriculum}. Session mode: {request.mode.value}.\n\nSESSION SO FAR:\n{request.lesson_context}\n\nLEARNER'S LATEST MESSAGE:\n{request.learner_message}"),
    ], claims, store)
    return GeneratedLearningResponse(content=content)


@router.post("/tutor/finish", response_model=GeneratedLearningResponse)
async def finish_tutor_session(request: TutorFinishRequest, claims: Annotated[dict[str, Any], Depends(enforce_chat_access)], store: Annotated[LearningStore, Depends(lambda: learning_store)], billing: Annotated[BillingStore, Depends(get_billing_store)]) -> GeneratedLearningResponse:
    content = await _generate([
        ChatMessage(role="system", content="You are the Sfumato Tutor mastery assessor. Judge only demonstrated learner evidence in the session. Score understanding, reasoning, accuracy and independence. Never award mastery merely because the tutor explained the answer. Use clean plain text."),
        ChatMessage(role="user", content=f"Subject: {request.subject}. Topic: {request.topic}. Level: {request.grade or 'not specified'}. Curriculum: {request.curriculum or 'not specified'}. Mode: {request.mode.value}.\n\nSESSION:\n{request.lesson_context}\n\nReturn exactly: MASTERY SCORE: n/100; RESULT: MASTERED or KEEP LEARNING; then strengths, gaps, and a short next study plan."),
    ], claims, billing)
    match = re.search(r"MASTERY SCORE:\s*(\d{1,3})\s*/\s*100", content, re.IGNORECASE)
    score = max(0, min(100, int(match.group(1)))) if match else 0
    result_match = re.search(r"RESULT:\s*(MASTERED|KEEP LEARNING)", content, re.IGNORECASE)
    model_mastered = bool(result_match and result_match.group(1).upper() == "MASTERED")
    passed = score >= 70 and model_mastered
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if not uid:
        raise HTTPException(status_code=401, detail={"code": "authentication_required"})
    store.create(uid, "tutor_results", {"mode": request.mode.value, "subject": request.subject, "topic": request.topic, "grade": request.grade, "curriculum": request.curriculum, "mastery": score, "passed": passed, "summary": content})
    store.audit(uid, "tutor.session.finished", {"mastery": score, "passed": passed})
    return GeneratedLearningResponse(content=content, score=score, passed=passed)


@router.post("/arena", response_model=GeneratedLearningResponse)
async def generate_debate_opening(request: DebateAttemptCreate, claims: Annotated[dict[str, Any], Depends(enforce_chat_access)], store: Annotated[BillingStore, Depends(get_billing_store)]) -> GeneratedLearningResponse:
    ai_position = "against" if request.position.lower() == "for" else "for"
    stage_rules = {1: "Use a clear, accessible opening with two defensible arguments.", 2: "Use stronger evidence and challenge a likely weakness in the opponent's case.", 3: "Use nuanced reasoning, counterexamples, and expose hidden assumptions.", 4: "Argue at expert level with rigorous logic and anticipate rebuttals.", 5: "Argue at grandmaster level: steelman the opponent, rebut it, and present a difficult dilemma."}
    content = await _generate([ChatMessage(role="system", content="You are the Sfumato Debate Arena opponent. Be challenging but respectful. Stay on the assigned side and end with one direct question. Use clean plain text only."), ChatMessage(role="user", content=f"Debate topic: {request.topic}. The user is {request.position}; you are {ai_position}. Stage {request.stage.value}. {stage_rules[request.stage.value]}")], claims, store)
    return GeneratedLearningResponse(content=content)


@router.post("/arena/respond", response_model=GeneratedLearningResponse)
async def continue_debate(request: DebateFollowUpRequest, claims: Annotated[dict[str, Any], Depends(enforce_chat_access)], store: Annotated[BillingStore, Depends(get_billing_store)]) -> GeneratedLearningResponse:
    ai_position = "against" if request.user_position.lower() == "for" else "for"
    content = await _generate([ChatMessage(role="system", content="You are the Sfumato Debate Arena opponent in a live debate. Challenge the newest argument directly, remain respectful, rebut one weakness, and end with one direct question. Use clean plain text only."), ChatMessage(role="user", content=f"Topic: {request.topic}. Stage: {request.stage}. The learner is {request.user_position}; you are {ai_position}.\n\nDEBATE SO FAR:\n{request.debate_context[-12000:]}\n\nLEARNER'S NEW ARGUMENT:\n{request.learner_argument}")], claims, store)
    return GeneratedLearningResponse(content=content)


@router.post("/arena/finish", response_model=GeneratedLearningResponse)
async def judge_debate(request: DebateFinishRequest, claims: Annotated[dict[str, Any], Depends(enforce_chat_access)], store: Annotated[LearningStore, Depends(lambda: learning_store)], billing: Annotated[BillingStore, Depends(get_billing_store)]) -> GeneratedLearningResponse:
    stage_pass_scores = {1: 60, 2: 70, 3: 80, 4: 90, 5: 95}
    pass_score = stage_pass_scores.get(request.stage, 60)
    content = await _generate([ChatMessage(role="system", content="You are the impartial Sfumato Debate Arena judge. Score only the learner: reasoning 25, evidence 20, rebuttal 15, opposing-view understanding 15, clarity 10, cross-examination 10, civility 5. Be demanding and fair."), ChatMessage(role="user", content=f"Topic: {request.topic}. Learner position: {request.user_position}. Stage: {request.stage}. Passing score: {pass_score}/100.\n\nFULL DEBATE:\n{request.debate_context[-16000:]}\n\nReturn exactly: FINAL SCORE: n/100; RESULT: PASS or RETRY; then category scores, strongest points, improvements, and judge summary.")], claims, billing)
    score_match = re.search(r"FINAL SCORE:\s*(\d{1,3})\s*/\s*100", content, re.IGNORECASE)
    score = max(0, min(100, int(score_match.group(1)))) if score_match else 0
    passed = score >= pass_score
    uid = str(claims.get("uid") or claims["sub"])
    prior_results = store.list(uid, "debate_results")
    prior_overall = max((int(item.get("overall_score", 0)) for item in prior_results), default=0)
    overall_score = max(prior_overall, round(score * 0.85))
    store.create(uid, "debate_results", {"total": score, "overall_score": overall_score, "stage": request.stage, "position": request.user_position, "topic": request.topic, "passed": passed, "judge_summary": content, "judge_model": "primary-provider"})
    store.audit(uid, "arena.result.judged", {"stage": request.stage, "total": score, "passed": passed})
    saved_results = prior_results + [{"stage": request.stage, "total": score, "passed": passed}]
    highest = highest_unlocked_stage(saved_results)
    return GeneratedLearningResponse(content=content, score=score, passed=passed, highest_unlocked_stage=int(highest))
