from __future__ import annotations

from datetime import datetime
from hmac import compare_digest
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel, Field

from app.config import get_settings
from app.billing_api import require_student_entitlement
from app.learning import (
    DebateScore,
    DebateStage,
    OverallScoreInputs,
    TutorMode,
    STAGE_PASS_SCORES,
    highest_unlocked_stage,
    overall_higuru_score,
)
from app.learning_store import LearningStore, learning_store

router = APIRouter(prefix="/v1/learning", tags=["learning"])


def get_learning_store() -> LearningStore:
    return learning_store


def require_judge_service(
    judge_token: Annotated[str | None, Header(alias="X-Sfumato-Judge-Token")] = None,
) -> None:
    configured = get_settings().learning_judge_token
    if configured is None or judge_token is None or not compare_digest(
        judge_token, configured.get_secret_value()
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "judge_authorization_required"},
        )


def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims["sub"])


class TutorSessionCreate(BaseModel):
    mode: TutorMode
    subject: str = Field(min_length=1, max_length=100)
    topic: str = Field(min_length=1, max_length=160)
    grade: str | None = Field(default=None, max_length=40)
    curriculum: str | None = Field(default=None, max_length=60)


class TutorResultCreate(BaseModel):
    session_id: str = Field(min_length=1, max_length=80)
    questions_attempted: int = Field(ge=1, le=100)
    questions_correct: int = Field(ge=0, le=100)
    mastery: int = Field(ge=0, le=100)


class DebateAttemptCreate(BaseModel):
    topic: str = Field(min_length=3, max_length=300)
    stage: DebateStage
    position: str = Field(min_length=1, max_length=40)


class DebateResultCreate(BaseModel):
    attempt_id: str = Field(min_length=1, max_length=80)
    score: DebateScore
    overall_inputs: OverallScoreInputs
    judge_summary: str = Field(min_length=1, max_length=4000)
    judge_model: str = Field(min_length=1, max_length=160)


class LearningRecord(BaseModel):
    id: str
    user_id: str
    created_at: datetime
    data: dict[str, Any]


class ArenaStatus(BaseModel):
    highest_unlocked_stage: DebateStage
    best_debate_score: int
    overall_higuru_score: int


@router.post("/tutor/sessions", response_model=LearningRecord, status_code=201)
def create_tutor_session(
    request: TutorSessionCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
) -> LearningRecord:
    uid = _uid(claims)
    record = store.create(uid, "tutor_sessions", request.model_dump(mode="json"))
    store.audit(uid, "tutor.session.created", {"record_id": record["id"]})
    return _record(record)


@router.post("/tutor/results", response_model=LearningRecord, status_code=201)
def record_tutor_result(
    request: TutorResultCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
) -> LearningRecord:
    if request.questions_correct > request.questions_attempted:
        raise HTTPException(
            status_code=422,
            detail={"code": "invalid_tutor_result", "message": "Correct answers exceed attempts."},
        )
    uid = _uid(claims)
    record = store.create(uid, "tutor_results", request.model_dump(mode="json"))
    store.audit(uid, "tutor.result.recorded", {"record_id": record["id"]})
    return _record(record)


@router.get("/tutor/results", response_model=list[LearningRecord])
def list_tutor_results(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
) -> list[LearningRecord]:
    return [_record(item) for item in store.list(_uid(claims), "tutor_results")]


@router.post("/arena/attempts", response_model=LearningRecord, status_code=201)
def create_debate_attempt(
    request: DebateAttemptCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
) -> LearningRecord:
    uid = _uid(claims)
    status_value = _arena_status(uid, store)
    if request.stage > status_value.highest_unlocked_stage:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "stage_locked", "message": "Qualification requirements are not met."},
        )
    record = store.create(uid, "debate_attempts", request.model_dump(mode="json"))
    store.audit(uid, "arena.attempt.created", {"record_id": record["id"], "stage": request.stage})
    return _record(record)


@router.post("/arena/results", response_model=LearningRecord, status_code=201)
def record_debate_result(
    request: DebateResultCreate,
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
    _: Annotated[None, Depends(require_judge_service)],
) -> LearningRecord:
    uid = _uid(claims)
    attempt = next(
        (
            item
            for item in store.list(uid, "debate_attempts")
            if item["id"] == request.attempt_id
        ),
        None,
    )
    if attempt is None:
        raise HTTPException(status_code=404, detail={"code": "attempt_not_found"})
    payload = request.model_dump(mode="json")
    payload["stage"] = int(attempt["stage"])
    payload["passed"] = request.score.total >= STAGE_PASS_SCORES[int(attempt["stage"])]
    payload["total"] = request.score.total
    payload["overall_score"] = overall_higuru_score(request.overall_inputs)
    record = store.create(uid, "debate_results", payload)
    store.audit(
        uid,
        "arena.result.judged",
        {
            "record_id": record["id"],
            "attempt_id": request.attempt_id,
            "total": request.score.total,
            "judge_model": request.judge_model,
        },
    )
    return _record(record)


@router.get("/arena/status", response_model=ArenaStatus)
def arena_status(
    claims: Annotated[dict[str, Any], Depends(require_student_entitlement)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
) -> ArenaStatus:
    return _arena_status(_uid(claims), store)


def _arena_status(uid: str, store: LearningStore) -> ArenaStatus:
    results = store.list(uid, "debate_results")
    best = max((int(item.get("total", 0)) for item in results), default=0)
    overall = max((int(item.get("overall_score", 0)) for item in results), default=0)
    highest = highest_unlocked_stage(results)
    return ArenaStatus(
        highest_unlocked_stage=highest,
        best_debate_score=best,
        overall_higuru_score=overall,
    )


def _record(record: dict[str, Any]) -> LearningRecord:
    reserved = {"id", "user_id", "created_at"}
    return LearningRecord(
        id=record["id"],
        user_id=record["user_id"],
        created_at=record["created_at"],
        data={key: value for key, value in record.items() if key not in reserved},
    )
