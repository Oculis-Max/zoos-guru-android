from __future__ import annotations

import asyncio
import json
from typing import Annotated, Any

import httpx
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from app.billing_api import require_business_entitlement
from app.config import Settings, get_settings
from app.learning_store import LearningStore, learning_store

router = APIRouter(prefix="/v1/journalist", tags=["journalist"])
MAX_AUDIO_BYTES = 40 * 1024 * 1024
ALLOWED_AUDIO = {"audio/mp4", "audio/m4a", "audio/aac", "audio/mpeg", "audio/mp3", "audio/wav", "audio/ogg", "audio/flac"}


class JournalistNotes(BaseModel):
    transcript: str
    summary: str
    key_quotes: list[str] = Field(default_factory=list)
    facts_to_verify: list[str] = Field(default_factory=list)
    follow_up_questions: list[str] = Field(default_factory=list)
    article_outline: list[str] = Field(default_factory=list)
    headline_suggestions: list[str] = Field(default_factory=list)
    privacy_notice: str = "The temporary cloud audio file was deleted after processing."


def get_learning_store() -> LearningStore:
    return learning_store


def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims.get("sub") or "")


def _extract_json(response: httpx.Response) -> dict[str, Any]:
    try:
        payload = response.json()
        text = payload["candidates"][0]["content"]["parts"][0]["text"]
        return json.loads(text)
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise HTTPException(502, detail={"code": "invalid_transcription_response"}) from exc


@router.post("/transcribe", response_model=JournalistNotes)
async def transcribe_interview(
    claims: Annotated[dict[str, Any], Depends(require_business_entitlement)],
    settings: Annotated[Settings, Depends(get_settings)],
    store: Annotated[LearningStore, Depends(get_learning_store)],
    audio: UploadFile = File(...),
    consent_confirmed: bool = Form(...),
    save_notes: bool = Form(True),
) -> JournalistNotes:
    if not consent_confirmed:
        raise HTTPException(400, detail={"code": "recording_consent_required"})
    if not settings.journalist_audio_enabled:
        raise HTTPException(503, detail={"code": "journalist_audio_not_enabled"})
    if settings.gemini_api_key is None:
        raise HTTPException(503, detail={"code": "audio_provider_not_configured"})

    mime = (audio.content_type or "").lower()
    if mime not in ALLOWED_AUDIO:
        raise HTTPException(415, detail={"code": "unsupported_audio_format"})

    raw = await audio.read(MAX_AUDIO_BYTES + 1)
    await audio.close()
    if not raw:
        raise HTTPException(400, detail={"code": "empty_audio"})
    if len(raw) > MAX_AUDIO_BYTES:
        raise HTTPException(413, detail={"code": "audio_too_large", "max_bytes": MAX_AUDIO_BYTES})

    key = settings.gemini_api_key.get_secret_value()
    model = settings.gemini_model.strip()
    file_name: str | None = None
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            upload_start = await client.post(
                "https://generativelanguage.googleapis.com/upload/v1beta/files",
                headers={
                    "x-goog-api-key": key,
                    "X-Goog-Upload-Protocol": "resumable",
                    "X-Goog-Upload-Command": "start",
                    "X-Goog-Upload-Header-Content-Length": str(len(raw)),
                    "X-Goog-Upload-Header-Content-Type": mime,
                    "Content-Type": "application/json",
                },
                json={"file": {"display_name": audio.filename or "interview.m4a"}},
            )
            upload_url = upload_start.headers.get("x-goog-upload-url")
            if upload_start.status_code >= 400 or not upload_url:
                raise HTTPException(502, detail={"code": "audio_upload_failed"})
            upload = await client.post(
                upload_url,
                headers={
                    "Content-Length": str(len(raw)),
                    "X-Goog-Upload-Offset": "0",
                    "X-Goog-Upload-Command": "upload, finalize",
                },
                content=raw,
            )
            if upload.status_code >= 400:
                raise HTTPException(502, detail={"code": "audio_upload_failed"})
            file_payload = upload.json().get("file") or {}
            file_uri = file_payload.get("uri")
            file_name = file_payload.get("name")
            if not file_uri or not file_name:
                raise HTTPException(502, detail={"code": "audio_upload_invalid"})

            for _ in range(30):
                file_status = await client.get(
                    f"https://generativelanguage.googleapis.com/v1beta/{file_name}",
                    params={"key": key},
                )
                if file_status.status_code >= 400:
                    raise HTTPException(502, detail={"code": "audio_processing_failed"})
                state = (file_status.json().get("state") or "").upper()
                if state == "ACTIVE":
                    break
                if state == "FAILED":
                    raise HTTPException(422, detail={"code": "audio_processing_failed"})
                await asyncio.sleep(2)
            else:
                raise HTTPException(504, detail={"code": "audio_processing_timeout"})

            prompt = (
                "You are HiGURU Journalist Studio. Transcribe this interview faithfully. "
                "Use speaker labels Journalist and Guest when inferable; otherwise Speaker 1 and Speaker 2. "
                "Preserve meaningful wording, add timestamps regularly, and never invent quotations. "
                "Then return strict JSON with keys transcript, summary, key_quotes, facts_to_verify, "
                "follow_up_questions, article_outline, and headline_suggestions. "
                "Quotes must be verbatim from the transcript. Facts to verify must flag uncertainty."
            )
            generated = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                params={"key": key},
                json={
                    "contents": [{"parts": [
                        {"text": prompt},
                        {"file_data": {"mime_type": mime, "file_uri": file_uri}},
                    ]}],
                    "generationConfig": {"response_mime_type": "application/json"},
                },
            )
            if generated.status_code == 429:
                raise HTTPException(429, detail={"code": "journalist_rate_limited"})
            if generated.status_code >= 400:
                raise HTTPException(502, detail={"code": "transcription_failed"})
            notes = JournalistNotes.model_validate(_extract_json(generated))
    finally:
        if file_name and settings.gemini_api_key is not None:
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    await client.delete(
                        f"https://generativelanguage.googleapis.com/v1beta/{file_name}",
                        params={"key": key},
                    )
            except httpx.HTTPError:
                pass

    if save_notes:
        record = notes.model_dump()
        record.pop("privacy_notice", None)
        store.create(_uid(claims), "journalist_notes", record)
        store.audit(_uid(claims), "journalist.notes.created", {
            "audio_filename": audio.filename or "interview",
            "audio_bytes": len(raw),
        })
    return notes
