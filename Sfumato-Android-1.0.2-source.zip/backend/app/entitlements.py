from enum import StrEnum
from typing import Protocol
from uuid import UUID

from pydantic import BaseModel


class PlanId(StrEnum):
    FREE = "free"
    STUDENT = "student"
    PLUS = "plus"
    SPONSORED = "sponsored"


class Entitlement(BaseModel):
    identity_id: UUID
    plan: PlanId = PlanId.FREE
    ai_messages_per_month: int = 30
    advanced_matching: bool = False
    cloud_sync: bool = False
    source: str = "local_default"


class PurchaseReceipt(BaseModel):
    provider: str
    product_id: str
    purchase_token: str


class BillingGateway(Protocol):
    async def verify(self, receipt: PurchaseReceipt) -> Entitlement: ...


class BillingNotConfiguredError(RuntimeError):
    pass


class UnconfiguredBillingGateway:
    async def verify(self, receipt: PurchaseReceipt) -> Entitlement:
        raise BillingNotConfiguredError("Google Play Billing verification is not configured")


def free_entitlement(identity_id: UUID) -> Entitlement:
    return Entitlement(identity_id=identity_id)
