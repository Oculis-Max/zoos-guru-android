from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from threading import RLock
from typing import Any, Protocol
from uuid import uuid4

import firebase_admin
from firebase_admin import firestore


class ProgressStore(Protocol):
    def create(self, subject_uid: str, data: dict[str, Any]) -> dict[str, Any]: ...
    def list_subject(self, subject_uid: str) -> list[dict[str, Any]]: ...
    def list_viewer(self, viewer_email: str) -> list[dict[str, Any]]: ...
    def get(self, share_id: str) -> dict[str, Any] | None: ...
    def revoke(self, subject_uid: str, share_id: str) -> bool: ...


class FirestoreProgressStore:
    collection = "progress_shares"

    def _client(self):
        firebase_admin.get_app()
        return firestore.client()

    def create(self, subject_uid: str, data: dict[str, Any]) -> dict[str, Any]:
        record = {**data, "id": str(uuid4()), "subject_uid": subject_uid, "status": "active", "created_at": datetime.now(UTC)}
        self._client().collection(self.collection).document(record["id"]).set(record)
        return record

    def list_subject(self, subject_uid: str) -> list[dict[str, Any]]:
        query = self._client().collection(self.collection).where("subject_uid", "==", subject_uid)
        records = [item.to_dict() for item in query.stream()]
        return sorted((item for item in records if item.get("status") == "active"), key=lambda item: item["created_at"], reverse=True)

    def list_viewer(self, viewer_email: str) -> list[dict[str, Any]]:
        query = self._client().collection(self.collection).where("viewer_email", "==", viewer_email.lower())
        records = [item.to_dict() for item in query.stream()]
        return [item for item in records if item.get("status") == "active"]

    def get(self, share_id: str) -> dict[str, Any] | None:
        snapshot = self._client().collection(self.collection).document(share_id).get()
        return snapshot.to_dict() if snapshot.exists else None

    def revoke(self, subject_uid: str, share_id: str) -> bool:
        ref = self._client().collection(self.collection).document(share_id)
        snapshot = ref.get()
        if not snapshot.exists or snapshot.to_dict().get("subject_uid") != subject_uid:
            return False
        ref.update({"status": "revoked", "revoked_at": datetime.now(UTC)})
        return True


class InMemoryProgressStore:
    def __init__(self) -> None:
        self.records: dict[str, dict[str, Any]] = {}
        self._lock = RLock()

    def create(self, subject_uid: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            record = {**deepcopy(data), "id": str(uuid4()), "subject_uid": subject_uid, "status": "active", "created_at": datetime.now(UTC)}
            self.records[record["id"]] = record
            return deepcopy(record)

    def list_subject(self, subject_uid: str) -> list[dict[str, Any]]:
        with self._lock:
            return [deepcopy(item) for item in reversed(list(self.records.values())) if item["subject_uid"] == subject_uid and item.get("status") == "active"]

    def list_viewer(self, viewer_email: str) -> list[dict[str, Any]]:
        with self._lock:
            return [deepcopy(item) for item in self.records.values() if item["viewer_email"] == viewer_email.lower() and item["status"] == "active"]

    def get(self, share_id: str) -> dict[str, Any] | None:
        with self._lock:
            value = self.records.get(share_id)
            return deepcopy(value) if value else None

    def revoke(self, subject_uid: str, share_id: str) -> bool:
        with self._lock:
            value = self.records.get(share_id)
            if value is None or value["subject_uid"] != subject_uid:
                return False
            value["status"] = "revoked"
            value["revoked_at"] = datetime.now(UTC)
            return True


progress_store: ProgressStore = FirestoreProgressStore()