from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from datetime import UTC, datetime
from threading import RLock
from typing import Any, Protocol
from uuid import uuid4

import firebase_admin
from firebase_admin import firestore
from google.cloud import firestore as google_firestore


class LearningStore(Protocol):
    def create(self, uid: str, collection: str, data: dict[str, Any]) -> dict[str, Any]: ...
    def get(self, uid: str, collection: str, record_id: str) -> dict[str, Any] | None: ...
    def list(self, uid: str, collection: str) -> list[dict[str, Any]]: ...
    def update(self, uid: str, collection: str, record_id: str, data: dict[str, Any]) -> dict[str, Any]: ...
    def claim(self, uid: str, collection: str, record_id: str, expected_status: str, new_status: str) -> bool: ...
    def delete(self, uid: str, collection: str, record_id: str) -> None: ...
    def delete_all(self, uid: str, collection: str) -> None: ...
    def audit(self, uid: str, event_type: str, data: dict[str, Any]) -> None: ...


class FirestoreLearningStore:
    """Server-only persistence; clients never choose another user's document path."""

    def _client(self):
        firebase_admin.get_app()
        return firestore.client()

    def _collection(self, uid: str, collection: str):
        return self._client().collection("users").document(uid).collection(collection)

    def create(self, uid: str, collection: str, data: dict[str, Any]) -> dict[str, Any]:
        record = {
            **data,
            "id": str(uuid4()),
            "user_id": uid,
            "created_at": datetime.now(UTC),
        }
        self._collection(uid, collection).document(record["id"]).set(record)
        return record

    def get(self, uid: str, collection: str, record_id: str) -> dict[str, Any] | None:
        snapshot = self._collection(uid, collection).document(record_id).get()
        return snapshot.to_dict() if snapshot.exists else None

    def list(self, uid: str, collection: str) -> list[dict[str, Any]]:
        query = self._collection(uid, collection).order_by(
            "created_at", direction=firestore.Query.DESCENDING
        )
        return [snapshot.to_dict() for snapshot in query.stream()]

    def update(
        self,
        uid: str,
        collection: str,
        record_id: str,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        reference = self._collection(uid, collection).document(record_id)
        snapshot = reference.get()
        if not snapshot.exists:
            raise KeyError(record_id)
        patch = {**data, "updated_at": datetime.now(UTC)}
        reference.set(patch, merge=True)
        return {**(snapshot.to_dict() or {}), **patch}

    def claim(
        self,
        uid: str,
        collection: str,
        record_id: str,
        expected_status: str,
        new_status: str,
    ) -> bool:
        reference = self._collection(uid, collection).document(record_id)
        transaction = self._client().transaction()

        @google_firestore.transactional
        def apply_claim(txn):
            snapshot = reference.get(transaction=txn)
            if not snapshot.exists or (snapshot.to_dict() or {}).get("status") != expected_status:
                return False
            txn.update(
                reference,
                {"status": new_status, "updated_at": datetime.now(UTC)},
            )
            return True

        return bool(apply_claim(transaction))

    def delete(self, uid: str, collection: str, record_id: str) -> None:
        self._collection(uid, collection).document(record_id).delete()

    def delete_all(self, uid: str, collection: str) -> None:
        for snapshot in self._collection(uid, collection).stream():
            snapshot.reference.delete()

    def audit(self, uid: str, event_type: str, data: dict[str, Any]) -> None:
        event = {
            "id": str(uuid4()),
            "user_id": uid,
            "event_type": event_type,
            "data": data,
            "created_at": datetime.now(UTC),
        }
        self._client().collection("learning_audit").document(event["id"]).set(event)


class InMemoryLearningStore:
    """Deterministic test store implementing the production persistence boundary."""

    def __init__(self) -> None:
        self._records: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        self.audit_events: list[dict[str, Any]] = []
        self._lock = RLock()

    def create(self, uid: str, collection: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            record = {
                **deepcopy(data),
                "id": str(uuid4()),
                "user_id": uid,
                "created_at": datetime.now(UTC),
            }
            self._records[(uid, collection)].append(record)
            return deepcopy(record)

    def get(self, uid: str, collection: str, record_id: str) -> dict[str, Any] | None:
        with self._lock:
            for record in self._records[(uid, collection)]:
                if record["id"] == record_id:
                    return deepcopy(record)
            return None

    def list(self, uid: str, collection: str) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(list(reversed(self._records[(uid, collection)])))

    def update(
        self,
        uid: str,
        collection: str,
        record_id: str,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        with self._lock:
            for index, record in enumerate(self._records[(uid, collection)]):
                if record["id"] == record_id:
                    updated = {
                        **record,
                        **deepcopy(data),
                        "updated_at": datetime.now(UTC),
                    }
                    self._records[(uid, collection)][index] = updated
                    return deepcopy(updated)
            raise KeyError(record_id)

    def claim(
        self,
        uid: str,
        collection: str,
        record_id: str,
        expected_status: str,
        new_status: str,
    ) -> bool:
        with self._lock:
            for index, record in enumerate(self._records[(uid, collection)]):
                if record["id"] == record_id and record.get("status") == expected_status:
                    self._records[(uid, collection)][index] = {
                        **record,
                        "status": new_status,
                        "updated_at": datetime.now(UTC),
                    }
                    return True
            return False

    def delete(self, uid: str, collection: str, record_id: str) -> None:
        with self._lock:
            self._records[(uid, collection)] = [
                record
                for record in self._records[(uid, collection)]
                if record["id"] != record_id
            ]

    def delete_all(self, uid: str, collection: str) -> None:
        with self._lock:
            self._records[(uid, collection)] = []

    def audit(self, uid: str, event_type: str, data: dict[str, Any]) -> None:
        with self._lock:
            self.audit_events.append(
                {
                    "id": str(uuid4()),
                    "user_id": uid,
                    "event_type": event_type,
                    "data": deepcopy(data),
                    "created_at": datetime.now(UTC),
                }
            )


learning_store: LearningStore = FirestoreLearningStore()
