from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import urlencode

import httpx
from cryptography.fernet import Fernet, InvalidToken

from app.advanced_assistant_store import AssistantStore
from app.config import Settings


GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GMAIL_SEND_SCOPE = "https://www.googleapis.com/auth/gmail.send"
GMAIL_READONLY_SCOPE = "https://www.googleapis.com/auth/gmail.readonly"


class OAuthConfigurationError(RuntimeError):
    pass


class TokenCipher:
    def __init__(self, secret: str) -> None:
        key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode()).digest())
        self.fernet = Fernet(key)

    def encrypt(self, value: str) -> str:
        return self.fernet.encrypt(value.encode()).decode()

    def decrypt(self, value: str) -> str:
        try:
            return self.fernet.decrypt(value.encode()).decode()
        except InvalidToken as exc:
            raise RuntimeError("gmail_reconnection_required") from exc


class StateSigner:
    def __init__(self, secret: str, store: AssistantStore) -> None:
        self.secret = secret.encode()
        self.store = store

    def create(self, uid: str) -> str:
        nonce = secrets.token_urlsafe(24)
        expires_at = int(time.time()) + 600
        payload = {"uid": uid, "exp": expires_at, "nonce": nonce}
        encoded = base64.urlsafe_b64encode(
            json.dumps(payload, separators=(",", ":")).encode()
        ).decode().rstrip("=")
        signature = hmac.new(self.secret, encoded.encode(), hashlib.sha256).hexdigest()
        state = encoded + "." + signature
        self.store.create(
            "oauth_states",
            {
                "owner_uid": uid,
                "provider": "google",
                "nonce_hash": hashlib.sha256(nonce.encode()).hexdigest(),
                "expires_at_epoch": expires_at,
                "status": "pending",
            },
        )
        return state

    def _verified_payload(self, state: str) -> tuple[str, str, int]:
        try:
            encoded, supplied = state.split(".", 1)
            expected = hmac.new(self.secret, encoded.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected, supplied):
                raise ValueError
            raw = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4))
            payload = json.loads(raw)
            uid = str(payload["uid"])
            nonce = str(payload["nonce"])
            expires_at = int(payload["exp"])
            if expires_at < int(time.time()):
                raise ValueError
            return uid, nonce, expires_at
        except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
            raise RuntimeError("invalid_oauth_state") from exc

    def verify(self, state: str) -> str:
        """Validate signature and expiry without consuming the state.

        Kept for diagnostics/tests. Production OAuth completion uses
        verify_and_consume so callback state remains strictly single-use.
        """
        uid, _, _ = self._verified_payload(state)
        return uid

    def verify_and_consume(self, state: str) -> str:
        uid, nonce, _ = self._verified_payload(state)
        nonce_hash = hashlib.sha256(nonce.encode()).hexdigest()
        match = next(
            (
                item
                for item in self.store.list_for_user("oauth_states", uid)
                if item.get("provider") == "google"
                and item.get("nonce_hash") == nonce_hash
            ),
            None,
        )
        if match is None or match.get("status") != "pending":
            raise RuntimeError("invalid_oauth_state")
        if int(match.get("expires_at_epoch") or 0) < int(time.time()):
            raise RuntimeError("invalid_oauth_state")
        self.store.update(
            "oauth_states",
            str(match["id"]),
            {"status": "consumed", "consumed_at": datetime.now(UTC)},
        )
        return uid


class GoogleOAuthService:
    def __init__(
        self,
        settings: Settings,
        store: AssistantStore,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.settings = settings
        self.store = store
        self.client = client or httpx.AsyncClient(timeout=settings.request_timeout_seconds)
        client_id = settings.google_oauth_client_id
        client_secret = settings.google_oauth_client_secret
        encryption_secret = settings.assistant_token_encryption_secret
        if not client_id or client_secret is None or encryption_secret is None:
            raise OAuthConfigurationError("gmail_oauth_configuration_required")
        self.client_id = client_id
        self.client_secret = client_secret.get_secret_value()
        secret = encryption_secret.get_secret_value()
        if len(secret) < 32:
            raise OAuthConfigurationError("assistant_encryption_secret_too_short")
        self.cipher = TokenCipher(secret)
        self.signer = StateSigner(secret, store)

    def authorization_url(self, uid: str, login_hint: str | None = None) -> str:
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.settings.google_oauth_callback_url,
            "response_type": "code",
            "scope": "openid email " + GMAIL_SEND_SCOPE + " " + GMAIL_READONLY_SCOPE,
            "access_type": "offline",
            "prompt": "consent",
            "include_granted_scopes": "true",
            "state": self.signer.create(uid),
        }
        if login_hint:
            params["login_hint"] = login_hint
        return GOOGLE_AUTH_URL + "?" + urlencode(params)

    async def complete(self, code: str, state: str) -> dict[str, Any]:
        uid = self.signer.verify_and_consume(state)
        response = await self.client.post(
            GOOGLE_TOKEN_URL,
            data={
                "code": code,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "redirect_uri": self.settings.google_oauth_callback_url,
                "grant_type": "authorization_code",
            },
        )
        if response.is_error:
            raise RuntimeError("gmail_oauth_exchange_failed")
        payload = response.json()
        access_token = str(payload.get("access_token") or "")
        refresh_token = str(payload.get("refresh_token") or "")
        if not access_token or not refresh_token:
            raise RuntimeError("gmail_refresh_token_missing")
        expires_in = int(payload.get("expires_in") or 3600)
        return self.store.create(
            "connections",
            {
                "owner_uid": uid,
                "channel": "email",
                "provider": "google",
                "access_token_encrypted": self.cipher.encrypt(access_token),
                "refresh_token_encrypted": self.cipher.encrypt(refresh_token),
                "expires_at": datetime.now(UTC) + timedelta(seconds=expires_in),
                "scope": str(
                    payload.get("scope")
                    or (GMAIL_SEND_SCOPE + " " + GMAIL_READONLY_SCOPE)
                ),
                "status": "connected",
            },
        )

    async def access_token(self, uid: str) -> str | None:
        connection = next(
            (
                item
                for item in self.store.list_for_user("connections", uid)
                if item.get("provider") == "google"
                and item.get("status") == "connected"
            ),
            None,
        )
        if connection is None:
            return None
        expires_at = connection.get("expires_at")
        if (
            isinstance(expires_at, datetime)
            and expires_at > datetime.now(UTC) + timedelta(minutes=2)
        ):
            return self.cipher.decrypt(str(connection["access_token_encrypted"]))
        refresh_token = self.cipher.decrypt(str(connection["refresh_token_encrypted"]))
        response = await self.client.post(
            GOOGLE_TOKEN_URL,
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token",
            },
        )
        if response.is_error:
            self.store.update(
                "connections",
                str(connection["id"]),
                {"status": "reconnect_required"},
            )
            raise RuntimeError("gmail_reconnection_required")
        payload = response.json()
        access_token = str(payload.get("access_token") or "")
        if not access_token:
            raise RuntimeError("gmail_reconnection_required")
        self.store.update(
            "connections",
            str(connection["id"]),
            {
                "access_token_encrypted": self.cipher.encrypt(access_token),
                "expires_at": datetime.now(UTC)
                + timedelta(seconds=int(payload.get("expires_in") or 3600)),
            },
        )
        return access_token
