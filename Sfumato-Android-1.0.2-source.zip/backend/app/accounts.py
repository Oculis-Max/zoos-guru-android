from datetime import UTC, datetime
from enum import StrEnum
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class SchoolLevel(StrEnum):
    HIGH_SCHOOL = "high_school"
    COLLEGE = "college"
    UNIVERSITY = "university"
    OTHER = "other"


class GuestIdentity(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    kind: str = "guest"
    local_only: bool = True


class StudentProfile(BaseModel):
    identity_id: UUID
    country_code: str = Field(min_length=2, max_length=2)
    school_level: SchoolLevel
    graduation_year: int | None = Field(default=None, ge=2020, le=2100)
    subjects: list[str] = Field(default_factory=list, max_length=12)
    career_interests: list[str] = Field(default_factory=list, max_length=12)
    citizenship_country_codes: list[str] = Field(default_factory=list, max_length=5)
    profile_complete: bool = False


class AccountStore:
    """Process-local MVP store; replace behind this interface after auth vendor selection."""

    def __init__(self) -> None:
        self.identities: dict[UUID, GuestIdentity] = {}
        self.profiles: dict[UUID, StudentProfile] = {}

    def create_guest(self) -> GuestIdentity:
        identity = GuestIdentity()
        self.identities[identity.id] = identity
        return identity

    def save_profile(self, profile: StudentProfile) -> StudentProfile:
        if profile.identity_id not in self.identities:
            raise KeyError("identity_not_found")
        stored = profile.model_copy(update={"profile_complete": True})
        self.profiles[profile.identity_id] = stored
        return stored

    def get_profile(self, identity_id: UUID) -> StudentProfile | None:
        return self.profiles.get(identity_id)


account_store = AccountStore()
