import hashlib
import hmac
import json
from datetime import UTC, datetime
from typing import Annotated, Any

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, Field, HttpUrl, field_validator

from app.billing_catalog import SubscriptionPlan, SubscriptionTier, subscription_catalog, tier_for_plan_code
from app.billing_store import BillingStore, billing_store
from app.config import Settings, get_settings
from app.security import require_firebase_user
from app.voucher_store import VoucherError, VoucherStore, voucher_store

router = APIRouter(prefix="/v1/billing", tags=["billing"])
FREE_DAILY_PROMPT_LIMIT = 20


class CheckoutRequest(BaseModel):
    tier: SubscriptionTier


class CheckoutResponse(BaseModel):
    tier: SubscriptionTier
    checkout_url: HttpUrl
    reference: str


class EntitlementResponse(BaseModel):
    tier: SubscriptionTier = SubscriptionTier.FREE
    status: str = "inactive"
    autonomous_coding: bool = False
    updated_at: datetime | None = None
    source: str | None = None
    campaign_id: str | None = None
    sponsor: str | None = None
    sponsored_until: datetime | None = None


class VoucherRedemptionRequest(BaseModel):
    code: str = Field(min_length=12, max_length=40)
    institution: str = Field(min_length=2, max_length=120)
    education_level: str = Field(min_length=2, max_length=40)
    grade: str = Field(default="", max_length=40)
    curriculum: str = Field(default="", max_length=60)
    subjects: list[str] = Field(default_factory=list, max_length=12)

    @field_validator("code", "institution", "education_level", "grade", "curriculum")
    @classmethod
    def clean_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("subjects")
    @classmethod
    def clean_subjects(cls, values: list[str]) -> list[str]:
        return list(dict.fromkeys(value.strip()[:60] for value in values if value.strip()))


class VoucherRedemptionResponse(BaseModel):
    tier: SubscriptionTier = SubscriptionTier.STUDENT
    status: str = "active"
    campaign_id: str | None = None
    sponsor: str | None = None
    sponsored_until: datetime | None = None


class PaystackGateway:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def _secret(self) -> str:
        if self.settings.paystack_secret_key is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={"code": "billing_not_configured"},
            )
        return self.settings.paystack_secret_key.get_secret_value()

    async def initialize(self, email: str, uid: str, plan_code: str, tier: SubscriptionTier) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.settings.request_timeout_seconds) as client:
            response = await client.post(
                "https://api.paystack.co/transaction/initialize",
                headers={"Authorization": f"Bearer {self._secret()}"},
                json={
                    "email": email,
                    "plan": plan_code,
                    "currency": "ZAR",
                    "metadata": {"higuru_uid": uid, "higuru_tier": tier.value},
                },
            )
        if response.status_code >= 400:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail={"code": "checkout_initialization_failed"},
            )
        payload = response.json()
        if not payload.get("status") or not payload.get("data", {}).get("authorization_url"):
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail={"code": "invalid_checkout_response"},
            )
        return payload["data"]

    async def verify(self, reference: str) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.settings.request_timeout_seconds) as client:
            response = await client.get(
                f"https://api.paystack.co/transaction/verify/{reference}",
                headers={"Authorization": f"Bearer {self._secret()}"},
            )
        if response.status_code >= 400:
            raise HTTPException(status_code=502, detail={"code": "verification_failed"})
        payload = response.json()
        if not payload.get("status") or payload.get("data", {}).get("status") != "success":
            raise HTTPException(status_code=400, detail={"code": "payment_not_successful"})
        return payload["data"]


def get_paystack_gateway(settings: Annotated[Settings, Depends(get_settings)]) -> PaystackGateway:
    return PaystackGateway(settings)


def get_billing_store() -> BillingStore:
    return billing_store


def get_voucher_store() -> VoucherStore:
    return voucher_store


def _active_tier(record: dict[str, Any] | None) -> SubscriptionTier:
    if record is None or record.get("status") != "active":
        return SubscriptionTier.FREE
    sponsored_until = record.get("sponsored_until")
    if sponsored_until is not None and sponsored_until <= datetime.now(UTC):
        return SubscriptionTier.FREE
    try:
        return SubscriptionTier(record.get("tier", SubscriptionTier.FREE.value))
    except (TypeError, ValueError):
        return SubscriptionTier.FREE


def _require_exact_tier(
    claims: dict[str, Any],
    store: BillingStore,
    required: SubscriptionTier,
    code: str,
) -> dict[str, Any]:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if _active_tier(store.get(uid)) != required:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail={"code": code})
    return claims


def enforce_chat_access(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if not uid:
        raise HTTPException(status_code=401, detail={"code": "authentication_required"})
    if _active_tier(store.get(uid)) == SubscriptionTier.FREE:
        day = datetime.now(UTC).date().isoformat()
        allowed, used = store.consume_daily_prompt(uid, day, FREE_DAILY_PROMPT_LIMIT)
        if not allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "code": "free_daily_prompt_limit",
                    "message": "Free accounts can send 20 prompts per day. Upgrade for continued access.",
                    "limit": FREE_DAILY_PROMPT_LIMIT,
                    "used": used,
                },
            )
    return claims


@router.get("/plans", response_model=list[SubscriptionPlan])
def list_plans(settings: Annotated[Settings, Depends(get_settings)]) -> list[SubscriptionPlan]:
    return list(subscription_catalog(settings).values())


@router.post("/checkout", response_model=CheckoutResponse)
async def create_checkout(
    request: CheckoutRequest,
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    settings: Annotated[Settings, Depends(get_settings)],
    gateway: Annotated[PaystackGateway, Depends(get_paystack_gateway)],
) -> CheckoutResponse:
    if request.tier == SubscriptionTier.FREE:
        raise HTTPException(status_code=400, detail={"code": "free_plan_has_no_checkout"})
    uid = str(claims.get("uid") or claims.get("sub") or "")
    email = claims.get("email")
    if not uid or not email or claims.get("email_verified") is not True:
        raise HTTPException(status_code=400, detail={"code": "verified_email_required"})
    plan = subscription_catalog(settings)[request.tier]
    if plan.plan_code is None:
        raise HTTPException(status_code=503, detail={"code": "checkout_not_configured"})
    checkout = await gateway.initialize(str(email), uid, plan.plan_code, request.tier)
    return CheckoutResponse(
        tier=request.tier,
        checkout_url=checkout["authorization_url"],
        reference=checkout["reference"],
    )


@router.get("/entitlement", response_model=EntitlementResponse)
def get_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> EntitlementResponse:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    record = store.get(uid)
    if record is None:
        return EntitlementResponse()
    raw_tier = record.get("tier", SubscriptionTier.FREE.value)
    try:
        tier = SubscriptionTier(raw_tier)
    except (TypeError, ValueError):
        tier = SubscriptionTier.FREE
    current_status = record.get("status", "inactive")
    sponsored_until = record.get("sponsored_until")
    if sponsored_until is not None and sponsored_until <= datetime.now(UTC):
        current_status = "expired"
    if tier == SubscriptionTier.FREE and raw_tier not in {SubscriptionTier.FREE, SubscriptionTier.FREE.value}:
        current_status = "inactive"
    return EntitlementResponse(
        tier=tier,
        status=current_status,
        autonomous_coding=tier == SubscriptionTier.DEVELOPER
        and current_status == "active",
        updated_at=record.get("updated_at"),
        source=record.get("source"),
        campaign_id=record.get("campaign_id"),
        sponsor=record.get("sponsor"),
        sponsored_until=sponsored_until,
    )


@router.post("/vouchers/redeem", response_model=VoucherRedemptionResponse)
def redeem_voucher(
    request: VoucherRedemptionRequest,
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[VoucherStore, Depends(get_voucher_store)],
) -> VoucherRedemptionResponse:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if not uid:
        raise HTTPException(status_code=401, detail={"code": "authentication_required"})
    if claims.get("email_verified") is not True:
        raise HTTPException(status_code=400, detail={"code": "verified_email_required"})
    try:
        entitlement = store.redeem(
            request.code,
            uid,
            {
                "institution": request.institution,
                "schoolLevel": request.education_level,
                "grade": request.grade,
                "curriculum": request.curriculum,
                "subjects": request.subjects,
            },
        )
    except VoucherError as error:
        raise HTTPException(status_code=400, detail={"code": error.code}) from error
    return VoucherRedemptionResponse(
        campaign_id=entitlement.get("campaign_id"),
        sponsor=entitlement.get("sponsor"),
        sponsored_until=entitlement.get("sponsored_until"),
    )


def require_autonomous_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    return _require_exact_tier(
        claims, store, SubscriptionTier.DEVELOPER, "autonomous_coding_plan_required"
    )


def require_student_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    return _require_exact_tier(claims, store, SubscriptionTier.STUDENT, "student_plan_required")


def require_business_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    return _require_exact_tier(claims, store, SubscriptionTier.BUSINESS, "business_plan_required")


def require_enoch_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if _active_tier(store.get(uid)) not in {SubscriptionTier.DEVELOPER, SubscriptionTier.BUSINESS}:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "enoch_plan_required"},
        )
    return claims


def require_security_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    uid = str(claims.get("uid") or claims.get("sub") or "")
    if _active_tier(store.get(uid)) not in {SubscriptionTier.DEVELOPER, SubscriptionTier.BUSINESS}:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "security_plan_required"},
        )
    return claims


def require_scholarship_entitlement(
    claims: Annotated[dict[str, Any], Depends(require_firebase_user)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
) -> dict[str, Any]:
    return require_student_entitlement(claims, store)


@router.post("/webhooks/paystack", status_code=status.HTTP_200_OK)
async def paystack_webhook(
    request: Request,
    settings: Annotated[Settings, Depends(get_settings)],
    gateway: Annotated[PaystackGateway, Depends(get_paystack_gateway)],
    store: Annotated[BillingStore, Depends(get_billing_store)],
    signature: Annotated[str | None, Header(alias="x-paystack-signature")] = None,
) -> dict[str, bool]:
    raw_body = await request.body()
    if settings.paystack_secret_key is None or signature is None:
        raise HTTPException(status_code=401, detail={"code": "invalid_webhook_signature"})
    expected = hmac.new(
        settings.paystack_secret_key.get_secret_value().encode(),
        raw_body,
        hashlib.sha512,
    ).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise HTTPException(status_code=401, detail={"code": "invalid_webhook_signature"})

    payload = json.loads(raw_body)
    event = payload.get("event")
    data = payload.get("data") or {}
    if event == "charge.success":
        verified = await gateway.verify(str(data.get("reference", "")))
        metadata = verified.get("metadata") or {}
        uid = str(metadata.get("higuru_uid", "")) if isinstance(metadata, dict) else ""
        requested_tier = str(metadata.get("higuru_tier", "")) if isinstance(metadata, dict) else ""
        plan_value = verified.get("plan")
        plan_code = plan_value.get("plan_code") if isinstance(plan_value, dict) else plan_value
        tier = tier_for_plan_code(settings, str(plan_code or ""))
        if not uid or tier is None or requested_tier != tier.value:
            raise HTTPException(status_code=400, detail={"code": "payment_identity_mismatch"})
        plan = subscription_catalog(settings)[tier]
        if verified.get("currency") != "ZAR" or int(verified.get("amount", -1)) != plan.amount_zar * 100:
            raise HTTPException(status_code=400, detail={"code": "payment_amount_mismatch"})
        customer = verified.get("customer") or {}
        record = store.save(
            uid,
            {
                "tier": tier.value,
                "status": "active",
                "plan_code": plan.plan_code,
                "customer_code": customer.get("customer_code"),
                "reference": verified.get("reference"),
                "paid_at": verified.get("paid_at") or datetime.now(UTC).isoformat(),
            },
        )
        store.audit("billing.payment.activated", {"user_id": uid, "tier": tier.value, "reference": record.get("reference")})
    elif event in {"subscription.disable", "invoice.payment_failed"}:
        customer = data.get("customer") or {}
        match = store.find_by_customer(str(customer.get("customer_code", "")))
        if match is not None:
            uid, _record = match
            new_status = "cancelled" if event == "subscription.disable" else "past_due"
            store.save(uid, {"status": new_status})
            store.audit(f"billing.{new_status}", {"user_id": uid})
    return {"accepted": True}
