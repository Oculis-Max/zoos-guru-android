from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.billing_api import require_business_entitlement
from app.config import get_settings
from app.learning_store import LearningStore, learning_store
from app.models import ChatMessage
from app.provider import ProviderError, ProviderRateLimitError, build_provider

router = APIRouter(prefix="/v1/business", tags=["business"])

class AssistantMode(StrEnum):
    STANDARD = "standard"
    ADVANCED = "advanced"
    EMERGENCY = "emergency"

class BusinessArea(StrEnum):
    EXECUTIVE = "executive"
    OPERATIONS = "operations"
    FINANCE = "finance"
    HUMAN_RESOURCES = "human_resources"
    SALES = "sales"
    MARKETING = "marketing"
    CUSTOMER_SERVICE = "customer_service"
    PROCUREMENT = "procurement"
    PROJECTS = "projects"
    LEGAL_COMPLIANCE = "legal_compliance"
    RISK = "risk"
    IT_CYBERSECURITY = "it_cybersecurity"
    RECORDS = "records"
    GENERAL_ADMIN = "general_admin"

class BusinessRequest(BaseModel):
    mode: AssistantMode = AssistantMode.STANDARD
    area: BusinessArea = BusinessArea.GENERAL_ADMIN
    task: str = Field(min_length=8, max_length=4000)
    organization_context: str | None = Field(default=None, max_length=6000)
    document_type: str | None = Field(default=None, max_length=80)

class BusinessResponse(BaseModel):
    run_id: str
    mode: AssistantMode
    area: BusinessArea
    content: str
    approvals_required: list[str]
    execution_status: str = "draft_only"

APPROVAL_CATEGORIES = [
    "Sending external communications",
    "Spending, transferring or committing money",
    "Signing contracts or accepting legal terms",
    "Hiring, dismissal, discipline or payroll changes",
    "Submitting regulatory, tax or legal filings",
    "Deleting records or changing access/security controls",
    "Publishing public statements or crisis communications",
]

def _uid(claims: dict[str, Any]) -> str:
    return str(claims.get("uid") or claims["sub"])

def _mode_instruction(mode: AssistantMode) -> str:
    if mode == AssistantMode.ADVANCED:
        return "Coordinate relevant departments in parallel. Prioritise dependencies, owners, deadlines and measurable outcomes. Draft every artifact needed for execution, but do not claim an external action occurred."
    if mode == AssistantMode.EMERGENCY:
        return "Operate as a damage-control command centre. Start with immediate containment, facts known versus unknown, a decision log, legal/security/PR escalation, stakeholder briefing, recovery actions and a post-incident plan."
    return "Act as a careful executive assistant. Analyse the request, draft the work, identify missing information and present a practical approval-ready plan."

@router.get("/capabilities")
def capabilities() -> dict[str, Any]:
    return {
        "modes": [mode.value for mode in AssistantMode],
        "areas": [area.value for area in BusinessArea],
        "documents": ["action_plan", "business_plan", "proposal", "report", "policy", "sop", "meeting_minutes", "email", "memo", "agenda", "project_plan", "budget_brief", "risk_register", "job_description", "performance_plan", "marketing_plan", "sales_plan", "customer_response", "procurement_brief", "compliance_checklist", "incident_brief"],
        "approval_categories": APPROVAL_CATEGORIES,
    }

@router.post("/assistant", response_model=BusinessResponse)
async def business_assistant(request: BusinessRequest, claims: Annotated[dict[str, Any], Depends(require_business_entitlement)], store: Annotated[LearningStore, Depends(lambda: learning_store)]) -> BusinessResponse:
    context = request.organization_context.strip() if request.organization_context else "Not provided"
    document = request.document_type.strip() if request.document_type else "action_plan"
    system = f"""
You are Enoch, the Sfumato Business Assistant.
You support complete business administration across executive management, operations, finance,
human resources, sales, marketing, customer service, procurement, projects, legal/compliance,
risk, IT/cybersecurity, records and general administration.
Mode: {request.mode.value}. Area: {request.area.value}.
{_mode_instruction(request.mode)}

Produce a professional {document}. Use these headings where relevant:
Executive summary; Current situation; Recommended actions; Owners and deadlines;
Business documents/drafts; Financial implications; People implications; Legal/compliance;
Risks and controls; Metrics; Approvals required; Next review.

Rules:
- Be commercially practical and decision-useful.
- Never mention or expose the underlying AI/model/provider to the customer.
- Never invent company facts, financial figures, laws, sources or completed actions.
- Clearly label assumptions and missing information.
- Treat legal, tax, medical, accounting and regulatory content as decision support requiring a qualified professional where appropriate.
- Never send, submit, purchase, sign, delete, hire, dismiss, publish, transfer money or change security. Draft only until a human approves through an authorised connector.
- Flag conflicts, privacy concerns, fraud risk, labour implications and record-retention needs.
- Prefer reversible steps and keep an explainable decision trail.
""".strip()
    user = f"Organisation context:\n{context}\n\nBusiness request:\n{request.task.strip()}\n\nRequested deliverable: {document}"
    try:
        content, _usage = await build_provider(get_settings()).complete([ChatMessage(role="system", content=system), ChatMessage(role="user", content=user)])
    except ProviderRateLimitError as exc:
        raise HTTPException(429, detail={"code": "business_assistant_busy"}) from exc
    except ProviderError as exc:
        raise HTTPException(503, detail={"code": "business_assistant_unavailable"}) from exc

    content = content.strip()
    if not content:
        raise HTTPException(503, detail={"code": "business_assistant_empty_response"})

    run_id = str(uuid4())
    store.create(_uid(claims), "business_runs", {"run_id": run_id, "mode": request.mode.value, "area": request.area.value, "task": request.task.strip(), "document_type": request.document_type, "content": content, "execution_status": "draft_only"})
    store.audit(_uid(claims), "business.assistant.draft_created", {"run_id": run_id, "mode": request.mode.value, "area": request.area.value})
    return BusinessResponse(run_id=run_id, mode=request.mode, area=request.area, content=content, approvals_required=APPROVAL_CATEGORIES)
