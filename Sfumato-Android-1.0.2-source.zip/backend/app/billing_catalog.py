from enum import StrEnum

from pydantic import BaseModel

from app.config import Settings


class SubscriptionTier(StrEnum):
    FREE = "free"
    STUDENT = "student"
    DEVELOPER = "developer"
    BUSINESS = "business"


class SubscriptionPlan(BaseModel):
    tier: SubscriptionTier
    name: str
    amount_zar: int
    interval: str = "monthly"
    plan_code: str | None = None
    checkout_url: str | None = None
    autonomous_coding: bool = False


def subscription_catalog(settings: Settings) -> dict[SubscriptionTier, SubscriptionPlan]:
    return {
        SubscriptionTier.FREE: SubscriptionPlan(
            tier=SubscriptionTier.FREE,
            name="Free",
            amount_zar=0,
        ),
        SubscriptionTier.STUDENT: SubscriptionPlan(
            tier=SubscriptionTier.STUDENT,
            name="Sfumato Student Pro",
            amount_zar=200,
            plan_code=settings.paystack_student_plan_code,
            checkout_url=settings.paystack_student_checkout_url,
        ),
        SubscriptionTier.DEVELOPER: SubscriptionPlan(
            tier=SubscriptionTier.DEVELOPER,
            name="Sfumato Developer",
            amount_zar=1000,
            plan_code=settings.paystack_developer_plan_code,
            checkout_url=settings.paystack_developer_checkout_url,
            autonomous_coding=True,
        ),
        SubscriptionTier.BUSINESS: SubscriptionPlan(
            tier=SubscriptionTier.BUSINESS,
            name="Sfumato Business",
            amount_zar=5000,
            plan_code=settings.paystack_business_plan_code,
            checkout_url=settings.paystack_business_checkout_url,
        ),
    }


def tier_for_plan_code(settings: Settings, plan_code: str) -> SubscriptionTier | None:
    for tier, plan in subscription_catalog(settings).items():
        if plan.plan_code == plan_code:
            return tier
    return None
