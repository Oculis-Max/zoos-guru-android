from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from threading import RLock
from typing import Any, Protocol

import firebase_admin
from firebase_admin import firestore


class BillingStore(Protocol):
    def get(self, uid: str) -> dict[str, Any] | None: ...
    def save(self, uid: str, data: dict[str, Any]) -> dict[str, Any]: ...
    def find_by_customer(self, customer_code: str) -> tuple[str, dict[str, Any]] | None: ...
    def audit(self, event_type: str, data: dict[str, Any]) -> None: ...
    def consume_daily_prompt(self, uid: str, day: str, limit: int) -> tuple[bool, int]: ...
    def get_daily_tokens(self, uid: str, day: str) -> int: ...
    def record_daily_tokens(self, uid: str, day: str, tokens: int) -> int: ...


class FirestoreBillingStore:
    def _client(self):
        firebase_admin.get_app()
        return firestore.client()

    def _document(self, uid: str):
        return (
            self._client()
            .collection("users")
            .document(uid)
            .collection("billing")
            .document("entitlement")
        )

    def _usage_document(self, uid: str, day: str):
        return (
            self._client()
            .collection("users")
            .document(uid)
            .collection("prompt_usage")
            .document(day)
        )

    def get(self, uid: str) -> dict[str, Any] | None:
        snapshot = self._document(uid).get()
        return snapshot.to_dict() if snapshot.exists else None

    def save(self, uid: str, data: dict[str, Any]) -> dict[str, Any]:
        record = {**data, "user_id": uid, "updated_at": datetime.now(UTC)}
        self._document(uid).set(record, merge=True)
        return record

    def find_by_customer(self, customer_code: str) -> tuple[str, dict[str, Any]] | None:
        query = (
            self._client()
            .collection_group("billing")
            .where("customer_code", "==", customer_code)
            .limit(1)
        )
        for snapshot in query.stream():
            data = snapshot.to_dict()
            return str(data["user_id"]), data
        return None

    def audit(self, event_type: str, data: dict[str, Any]) -> None:
        self._client().collection("billing_audit").add(
            {"event_type": event_type, "data": data, "created_at": datetime.now(UTC)}
        )

    def consume_daily_prompt(self, uid: str, day: str, limit: int) -> tuple[bool, int]:
        document = self._usage_document(uid, day)
        transaction = self._client().transaction()

        @firestore.transactional
        def consume(transaction):
            snapshot = document.get(transaction=transaction)
            used = int((snapshot.to_dict() or {}).get("used", 0)) if snapshot.exists else 0
            if used >= limit:
                return False, used
            used += 1
            transaction.set(
                document,
                {"used": used, "day": day, "updated_at": datetime.now(UTC)},
                merge=True,
            )
            return True, used

        return consume(transaction)

    def get_daily_tokens(self, uid: str, day: str) -> int:
        snapshot = self._usage_document(uid, day).get()
        return int((snapshot.to_dict() or {}).get("tokens", 0)) if snapshot.exists else 0

    def record_daily_tokens(self, uid: str, day: str, tokens: int) -> int:
        document = self._usage_document(uid, day)
        transaction = self._client().transaction()

        @firestore.transactional
        def record(transaction):
            snapshot = document.get(transaction=transaction)
            current = int((snapshot.to_dict() or {}).get("tokens", 0)) if snapshot.exists else 0
            total = current + max(0, int(tokens))
            transaction.set(
                document,
                {"tokens": total, "day": day, "updated_at": datetime.now(UTC)},
                merge=True,
            )
            return total

        return record(transaction)


class InMemoryBillingStore:
    def __init__(self) -> None:
        self.records = {}
        self.audit_events = []
        self.prompt_usage = {}
        self.token_usage = {}
        self._lock = RLock()

    def get(self, uid):
        with self._lock:
            value = self.records.get(uid)
            return deepcopy(value) if value else None

    def save(self, uid, data):
        with self._lock:
            record = {
                **self.records.get(uid, {}),
                **deepcopy(data),
                "user_id": uid,
                "updated_at": datetime.now(UTC),
            }
            self.records[uid] = record
            return deepcopy(record)

    def find_by_customer(self, customer_code):
        with self._lock:
            for uid, record in self.records.items():
                if record.get("customer_code") == customer_code:
                    return uid, deepcopy(record)
        return None

    def audit(self, event_type, data):
        with self._lock:
            self.audit_events.append({"event_type": event_type, "data": deepcopy(data)})

    def consume_daily_prompt(self, uid, day, limit):
        with self._lock:
            key = (uid, day)
            used = self.prompt_usage.get(key, 0)
            if used >= limit:
                return False, used
            used += 1
            self.prompt_usage[key] = used
            return True, used

    def get_daily_tokens(self, uid, day):
        with self._lock:
            return self.token_usage.get((uid, day), 0)

    def record_daily_tokens(self, uid, day, tokens):
        with self._lock:
            key = (uid, day)
            self.token_usage[key] = self.token_usage.get(key, 0) + max(0, int(tokens))
            return self.token_usage[key]


billing_store: BillingStore = FirestoreBillingStore()
