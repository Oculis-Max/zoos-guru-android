from __future__ import annotations

from typing import Annotated

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse

from app.coding_api import (
    CONNECTIONS,
    _consume_state,
    _fernet,
    _github_headers,
    _require_oauth,
    _verify_state,
    get_learning_store,
)
from app.config import Settings, get_settings
from app.learning_store import LearningStore

router = APIRouter(prefix="/v1/coding", tags=["coding"])


def _oauth_error_page(message: str) -> HTMLResponse:
    return HTMLResponse(
        "<html><body style='font-family:sans-serif;background:#111;color:#fff;padding:32px'>"
        "<h2>GitHub connection failed</h2>"
        f"<p>{message}</p>"
        "<p>You can safely return to Sfumato and try again.</p>"
        "</body></html>",
        status_code=400,
    )


@router.get("/github/callback", response_class=HTMLResponse)
async def github_callback_fixed(
    code: Annotated[str | None, Query()] = None,
    state_value: Annotated[str | None, Query(alias="state")] = None,
    error: Annotated[str | None, Query()] = None,
    error_description: Annotated[str | None, Query()] = None,
    settings: Settings = Depends(get_settings),
    store: LearningStore = Depends(get_learning_store),
) -> HTMLResponse:
    if error:
        return _oauth_error_page(error_description or "GitHub authorization was cancelled.")
    if not code or not state_value:
        raise HTTPException(400, detail={"code": "github_oauth_missing_parameters"})

    client_id, client_secret, secret = _require_oauth(settings)
    uid, state_hash = _verify_state(state_value, secret)
    _consume_state(uid, state_hash, store)

    token_payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code,
        "redirect_uri": settings.github_oauth_callback_url,
    }

    try:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            token_response = await client.post(
                "https://github.com/login/oauth/access_token",
                headers={"Accept": "application/json"},
                data=token_payload,
            )
            token_data = token_response.json() if token_response.content else {}

            # GitHub permits redirect_uri to be omitted, in which case the registered
            # callback is used. Retry once for callback mismatch so a stale OAuth-app
            # callback setting cannot strand the mobile connection flow.
            if token_data.get("error") == "redirect_uri_mismatch":
                token_payload.pop("redirect_uri", None)
                token_response = await client.post(
                    "https://github.com/login/oauth/access_token",
                    headers={"Accept": "application/json"},
                    data=token_payload,
                )
                token_data = token_response.json() if token_response.content else {}

            access_token = token_data.get("access_token")
            if token_response.status_code != 200 or not access_token:
                oauth_error = str(token_data.get("error") or "oauth_exchange_failed")
                store.audit(uid, "coding.github.oauth_failed", {"error": oauth_error})
                return _oauth_error_page(
                    "GitHub could not complete authorization. Please reconnect your GitHub account."
                )

            user_response = await client.get(
                "https://api.github.com/user",
                headers=_github_headers(str(access_token)),
            )
            if user_response.status_code != 200:
                store.audit(uid, "coding.github.identity_failed", {"status": user_response.status_code})
                return _oauth_error_page("GitHub authorized the connection but identity verification failed.")
            login = str(user_response.json()["login"])
    except (httpx.RequestError, ValueError) as exc:
        raise HTTPException(503, detail={"code": "github_temporarily_unavailable"}) from exc

    store.delete_all(uid, CONNECTIONS)
    store.create(
        uid,
        CONNECTIONS,
        {
            "login": login,
            "encrypted_token": _fernet(secret).encrypt(str(access_token).encode()).decode(),
        },
    )
    store.audit(uid, "coding.github.connected", {"login": login})
    return HTMLResponse(
        "<html><body style='font-family:sans-serif;background:#111;color:#fff;padding:32px'>"
        "<h2>GitHub connected to Sfumato</h2><p>You can return to the app.</p>"
        "</body></html>"
    )
