from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GitHubOAuthFailure:
    code: str
    message: str
    retryable: bool = False


_MESSAGES: dict[str, GitHubOAuthFailure] = {
    "incorrect_client_credentials": GitHubOAuthFailure(
        code="incorrect_client_credentials",
        message="Sfumato's GitHub connection credentials need attention. Please contact support.",
    ),
    "redirect_uri_mismatch": GitHubOAuthFailure(
        code="redirect_uri_mismatch",
        message="Sfumato's GitHub callback configuration does not match. Please contact support.",
    ),
    "bad_verification_code": GitHubOAuthFailure(
        code="bad_verification_code",
        message="This GitHub authorization expired or was already used. Return to Sfumato and connect GitHub again.",
        retryable=True,
    ),
    "unverified_user_email": GitHubOAuthFailure(
        code="unverified_user_email",
        message="GitHub requires a verified email address before this account can be connected.",
    ),
    "github_oauth_timeout": GitHubOAuthFailure(
        code="github_oauth_timeout",
        message="GitHub took too long to respond. Return to Sfumato and try connecting again.",
        retryable=True,
    ),
    "github_oauth_network_error": GitHubOAuthFailure(
        code="github_oauth_network_error",
        message="Sfumato could not reach GitHub. Check your connection and try again.",
        retryable=True,
    ),
}


def safe_github_oauth_failure(error_code: str | None) -> GitHubOAuthFailure:
    code = (error_code or "github_oauth_failed").strip().lower()
    return _MESSAGES.get(
        code,
        GitHubOAuthFailure(
            code="github_oauth_failed",
            message="GitHub could not complete the connection. Return to Sfumato and try again.",
            retryable=True,
        ),
    )
