from datetime import UTC, datetime
from enum import StrEnum
from typing import Protocol

from pydantic import BaseModel, Field, field_validator


class AnalyticsEventName(StrEnum):
    ONBOARDING_COMPLETED = "onboarding_completed"
    CHAT_SEND_SUCCEEDED = "chat_send_succeeded"
    CHAT_SEND_FAILED = "chat_send_failed"
    OFFLINE_RETRY_SUCCEEDED = "offline_retry_succeeded"
    SCHOLARSHIP_VIEWED = "scholarship_viewed"
    SCHOLARSHIP_BOOKMARKED = "scholarship_bookmarked"
    APPLICATION_STATUS_CHANGED = "application_status_changed"
    ENTITLEMENT_VIEWED = "entitlement_viewed"


ALLOWED_DIMENSIONS = {"screen", "result", "network_state", "school_level", "country_group"}
FORBIDDEN_TERMS = {"message", "prompt", "answer", "email", "name", "phone", "token", "document", "essay"}


class AnalyticsEvent(BaseModel):
    name: AnalyticsEventName
    dimensions: dict[str, str] = Field(default_factory=dict, max_length=5)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @field_validator("dimensions")
    @classmethod
    def privacy_guard(cls, value: dict[str, str]) -> dict[str, str]:
        unknown = set(value) - ALLOWED_DIMENSIONS
        if unknown:
            raise ValueError(f"Unsupported analytics dimensions: {sorted(unknown)}")
        for key, item in value.items():
            lowered = f"{key} {item}".lower()
            if any(term in lowered for term in FORBIDDEN_TERMS):
                raise ValueError("Analytics may not contain chat content or personal data")
            if len(item) > 40:
                raise ValueError("Analytics dimensions must be short categorical values")
        return value


class AnalyticsSink(Protocol):
    def record(self, event: AnalyticsEvent) -> None: ...


class LocalAnalyticsSink:
    """No-op/local boundary until the owner selects and consents to a vendor."""

    def __init__(self) -> None:
        self.events: list[AnalyticsEvent] = []

    def record(self, event: AnalyticsEvent) -> None:
        self.events.append(event)


analytics_sink = LocalAnalyticsSink()
