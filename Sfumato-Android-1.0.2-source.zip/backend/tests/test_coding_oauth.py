import base64
import time

import pytest
from fastapi import HTTPException

from app.coding_api import _consume_state, _new_state, _verify_state
from app.learning_store import InMemoryLearningStore


def test_oauth_state_round_trip_and_single_use() -> None:
    store = InMemoryLearningStore()
    value, state_hash, expires = _new_state("user-1", "test-secret")
    uid, verified_hash = _verify_state(value, "test-secret")
    assert uid == "user-1"
    assert verified_hash == state_hash
    store.create(uid, "github_oauth_states", {"state_hash": state_hash, "expires_epoch": expires})
    _consume_state(uid, state_hash, store)
    with pytest.raises(HTTPException) as error:
        _consume_state(uid, state_hash, store)
    assert error.value.detail["code"] == "oauth_state_reused_or_unknown"


def test_tampered_oauth_state_is_rejected() -> None:
    value, _, _ = _new_state("user-1", "test-secret")
    decoded = bytearray(base64.urlsafe_b64decode(value.encode()))
    decoded[0] ^= 1
    tampered = base64.urlsafe_b64encode(bytes(decoded)).decode()
    with pytest.raises(HTTPException) as error:
        _verify_state(tampered, "test-secret")
    assert error.value.detail["code"] == "invalid_oauth_state"


def test_malformed_oauth_state_is_rejected_cleanly() -> None:
    with pytest.raises(HTTPException) as error:
        _verify_state("not-valid-base64%%%", "test-secret")
    assert error.value.status_code == 400
    assert error.value.detail["code"] == "invalid_oauth_state"


def test_expired_stored_state_is_rejected_even_if_hash_matches() -> None:
    store = InMemoryLearningStore()
    value, state_hash, _ = _new_state("user-1", "test-secret")
    uid, _ = _verify_state(value, "test-secret")
    store.create(uid, "github_oauth_states", {"state_hash": state_hash, "expires_epoch": int(time.time()) - 1})
    with pytest.raises(HTTPException) as error:
        _consume_state(uid, state_hash, store)
    assert error.value.detail["code"] == "invalid_oauth_state"
