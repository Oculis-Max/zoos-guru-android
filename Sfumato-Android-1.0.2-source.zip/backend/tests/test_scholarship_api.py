from fastapi.testclient import TestClient

from app.billing_api import get_billing_store
from app.billing_store import InMemoryBillingStore
from app.learning_store import InMemoryLearningStore
from app.main import app
from app.security import require_firebase_user
import app.scholarship_api as scholarship_api


def setup_function() -> None:
    billing = InMemoryBillingStore()
    app.dependency_overrides[get_billing_store] = lambda: billing
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "student-1",
        "email": "student@example.com",
    }
    scholarship_api.learning_store = InMemoryLearningStore()


def teardown_function() -> None:
    app.dependency_overrides.clear()


def activate_student() -> None:
    app.dependency_overrides[get_billing_store]().save(
        "student-1", {"tier": "student", "status": "active"}
    )


def test_finder_only_returns_current_verified_opportunities_by_default() -> None:
    activate_student()
    response = TestClient(app).get("/v1/scholarships?country=ZA")
    assert response.status_code == 200
    payload = response.json()
    assert any(item["id"] == "allan-gray-high-school-2026" for item in payload)
    assert all(item["status"] != "closed" for item in payload)
    assert all(item["official_url"].startswith("https://") for item in payload)


def test_finder_can_include_closed_for_reference() -> None:
    activate_student()
    payload = TestClient(app).get("/v1/scholarships?include_closed=true").json()
    assert any(item["id"] == "nsfas-2026" and item["status"] == "closed" for item in payload)


def test_scholarship_guru_requires_student_pro_access() -> None:
    finder = TestClient(app).get("/v1/scholarships")
    assert finder.status_code == 403

    response = TestClient(app).post("/v1/scholarships/readiness", json={
        "grades": 80, "study_consistency": 70, "leadership": 60,
        "community_service": 50, "digital_skills": 90, "certificates": 40,
        "career_goal": 80, "personal_statement": 70,
    })
    assert response.status_code == 403


def test_readiness_is_weighted_and_never_claims_a_guarantee() -> None:
    activate_student()
    response = TestClient(app).post("/v1/scholarships/readiness", json={
        "grades": 80, "study_consistency": 70, "leadership": 60,
        "community_service": 50, "digital_skills": 90, "certificates": 40,
        "career_goal": 80, "personal_statement": 70,
    })
    assert response.status_code == 200
    assert response.json()["score"] == 70
    assert "not a scholarship guarantee" in response.json()["disclaimer"]


def test_only_official_registry_items_can_be_tracked() -> None:
    activate_student()
    rejected = TestClient(app).post("/v1/scholarships/applications", json={
        "scholarship_id": "social-media-rumour",
    })
    assert rejected.status_code == 422

    saved = TestClient(app).post("/v1/scholarships/applications", json={
        "scholarship_id": "allan-gray-high-school-2026",
        "status": "preparing",
        "next_step": "Read the official eligibility requirements",
    })
    assert saved.status_code == 200
    assert saved.json()["user_id"] == "student-1"
    assert scholarship_api.learning_store.audit_events[0]["event_type"] == "scholarship.application.saved"


def test_tracking_the_same_scholarship_updates_instead_of_duplicating() -> None:
    activate_student()
    client = TestClient(app)
    first = client.post("/v1/scholarships/applications", json={
        "scholarship_id": "allan-gray-high-school-2026",
        "status": "saved",
        "next_step": "Check requirements",
    })
    second = client.post("/v1/scholarships/applications", json={
        "scholarship_id": "allan-gray-high-school-2026",
        "status": "preparing",
        "next_step": "Collect documents",
    })

    assert first.status_code == 200
    assert second.status_code == 200
    assert second.json()["id"] == first.json()["id"]
    applications = client.get("/v1/scholarships/applications").json()
    assert len(applications) == 1
    assert applications[0]["status"] == "preparing"
