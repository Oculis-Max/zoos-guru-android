from fastapi.testclient import TestClient

from app.billing_api import get_billing_store
from app.billing_store import InMemoryBillingStore
from app.config import Settings, get_settings
from app.learning_store import InMemoryLearningStore
from app.main import app
from app.security import require_firebase_user
import app.engineering_api as engineering_api


class FakeProvider:
    async def complete(self, messages):
        system = messages[0].content
        assert "Never present output as signed" in system
        assert "Show units for every engineering value" in system
        assert "Jurisdiction supplied by user" in system
        assert "clean plain text only" in system
        return (
            "Known inputs\nSpan: 4 m\nAssumptions\nProfessional verification required.",
            None,
        )


def setup_function() -> None:
    billing = InMemoryBillingStore()
    app.dependency_overrides[get_settings] = lambda: Settings(gemini_api_key="test")
    app.dependency_overrides[get_billing_store] = lambda: billing
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "engineering-user",
        "email": "engineer@example.com",
    }
    engineering_api.learning_store = InMemoryLearningStore()


def teardown_function() -> None:
    app.dependency_overrides.clear()


def activate_business() -> None:
    app.dependency_overrides[get_billing_store]().save(
        "engineering-user", {"tier": "business", "status": "active"}
    )


def test_capabilities_define_release_boundaries() -> None:
    activate_business()
    response = TestClient(app).get("/v1/engineering/capabilities")
    assert response.status_code == 200
    payload = response.json()
    assert payload["phase"] == 1
    assert {"civil", "structural", "mechanical", "electrical"} <= set(payload["disciplines"])
    assert {"calculation_review", "design_review", "materials_estimate"} <= set(payload["modes"])
    assert len(payload["limitations"]) == 4


def test_non_business_user_is_blocked() -> None:
    capabilities = TestClient(app).get("/v1/engineering/capabilities")
    assert capabilities.status_code == 403

    response = TestClient(app).post(
        "/v1/engineering/assist",
        json={"task": "Explain the preliminary beam loading assumptions"},
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "business_plan_required"


def test_business_user_receives_audited_non_certified_draft(monkeypatch) -> None:
    activate_business()
    monkeypatch.setattr(engineering_api, "build_provider", lambda _settings: FakeProvider())

    response = TestClient(app).post(
        "/v1/engineering/assist",
        json={
            "discipline": "structural",
            "mode": "calculation_review",
            "task": "Review the preliminary loading method for this concept beam",
            "project_context": "Concept design for a small South African office",
            "drawing_notes": "Clear span 4 m; support conditions not yet confirmed",
            "jurisdiction": "South Africa",
            "standards": "SANS edition to be confirmed by the project engineer",
            "units": "metric",
        },
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["safety_status"] == "professional_review_required"
    assert payload["limitations"]
    runs = engineering_api.learning_store.list("engineering-user", "engineering_runs")
    assert runs[0]["jurisdiction"] == "South Africa"
    assert engineering_api.learning_store.list("engineering-user", "engineering_runs")
    assert engineering_api.learning_store.audit_events[0]["event_type"] == (
        "engineering.assistant.draft_created"
    )


def test_unknown_units_are_rejected() -> None:
    billing = app.dependency_overrides[get_billing_store]()
    billing.save("engineering-user", {"tier": "business", "status": "active"})
    response = TestClient(app).post(
        "/v1/engineering/assist",
        json={"task": "Explain this preliminary concept safely", "units": "unknown"},
    )
    assert response.status_code == 422
