from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient

from app.main import app
import app.main as main_module
from app import security
from app.billing_api import get_billing_store
from app.billing_store import InMemoryBillingStore
from app.config import Settings, get_settings

client = TestClient(app)
HEADERS = {"Authorization": "Bearer valid-test-token"}


@pytest.fixture(autouse=True)
def stub_firebase_verification(monkeypatch: pytest.MonkeyPatch) -> Generator[None]:
    store = InMemoryBillingStore()
    app.dependency_overrides[get_billing_store] = lambda: store
    app.dependency_overrides[get_settings] = lambda: Settings(allow_demo_provider=True)
    monkeypatch.setattr(main_module, "get_settings", lambda: Settings(allow_demo_provider=True))
    def verify(token: str) -> dict[str, str]:
        if token != "valid-test-token":
            raise ValueError("invalid token")
        return {"uid": "test-user", "sub": "test-user"}

    monkeypatch.setattr(security, "verify_firebase_id_token", verify)
    yield
    app.dependency_overrides.clear()


def test_chat_requires_bearer_token() -> None:
    response = client.post(
        "/chat",
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )
    assert response.status_code == 401
    assert response.headers["www-authenticate"] == "Bearer"


def test_chat_rejects_wrong_auth_scheme() -> None:
    response = client.post(
        "/chat",
        headers={"Authorization": "Basic valid-test-token"},
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )
    assert response.status_code == 401


def test_chat_rejects_invalid_firebase_token() -> None:
    response = client.post(
        "/chat",
        headers={"Authorization": "Bearer invalid"},
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )
    assert response.status_code == 401


def test_chat_demo_mode() -> None:
    response = client.post(
        "/chat",
        headers=HEADERS,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["message"]["role"] == "assistant"
    assert "Hello" in body["message"]["content"]
    assert body["usage"]["total_tokens"] == 0


def test_chat_rejects_blank_message() -> None:
    response = client.post(
        "/chat",
        headers=HEADERS,
        json={"messages": [{"role": "user", "content": "   "}]},
    )
    assert response.status_code == 422
