import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

from app.billing_api import require_enoch_entitlement
from app.billing_store import InMemoryBillingStore
from app.main import app


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_enoch_session_requires_authorized_dependency() -> None:
    app.dependency_overrides[require_enoch_entitlement] = lambda: {"uid": "developer-1"}
    response = TestClient(app).post("/v1/enoch/session", json={})
    assert response.status_code == 200
    assert response.json() == {"authorized": True, "max_seconds": 360}


def test_enoch_allows_only_active_developer_and_business() -> None:
    store = InMemoryBillingStore()
    developer = {"uid": "developer-1"}
    business = {"uid": "business-1"}
    student = {"uid": "student-1"}
    store.save(developer["uid"], {"tier": "developer", "status": "active"})
    store.save(business["uid"], {"tier": "business", "status": "active"})
    store.save(student["uid"], {"tier": "student", "status": "active"})

    assert require_enoch_entitlement(developer, store) == developer
    assert require_enoch_entitlement(business, store) == business
    with pytest.raises(HTTPException) as student_error:
        require_enoch_entitlement(student, store)
    assert student_error.value.detail["code"] == "enoch_plan_required"


def test_enoch_rejects_inactive_developer() -> None:
    store = InMemoryBillingStore()
    claims = {"uid": "cancelled-developer"}
    store.save(claims["uid"], {"tier": "developer", "status": "cancelled"})
    with pytest.raises(HTTPException):
        require_enoch_entitlement(claims, store)
