from fastapi.testclient import TestClient

import app.advanced_assistant_api as assistant_api
from app.advanced_assistant_api import (
    get_assistant_store,
    get_outbound_connector,
)
from app.advanced_assistant_store import InMemoryAssistantStore
from app.billing_api import require_business_entitlement
from app.main import app
from app.security import require_firebase_user


claims = {"uid": "owner-1", "email": "owner@example.com"}


class FakeProvider:
    async def complete(self, messages):
        return "Prepared content for review.", None


class RecordingConnector:
    def __init__(self) -> None:
        self.sent = []

    async def send(self, action):
        self.sent.append(action)
        return "provider-message-1"


def setup_function() -> None:
    global claims
    claims = {"uid": "owner-1", "email": "owner@example.com"}
    store = InMemoryAssistantStore()
    connector = RecordingConnector()
    app.dependency_overrides[require_firebase_user] = lambda: claims
    app.dependency_overrides[require_business_entitlement] = lambda: claims
    app.dependency_overrides[get_assistant_store] = lambda: store
    app.dependency_overrides[get_outbound_connector] = lambda: connector


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_message_cannot_dispatch_until_owner_approves(monkeypatch) -> None:
    monkeypatch.setattr(assistant_api, "build_provider", lambda settings: FakeProvider())
    client = TestClient(app)
    draft = client.post("/v1/advanced-assistant/actions/draft", json={
        "channel": "email",
        "recipient": "sponsor@example.com",
        "instruction": "Reply politely and request a meeting.",
        "context": "They asked for the Sfumato sponsorship proposal.",
    })
    assert draft.status_code == 200
    action_id = draft.json()["id"]
    assert draft.json()["status"] == "awaiting_approval"

    blocked = client.post(f"/v1/advanced-assistant/actions/{action_id}/dispatch")
    assert blocked.status_code == 409
    assert blocked.json()["detail"]["code"] == "user_approval_required"

    approved = client.post(f"/v1/advanced-assistant/actions/{action_id}/approve")
    assert approved.status_code == 200
    assert approved.json()["status"] == "approved"

    sent = client.post(f"/v1/advanced-assistant/actions/{action_id}/dispatch")
    assert sent.status_code == 200
    assert sent.json()["status"] == "sent"
    assert sent.json()["provider_message_id"] == "provider-message-1"


def test_other_user_cannot_approve_private_draft(monkeypatch) -> None:
    monkeypatch.setattr(assistant_api, "build_provider", lambda settings: FakeProvider())
    client = TestClient(app)
    draft = client.post("/v1/advanced-assistant/actions/draft", json={
        "channel": "facebook",
        "instruction": "Prepare a launch announcement.",
    }).json()

    global claims
    claims = {"uid": "attacker", "email": "attacker@example.com"}
    response = client.post(f"/v1/advanced-assistant/actions/{draft['id']}/approve")
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "assistant_record_access_denied"


def test_long_report_is_saved_as_draft_for_review(monkeypatch) -> None:
    monkeypatch.setattr(assistant_api, "build_provider", lambda settings: FakeProvider())
    client = TestClient(app)
    response = client.post("/v1/advanced-assistant/reports", json={
        "title": "Sfumato Weekly Operations Report",
        "objective": "Summarize progress and identify blockers.",
        "report_type": "operations",
        "source_material": "Phase 2 passed backend and Android CI. Sponsor replies remain pending.",
    })
    assert response.status_code == 200
    assert response.json()["status"] == "draft"
    assert response.json()["content"] == "Prepared content for review."


def test_editing_approved_action_requires_fresh_approval(monkeypatch) -> None:
    monkeypatch.setattr(assistant_api, "build_provider", lambda settings: FakeProvider())
    client = TestClient(app)
    action = client.post("/v1/advanced-assistant/actions/draft", json={
        "channel": "whatsapp",
        "instruction": "Confirm tomorrow's appointment.",
    }).json()
    client.post(f"/v1/advanced-assistant/actions/{action['id']}/approve")

    edited = client.put(f"/v1/advanced-assistant/actions/{action['id']}", json={
        "recipient": "+27000000000",
        "subject": None,
        "content": "Your appointment is confirmed for tomorrow.",
    })
    assert edited.status_code == 200
    assert edited.json()["status"] == "awaiting_approval"
    assert edited.json()["approved_by"] is None
