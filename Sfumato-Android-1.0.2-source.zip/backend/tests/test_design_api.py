from fastapi.testclient import TestClient

from app.billing_api import get_billing_store
from app.billing_store import InMemoryBillingStore
from app.config import Settings, get_settings
from app.learning_store import InMemoryLearningStore
from app.main import app
from app.security import require_firebase_user
import app.design_api as design_api


class FakeProvider:
    async def complete(self, messages):
        assert "non-overlapping axis-aligned room rectangles" in messages[0].content
        return ('{"rooms":[{"id":"room-1","name":"Living","x":0.5,"y":0.5,"width":4.0,"height":3.0},{"id":"room-2","name":"Bedroom","x":4.5,"y":0.5,"width":3.0,"height":3.0}],"assumptions":["Concept only"],"warnings":["Verify locally"]}', None)


class DuplicateIdProvider:
    async def complete(self, messages):
        return ('{"rooms":[{"id":"same","name":"One","x":0,"y":0,"width":2,"height":2},{"id":"same","name":"Two","x":2,"y":0,"width":1,"height":2}]}', None)


def setup_function() -> None:
    billing = InMemoryBillingStore()
    app.dependency_overrides[get_settings] = lambda: Settings(gemini_api_key="test")
    app.dependency_overrides[get_billing_store] = lambda: billing
    app.dependency_overrides[require_firebase_user] = lambda: {"uid": "designer", "email": "designer@example.com"}
    design_api.learning_store = InMemoryLearningStore()


def teardown_function() -> None:
    app.dependency_overrides.clear()


def enable_business() -> None:
    billing = app.dependency_overrides[get_billing_store]()
    billing.save("designer", {"tier": "business", "status": "active"})


def seed_project(width=12, depth=15) -> None:
    design_api.learning_store.create("designer", "design_projects", {"project_id": "project-1", "name": "Existing concept", "version": 1, "units": "metric", "site_width_m": width, "site_depth_m": depth, "rooms": [], "total_floor_area_m2": 0, "quantities": [], "assumptions": [], "warnings": [], "status": "concept_only"})


def test_design_studio_is_business_only() -> None:
    assert TestClient(app).get("/v1/design/capabilities").status_code == 403
    response = TestClient(app).post("/v1/design/generate", json={"prompt": "Create a compact two-bedroom home concept", "project_name": "Home", "site_width_m": 12, "site_depth_m": 15})
    assert response.status_code == 403


def test_generate_validated_editable_layout(monkeypatch) -> None:
    enable_business()
    monkeypatch.setattr(design_api, "build_provider", lambda _settings: FakeProvider())
    response = TestClient(app).post("/v1/design/generate", json={"prompt": "Create a compact two-bedroom home concept", "project_name": "Home concept", "site_width_m": 12, "site_depth_m": 15})
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "concept_only"
    assert len(payload["rooms"]) == 2
    assert payload["total_floor_area_m2"] == 21
    assert payload["quantities"][0]["quantity"] == 23.1


def test_three_metre_site_matches_android_boundary(monkeypatch) -> None:
    enable_business()
    class SmallProvider:
        async def complete(self, messages):
            return ('{"rooms":[{"id":"room-1","name":"Room","x":0,"y":0,"width":3,"height":3}]}', None)
    monkeypatch.setattr(design_api, "build_provider", lambda _settings: SmallProvider())
    response = TestClient(app).post("/v1/design/generate", json={"prompt": "Create one compact room concept", "project_name": "Small", "site_width_m": 3, "site_depth_m": 3})
    assert response.status_code == 200


def test_duplicate_generated_room_ids_are_rejected(monkeypatch) -> None:
    enable_business()
    monkeypatch.setattr(design_api, "build_provider", lambda _settings: DuplicateIdProvider())
    response = TestClient(app).post("/v1/design/generate", json={"prompt": "Create a compact two-room concept", "project_name": "Duplicate test", "site_width_m": 12, "site_depth_m": 15})
    assert response.status_code == 502
    assert response.json()["detail"]["code"] == "invalid_generated_layout"


def test_save_version_recalculates_quantities() -> None:
    enable_business(); seed_project()
    response = TestClient(app).post("/v1/design/projects/project-1/versions", json={"name": "Edited concept", "previous_version": 1, "rooms": [{"id": "room-1", "name": "Room", "x": 0, "y": 0, "width": 5, "height": 4}]})
    assert response.status_code == 200
    assert response.json()["version"] == 2
    assert response.json()["total_floor_area_m2"] == 20


def test_overlapping_and_duplicate_rooms_are_rejected_on_save() -> None:
    enable_business(); seed_project()
    overlapping = TestClient(app).post("/v1/design/projects/project-1/versions", json={"name": "Overlap", "previous_version": 1, "rooms": [{"id": "one", "name": "One", "x": 0, "y": 0, "width": 4, "height": 4}, {"id": "two", "name": "Two", "x": 2, "y": 2, "width": 4, "height": 4}]})
    assert overlapping.status_code == 422
    duplicate = TestClient(app).post("/v1/design/projects/project-1/versions", json={"name": "Duplicate", "previous_version": 1, "rooms": [{"id": "same", "name": "One", "x": 0, "y": 0, "width": 2, "height": 2}, {"id": "same", "name": "Two", "x": 2, "y": 0, "width": 2, "height": 2}]})
    assert duplicate.status_code == 422


def test_stale_or_unknown_project_version_is_rejected() -> None:
    enable_business(); seed_project()
    unknown = TestClient(app).post("/v1/design/projects/not-owned/versions", json={"name": "Unknown", "previous_version": 1, "rooms": [{"id": "room-1", "name": "One", "x": 0, "y": 0, "width": 4, "height": 4}]})
    assert unknown.status_code == 404
    stale = TestClient(app).post("/v1/design/projects/project-1/versions", json={"name": "Stale", "previous_version": 2, "rooms": [{"id": "room-1", "name": "One", "x": 0, "y": 0, "width": 4, "height": 4}]})
    assert stale.status_code == 409
