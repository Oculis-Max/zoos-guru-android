import base64
from email import message_from_bytes

import httpx
from pydantic import SecretStr

from app.channel_connectors import OfficialOutboundConnector
from app.config import Settings


def test_gmail_uses_mime_and_official_send_endpoint() -> None:
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        return httpx.Response(200, json={"id": "gmail-1"})

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    connector = OfficialOutboundConnector(
        Settings(gmail_access_token=SecretStr("oauth-token")), client
    )
    action = {
        "channel": "email", "recipient": "person@example.com",
        "subject": "Approved subject", "content": "Approved body",
    }

    import asyncio
    result = asyncio.run(connector.send(action))
    assert result == "gmail-1"
    request = captured["request"]
    assert str(request.url).endswith("/gmail/v1/users/me/messages/send")
    raw = httpx.Response(200, content=request.content).json()["raw"]
    decoded = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))
    message = message_from_bytes(decoded)
    assert message["To"] == "person@example.com"
    assert message["Subject"] == "Approved subject"


def test_whatsapp_uses_cloud_api_text_payload() -> None:
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        return httpx.Response(200, json={"messages": [{"id": "wamid-1"}]})

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    connector = OfficialOutboundConnector(Settings(
        meta_access_token=SecretStr("meta-token"),
        whatsapp_phone_number_id="phone-id",
    ), client)

    import asyncio
    result = asyncio.run(connector.send({
        "channel": "whatsapp", "recipient": "27820000000", "content": "Approved text",
    }))
    assert result == "wamid-1"
    request = captured["request"]
    assert str(request.url).endswith("/phone-id/messages")
    payload = httpx.Response(200, content=request.content).json()
    assert payload["messaging_product"] == "whatsapp"
    assert payload["text"]["body"] == "Approved text"


def test_sms_uses_twilio_messages_api() -> None:
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["request"] = request
        return httpx.Response(201, json={"sid": "SM123"})

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    connector = OfficialOutboundConnector(Settings(
        twilio_account_sid="AC123",
        twilio_auth_token=SecretStr("token"),
        twilio_from_number="+27110000000",
    ), client)

    import asyncio
    result = asyncio.run(connector.send({
        "channel": "sms", "recipient": "+27820000000", "content": "Approved SMS",
    }))
    assert result == "SM123"
    assert str(captured["request"].url).endswith("/Accounts/AC123/Messages.json")


def test_connection_status_never_exposes_secrets() -> None:
    connector = OfficialOutboundConnector(Settings(
        gmail_access_token=SecretStr("private-token"),
        meta_access_token=SecretStr("meta-secret"),
        facebook_page_id="page-1",
    ))
    status = connector.connection_status()
    assert next(item for item in status if item["channel"] == "email")["connected"] is True
    assert next(item for item in status if item["channel"] == "facebook")["connected"] is True
    assert "private-token" not in str(status)
    assert "meta-secret" not in str(status)


def test_instagram_requires_media_instead_of_faking_success() -> None:
    connector = OfficialOutboundConnector(Settings())
    import asyncio
    try:
        asyncio.run(connector.send({"channel": "instagram", "content": "Text only"}))
        assert False, "Instagram text-only dispatch must fail"
    except RuntimeError as error:
        assert str(error) == "instagram_media_required"


def test_gmail_reader_returns_unread_message_metadata() -> None:
    requests = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        if request.url.path.endswith("/gmail/v1/users/me/messages"):
            return httpx.Response(200, json={"messages": [{"id": "m-1"}]})
        return httpx.Response(200, json={
            "id": "m-1",
            "threadId": "t-1",
            "snippet": "Can you approve this before Friday?",
            "payload": {"headers": [
                {"name": "From", "value": "Pat Example <pat@example.com>"},
                {"name": "Subject", "value": "Approval required"},
                {"name": "Date", "value": "Fri, 9 Aug 2026 09:00:00 +0200"},
            ]},
        })

    class FakeGoogleOAuth:
        async def access_token(self, uid: str) -> str:
            assert uid == "user-1"
            return "read-token"

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    connector = OfficialOutboundConnector(Settings(), client)
    connector.google_oauth = FakeGoogleOAuth()
    import asyncio
    emails = asyncio.run(connector.read_inbox("user-1"))
    assert emails == [{
        "message_id": "m-1",
        "thread_id": "t-1",
        "sender": "Pat Example",
        "sender_email": "pat@example.com",
        "subject": "Approval required",
        "received_at": "Fri, 9 Aug 2026 09:00:00 +0200",
        "snippet": "Can you approve this before Friday?",
    }]
    assert all(request.headers["authorization"] == "Bearer read-token" for request in requests)
