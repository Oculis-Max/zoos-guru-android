from app.config import Settings
from app.provider import DemoProvider, UnavailableProvider, build_provider


def test_missing_provider_fails_closed_by_default() -> None:
    provider = build_provider(Settings())
    assert isinstance(provider, UnavailableProvider)


def test_demo_provider_requires_explicit_opt_in() -> None:
    provider = build_provider(Settings(allow_demo_provider=True))
    assert isinstance(provider, DemoProvider)
