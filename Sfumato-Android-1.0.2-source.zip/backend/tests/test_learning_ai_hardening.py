import pytest
from pydantic import ValidationError

import app.learning_ai_api as learning_ai
from app.learning_ai_api import TutorFinishRequest, TutorFollowUpRequest, finish_tutor_session
from app.learning_store import InMemoryLearningStore


def test_tutor_follow_up_rejects_empty_and_oversized_input() -> None:
    with pytest.raises(ValidationError):
        TutorFollowUpRequest(mode="practice", subject="Math", topic="Algebra", lesson_context="ctx", learner_message="")
    with pytest.raises(ValidationError):
        TutorFollowUpRequest(mode="practice", subject="Math", topic="Algebra", lesson_context="x" * 16001, learner_message="answer")


def test_tutor_finish_rejects_unknown_mode() -> None:
    with pytest.raises(ValidationError):
        TutorFinishRequest(mode="unsupported", subject="Math", topic="Algebra", lesson_context="evidence")


@pytest.mark.asyncio
async def test_tutor_finish_requires_mastered_result_and_score(monkeypatch) -> None:
    async def generated(messages, claims, billing):
        return "MASTERY SCORE: 95/100; RESULT: KEEP LEARNING; Gaps remain."

    monkeypatch.setattr(learning_ai, "_generate", generated)
    store = InMemoryLearningStore()
    response = await finish_tutor_session(
        TutorFinishRequest(mode="practice", subject="Math", topic="Algebra", lesson_context="learner evidence"),
        {"uid": "learner"}, store, object()
    )
    assert response.score == 95
    assert response.passed is False
    assert store.list("learner", "tutor_results")[0]["passed"] is False
