import asyncio
from urllib.parse import parse_qs, urlparse

import httpx
from pydantic import SecretStr

from app.advanced_assistant_store import InMemoryAssistantStore
from app.config import Settings
from app.google_oauth import GMAIL_READONLY_SCOPE, GMAIL_SEND_SCOPE, GoogleOAuthService


def settings() -> Settings:
    return Settings(
        google_oauth_client_id="client.apps.googleusercontent.com",
        google_oauth_client_secret=SecretStr("client-secret"),
        assistant_token_encryption_secret=SecretStr("a" * 48),
        google_oauth_callback_url="https://api.example.com/oauth/google/callback",
    )


def test_authorization_url_is_offline_narrow_scope_and_signed() -> None:
    service = GoogleOAuthService(settings(), InMemoryAssistantStore())
    url = service.authorization_url("user-1", "owner@example.com")
    query = parse_qs(urlparse(url).query)
    assert query["access_type"] == ["offline"]
    assert query["prompt"] == ["consent"]
    assert GMAIL_SEND_SCOPE in query["scope"][0]
    assert GMAIL_READONLY_SCOPE in query["scope"][0]
    assert service.signer.verify(query["state"][0]) == "user-1"


def test_tampered_oauth_state_is_rejected() -> None:
    service = GoogleOAuthService(settings(), InMemoryAssistantStore())
    state = parse_qs(urlparse(service.authorization_url("user-1")).query)["state"][0]
    try:
        service.signer.verify(state + "tampered")
        assert False, "tampered state must fail"
    except RuntimeError as error:
        assert str(error) == "invalid_oauth_state"


def test_callback_stores_encrypted_tokens_and_returns_access_token() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={
            "access_token": "plain-access-token",
            "refresh_token": "plain-refresh-token",
            "expires_in": 3600,
            "scope": GMAIL_SEND_SCOPE,
        })

    store = InMemoryAssistantStore()
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    service = GoogleOAuthService(settings(), store, client)
    state = parse_qs(urlparse(service.authorization_url("user-1")).query)["state"][0]
    connection = asyncio.run(service.complete("authorization-code", state))
    assert connection["status"] == "connected"
    assert "plain-access-token" not in str(connection)
    assert "plain-refresh-token" not in str(connection)
    assert asyncio.run(service.access_token("user-1")) == "plain-access-token"


def test_token_exchange_failure_does_not_create_connection() -> None:
    client = httpx.AsyncClient(
        transport=httpx.MockTransport(lambda request: httpx.Response(400, json={"error": "invalid_grant"}))
    )
    store = InMemoryAssistantStore()
    service = GoogleOAuthService(settings(), store, client)
    state = parse_qs(urlparse(service.authorization_url("user-1")).query)["state"][0]
    try:
        asyncio.run(service.complete("bad-code", state))
        assert False, "failed exchange must not connect"
    except RuntimeError as error:
        assert str(error) == "gmail_oauth_exchange_failed"
    assert store.list_for_user("connections", "user-1") == []
