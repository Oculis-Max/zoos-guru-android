from fastapi.testclient import TestClient

from app.billing_api import get_billing_store
from app.billing_store import InMemoryBillingStore
from app.config import Settings, get_settings
from app.journalist_api import get_learning_store
from app.learning_store import InMemoryLearningStore
from app.main import app
from app.security import require_firebase_user


def setup_function() -> None:
    billing = InMemoryBillingStore()
    learning = InMemoryLearningStore()
    app.dependency_overrides[get_billing_store] = lambda: billing
    app.dependency_overrides[get_learning_store] = lambda: learning
    app.dependency_overrides[get_settings] = lambda: Settings(gemini_api_key="test-key", journalist_audio_enabled=True)
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "journalist-1",
        "email": "journalist@example.com",
    }


def teardown_function() -> None:
    app.dependency_overrides.clear()


def audio_request(consent: str = "true", mime: str = "audio/mp4"):
    return {
        "files": {"audio": ("interview.m4a", b"audio-data", mime)},
        "data": {"consent_confirmed": consent, "save_notes": "true"},
    }


def test_business_access_is_required() -> None:
    request = audio_request()
    response = TestClient(app).post("/v1/journalist/transcribe", **request)
    assert response.status_code == 403


def test_recording_consent_is_required_before_audio_processing() -> None:
    app.dependency_overrides[get_billing_store]().save(
        "journalist-1", {"tier": "business", "status": "active"}
    )
    request = audio_request(consent="false")
    response = TestClient(app).post("/v1/journalist/transcribe", **request)
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "recording_consent_required"


def test_unsupported_audio_is_rejected_before_provider_call() -> None:
    app.dependency_overrides[get_billing_store]().save(
        "journalist-1", {"tier": "business", "status": "active"}
    )
    request = audio_request(mime="application/pdf")
    response = TestClient(app).post("/v1/journalist/transcribe", **request)
    assert response.status_code == 415
    assert response.json()["detail"]["code"] == "unsupported_audio_format"
