from fastapi.testclient import TestClient

from app.billing_api import get_billing_store
from app.billing_store import InMemoryBillingStore
from app.config import Settings, get_settings
from app.learning_store import InMemoryLearningStore
from app.main import app
from app.security import require_firebase_user
import app.business_api as business_api


class FakeProvider:
    async def complete(self, messages):
        assert "Never send, submit, purchase" in messages[0].content
        return "Executive summary\nDraft only. Human approval required.", None


def setup_function() -> None:
    billing = InMemoryBillingStore()
    app.dependency_overrides[get_settings] = lambda: Settings(gemini_api_key="test")
    app.dependency_overrides[get_billing_store] = lambda: billing
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "business-user",
        "email": "owner@example.com",
    }
    business_api.learning_store = InMemoryLearningStore()


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_business_capabilities_cover_all_modes_and_admin_areas() -> None:
    response = TestClient(app).get("/v1/business/capabilities")
    assert response.status_code == 200
    payload = response.json()
    assert payload["modes"] == ["standard", "advanced", "emergency"]
    assert {"finance", "human_resources", "operations", "legal_compliance", "it_cybersecurity"} <= set(
        payload["areas"]
    )
    assert "sop" in payload["documents"]
    assert len(payload["approval_categories"]) == 7


def test_non_business_user_is_blocked() -> None:
    response = TestClient(app).post(
        "/v1/business/assistant",
        json={"task": "Prepare a complete monthly operations report"},
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "business_plan_required"


def test_business_user_receives_draft_with_audit(monkeypatch) -> None:
    billing = app.dependency_overrides[get_billing_store]()
    billing.save("business-user", {"tier": "business", "status": "active"})
    monkeypatch.setattr(business_api, "build_provider", lambda _settings: FakeProvider())

    response = TestClient(app).post(
        "/v1/business/assistant",
        json={
            "mode": "advanced",
            "area": "operations",
            "task": "Prepare a complete monthly operations report",
            "organization_context": "A small South African services company",
            "document_type": "report",
        },
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["execution_status"] == "draft_only"
    assert payload["mode"] == "advanced"
    assert payload["approvals_required"]
    assert business_api.learning_store.list("business-user", "business_runs")
    assert business_api.learning_store.audit_events[0]["event_type"] == "business.assistant.draft_created"
