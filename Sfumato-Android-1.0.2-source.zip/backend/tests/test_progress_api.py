from fastapi.testclient import TestClient

from app.learning_store import InMemoryLearningStore
from app.billing_api import require_student_entitlement
from app.main import app
from app.progress_api import get_learning_store, get_progress_store
from app.progress_store import InMemoryProgressStore
from app.security import require_firebase_user


claims = {"uid": "student-1", "email": "student@example.com", "name": "Student One"}


def setup_function() -> None:
    global claims
    claims = {"uid": "student-1", "email": "student@example.com", "name": "Student One"}
    progress = InMemoryProgressStore()
    learning = InMemoryLearningStore()
    app.dependency_overrides[require_firebase_user] = lambda: claims
    app.dependency_overrides[require_student_entitlement] = lambda: claims
    app.dependency_overrides[get_progress_store] = lambda: progress
    app.dependency_overrides[get_learning_store] = lambda: learning


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_own_summary_exposes_counts_not_private_content() -> None:
    learning = app.dependency_overrides[get_learning_store]()
    learning.create("student-1", "tutor_sessions", {"private_answer": "Never share this"})
    learning.create("student-1", "debate_sessions", {"private_prompt": "Never share this either"})

    response = TestClient(app).get("/v1/progress/summary")
    assert response.status_code == 200
    payload = response.json()
    assert payload["total_activities"] == 2
    assert "private_answer" not in response.text
    assert "private_prompt" not in response.text
    assert "never included" in payload["privacy_notice"]


def test_subject_can_grant_and_revoke_parent_access() -> None:
    client = TestClient(app)
    created = client.post("/v1/progress/shares", json={
        "viewer_email": "parent@example.com",
        "viewer_role": "parent",
        "subject_name": "Student One",
        "categories": ["learning", "debate"],
    })
    assert created.status_code == 200
    share_id = created.json()["id"]

    global claims
    claims = {"uid": "parent-1", "email": "parent@example.com"}
    assert client.get("/v1/progress/viewer").json()[0]["id"] == share_id
    assert client.get(f"/v1/progress/viewer/{share_id}/summary").status_code == 200

    claims = {"uid": "student-1", "email": "student@example.com"}
    assert client.delete(f"/v1/progress/shares/{share_id}").status_code == 204

    claims = {"uid": "parent-1", "email": "parent@example.com"}
    assert client.get(f"/v1/progress/viewer/{share_id}/summary").status_code == 403


def test_uninvited_employer_cannot_view_progress() -> None:
    client = TestClient(app)
    created = client.post("/v1/progress/shares", json={
        "viewer_email": "approved@company.co.za",
        "viewer_role": "employer",
        "subject_name": "Employee One",
        "categories": ["coding", "business"],
    })
    share_id = created.json()["id"]

    global claims
    claims = {"uid": "other-employer", "email": "other@company.co.za"}
    response = client.get(f"/v1/progress/viewer/{share_id}/summary")
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "progress_access_denied"


def test_cannot_share_dashboard_with_same_account() -> None:
    response = TestClient(app).post("/v1/progress/shares", json={
        "viewer_email": "student@example.com",
        "viewer_role": "parent",
        "subject_name": "Student One",
        "categories": ["learning"],
    })
    assert response.status_code == 400


def test_teacher_can_leave_private_feedback_for_shared_learner() -> None:
    client = TestClient(app)
    created = client.post("/v1/progress/shares", json={
        "viewer_email": "teacher@example.com",
        "viewer_role": "teacher",
        "subject_name": "Student One",
        "categories": ["learning"],
    })
    share_id = created.json()["id"]

    global claims
    claims = {"uid": "teacher-1", "email": "teacher@example.com"}
    feedback = client.post(
        f"/v1/progress/viewer/{share_id}/feedback",
        json={"message": "Strong effort this week.", "action": "Complete one algebra practice set."},
    )
    assert feedback.status_code == 200
    assert feedback.json()["author_role"] == "teacher"

    claims = {"uid": "student-1", "email": "student@example.com"}
    learner_feedback = client.get("/v1/progress/feedback")
    assert learner_feedback.status_code == 200
    assert learner_feedback.json()[0]["message"] == "Strong effort this week."


def test_parent_cannot_create_educator_feedback() -> None:
    client = TestClient(app)
    created = client.post("/v1/progress/shares", json={
        "viewer_email": "parent@example.com",
        "viewer_role": "parent",
        "subject_name": "Student One",
        "categories": ["learning"],
    })
    share_id = created.json()["id"]

    global claims
    claims = {"uid": "parent-1", "email": "parent@example.com"}
    response = client.post(
        f"/v1/progress/viewer/{share_id}/feedback",
        json={"message": "Attempted feedback"},
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "educator_role_required"
