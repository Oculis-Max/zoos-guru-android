from pydantic import ValidationError
import pytest

from app.learning_ai_api import TutorFinishRequest, TutorFollowUpRequest
from app.learning_api import TutorSessionCreate


def test_tutor_requests_preserve_grade_and_curriculum_context() -> None:
    session = TutorSessionCreate(
        mode="lesson",
        subject="Mathematics",
        topic="Algebra",
        grade="Grade 8",
        curriculum="CAPS",
    )
    follow_up = TutorFollowUpRequest(
        mode="lesson",
        subject="Mathematics",
        topic="Algebra",
        grade="Grade 8",
        curriculum="CAPS",
        lesson_context="Tutor introduced variables.",
        learner_message="Why does x represent a number?",
    )
    finish = TutorFinishRequest(
        mode="lesson",
        subject="Mathematics",
        topic="Algebra",
        grade="Grade 8",
        curriculum="CAPS",
        lesson_context="Completed lesson.",
    )

    assert session.curriculum == follow_up.curriculum == finish.curriculum == "CAPS"
    assert session.grade == follow_up.grade == finish.grade == "Grade 8"


def test_tutor_curriculum_length_is_bounded() -> None:
    with pytest.raises(ValidationError):
        TutorSessionCreate(
            mode="lesson",
            subject="Mathematics",
            topic="Algebra",
            grade="Grade 8",
            curriculum="x" * 61,
        )
