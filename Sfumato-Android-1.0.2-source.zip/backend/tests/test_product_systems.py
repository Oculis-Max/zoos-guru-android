from datetime import UTC, date, datetime, timedelta

import pytest
from fastapi.testclient import TestClient

from app.accounts import account_store
from app.analytics import AnalyticsEvent
from app.main import app
from app.scholarships import Scholarship, scholarship_store


client = TestClient(app)


@pytest.fixture(autouse=True)
def clear_stores() -> None:
    account_store.identities.clear()
    account_store.profiles.clear()
    scholarship_store.scholarships.clear()
    scholarship_store.applications.clear()


def create_profile() -> str:
    identity = client.post("/v1/identities/guest").json()
    identity_id = identity["id"]
    response = client.put(
        f"/v1/profiles/{identity_id}",
        json={
            "identity_id": identity_id,
            "country_code": "ZA",
            "school_level": "university",
            "subjects": ["Computer Science"],
            "career_interests": ["Technology"],
            "citizenship_country_codes": ["ZA"],
        },
    )
    assert response.status_code == 200
    return identity_id


def test_guest_profile_and_free_entitlement() -> None:
    identity_id = create_profile()
    profile = client.get(f"/v1/profiles/{identity_id}")
    entitlement = client.get(f"/v1/entitlements/{identity_id}")
    assert profile.json()["profile_complete"] is True
    assert entitlement.json()["plan"] == "free"
    assert entitlement.json()["source"] == "local_default"


def test_search_match_bookmark_and_application_status() -> None:
    identity_id = create_profile()
    scholarship = Scholarship(
        title="African Technology Scholars",
        provider="Example University",
        country_codes=["ZA"],
        citizenship_country_codes=["ZA"],
        school_levels=["university"],
        subjects=["Computer Science", "Technology"],
        deadline=date.today() + timedelta(days=60),
        financial_need_supported=True,
        required_documents=["transcript"],
        source_url="https://www.nrf.ac.za/nrf-for-post-graduate-students/bursaries-scholarships/",
        source_verified_at=datetime.now(UTC),
    )
    scholarship_store.upsert_verified(scholarship)
    results = client.post("/v1/scholarships/search", json={"country_code": "ZA"})
    match = client.get(f"/v1/scholarships/{scholarship.id}/match/{identity_id}")
    application = client.put(
        "/v1/applications",
        json={
            "identity_id": identity_id,
            "scholarship_id": str(scholarship.id),
            "status": "preparing",
            "bookmarked": True,
        },
    )
    assert len(results.json()) == 1
    assert match.json()["score"] == 100
    assert len(match.json()["factors"]) == 6
    assert "never guarantees" in match.json()["disclaimer"]
    assert application.json()["status"] == "preparing"


def test_analytics_accepts_only_safe_categorical_dimensions() -> None:
    response = client.post(
        "/v1/analytics/events",
        json={"name": "scholarship_viewed", "dimensions": {"screen": "search"}},
    )
    assert response.status_code == 202
    with pytest.raises(ValueError):
        AnalyticsEvent(
            name="chat_send_succeeded",
            dimensions={"prompt": "My private scholarship essay"},
        )


def test_profile_requires_existing_guest_identity() -> None:
    response = client.put(
        "/v1/profiles/00000000-0000-0000-0000-000000000001",
        json={
            "identity_id": "00000000-0000-0000-0000-000000000001",
            "country_code": "ZA",
            "school_level": "high_school",
        },
    )
    assert response.status_code == 404


def test_search_hides_expired_and_unverified_records() -> None:
    expired = Scholarship(
        title="Expired official opportunity",
        provider="NSFAS",
        country_codes=["ZA"],
        school_levels=["university"],
        deadline=date.today() - timedelta(days=1),
        source_url="https://www.nsfas.org.za/content/how-to-apply.html",
        source_verified_at=datetime.now(UTC),
    )
    current_unverified = Scholarship(
        title="Needs editorial review",
        provider="Example",
        country_codes=["ZA"],
        school_levels=["university"],
        deadline=date.today() + timedelta(days=30),
        source_url="https://example.org/bursary",
    )
    scholarship_store.upsert_verified(expired)
    scholarship_store.scholarships[current_unverified.id] = current_unverified

    response = client.post("/v1/scholarships/search", json={"country_code": "ZA"})

    assert response.status_code == 200
    assert response.json() == []


def test_ingestion_rejects_non_official_source_domains() -> None:
    record = Scholarship(
        title="Untrusted listing",
        provider="Unknown",
        country_codes=["ZA"],
        school_levels=["university"],
        deadline=date.today() + timedelta(days=30),
        source_url="https://example.org/bursary",
        source_verified_at=datetime.now(UTC),
    )

    with pytest.raises(ValueError, match="approved official domain"):
        scholarship_store.upsert_verified(record)
