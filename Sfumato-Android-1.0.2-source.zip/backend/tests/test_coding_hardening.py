from fastapi import HTTPException
import pytest

from app.coding_agent_api import (
    ProposedChangeSet,
    ProposedFile,
    _normalise_safe_path,
    _parse_change_set,
    _task_hash,
    _validate_change_set,
    _validate_content,
)
from app.learning_store import InMemoryLearningStore


def test_normal_source_and_test_paths_are_allowed() -> None:
    assert _normalise_safe_path("app/src/main/Feature.kt") == "app/src/main/Feature.kt"
    assert _normalise_safe_path("tests/test_feature.py") == "tests/test_feature.py"


@pytest.mark.parametrize(
    "path",
    [
        "../outside.py",
        "/absolute/file.py",
        ".github/workflows/release.yml",
        "scripts/deploy.sh",
        "keys/service-account.json",
    ],
)
def test_sensitive_or_executable_paths_are_blocked(path: str) -> None:
    with pytest.raises(HTTPException) as error:
        _normalise_safe_path(path)
    assert error.value.status_code == 422


def test_build_and_dependency_manifests_are_allowed() -> None:
    assert _normalise_safe_path("app/build.gradle.kts") == "app/build.gradle.kts"
    assert _normalise_safe_path("package.json") == "package.json"
    assert _normalise_safe_path("requirements.txt") == "requirements.txt"


def test_delete_requires_existing_file_and_no_content() -> None:
    valid = ProposedChangeSet(
        summary="remove obsolete code",
        files=[ProposedFile(path="src/Old.kt", operation="delete", content="")],
    )
    result = _validate_change_set(valid, existing_paths={"src/Old.kt"})
    assert result[0].operation == "delete"

    with pytest.raises(HTTPException) as error:
        _validate_change_set(valid, existing_paths={"src/Other.kt"})
    assert error.value.detail["code"] == "delete_target_not_found"


def test_duplicate_paths_are_rejected_case_insensitively() -> None:
    change_set = ProposedChangeSet(
        summary="duplicate",
        files=[
            ProposedFile(path="src/Feature.kt", content="class Feature"),
            ProposedFile(path="src/feature.kt", content="class Other"),
        ],
    )
    with pytest.raises(HTTPException) as error:
        _validate_change_set(change_set)
    assert error.value.detail["code"] == "duplicate_file_change"


def test_private_key_material_is_rejected() -> None:
    with pytest.raises(HTTPException) as error:
        _validate_content(
            "-----BEGIN PRIVATE KEY-----\nnot-a-real-key\n-----END PRIVATE KEY-----"
        )
    assert error.value.detail["code"] == "possible_secret_in_change"


def test_approval_hash_is_bound_to_repository_commit_task_and_plan() -> None:
    original = _task_hash("owner/repo", "main", "abc123", "Fix bug", "Plan A")
    assert original == _task_hash("owner/repo", "main", "abc123", "Fix bug", "Plan A")
    assert original != _task_hash("owner/repo", "main", "changed", "Fix bug", "Plan A")
    assert original != _task_hash("owner/repo", "main", "abc123", "Different", "Plan A")
    changed_preview = [{"path": "src/App.kt", "operation": "upsert", "content": "new"}]
    assert original != _task_hash(
        "owner/repo", "main", "abc123", "Fix bug", "Plan A", changed_preview
    )


def test_task_claim_is_single_use() -> None:
    store = InMemoryLearningStore()
    task = store.create("user-1", "coding_tasks", {"status": "planned"})
    assert store.claim("user-1", "coding_tasks", task["id"], "planned", "applying")
    assert not store.claim("user-1", "coding_tasks", task["id"], "planned", "applying")
    assert store.get("user-1", "coding_tasks", task["id"])["status"] == "applying"


def test_disconnect_storage_delete_all_removes_connections() -> None:
    store = InMemoryLearningStore()
    store.create("user-1", "github_connections", {"encrypted_token": "one"})
    store.create("user-1", "github_connections", {"encrypted_token": "two"})
    store.delete_all("user-1", "github_connections")
    assert store.list("user-1", "github_connections") == []


def test_valid_json_code_fence_from_provider_is_accepted() -> None:
    change_set = _parse_change_set(
        """```json
{"summary":"safe fix","files":[{"path":"src/App.kt","operation":"upsert","content":"class App"}]}
```"""
    )
    assert change_set.summary == "safe fix"
    assert change_set.files[0].path == "src/App.kt"
