from app.learning import (
    DebateScore,
    DebateStage,
    OverallScoreInputs,
    overall_higuru_score,
    stage_unlocked,
)


def test_debate_score_totals_to_one_hundred() -> None:
    score = DebateScore(
        reasoning=25,
        evidence=20,
        rebuttal=15,
        opposing_view=15,
        clarity=10,
        cross_examination=10,
        civility=5,
    )
    assert score.total == 100


def test_overall_score_is_not_debate_only() -> None:
    score = overall_higuru_score(
        OverallScoreInputs(
            debate_mastery=100,
            tutor_mastery=50,
            scholarship_readiness=50,
            completed_goals=50,
            research_quality=50,
            responsible_participation=50,
        )
    )
    assert score == 70


def test_grandmaster_requires_debate_and_overall_mastery() -> None:
    assert stage_unlocked(DebateStage.GRANDMASTER, 95, 85)
    assert not stage_unlocked(DebateStage.GRANDMASTER, 95, 79)
    assert not stage_unlocked(DebateStage.GRANDMASTER, 89, 95)
