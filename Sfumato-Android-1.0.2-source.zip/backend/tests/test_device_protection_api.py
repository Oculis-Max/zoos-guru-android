from datetime import UTC, datetime, timedelta

import pytest
from fastapi import HTTPException

from app.device_protection_api import _hash_secret, _require_recent_auth


def test_device_secret_hash_is_deterministic_and_not_plaintext():
    hashed = _hash_secret("owner-device-secret")
    assert hashed == _hash_secret("owner-device-secret")
    assert hashed != "owner-device-secret"
    assert len(hashed) == 64


def test_remote_lock_requires_recent_authentication():
    old = datetime.now(UTC) - timedelta(minutes=6)
    with pytest.raises(HTTPException) as raised:
        _require_recent_auth({"auth_time": int(old.timestamp())})
    assert raised.value.status_code == 403
    assert raised.value.detail["code"] == "recent_authentication_required"


def test_recent_authentication_is_accepted():
    current = datetime.now(UTC) - timedelta(seconds=30)
    _require_recent_auth({"auth_time": int(current.timestamp())})
