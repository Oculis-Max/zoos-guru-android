import pytest

import app.learning_ai_api as learning_ai
from app.learning_ai_api import TutorFinishRequest, finish_tutor_session
from app.learning_store import InMemoryLearningStore


@pytest.mark.asyncio
async def test_tutor_finish_saves_mastery_for_authenticated_learner(monkeypatch) -> None:
    async def generated(messages, claims, billing):
        return (
            "MASTERY SCORE: 82/100; RESULT: MASTERED; "
            "Strengths: reasoning and accuracy. Gaps: notation and checking."
        )

    monkeypatch.setattr(learning_ai, "_generate", generated)
    store = InMemoryLearningStore()
    response = await finish_tutor_session(
        TutorFinishRequest(
            mode="practice",
            subject="Mathematics",
            topic="Algebra",
            grade="10",
            lesson_context="TUTOR: Solve x + 2 = 5. LEARNER: x = 3 because I subtract 2.",
        ),
        {"uid": "learner-1"},
        store,
        object(),
    )
    assert response.score == 82
    assert response.passed is True
    saved = store.list("learner-1", "tutor_results")
    assert saved[0]["mastery"] == 82
    assert saved[0]["topic"] == "Algebra"


@pytest.mark.asyncio
async def test_tutor_mastery_is_clamped_and_defaults_safely(monkeypatch) -> None:
    async def generated(messages, claims, billing):
        return "Assessment unavailable in expected format. Keep practising."

    monkeypatch.setattr(learning_ai, "_generate", generated)
    response = await finish_tutor_session(
        TutorFinishRequest(
            mode="lesson",
            subject="Science",
            topic="Cells",
            lesson_context="TUTOR: What is a cell? LEARNER: I am not sure.",
        ),
        {"uid": "learner-2"},
        InMemoryLearningStore(),
        object(),
    )
    assert response.score == 0
    assert response.passed is False
