from fastapi.testclient import TestClient

from app.learning import DebateStage, highest_unlocked_stage
from app.learning_api import get_learning_store, require_judge_service
from app.learning_store import InMemoryLearningStore
from app.billing_api import require_student_entitlement
from app.main import app
from app.security import require_firebase_user


def _client(uid: str = "student-1") -> tuple[TestClient, InMemoryLearningStore]:
    store = InMemoryLearningStore()
    app.dependency_overrides[require_firebase_user] = lambda: {"uid": uid}
    app.dependency_overrides[require_student_entitlement] = lambda: {"uid": uid}
    app.dependency_overrides[get_learning_store] = lambda: store
    app.dependency_overrides[require_judge_service] = lambda: None
    return TestClient(app), store


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_learning_endpoints_require_authentication() -> None:
    client = TestClient(app)
    response = client.get("/v1/learning/arena/status")
    assert response.status_code == 401


def test_tutor_results_are_scoped_and_audited() -> None:
    client, store = _client()
    session = client.post(
        "/v1/learning/tutor/sessions",
        json={"mode": "diagnostic", "subject": "Mathematics", "topic": "Algebra", "grade": "10"},
    )
    assert session.status_code == 201
    result = client.post(
        "/v1/learning/tutor/results",
        json={
            "session_id": session.json()["id"],
            "questions_attempted": 10,
            "questions_correct": 8,
            "mastery": 80,
        },
    )
    assert result.status_code == 201
    assert client.get("/v1/learning/tutor/results").json()[0]["user_id"] == "student-1"
    assert [event["event_type"] for event in store.audit_events] == [
        "tutor.session.created",
        "tutor.result.recorded",
    ]


def test_stage_five_requires_both_debate_and_overall_scores() -> None:
    client, store = _client()
    attempt = store.create(
        "student-1",
        "debate_attempts",
        {"topic": "Energy policy", "stage": 4, "position": "for"},
    )
    score = {
        "reasoning": 25,
        "evidence": 20,
        "rebuttal": 15,
        "opposing_view": 15,
        "clarity": 10,
        "cross_examination": 10,
        "civility": 5,
    }
    high_inputs = {
        "debate_mastery": 100,
        "tutor_mastery": 100,
        "scholarship_readiness": 100,
        "completed_goals": 100,
        "research_quality": 100,
        "responsible_participation": 100,
    }
    response = client.post(
        "/v1/learning/arena/results",
        json={
            "attempt_id": attempt["id"],
            "score": score,
            "overall_inputs": high_inputs,
            "judge_summary": "Verified structured evaluation.",
            "judge_model": "separate-judge-model",
        },
    )
    assert response.status_code == 201
    status = client.get("/v1/learning/arena/status").json()
    assert status == {
        "highest_unlocked_stage": 5,
        "best_debate_score": 100,
        "overall_higuru_score": 100,
    }
    stage_five = client.post(
        "/v1/learning/arena/attempts",
        json={"topic": "Energy policy", "stage": 5, "position": "against"},
    )
    assert stage_five.status_code == 201
    assert store.audit_events[-1]["event_type"] == "arena.attempt.created"


def test_user_cannot_score_another_users_attempt() -> None:
    client, store = _client()
    other = store.create(
        "student-2",
        "debate_attempts",
        {"topic": "Education", "stage": 1, "position": "for"},
    )
    response = client.post(
        "/v1/learning/arena/results",
        json={
            "attempt_id": other["id"],
            "score": {
                "reasoning": 1,
                "evidence": 1,
                "rebuttal": 1,
                "opposing_view": 1,
                "clarity": 1,
                "cross_examination": 1,
                "civility": 1,
            },
            "overall_inputs": {
                "debate_mastery": 1,
                "tutor_mastery": 1,
                "scholarship_readiness": 1,
                "completed_goals": 1,
                "research_quality": 1,
                "responsible_participation": 1,
            },
            "judge_summary": "No cross-user access.",
            "judge_model": "judge",
        },
    )
    assert response.status_code == 404


def test_each_verified_stage_pass_unlocks_the_next_stage() -> None:
    results: list[dict] = []
    for stage, pass_score in ((1, 60), (2, 70), (3, 80), (4, 90)):
        results.append({"stage": stage, "total": pass_score, "passed": True})
        assert highest_unlocked_stage(results) == DebateStage(stage + 1)


def test_failed_stage_does_not_unlock_the_next_stage() -> None:
    assert highest_unlocked_stage(
        [{"stage": 1, "total": 59, "passed": False}]
    ) == DebateStage.FOUNDATION
