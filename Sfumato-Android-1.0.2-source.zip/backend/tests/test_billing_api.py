import hashlib
import hmac
import json
from datetime import UTC, datetime, timedelta
from typing import Any

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

from app.billing_api import (
    FREE_DAILY_PROMPT_LIMIT,
    enforce_chat_access,
    get_billing_store,
    get_paystack_gateway,
    get_voucher_store,
    require_business_entitlement,
    require_security_entitlement,
    require_student_entitlement,
)
from app.billing_store import InMemoryBillingStore
from app.config import Settings, get_settings
from app.main import app
from app.security import require_firebase_user
from app.voucher_store import InMemoryVoucherStore


TEST_SETTINGS = Settings(
    paystack_secret_key="test-secret",
    paystack_student_plan_code="PLN_student",
    paystack_developer_plan_code="PLN_developer",
    paystack_business_plan_code="PLN_business",
)


class FakeGateway:
    async def initialize(self, email: str, uid: str, plan_code: str, tier: Any) -> dict[str, str]:
        assert email == "student@example.com"
        assert uid == "student-1"
        assert plan_code == "PLN_developer"
        return {"authorization_url": "https://checkout.example/session", "reference": "ref-1"}

    async def verify(self, reference: str) -> dict[str, Any]:
        assert reference == "ref-1"
        return {
            "status": "success",
            "reference": reference,
            "amount": 100000,
            "currency": "ZAR",
            "plan": "PLN_developer",
            "metadata": {"higuru_uid": "student-1", "higuru_tier": "developer"},
            "customer": {"customer_code": "CUS_1"},
            "paid_at": "2026-07-23T18:00:00Z",
        }


def _store() -> InMemoryBillingStore:
    return app.dependency_overrides[get_billing_store]()


def setup_function() -> None:
    store = InMemoryBillingStore()
    voucher_store = InMemoryVoucherStore()
    app.dependency_overrides[get_settings] = lambda: TEST_SETTINGS
    app.dependency_overrides[get_paystack_gateway] = lambda: FakeGateway()
    app.dependency_overrides[get_billing_store] = lambda: store
    app.dependency_overrides[get_voucher_store] = lambda: voucher_store


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_catalog_has_locked_prices_and_developer_coding() -> None:
    plans = TestClient(app).get("/v1/billing/plans")
    assert plans.status_code == 200
    by_tier = {plan["tier"]: plan for plan in plans.json()}
    assert by_tier["free"]["amount_zar"] == 0
    assert by_tier["student"]["amount_zar"] == 200
    assert by_tier["developer"]["amount_zar"] == 1000
    assert by_tier["developer"]["autonomous_coding"] is True
    assert by_tier["business"]["amount_zar"] == 5000
    assert by_tier["business"]["autonomous_coding"] is False


def test_checkout_requires_firebase_authentication() -> None:
    response = TestClient(app).post("/v1/billing/checkout", json={"tier": "student"})
    assert response.status_code == 401


def test_unverified_email_cannot_start_paid_checkout() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "unverified-1",
        "email": "unverified@example.com",
        "email_verified": False,
    }
    response = TestClient(app).post("/v1/billing/checkout", json={"tier": "developer"})
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "verified_email_required"


def test_authenticated_checkout_is_bound_to_user_and_plan() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "student-1",
        "email": "student@example.com",
        "email_verified": True,
    }
    response = TestClient(app).post("/v1/billing/checkout", json={"tier": "developer"})
    assert response.status_code == 200
    assert response.json() == {
        "tier": "developer",
        "checkout_url": "https://checkout.example/session",
        "reference": "ref-1",
    }


def test_valid_signed_payment_activates_entitlement() -> None:
    raw = json.dumps({"event": "charge.success", "data": {"reference": "ref-1"}}, separators=(",", ":")).encode()
    signature = hmac.new(b"test-secret", raw, hashlib.sha512).hexdigest()
    response = TestClient(app).post(
        "/v1/billing/webhooks/paystack",
        content=raw,
        headers={"content-type": "application/json", "x-paystack-signature": signature},
    )
    assert response.status_code == 200
    record = _store().get("student-1")
    assert record is not None
    assert record["tier"] == "developer"
    assert record["status"] == "active"
    assert _store().audit_events[0]["event_type"] == "billing.payment.activated"


def test_payment_with_wrong_amount_cannot_activate_entitlement() -> None:
    class WrongAmountGateway(FakeGateway):
        async def verify(self, reference: str) -> dict[str, Any]:
            payload = await super().verify(reference)
            payload["amount"] = 1
            return payload

    app.dependency_overrides[get_paystack_gateway] = lambda: WrongAmountGateway()
    raw = json.dumps(
        {"event": "charge.success", "data": {"reference": "ref-1"}},
        separators=(",", ":"),
    ).encode()
    signature = hmac.new(b"test-secret", raw, hashlib.sha512).hexdigest()
    response = TestClient(app).post(
        "/v1/billing/webhooks/paystack",
        content=raw,
        headers={"content-type": "application/json", "x-paystack-signature": signature},
    )
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "payment_amount_mismatch"
    assert _store().get("student-1") is None


def test_payment_with_mismatched_tier_cannot_activate_entitlement() -> None:
    class WrongTierGateway(FakeGateway):
        async def verify(self, reference: str) -> dict[str, Any]:
            payload = await super().verify(reference)
            payload["metadata"]["higuru_tier"] = "business"
            return payload

    app.dependency_overrides[get_paystack_gateway] = lambda: WrongTierGateway()
    raw = json.dumps(
        {"event": "charge.success", "data": {"reference": "ref-1"}},
        separators=(",", ":"),
    ).encode()
    signature = hmac.new(b"test-secret", raw, hashlib.sha512).hexdigest()
    response = TestClient(app).post(
        "/v1/billing/webhooks/paystack",
        content=raw,
        headers={"content-type": "application/json", "x-paystack-signature": signature},
    )
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "payment_identity_mismatch"
    assert _store().get("student-1") is None


def test_invalid_webhook_signature_is_rejected() -> None:
    response = TestClient(app).post(
        "/v1/billing/webhooks/paystack",
        content=b'{"event":"charge.success"}',
        headers={"content-type": "application/json", "x-paystack-signature": "wrong"},
    )
    assert response.status_code == 401


def test_free_plan_cannot_open_checkout() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {"uid": "student-1"}
    response = TestClient(app).post("/v1/billing/checkout", json={"tier": "free"})
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "free_plan_has_no_checkout"


def test_only_developer_plan_unlocks_autonomous_coding() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "developer-1",
        "email": "developer@example.com",
    }
    store = _store()
    store.save("developer-1", {"tier": "developer", "status": "active"})
    response = TestClient(app).get("/v1/billing/entitlement")
    assert response.status_code == 200
    assert response.json()["autonomous_coding"] is True

    store.save("developer-1", {"tier": "business", "status": "active"})
    business = TestClient(app).get("/v1/billing/entitlement")
    assert business.status_code == 200
    assert business.json()["autonomous_coding"] is False


def test_free_accounts_are_limited_to_twenty_prompts_per_utc_day() -> None:
    claims = {"uid": "free-prompts-1"}
    store = _store()
    for _ in range(FREE_DAILY_PROMPT_LIMIT):
        assert enforce_chat_access(claims, store) == claims

    with pytest.raises(HTTPException) as error:
        enforce_chat_access(claims, store)
    assert error.value.status_code == 429
    assert error.value.detail["code"] == "free_daily_prompt_limit"
    assert error.value.detail["limit"] == 20


def test_active_paid_accounts_do_not_consume_the_free_prompt_allowance() -> None:
    claims = {"uid": "paid-chat-1"}
    store = _store()
    store.save("paid-chat-1", {"tier": "student", "status": "active"})
    for _ in range(25):
        assert enforce_chat_access(claims, store) == claims
    assert store.prompt_usage == {}


def test_specialist_plans_are_exact_and_not_hierarchical() -> None:
    store = _store()
    student = {"uid": "student-exact-1"}
    business = {"uid": "business-exact-1"}
    store.save(student["uid"], {"tier": "student", "status": "active"})
    store.save(business["uid"], {"tier": "business", "status": "active"})

    assert require_student_entitlement(student, store) == student
    assert require_business_entitlement(business, store) == business
    with pytest.raises(HTTPException):
        require_business_entitlement(student, store)
    with pytest.raises(HTTPException):
        require_student_entitlement(business, store)


def test_cyber_safety_is_shared_only_by_developer_and_business() -> None:
    store = _store()
    developer = {"uid": "security-developer-1"}
    business = {"uid": "security-business-1"}
    student = {"uid": "security-student-1"}
    store.save(developer["uid"], {"tier": "developer", "status": "active"})
    store.save(business["uid"], {"tier": "business", "status": "active"})
    store.save(student["uid"], {"tier": "student", "status": "active"})

    assert require_security_entitlement(developer, store) == developer
    assert require_security_entitlement(business, store) == business
    with pytest.raises(HTTPException) as error:
        require_security_entitlement(student, store)
    assert error.value.detail["code"] == "security_plan_required"


def test_expired_sponsored_student_access_is_rejected() -> None:
    claims = {"uid": "expired-learner-1"}
    _store().save(
        claims["uid"],
        {
            "tier": "student",
            "status": "active",
            "source": "sponsored_voucher",
            "sponsored_until": datetime.now(UTC) - timedelta(seconds=1),
        },
    )
    with pytest.raises(HTTPException) as error:
        require_student_entitlement(claims, _store())
    assert error.value.status_code == 403
    assert error.value.detail["code"] == "student_plan_required"


def test_free_user_cannot_run_autonomous_coding() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "free-1",
        "email": "student@example.com",
    }
    response = TestClient(app).post(
        "/v1/coding/tasks/plan",
        json={"repository": "bookingdiallocarnal-del/uilis5", "task": "Update the readme safely"},
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "autonomous_coding_plan_required"


def test_business_user_cannot_run_developer_coding_agent() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "business-coding-1",
        "email": "owner@example.com",
    }
    _store().save("business-coding-1", {"tier": "business", "status": "active"})
    response = TestClient(app).post(
        "/v1/coding/tasks/plan",
        json={"repository": "bookingdiallocarnal-del/uilis5", "task": "Update the readme safely"},
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "autonomous_coding_plan_required"


def test_unverified_email_cannot_redeem_sponsored_voucher() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "unverified-learner",
        "email_verified": False,
    }
    response = TestClient(app).post(
        "/v1/billing/vouchers/redeem",
        json={
            "code": "HIGURU-ABCDE-FGHIJ-KLMNP",
            "institution": "School",
            "education_level": "High school",
            "subjects": ["Mathematics"],
        },
    )
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "verified_email_required"


def test_sponsored_voucher_activates_student_plan_and_profile() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {
        "uid": "learner-1",
        "email": "learner@example.com",
        "email_verified": True,
    }
    voucher_store = app.dependency_overrides[get_voucher_store]()
    voucher_store.add(
        "HIGURU-ABCDE-FGHIJ-KLMNP",
        campaign_id="sponsor-2000-match-2000",
        sponsor="Example Sponsor",
        funding_source="sponsor",
    )
    response = TestClient(app).post(
        "/v1/billing/vouchers/redeem",
        json={
            "code": "higuru abcde fghij klmnp",
            "institution": "Upington High School",
            "education_level": "High school",
            "grade": "Grade 10",
            "curriculum": "CAPS",
            "subjects": ["Mathematics", "Physical Sciences"],
        },
    )
    assert response.status_code == 200
    assert response.json()["tier"] == "student"
    assert voucher_store.entitlements["learner-1"]["status"] == "active"
    assert voucher_store.profiles["learner-1"]["grade"] == "Grade 10"


def test_sponsored_voucher_is_single_user_but_idempotent_for_owner() -> None:
    voucher_store = app.dependency_overrides[get_voucher_store]()
    voucher_store.add("HIGURU-22222-33333-44444", campaign_id="campaign-1")
    profile = {
        "code": "HIGURU-22222-33333-44444",
        "institution": "Northern Cape High School",
        "education_level": "High school",
        "grade": "Grade 11",
        "subjects": ["English"],
    }
    app.dependency_overrides[require_firebase_user] = lambda: {"uid": "learner-owner", "email_verified": True}
    first = TestClient(app).post("/v1/billing/vouchers/redeem", json=profile)
    retry = TestClient(app).post("/v1/billing/vouchers/redeem", json=profile)
    assert first.status_code == 200
    assert retry.status_code == 200

    app.dependency_overrides[require_firebase_user] = lambda: {"uid": "different-learner", "email_verified": True}
    stolen = TestClient(app).post("/v1/billing/vouchers/redeem", json=profile)
    assert stolen.status_code == 400
    assert stolen.json()["detail"]["code"] == "voucher_already_redeemed"


def test_invalid_voucher_returns_generic_safe_error() -> None:
    app.dependency_overrides[require_firebase_user] = lambda: {"uid": "learner-2", "email_verified": True}
    response = TestClient(app).post(
        "/v1/billing/vouchers/redeem",
        json={
            "code": "HIGURU-WRONG-CODE-00000",
            "institution": "College",
            "education_level": "College",
            "subjects": [],
        },
    )
    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "invalid_voucher"
