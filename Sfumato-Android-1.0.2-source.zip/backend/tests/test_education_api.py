from fastapi.testclient import TestClient

from app.education_api import get_education_store
from app.education_store import InMemoryEducationStore
from app.billing_api import require_student_entitlement
from app.main import app
from app.security import require_firebase_user


claims = {"uid": "teacher-1", "email": "teacher@example.com", "name": "Teacher One"}


def setup_function() -> None:
    global claims
    claims = {"uid": "teacher-1", "email": "teacher@example.com", "name": "Teacher One"}
    store = InMemoryEducationStore()
    app.dependency_overrides[require_firebase_user] = lambda: claims
    app.dependency_overrides[require_student_entitlement] = lambda: claims
    app.dependency_overrides[get_education_store] = lambda: store


def teardown_function() -> None:
    app.dependency_overrides.clear()


def test_class_join_assignment_and_teacher_approved_marking() -> None:
    client = TestClient(app)
    classroom = client.post("/v1/education/classes", json={
        "name": "Mathematics 10",
        "institution": "Sfumato School",
        "level": "Grade 10",
        "educator_role": "teacher",
    }).json()
    assignment = client.post(
        f"/v1/education/classes/{classroom['id']}/assignments",
        json={"title": "Algebra", "instructions": "Solve x + 2 = 5", "max_score": 10},
    ).json()

    global claims
    claims = {"uid": "student-1", "email": "student@example.com", "name": "Student One"}
    assert client.post("/v1/education/classes/join", json={"join_code": classroom["join_code"]}).status_code == 200
    submission = client.post(
        f"/v1/education/assignments/{assignment['id']}/submit",
        json={"content": "x = 3"},
    ).json()

    claims = {"uid": "teacher-1", "email": "teacher@example.com", "name": "Teacher One"}
    marked = client.post(
        f"/v1/education/submissions/{submission['id']}/mark",
        json={"score": 10, "feedback": "Correct solution."},
    )
    assert marked.status_code == 200
    assert marked.json()["status"] == "marked"
    assert marked.json()["score"] == 10


def test_student_cannot_publish_assignment_or_mark_submission() -> None:
    client = TestClient(app)
    classroom = client.post("/v1/education/classes", json={
        "name": "Biology",
        "institution": "Sfumato School",
        "level": "Grade 11",
        "educator_role": "teacher",
    }).json()

    global claims
    claims = {"uid": "student-1", "email": "student@example.com", "name": "Student One"}
    client.post("/v1/education/classes/join", json={"join_code": classroom["join_code"]})
    response = client.post(
        f"/v1/education/classes/{classroom['id']}/assignments",
        json={"title": "Cells", "instructions": "Explain mitosis", "max_score": 20},
    )
    assert response.status_code == 403
    assert response.json()["detail"]["code"] == "educator_owner_required"
