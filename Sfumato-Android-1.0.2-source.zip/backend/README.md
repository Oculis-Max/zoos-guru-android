# Sfumato backend

FastAPI gateway for the Sfumato Android app. It keeps the model-provider key out of the APK and provides authenticated `/chat` and unauthenticated `/health` endpoints.

## Local development

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
pytest -q
ruff check app tests
uvicorn app.main:app --reload
```

## Configuration

Environment variables use the `HIGURU_` prefix:

- `HIGURU_BACKEND_ACCESS_TOKEN`: token expected in the `X-Sfumato-Token` request header.
- `HIGURU_OPENROUTER_API_KEY`: optional provider secret. Without it, the service runs in demo mode.
- `HIGURU_OPENROUTER_MODEL`: provider model identifier.
- `HIGURU_REQUEST_TIMEOUT_SECONDS`: upstream timeout.

Never commit a real token or provider key. Configure secrets in the deployment environment.

## Container

```bash
docker build -t higuru-backend ./backend
docker run --rm -p 8000:8000 \
  -e HIGURU_BACKEND_ACCESS_TOKEN=replace-me \
  higuru-backend
```
