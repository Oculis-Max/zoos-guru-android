"""Create a one-time CSV voucher batch and store only code hashes in Firestore."""

import argparse
import csv
import hashlib
import secrets
from datetime import UTC, datetime
from pathlib import Path

import firebase_admin
from firebase_admin import firestore


ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"


def create_code() -> str:
    body = "".join(secrets.choice(ALPHABET) for _ in range(15))
    return "HIGURU-" + "-".join(body[index:index + 5] for index in range(0, 15, 5))


def code_hash(code: str) -> str:
    normalised = "".join(character for character in code if character.isalnum()).upper()
    return hashlib.sha256(normalised.encode()).hexdigest()


def parse_date(value: str) -> datetime:
    return datetime.fromisoformat(value + "T23:59:59").replace(tzinfo=UTC)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--campaign", required=True)
    parser.add_argument("--sponsor", required=True)
    parser.add_argument("--funding-source", choices=("sponsor", "higuru_match"), required=True)
    parser.add_argument("--count", type=int, required=True)
    parser.add_argument("--redemption-deadline", required=True, help="YYYY-MM-DD")
    parser.add_argument("--access-ends", required=True, help="YYYY-MM-DD")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.count < 1 or args.count > 10_000:
        raise SystemExit("--count must be between 1 and 10000")
    if args.output.exists():
        raise SystemExit("Refusing to overwrite an existing voucher CSV")

    firebase_admin.initialize_app()
    client = firestore.client()
    codes: set[str] = set()
    while len(codes) < args.count:
        codes.add(create_code())

    batch = client.batch()
    writes = 0
    created_at = datetime.now(UTC)
    for code in sorted(codes):
        ref = client.collection("sponsored_vouchers").document(code_hash(code))
        batch.create(
            ref,
            {
                "campaign_id": args.campaign,
                "sponsor": args.sponsor,
                "funding_source": args.funding_source,
                "redemption_expires_at": parse_date(args.redemption_deadline),
                "access_ends_at": parse_date(args.access_ends),
                "created_at": created_at,
            },
        )
        writes += 1
        if writes == 450:
            batch.commit()
            batch = client.batch()
            writes = 0
    if writes:
        batch.commit()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(("campaign", "sponsor", "funding_source", "voucher_code"))
        writer.writerows((args.campaign, args.sponsor, args.funding_source, code) for code in sorted(codes))
    print(f"Created {len(codes)} vouchers. Plaintext codes exist only in {args.output}.")


if __name__ == "__main__":
    main()
