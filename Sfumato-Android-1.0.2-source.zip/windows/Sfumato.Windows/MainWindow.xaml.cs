using System.Windows;
using System.Windows.Controls;
using Sfumato.WindowsApp.Models;
using Sfumato.WindowsApp.Services;
using Sfumato.WindowsApp.Views;

namespace Sfumato.WindowsApp;

public partial class MainWindow : Window
{
    private readonly AppServices _services = new();
    public MainWindow() { InitializeComponent(); ShowLogin(); }

    private void ShowLogin()
    {
        Sidebar.Visibility = Visibility.Collapsed; SidebarColumn.Width = new GridLength(0);
        SignOutButton.Visibility = Visibility.Collapsed;
        var login = new LoginView(_services); login.SignedIn += (_, _) => ShowWorkspace();
        MainContent.Content = login;
    }

    private void ShowWorkspace()
    {
        Sidebar.Visibility = Visibility.Visible; SidebarColumn.Width = new GridLength(260);
        SignOutButton.Visibility = Visibility.Visible;
        Navigation.ItemsSource = FeatureCatalog.All; Navigation.SelectedIndex = 0;
    }

    private void Navigation_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (Navigation.SelectedItem is not AppFeature feature || _services.Session.Current is not { } session) return;
        if (!FeatureCatalog.CanAccess(session.Tier, feature))
        {
            MainContent.Content = new FeatureView(feature, session.Tier);
            return;
        }

        MainContent.Content = feature.Id switch
        {
            "home" => new HomeView(_services),
            "assistant" => new AssistantView(_services),
            "cyber" => new CyberSafetyView(),
            "account" => new AccountView(_services),
            "student" or "debate" or "scholarships" or "coding" or "engineering" or "business" or "plans"
                => new SpecialistView(feature, _services),
            _ => new FeatureView(feature, session.Tier)
        };
    }

    private void SignOutButton_Click(object sender, RoutedEventArgs e)
    {
        _services.Session.SignOut(); Navigation.ItemsSource = null; ShowLogin();
    }
}
