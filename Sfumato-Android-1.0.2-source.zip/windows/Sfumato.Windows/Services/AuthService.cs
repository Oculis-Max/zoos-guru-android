using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Sfumato.WindowsApp.Models;

namespace Sfumato.WindowsApp.Services;

public sealed class AuthService(HttpClient http, AppConfiguration configuration)
{
    public async Task<UserSession> SignInAsync(
        string email,
        string password,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(configuration.FirebaseApiKey))
            throw new InvalidOperationException(
                "Firebase authentication is not configured for this Windows build.");

        var endpoint =
            $"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={Uri.EscapeDataString(configuration.FirebaseApiKey)}";
        using var response = await http.PostAsJsonAsync(endpoint, new
        {
            email = email.Trim(),
            password,
            returnSecureToken = true
        }, cancellationToken);

        var json = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(ReadFirebaseError(json));

        var payload = JsonSerializer.Deserialize<FirebaseSignInResponse>(
            json, new JsonSerializerOptions(JsonSerializerDefaults.Web))
            ?? throw new InvalidOperationException("Firebase returned an invalid sign-in response.");

        var seconds = int.TryParse(payload.ExpiresIn, out var value) ? value : 3600;
        return new UserSession(
            payload.LocalId,
            payload.Email,
            payload.IdToken,
            SubscriptionTier.Free,
            DateTimeOffset.UtcNow.AddSeconds(Math.Max(60, seconds - 60)));
    }

    private static string ReadFirebaseError(string json)
    {
        try
        {
            using var document = JsonDocument.Parse(json);
            var code = document.RootElement.GetProperty("error").GetProperty("message").GetString();
            return code switch
            {
                "INVALID_LOGIN_CREDENTIALS" => "The email or password is incorrect.",
                "EMAIL_NOT_FOUND" => "No Sfumato account uses this email.",
                "INVALID_PASSWORD" => "The email or password is incorrect.",
                "USER_DISABLED" => "This account has been disabled.",
                _ => "Sign-in failed. Please try again."
            };
        }
        catch
        {
            return "Sign-in failed. Please try again.";
        }
    }

    private sealed record FirebaseSignInResponse(
        string IdToken,
        string Email,
        string LocalId,
        string ExpiresIn);
}
