using Sfumato.WindowsApp.Models;

namespace Sfumato.WindowsApp.Services;

public sealed class SessionStore
{
    public UserSession? Current { get; private set; }
    public bool IsAuthenticated => Current is { } session && session.ExpiresAt > DateTimeOffset.UtcNow;

    public event EventHandler? Changed;

    public void Set(UserSession session)
    {
        Current = session;
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public void SignOut()
    {
        Current = null;
        Changed?.Invoke(this, EventArgs.Empty);
    }
}
