using System.IO;
using System.Text.Json;

namespace Sfumato.WindowsApp.Services;

public sealed class AppConfiguration
{
    public Uri BackendBaseUri { get; }
    public string FirebaseApiKey { get; }

    public AppConfiguration()
    {
        var file = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        var settings = File.Exists(file)
            ? JsonSerializer.Deserialize<DesktopSettings>(File.ReadAllText(file),
                new JsonSerializerOptions(JsonSerializerDefaults.Web))
            : null;
        BackendBaseUri = new Uri(Environment.GetEnvironmentVariable("SFUMATO_BACKEND_BASE_URL")
            ?? settings?.BackendBaseUrl ?? "https://higuru-api-beta.onrender.com/");
        FirebaseApiKey = Environment.GetEnvironmentVariable("SFUMATO_FIREBASE_API_KEY")
            ?? settings?.FirebaseApiKey ?? "";
    }

    public void Validate()
    {
        if (BackendBaseUri.Scheme != Uri.UriSchemeHttps)
            throw new InvalidOperationException("The Sfumato backend must use HTTPS.");
    }

    private sealed record DesktopSettings(string? BackendBaseUrl, string? FirebaseApiKey);
}
