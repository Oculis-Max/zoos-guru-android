using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Sfumato.WindowsApp.Models;

namespace Sfumato.WindowsApp.Services;

public sealed class BackendClient(HttpClient http, AppConfiguration configuration, SessionStore sessionStore)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public async Task<string> ChatAsync(IReadOnlyList<ChatMessage> messages, CancellationToken token = default)
    {
        using var document = await PostAsync("chat", new { messages }, token);
        return document.RootElement.GetProperty("message").GetProperty("content").GetString()
            ?? "Sfumato returned an empty response.";
    }

    public async Task<JsonDocument> GetAsync(string path, CancellationToken token = default)
    {
        using var request = CreateRequest(HttpMethod.Get, path);
        using var response = await http.SendAsync(request, token);
        return await ReadAsync(response, token);
    }

    public async Task<JsonDocument> PostAsync(string path, object payload, CancellationToken token = default)
    {
        using var request = CreateRequest(HttpMethod.Post, path);
        request.Content = JsonContent.Create(payload, options: Json);
        using var response = await http.SendAsync(request, token);
        return await ReadAsync(response, token);
    }

    public async Task<SubscriptionTier> RefreshEntitlementAsync(CancellationToken token = default)
    {
        using var document = await GetAsync("v1/billing/entitlement", token);
        var tier = document.RootElement.GetProperty("tier").GetString();
        return tier switch
        {
            "student" => SubscriptionTier.Student,
            "developer" => SubscriptionTier.Developer,
            "business" => SubscriptionTier.Business,
            _ => SubscriptionTier.Free
        };
    }

    private HttpRequestMessage CreateRequest(HttpMethod method, string path)
    {
        configuration.Validate();
        var token = sessionStore.Current?.IdToken
            ?? throw new InvalidOperationException("Sign in to continue.");
        var request = new HttpRequestMessage(method, new Uri(configuration.BackendBaseUri, path));
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        request.Headers.UserAgent.ParseAdd("Sfumato-Windows/1.0");
        return request;
    }

    private static async Task<JsonDocument> ReadAsync(HttpResponseMessage response, CancellationToken token)
    {
        var body = await response.Content.ReadAsStringAsync(token);
        if (response.IsSuccessStatusCode) return JsonDocument.Parse(body);
        try
        {
            using var error = JsonDocument.Parse(body);
            var detail = error.RootElement.GetProperty("detail");
            var message = detail.ValueKind == JsonValueKind.Object &&
                          detail.TryGetProperty("message", out var messageValue)
                ? messageValue.GetString()
                : detail.ValueKind == JsonValueKind.Object &&
                  detail.TryGetProperty("code", out var codeValue)
                    ? codeValue.GetString()?.Replace('_', ' ')
                    : null;
            throw new InvalidOperationException(message ?? $"Sfumato request failed ({(int)response.StatusCode}).");
        }
        catch (JsonException)
        {
            throw new InvalidOperationException($"Sfumato request failed ({(int)response.StatusCode}).");
        }
    }

    public sealed record ChatMessage(string Role, string Content);
}
