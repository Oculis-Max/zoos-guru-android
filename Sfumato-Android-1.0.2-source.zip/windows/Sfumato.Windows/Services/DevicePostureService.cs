using Microsoft.Win32;
using Sfumato.WindowsApp.Models;

namespace Sfumato.WindowsApp.Services;

public sealed class DevicePostureService
{
    public async Task<IReadOnlyList<SecurityFinding>> ScanAsync(CancellationToken cancellationToken = default)
    {
        var checks = await Task.WhenAll(
            CheckDefenderAsync(cancellationToken),
            CheckFirewallAsync(cancellationToken),
            Task.Run(CheckSmartScreen, cancellationToken),
            Task.Run(CheckWindowsVersion, cancellationToken));

        return checks.SelectMany(x => x).ToArray();
    }

    private static async Task<IReadOnlyList<SecurityFinding>> CheckDefenderAsync(CancellationToken token)
    {
        const string command =
            "$s=Get-MpComputerStatus; " +
            "'AntivirusEnabled=' + $s.AntivirusEnabled; " +
            "'RealTimeProtectionEnabled=' + $s.RealTimeProtectionEnabled; " +
            "'AntivirusSignatureLastUpdated=' + $s.AntivirusSignatureLastUpdated.ToString('o')";

        var output = await PowerShellReader.RunAsync(command, token);
        if (output is null)
            return [new("Microsoft Defender", FindingSeverity.Unknown,
                "Sfumato could not read Defender status. Another antivirus may be installed.",
                "windowsdefender:")];

        var enabled = output.Contains("AntivirusEnabled=True", StringComparison.OrdinalIgnoreCase);
        var realTime = output.Contains("RealTimeProtectionEnabled=True", StringComparison.OrdinalIgnoreCase);
        return [new(
            "Microsoft Defender",
            enabled && realTime ? FindingSeverity.Safe : FindingSeverity.Danger,
            enabled && realTime
                ? "Antivirus and real-time protection are active."
                : "Antivirus or real-time protection is turned off.",
            "windowsdefender:")];
    }

    private static async Task<IReadOnlyList<SecurityFinding>> CheckFirewallAsync(CancellationToken token)
    {
        const string command =
            "(Get-NetFirewallProfile | Where-Object Enabled -eq $false | Select-Object -ExpandProperty Name) -join ','";

        var disabledProfiles = await PowerShellReader.RunAsync(command, token);
        if (disabledProfiles is null)
            return [new("Windows Firewall", FindingSeverity.Unknown,
                "Sfumato could not read the firewall status.", "windowsdefender://network")];

        return [new(
            "Windows Firewall",
            string.IsNullOrWhiteSpace(disabledProfiles) ? FindingSeverity.Safe : FindingSeverity.Danger,
            string.IsNullOrWhiteSpace(disabledProfiles)
                ? "Firewall protection is enabled for all network profiles."
                : $"Firewall is disabled for: {disabledProfiles}.",
            "windowsdefender://network")];
    }

    private static IReadOnlyList<SecurityFinding> CheckSmartScreen()
    {
        using var key = Registry.LocalMachine.OpenSubKey(
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer");
        var value = key?.GetValue("SmartScreenEnabled")?.ToString();
        var enabled = !string.Equals(value, "Off", StringComparison.OrdinalIgnoreCase);

        return [new(
            "Microsoft Defender SmartScreen",
            enabled ? FindingSeverity.Safe : FindingSeverity.Attention,
            enabled
                ? "Windows is configured to warn about suspicious downloads and apps."
                : "SmartScreen appears to be disabled.",
            "windowsdefender://smartscreen")];
    }

    private static IReadOnlyList<SecurityFinding> CheckWindowsVersion()
    {
        return [new(
            "Windows updates",
            FindingSeverity.Attention,
            $"Running {Environment.OSVersion.VersionString}. Check Windows Update for the latest security fixes.",
            "ms-settings:windowsupdate")];
    }
}
