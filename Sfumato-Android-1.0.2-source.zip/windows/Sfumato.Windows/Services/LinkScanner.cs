using System.Globalization;

namespace Sfumato.WindowsApp.Services;

public enum LinkRisk
{
    Safe,
    Suspicious,
    Invalid
}

public sealed record LinkScanResult(LinkRisk Risk, string Host, IReadOnlyList<string> Reasons);

public sealed class LinkScanner
{
    private static readonly string[] CommonlyAbusedSuffixes =
        [".zip", ".mov", ".top", ".click", ".work"];

    private static readonly string[] PhishingPhrases =
        ["verify-account", "urgent-login", "claim-prize", "wallet-recovery", "password-reset"];

    public LinkScanResult Scan(string input)
    {
        var value = input.Trim();
        if (!value.Contains("://", StringComparison.Ordinal))
            value = "https://" + value;

        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri) ||
            string.IsNullOrWhiteSpace(uri.Host))
            return new(LinkRisk.Invalid, "", ["Enter a complete website address."]);

        var host = uri.IdnHost.ToLowerInvariant();
        var reasons = new List<string>();

        if (CommonlyAbusedSuffixes.Any(host.EndsWith))
            reasons.Add("The domain ending is frequently abused by scam campaigns.");

        if (PhishingPhrases.Any(p => value.Contains(p, StringComparison.OrdinalIgnoreCase)))
            reasons.Add("The address contains wording often used for phishing.");

        if (host.Split('.').Length > 5)
            reasons.Add("The address has an unusual number of subdomains.");

        if (input.Any(c => c > 127))
            reasons.Add("The address contains look-alike international characters.");

        try
        {
            var asciiHost = new IdnMapping().GetAscii(host);
            if (!string.Equals(asciiHost, host, StringComparison.OrdinalIgnoreCase))
                reasons.Add("The displayed domain differs from its network representation.");
        }
        catch (ArgumentException)
        {
            reasons.Add("The domain name contains invalid characters.");
        }

        return reasons.Count == 0
            ? new(LinkRisk.Safe, host, [])
            : new(LinkRisk.Suspicious, host, reasons);
    }
}
