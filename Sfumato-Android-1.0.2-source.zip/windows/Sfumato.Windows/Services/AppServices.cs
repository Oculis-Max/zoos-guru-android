using System.Net.Http;

namespace Sfumato.WindowsApp.Services;

public sealed class AppServices
{
    public AppConfiguration Configuration { get; } = new();
    public SessionStore Session { get; } = new();
    public HttpClient Http { get; } = new() { Timeout = TimeSpan.FromSeconds(45) };
    public AuthService Auth { get; }
    public BackendClient Backend { get; }

    public AppServices()
    {
        Auth = new AuthService(Http, Configuration);
        Backend = new BackendClient(Http, Configuration, Session);
    }
}
