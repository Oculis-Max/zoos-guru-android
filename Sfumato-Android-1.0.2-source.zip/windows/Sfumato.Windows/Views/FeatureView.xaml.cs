using System.Windows.Controls;
using Sfumato.WindowsApp.Models;

namespace Sfumato.WindowsApp.Views;

public partial class FeatureView : UserControl
{
    public FeatureView(AppFeature feature, SubscriptionTier currentTier)
    {
        InitializeComponent();
        FeatureIcon.Text = feature.Icon;
        FeatureName.Text = feature.Name;
        FeatureDescription.Text = feature.Description;
        AccessText.Text = $"Your {currentTier} plan does not include this workflow. It requires the {feature.RequiredTier} plan.";
    }
}
