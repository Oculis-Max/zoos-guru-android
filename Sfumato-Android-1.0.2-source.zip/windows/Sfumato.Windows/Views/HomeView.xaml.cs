using System.Windows.Controls;
using Sfumato.WindowsApp.Services;

namespace Sfumato.WindowsApp.Views;

public partial class HomeView : UserControl
{
    public HomeView(AppServices services)
    {
        InitializeComponent();
        var name = services.Session.Current?.Email.Split('@')[0] ?? "there";
        Greeting.Text = $"Hello, {name}";
    }
}
