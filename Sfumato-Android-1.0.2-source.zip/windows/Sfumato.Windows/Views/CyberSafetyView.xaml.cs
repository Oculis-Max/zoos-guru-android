using System.Windows;
using System.Windows.Controls;
using Sfumato.WindowsApp.Services;

namespace Sfumato.WindowsApp.Views;

public partial class CyberSafetyView : UserControl
{
    private readonly DevicePostureService _posture = new();
    private readonly LinkScanner _scanner = new();

    public CyberSafetyView()
    {
        InitializeComponent();
    }

    private async void ScanButton_Click(object sender, RoutedEventArgs e)
    {
        ScanButton.IsEnabled = false;
        Progress.Visibility = Visibility.Visible;
        try
        {
            var results = await _posture.ScanAsync();
            Findings.ItemsSource = results.Select(x => $"{x.Name}: {x.Detail}");
        }
        catch (Exception ex)
        {
            Findings.ItemsSource = new[] { $"Scan incomplete: {ex.Message}" };
        }
        finally
        {
            Progress.Visibility = Visibility.Collapsed;
            ScanButton.IsEnabled = true;
        }
    }

    private void ScanLink_Click(object sender, RoutedEventArgs e)
    {
        var result = _scanner.Scan(LinkInput.Text);
        LinkResult.Text = result.Reasons.Count == 0
            ? result.Risk == LinkRisk.Safe ? "No obvious danger found." : "Enter a valid link."
            : string.Join(Environment.NewLine, result.Reasons.Select(x => "• " + x));
    }
}
