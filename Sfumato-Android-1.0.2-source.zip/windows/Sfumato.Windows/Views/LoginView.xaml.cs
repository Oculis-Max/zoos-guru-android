using System.Windows;
using System.Windows.Controls;
using Sfumato.WindowsApp.Services;

namespace Sfumato.WindowsApp.Views;

public partial class LoginView : UserControl
{
    private readonly AppServices _services;

    public event EventHandler? SignedIn;

    public LoginView(AppServices services)
    {
        InitializeComponent();
        _services = services;
    }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Text = "";
        SignInButton.IsEnabled = false;
        Progress.Visibility = Visibility.Visible;
        try
        {
            var session = await _services.Auth.SignInAsync(EmailInput.Text, PasswordInput.Password);
            _services.Session.Set(session);
            var tier = await _services.Backend.RefreshEntitlementAsync();
            _services.Session.Set(session with { Tier = tier });
            SignedIn?.Invoke(this, EventArgs.Empty);
        }
        catch (Exception ex)
        {
            ErrorText.Text = ex.Message;
        }
        finally
        {
            Progress.Visibility = Visibility.Collapsed;
            SignInButton.IsEnabled = true;
        }
    }
}
