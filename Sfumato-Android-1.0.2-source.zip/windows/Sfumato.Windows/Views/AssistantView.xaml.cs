using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using Sfumato.WindowsApp.Services;

namespace Sfumato.WindowsApp.Views;

public partial class AssistantView : UserControl
{
    private readonly AppServices _services;
    private readonly ObservableCollection<MessageItem> _messages = [];

    public AssistantView(AppServices services)
    {
        InitializeComponent();
        _services = services;
        Conversation.ItemsSource = _messages;
    }

    private async void SendButton_Click(object sender, RoutedEventArgs e)
    {
        var prompt = PromptInput.Text.Trim();
        if (prompt.Length == 0) return;

        _messages.Add(new("You", prompt));
        PromptInput.Clear();
        SendButton.IsEnabled = false;
        try
        {
            var history = _messages.Select(message =>
                new BackendClient.ChatMessage(
                    message.Role == "You" ? "user" : "assistant",
                    message.Content)).ToArray();
            var response = await _services.Backend.ChatAsync(history);
            _messages.Add(new("Sfumato", response));
            Conversation.ScrollIntoView(_messages[^1]);
        }
        catch (Exception ex)
        {
            _messages.Add(new("Sfumato", ex.Message));
        }
        finally
        {
            SendButton.IsEnabled = true;
        }
    }

    private sealed record MessageItem(string Role, string Content);
}
