using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Sfumato.WindowsApp.Models;
using Sfumato.WindowsApp.Services;

namespace Sfumato.WindowsApp.Views;

public partial class SpecialistView : UserControl
{
    private readonly AppFeature _feature;
    private readonly AppServices _services;
    private string _sessionContext = "";

    public SpecialistView(AppFeature feature, AppServices services)
    {
        InitializeComponent();
        _feature = feature;
        _services = services;
        TitleText.Text = feature.Name;
        DescriptionText.Text = feature.Description;
        Configure();
    }

    private void Configure()
    {
        switch (_feature.Id)
        {
            case "student":
                SetForm("Mode", ["lesson","diagnostic","practice","revision"], "Grade", ["Grade 8","Grade 9","Grade 10","Grade 11","Grade 12","University"], "Subject", "Topic", "Curriculum", "Start tutoring");
                ContinueButton.Visibility = FinishButton.Visibility = Visibility.Visible;
                break;
            case "debate":
                SetForm("Stage", ["1","2","3","4","5"], "Position", ["for","against"], "Topic", "Your next argument", "Debate notes", "Start debate");
                ContinueButton.Visibility = FinishButton.Visibility = Visibility.Visible;
                break;
            case "scholarships":
                SetForm("Country", ["ZA","AFRICA"], "Level", ["undergraduate","honours","masters","high_school","tvet"], "Field", "Optional filter", "Notes", "Find verified scholarships");
                HideUnused(second: true, context: true);
                break;
            case "coding":
                SetForm("Base branch", ["main","master","develop"], "Action", ["plan"], "Repository (owner/name)", "Describe the coding task", "Safety notes", "Create reviewable plan");
                HideUnused(context: true);
                break;
            case "engineering":
                SetForm("Discipline", ["general","civil","structural","mechanical","electrical","architectural"], "Mode", ["explain","calculation_review","design_review","materials_estimate","codes_checklist"], "Engineering request", "Project context", "Jurisdiction and standards", "Generate engineering review");
                break;
            case "business":
                SetForm("Mode", ["standard","advanced","emergency"], "Area", ["general_admin","executive","operations","finance","human_resources","sales","marketing","projects","risk","it_cybersecurity"], "Business request", "Organisation context", "Document type", "Create approval-ready draft");
                break;
            case "plans":
                SetForm("Plans", ["all"], "Action", ["view"], "Filter", "Details", "Notes", "Load plans");
                HideUnused(primary: true, second: true, context: true);
                break;
        }
    }

    private void SetForm(string oneLabel, string[] one, string twoLabel, string[] two, string primary, string secondary, string context, string button)
    {
        ChoiceOneLabel.Text = oneLabel; ChoiceOne.ItemsSource = one; ChoiceOne.SelectedIndex = 0;
        ChoiceTwoLabel.Text = twoLabel; ChoiceTwo.ItemsSource = two; ChoiceTwo.SelectedIndex = 0;
        PrimaryLabel.Text = primary; SecondaryLabel.Text = secondary; ContextLabel.Text = context;
        RunButton.Content = button;
    }

    private void HideUnused(bool primary = false, bool second = false, bool context = false)
    {
        if (primary) { PrimaryLabel.Visibility = PrimaryInput.Visibility = Visibility.Collapsed; }
        if (second) { SecondaryLabel.Visibility = SecondaryInput.Visibility = Visibility.Collapsed; }
        if (context) { ContextLabel.Visibility = ContextInput.Visibility = Visibility.Collapsed; }
    }

    private async void RunButton_Click(object sender, RoutedEventArgs e) => await ExecuteAsync("start");
    private async void ContinueButton_Click(object sender, RoutedEventArgs e) => await ExecuteAsync("continue");
    private async void FinishButton_Click(object sender, RoutedEventArgs e) => await ExecuteAsync("finish");

    private async Task ExecuteAsync(string action)
    {
        ErrorText.Text = ""; Progress.Visibility = Visibility.Visible; RunButton.IsEnabled = false;
        try
        {
            using var result = await RequestAsync(action);
            var output = ExtractDisplay(result.RootElement);
            ResultText.Text = output;
            _sessionContext = string.IsNullOrWhiteSpace(_sessionContext) ? output : _sessionContext + "\n\n" + output;
        }
        catch (Exception ex) { ErrorText.Text = ex.Message; }
        finally { Progress.Visibility = Visibility.Collapsed; RunButton.IsEnabled = true; }
    }

    private Task<JsonDocument> RequestAsync(string action)
    {
        var one = ChoiceOne.SelectedItem?.ToString() ?? "";
        var two = ChoiceTwo.SelectedItem?.ToString() ?? "";
        var primary = PrimaryInput.Text.Trim();
        var secondary = SecondaryInput.Text.Trim();
        var context = ContextInput.Text.Trim();

        return _feature.Id switch
        {
            "student" when action == "start" => _services.Backend.PostAsync("v1/learning-ai/tutor", new { mode=one, subject=primary, topic=secondary, grade=two, curriculum=context }),
            "student" when action == "continue" => _services.Backend.PostAsync("v1/learning-ai/tutor/respond", new { mode=one, subject=primary, topic=secondary, grade=two, curriculum=context, lesson_context=_sessionContext, learner_message=context }),
            "student" => _services.Backend.PostAsync("v1/learning-ai/tutor/finish", new { mode=one, subject=primary, topic=secondary, grade=two, curriculum=context, lesson_context=_sessionContext }),
            "debate" when action == "start" => _services.Backend.PostAsync("v1/learning-ai/arena", new { topic=primary, stage=int.Parse(one), position=two }),
            "debate" when action == "continue" => _services.Backend.PostAsync("v1/learning-ai/arena/respond", new { topic=primary, stage=int.Parse(one), user_position=two, debate_context=_sessionContext, learner_argument=secondary }),
            "debate" => _services.Backend.PostAsync("v1/learning-ai/arena/finish", new { topic=primary, stage=int.Parse(one), user_position=two, debate_context=_sessionContext }),
            "scholarships" => _services.Backend.GetAsync($"v1/scholarships?country={Uri.EscapeDataString(one)}&level={Uri.EscapeDataString(two)}&field={Uri.EscapeDataString(primary)}"),
            "coding" => _services.Backend.PostAsync("v1/coding/tasks/plan", new { repository=primary, task=secondary, base_branch=one }),
            "engineering" => _services.Backend.PostAsync("v1/engineering/assist", new { discipline=one, mode=two, task=primary, project_context=secondary, jurisdiction=context, units="metric" }),
            "business" => _services.Backend.PostAsync("v1/business/assistant", new { mode=one, area=two, task=primary, organization_context=secondary, document_type=context }),
            "plans" => _services.Backend.GetAsync("v1/billing/plans"),
            _ => throw new InvalidOperationException("This workflow is not configured.")
        };
    }

    private static string ExtractDisplay(JsonElement root)
    {
        if (root.ValueKind == JsonValueKind.Array)
            return string.Join("\n\n", root.EnumerateArray().Select(FormatItem));
        foreach (var name in new[] { "content", "plan", "message" })
            if (root.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String)
                return value.GetString() ?? "";
        return JsonSerializer.Serialize(root, new JsonSerializerOptions { WriteIndented = true });
    }

    private static string FormatItem(JsonElement item)
    {
        if (item.TryGetProperty("name", out var name))
        {
            var provider = item.TryGetProperty("provider", out var p) ? p.GetString() : "";
            var deadline = item.TryGetProperty("deadline", out var d) ? d.GetString() : "";
            var url = item.TryGetProperty("official_url", out var u) ? u.GetString() : "";
            return $"{name.GetString()}\n{provider}\nDeadline: {deadline}\n{url}";
        }
        return JsonSerializer.Serialize(item, new JsonSerializerOptions { WriteIndented = true });
    }
}