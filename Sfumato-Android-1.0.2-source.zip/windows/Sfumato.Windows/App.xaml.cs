using System.Windows;

namespace Sfumato.WindowsApp;

public partial class App : Application
{
}
