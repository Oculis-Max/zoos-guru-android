namespace Sfumato.WindowsApp.Models;

public enum SubscriptionTier
{
    Free,
    Student,
    Developer,
    Business
}

public sealed record UserSession(
    string UserId,
    string Email,
    string IdToken,
    SubscriptionTier Tier,
    DateTimeOffset ExpiresAt);
