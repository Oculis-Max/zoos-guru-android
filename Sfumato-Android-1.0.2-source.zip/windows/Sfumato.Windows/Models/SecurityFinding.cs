namespace Sfumato.WindowsApp.Models;

public enum FindingSeverity
{
    Safe,
    Attention,
    Danger,
    Unknown
}

public sealed record SecurityFinding(
    string Name,
    FindingSeverity Severity,
    string Detail,
    string? ActionUri = null);
