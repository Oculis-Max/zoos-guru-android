namespace Sfumato.WindowsApp.Models;

public sealed record AppFeature(string Id, string Name, string Description, string Icon, SubscriptionTier RequiredTier, string Category);

public static class FeatureCatalog
{
    public static IReadOnlyList<AppFeature> All { get; } =
    [
        new("home","Home","Your Sfumato workspace","⌂",SubscriptionTier.Free,"Core"),
        new("assistant","Sfumato Assistant","Research, coaching and everyday intelligence","✦",SubscriptionTier.Free,"Core"),
        new("student","Student Guru","Study support, explanations and practice","🎓",SubscriptionTier.Student,"Learning"),
        new("debate","Debate Arena","Live structured debate practice","🎙",SubscriptionTier.Student,"Learning"),
        new("scholarships","Scholarship Guru","Verified opportunities and application readiness","🏆",SubscriptionTier.Student,"Learning"),
        new("coding","Autonomous Coding","Plan approved repository changes","⌘",SubscriptionTier.Developer,"Professional"),
        new("engineering","Engineering Guru","Engineering decision support and reviews","⚙",SubscriptionTier.Business,"Professional"),
        new("business","Business Assistant","Documents, analysis and approval-based workflows","▣",SubscriptionTier.Business,"Professional"),
        new("cyber","Cyber Safety","Windows security posture and link protection","◆",SubscriptionTier.Developer,"Protection"),
        new("plans","Plans","View subscriptions and access","♢",SubscriptionTier.Free,"Account"),
        new("account","Account","Profile, privacy and sign out","●",SubscriptionTier.Free,"Account")
    ];

    public static bool CanAccess(SubscriptionTier current, AppFeature feature) =>
        feature.Id switch
        {
            "home" or "assistant" or "plans" or "account" => true,
            "student" or "debate" or "scholarships" => current == SubscriptionTier.Student,
            "coding" => current == SubscriptionTier.Developer,
            "engineering" or "business" => current == SubscriptionTier.Business,
            "cyber" => current is SubscriptionTier.Developer or SubscriptionTier.Business,
            _ => false
        };
}
