# Sfumato for Windows

Native Windows desktop edition of Sfumato built with WPF and .NET 8.

## Included foundation

- Firebase email/password sign-in using the same Sfumato account
- Server-backed subscription entitlement checks
- Free, Student, Developer and Business feature gates
- General Sfumato Assistant connected to the existing authenticated `/chat` API
- Desktop navigation for Student Guru, Debate Arena, Scholarship Guru,
  Autonomous Coding, Engineering Guru, Business Assistant, Cyber Safety,
  Plans and Account
- Windows Cyber Safety posture checks for Defender, Firewall, SmartScreen and updates
- Suspicious-link checks
- Windows GitHub Actions build validation

The specialist screens are being connected incrementally to the existing backend
routes. Server-side authorization remains the source of truth; the desktop UI
does not grant paid access by itself.

## Local configuration

Set these environment variables on the Windows development machine:

```powershell
$env:SFUMATO_BACKEND_BASE_URL = "https://higuru-api-beta.onrender.com/"
$env:SFUMATO_FIREBASE_API_KEY = "<Firebase web API key>"
```

Do not commit the Firebase API key into source control. Firebase API keys identify
the project but authentication and backend authorization still require correctly
configured Firebase rules and verified ID tokens.

## Build

On Windows with the .NET 8 SDK:

```powershell
dotnet restore .\Sfumato.Windows\Sfumato.Windows.csproj
dotnet build .\Sfumato.Windows\Sfumato.Windows.csproj -c Release
dotnet run --project .\Sfumato.Windows\Sfumato.Windows.csproj
```

## Security architecture

The dashboard reads Windows security posture without administrator rights and
opens trusted Windows Security pages for user-approved changes. System-wide
malicious-domain blocking will use a separately signed, administrator-approved
background service with rollback and health checks; it is not falsely represented
as active in this foundation.
