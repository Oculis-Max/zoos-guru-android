#define MyAppName "Sfumato"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Sfumato"
#define MyAppExeName "Sfumato.exe"

[Setup]
AppId={{D3048517-72C1-4B5D-A9F4-84113EAF377B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Sfumato
DefaultGroupName=Sfumato
OutputDir=output
OutputBaseFilename=Sfumato-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\{#MyAppExeName}

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Sfumato"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Sfumato"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Sfumato"; Flags: nowait postinstall skipifsilent
