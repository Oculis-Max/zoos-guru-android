plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

android {
    namespace = "com.guru.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.guru.android"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.0.2"

        val backendBaseUrl = providers.gradleProperty("HIGURU_BACKEND_BASE_URL")
            .orElse(providers.environmentVariable("HIGURU_BACKEND_BASE_URL"))
            .orElse("https://higuru-api-beta.onrender.com/")
            .get()
        buildConfigField(
            "String",
            "HIGURU_BACKEND_BASE_URL",
            "\"" + backendBaseUrl.replace("\"", "\\\"") + "\"",
        )
        val liveModel = providers.gradleProperty("HIGURU_LIVE_MODEL")
            .orElse(providers.environmentVariable("HIGURU_LIVE_MODEL"))
            .orElse("gemini-2.5-flash-native-audio-preview-12-2025")
            .get()
        buildConfigField("String", "HIGURU_LIVE_MODEL", "\"" + liveModel + "\"")
    }

    signingConfigs {
        create("release") {
            storeFile = System.getenv("HIGURU_KEYSTORE_PATH")?.let(::file)
            storePassword = System.getenv("HIGURU_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("HIGURU_KEY_ALIAS")
            keyPassword = System.getenv("HIGURU_KEY_PASSWORD")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }
    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}

// Firestore 25.x and Firebase AI share Timestamp through firebase-common 21.x.
// Do not force firebase-common 20.x: Firestore first initializes after sign-in and
// an older runtime can cause a linkage crash while loading the account profile.

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation(platform("androidx.compose:compose-bom:2023.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("com.google.dagger:hilt-android:2.48")
    ksp("com.google.dagger:hilt-compiler:2.48")
    implementation("androidx.hilt:hilt-navigation-compose:1.1.0")
    implementation("androidx.hilt:hilt-work:1.1.0")
    ksp("androidx.hilt:hilt-compiler:1.1.0")
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")
    implementation("androidx.datastore:datastore-preferences:1.0.0")

    // Student homework capture: bundled OCR works immediately; scanner UI is delivered by Play Services.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0")

    // Keep established Firebase services on their proven Kotlin 1.9-compatible line.
    implementation(platform("com.google.firebase:firebase-bom:32.8.1"))
    implementation("com.google.firebase:firebase-auth")
    // 25.x uses the shared Timestamp from firebase-common, required by firebase-ai.
    implementation("com.google.firebase:firebase-firestore:25.1.1")
    implementation("com.google.firebase:firebase-storage")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-ai:17.11.0")
    // App Check must be present so Firebase AI Logic can attach Play Integrity tokens.
    implementation("com.google.firebase:firebase-appcheck-playintegrity:19.3.0")

    testImplementation("junit:junit:4.13.2")
}
