package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingProfessionalPathRegressionTest {
    @Test fun professionalPathAcceptsRoleAndFocus() {
        assertNull(OnboardingRules.validationError("professional", "", "", "", emptyList(), "Analyst", "", listOf("research")))
    }
}
