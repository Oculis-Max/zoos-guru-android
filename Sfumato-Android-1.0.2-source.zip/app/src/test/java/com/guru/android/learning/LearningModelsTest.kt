package com.guru.android.learning

import org.junit.Assert.assertEquals
import org.junit.Test

class LearningModelsTest {
    @Test
    fun mapsAllFiveArenaStages() {
        assertEquals(
            listOf("Foundation", "Challenger", "Advanced", "Expert", "Grandmaster"),
            (1..5).map(::stageName),
        )
    }
}
