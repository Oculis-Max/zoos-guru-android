package com.guru.android.account

import org.junit.Assert.assertFalse
import org.junit.Test

class OnboardingFreePlanRegressionTest {
    @Test fun freeDoesNotRouteToPayment() = assertFalse(OnboardingRules.canContinueToPayment("free"))
}
