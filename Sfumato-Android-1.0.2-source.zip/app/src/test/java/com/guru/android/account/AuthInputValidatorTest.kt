package com.guru.android.account

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AuthInputValidatorTest {
    @Test
    fun acceptsValidEmailAndStrongPassword() {
        assertNull(AuthInputValidator.emailError("student@example.org"))
        assertNull(AuthInputValidator.passwordError("study123"))
        assertNull(AuthInputValidator.displayNameError("Ada"))
    }

    @Test
    fun rejectsMalformedEmail() {
        assertEquals(
            "Enter a valid email address.",
            AuthInputValidator.emailError("not-an-email"),
        )
    }

    @Test
    fun rejectsShortPassword() {
        assertEquals(
            "Use at least 8 characters.",
            AuthInputValidator.passwordError("short"),
        )
    }

    @Test
    fun rejectsMissingDisplayName() {
        assertEquals("Enter your name.", AuthInputValidator.displayNameError(" "))
    }

    @Test
    fun requiresMatchingPasswordConfirmation() {
        assertNull(AuthInputValidator.passwordConfirmationError("study123", "study123"))
        assertEquals(
            "The passwords do not match.",
            AuthInputValidator.passwordConfirmationError("study123", "study124"),
        )
    }

    @Test
    fun requiresLegalConsent() {
        assertNull(AuthInputValidator.termsError(true))
        assertEquals(
            "Accept the Terms and Privacy Policy to create an account.",
            AuthInputValidator.termsError(false),
        )
    }
}
