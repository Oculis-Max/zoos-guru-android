package com.guru.android.coding

import org.junit.Assert.assertEquals
import org.junit.Test

class CodingFeatureTest {
    @Test
    fun normalizes_full_github_repository_links() {
        assertEquals(
            "bookingdiallocarnal-del/uilis5",
            normalizeRepositoryInput("https://github.com/bookingdiallocarnal-del/uilis5"),
        )
        assertEquals(
            "owner/private-repo",
            normalizeRepositoryInput("https://github.com/owner/private-repo.git/"),
        )
    }

    @Test
    fun accepts_owner_and_repository_without_a_url() {
        assertEquals("owner/repository", normalizeRepositoryInput(" owner/repository "))
    }
}
