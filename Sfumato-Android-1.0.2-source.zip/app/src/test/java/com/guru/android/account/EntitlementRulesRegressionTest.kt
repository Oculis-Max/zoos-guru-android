package com.guru.android.account

import com.guru.android.billing.EntitlementResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EntitlementRulesRegressionTest {
    @Test fun freeTierIsAlwaysActive() {
        val result = EntitlementRules.resolve(EntitlementResponse(tier = "free", status = "inactive"))
        assertEquals("free", result.tier)
        assertTrue(result.active)
        assertFalse(result.autonomousCoding)
    }

    @Test fun activeDeveloperCanReceiveAutonomousCoding() {
        val result = EntitlementRules.resolve(EntitlementResponse(tier = "developer", status = "active", autonomousCoding = true))
        assertTrue(result.active)
        assertTrue(result.autonomousCoding)
    }

    @Test fun inactiveDeveloperCannotKeepAutonomousCoding() {
        val result = EntitlementRules.resolve(EntitlementResponse(tier = "developer", status = "inactive", autonomousCoding = true))
        assertFalse(result.active)
        assertFalse(result.autonomousCoding)
    }

    @Test fun nonDeveloperTierCannotReceiveAutonomousCoding() {
        val result = EntitlementRules.resolve(EntitlementResponse(tier = "student_pro", status = "active", autonomousCoding = true))
        assertTrue(result.active)
        assertFalse(result.autonomousCoding)
    }

    @Test fun unknownTierFailsClosedToFree() {
        val result = EntitlementRules.resolve(EntitlementResponse(tier = "unexpected_paid_tier", status = "active", autonomousCoding = true))
        assertEquals("free", result.tier)
        assertTrue(result.active)
        assertFalse(result.autonomousCoding)
    }

    @Test fun tierAndStatusAreNormalized() {
        val result = EntitlementRules.resolve(EntitlementResponse(tier = " Developer ", status = "ACTIVE", autonomousCoding = true))
        assertEquals("developer", result.tier)
        assertTrue(result.active)
        assertTrue(result.autonomousCoding)
    }
}
