package com.guru.android.data.remote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BackendConfigTest {
    @Test
    fun appendsTrailingSlash() {
        assertEquals(
            "https://higuru-api.onrender.com/",
            BackendConfig.baseUrl("https://higuru-api.onrender.com"),
        )
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsInsecureHttp() {
        BackendConfig.baseUrl("http://example.com")
    }

    @Test
    fun detectsPlaceholderAndConfiguredUrls() {
        assertFalse(BackendConfig.isConfigured("https://example.invalid/"))
        assertTrue(BackendConfig.isConfigured("https://higuru-api.onrender.com/"))
    }
}
