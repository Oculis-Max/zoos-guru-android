package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingFreePathRegressionTest {
    @Test
    fun professionalCanCompleteFreeOnboarding() {
        val error = OnboardingRules.validationError(
            plan = "professional",
            institution = "",
            educationLevel = "",
            grade = "",
            subjects = emptyList(),
            role = "Researcher",
            organisation = "",
            focusAreas = listOf("research"),
        )
        assertNull(error)
    }
}
