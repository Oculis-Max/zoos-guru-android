package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingStudentPathRegressionTest {
    @Test
    fun studentProfileStillValidatesAsStudentWhenPaidPlanChanges() {
        val error = OnboardingRules.validationError(
            plan = "student",
            institution = "Northern Cape High School",
            educationLevel = "High school",
            grade = "12",
            subjects = listOf("Mathematics"),
            role = "",
            organisation = "",
            focusAreas = emptyList(),
        )
        assertNull(error)
    }
}
