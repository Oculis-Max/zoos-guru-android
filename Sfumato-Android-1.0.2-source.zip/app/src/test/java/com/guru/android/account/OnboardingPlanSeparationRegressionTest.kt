package com.guru.android.account

import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingPlanSeparationRegressionTest {
    @Test
    fun accessPlanAndProfilePathAreSeparateConcepts() {
        val accessPlans = setOf("free", "student", "developer", "business")
        val profilePaths = setOf("student", "developer", "professional", "business")
        assertTrue("free" in accessPlans && "free" !in profilePaths)
        assertTrue("professional" in profilePaths && "professional" !in accessPlans)
    }
}
