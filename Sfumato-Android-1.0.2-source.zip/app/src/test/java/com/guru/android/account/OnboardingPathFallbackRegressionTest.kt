package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingPathFallbackRegressionTest {
    @Test
    fun genericProfessionalProfileHasSafeFallback() {
        val error = OnboardingRules.validationError(
            plan = "professional",
            institution = "",
            educationLevel = "",
            grade = "",
            subjects = emptyList(),
            role = "Professional",
            organisation = "",
            focusAreas = listOf("productivity"),
        )
        assertNull(error)
    }
}
