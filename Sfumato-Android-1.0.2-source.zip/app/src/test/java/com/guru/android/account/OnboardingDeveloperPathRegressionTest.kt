package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingDeveloperPathRegressionTest {
    @Test
    fun developerProfileStillValidatesAsDeveloper() {
        val error = OnboardingRules.validationError(
            plan = "developer",
            institution = "",
            educationLevel = "",
            grade = "",
            subjects = emptyList(),
            role = "Android developer",
            organisation = "",
            focusAreas = listOf("Kotlin"),
        )
        assertNull(error)
    }
}
