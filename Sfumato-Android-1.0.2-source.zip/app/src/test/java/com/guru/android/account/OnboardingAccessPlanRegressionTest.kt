package com.guru.android.account

import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingAccessPlanRegressionTest {
    @Test
    fun paidPlansRemainValidCheckoutTargets() {
        assertTrue(OnboardingRules.canContinueToPayment("student"))
        assertTrue(OnboardingRules.canContinueToPayment("developer"))
        assertTrue(OnboardingRules.canContinueToPayment("business"))
    }
}
