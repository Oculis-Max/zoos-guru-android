package com.guru.android.learning

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EnochLiveVoiceTest {
    @Test
    fun live_prompt_preserves_enoch_identity_side_and_stage() {
        val prompt = enochLiveInstruction(
            topic = "Schools should require uniforms",
            stage = 4,
            learnerPosition = "for",
            opening = "Opening argument",
        )

        assertTrue(prompt.contains("You are Enoch"))
        assertTrue(prompt.contains("You argue against"))
        assertTrue(prompt.contains("Stage 4"))
        assertTrue(prompt.contains("separate Sfumato judge"))
        assertFalse(prompt.contains("Gemini"))
    }

    @Test
    fun live_round_has_a_bounded_allowance() {
        assertTrue(ENOCH_LIVE_LIMIT_SECONDS in 180..600)
    }
}
