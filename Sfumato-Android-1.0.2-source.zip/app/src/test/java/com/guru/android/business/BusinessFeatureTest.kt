package com.guru.android.business

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BusinessFeatureTest {
    @Test
    fun privacy_notice_uses_sfumato_brand_without_model_names() {
        val notice = BUSINESS_PRIVACY_NOTICE.lowercase()

        assertTrue(notice.contains("sfumato"))
        assertTrue(notice.contains("human approval"))
        assertFalse(notice.contains("gemini"))
        assertFalse(notice.contains("google"))
    }
}
