package com.guru.android.enoch

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EnochGeneralAssistantTest {
    @Test
    fun instruction_preserves_higuru_identity_and_voice_only_behavior() {
        val instruction = enochGeneralInstruction()
        assertTrue(instruction.contains("You are Enoch"))
        assertTrue(instruction.contains("audio-only"))
        assertTrue(instruction.contains("coaching"))
        assertTrue(instruction.contains("research"))
        assertFalse(instruction.contains("Gemini"))
        assertFalse(instruction.contains("Google"))
    }

    @Test
    fun voice_session_has_a_bounded_allowance() {
        assertTrue(ENOCH_GENERAL_LIMIT_SECONDS in 180..600)
    }
}
