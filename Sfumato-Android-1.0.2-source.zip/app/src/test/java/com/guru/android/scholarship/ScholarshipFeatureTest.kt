package com.guru.android.scholarship

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class ScholarshipFeatureTest {
    private val today = LocalDate.of(2026, 8, 11)

    @Test
    fun highlights_urgent_upcoming_deadlines() {
        assertEquals(
            "Closes in 10 days · 2026-08-21",
            scholarshipDeadlineLabel("2026-08-21", today),
        )
        assertEquals("Closes tomorrow", scholarshipDeadlineLabel("2026-08-12", today))
        assertEquals("Closes today", scholarshipDeadlineLabel("2026-08-11", today))
    }

    @Test
    fun marks_expired_opportunities_closed() {
        assertEquals("Closed", scholarshipDeadlineLabel("2026-08-10", today))
    }
}
