package com.guru.android.account

import org.junit.Assert.assertNotEquals
import org.junit.Test

class OnboardingNoFalseStudentValidationTest {
    @Test
    fun professionalDataMustNotRequireStudentInstitution() {
        val error = OnboardingRules.validationError(
            plan = "professional",
            institution = "",
            educationLevel = "High school",
            grade = "",
            subjects = emptyList(),
            role = "Coach",
            organisation = "",
            focusAreas = listOf("research"),
        )
        assertNotEquals("Enter your school, college or university.", error)
    }
}
