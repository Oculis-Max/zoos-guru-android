package com.guru.android.account

import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingRegressionSuiteMarkerTest {
    @Test fun regressionSuiteIsEnabled() = assertTrue(true)
}
