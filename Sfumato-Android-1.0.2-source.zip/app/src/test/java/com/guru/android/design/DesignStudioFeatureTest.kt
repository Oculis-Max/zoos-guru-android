package com.guru.android.design

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DesignStudioFeatureTest {
    private fun project(
        rooms: List<DesignRoom> = listOf(
            DesignRoom("room-1", "Living", 0.0, 0.0, 4.0, 4.0),
        ),
    ) = DesignProject(
        projectId = "project-1",
        name = "Home",
        version = 1,
        units = "metric",
        rooms = rooms,
        siteWidthM = 8.0,
        siteDepthM = 8.0,
        totalFloorAreaM2 = 0.0,
        quantities = emptyList(),
        assumptions = emptyList(),
        warnings = emptyList(),
        status = "concept_only",
    )

    @Test
    fun room_edits_stay_inside_site_and_update_quantities() {
        val edited = updateRoomGeometry(project(), "room-1", dx = 20.0, dw = 1.0)

        assertEquals(3.0, edited.rooms.first().x, 0.001)
        assertEquals(22.0, edited.quantities.first().quantity, 0.001)
        assertEquals(20.0, edited.totalFloorAreaM2, 0.001)
    }

    @Test
    fun overlapping_edit_is_rejected() {
        val original = project(
            listOf(
                DesignRoom("room-1", "One", 0.0, 0.0, 3.0, 3.0),
                DesignRoom("room-2", "Two", 4.0, 0.0, 3.0, 3.0),
            )
        )

        assertEquals(original, updateRoomGeometry(original, "room-2", dx = -2.0))
    }

    @Test
    fun added_room_uses_clear_space_or_reports_none() {
        val available = findAvailableRoom(project())
        assertTrue(available != null && !roomsOverlap(available, project().rooms.first()))

        val full = project(listOf(DesignRoom("room-1", "Full", 0.0, 0.0, 8.0, 8.0)))
        assertNull(findAvailableRoom(full))
    }
}
