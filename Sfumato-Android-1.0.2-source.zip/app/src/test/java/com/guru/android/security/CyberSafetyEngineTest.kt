package com.guru.android.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CyberSafetyEngineTest {
    @Test
    fun criticalLinkWithHiddenUserInfoIsBlocked() {
        val result = CyberSafetyEngine.assessLink("https://trusted.example@evil.example/login")
        assertEquals(SafetySeverity.CRITICAL, result.severity)
        assertFalse(result.mayProceed)
    }

    @Test
    fun insecureIpLinkIsHighRisk() {
        val result = CyberSafetyEngine.assessLink("http://192.168.0.10/verify-password")
        assertTrue(result.score >= SafetySeverity.HIGH.score)
    }

    @Test
    fun normalHttpsLinkIsNotAutomaticallyBlocked() {
        val result = CyberSafetyEngine.assessLink("https://www.gov.za/jobs")
        assertTrue(result.mayProceed)
        assertEquals(SafetySeverity.SAFE, result.severity)
    }

    @Test
    fun malformedLinkIsCritical() {
        val result = CyberSafetyEngine.assessLink("not a valid address")
        assertEquals(SafetySeverity.CRITICAL, result.severity)
        assertFalse(result.mayProceed)
    }

    @Test
    fun blankLinkFailsClosed() {
        val result = CyberSafetyEngine.assessLink("   ")
        assertEquals(SafetySeverity.CRITICAL, result.severity)
        assertFalse(result.mayProceed)
    }

    @Test
    fun encodedLookalikeDomainIsHighRiskButNotSilentlyBlocked() {
        val result = CyberSafetyEngine.assessLink("https://xn--pple-43d.example/login")
        assertEquals(SafetySeverity.HIGH, result.severity)
        assertTrue(result.mayProceed)
    }

    @Test
    fun shortenedLinkRaisesCaution() {
        val result = CyberSafetyEngine.assessLink("https://bit.ly/example")
        assertEquals(SafetySeverity.CAUTION, result.severity)
        assertTrue(result.mayProceed)
    }

    @Test
    fun plainHttpLinkIsHighRisk() {
        val result = CyberSafetyEngine.assessLink("http://example.com")
        assertEquals(SafetySeverity.HIGH, result.severity)
        assertTrue(result.mayProceed)
    }

    @Test
    fun misleadingUserInfoOverridesOtherFindingsAndBlocks() {
        val result = CyberSafetyEngine.assessLink("http://trusted.example@192.168.0.10/verify-password")
        assertEquals(SafetySeverity.CRITICAL, result.severity)
        assertFalse(result.mayProceed)
    }

    @Test
    fun hostWithoutSchemeIsSafelyNormalisedToHttps() {
        val result = CyberSafetyEngine.assessLink("www.gov.za")
        assertEquals(SafetySeverity.SAFE, result.severity)
        assertTrue(result.mayProceed)
    }
}
