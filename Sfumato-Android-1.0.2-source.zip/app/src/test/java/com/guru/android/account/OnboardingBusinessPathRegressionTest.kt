package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingBusinessPathRegressionTest {
    @Test
    fun businessProfileStillValidatesAsBusiness() {
        val error = OnboardingRules.validationError(
            plan = "business",
            institution = "",
            educationLevel = "",
            grade = "",
            subjects = emptyList(),
            role = "Founder",
            organisation = "Sfumato",
            focusAreas = listOf("growth"),
        )
        assertNull(error)
    }
}
