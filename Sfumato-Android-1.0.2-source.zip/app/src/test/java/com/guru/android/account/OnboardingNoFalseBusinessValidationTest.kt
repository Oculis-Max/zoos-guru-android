package com.guru.android.account

import org.junit.Assert.assertNotEquals
import org.junit.Test

class OnboardingNoFalseBusinessValidationTest {
    @Test
    fun professionalDataMustNotRequireBusinessOrganisation() {
        val error = OnboardingRules.validationError(
            plan = "professional",
            institution = "",
            educationLevel = "",
            grade = "",
            subjects = emptyList(),
            role = "Operations manager",
            organisation = "",
            focusAreas = listOf("planning"),
        )
        assertNotEquals("Enter your business or organisation.", error)
    }
}
