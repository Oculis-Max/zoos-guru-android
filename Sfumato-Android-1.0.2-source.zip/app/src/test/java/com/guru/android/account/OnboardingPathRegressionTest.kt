package com.guru.android.account

import org.junit.Assert.assertEquals
import org.junit.Test

class OnboardingPathRegressionTest {
    @Test
    fun paidPlanMustNotDefinePersonalizationPath() {
        assertEquals("professional", recoverPath("business", "", "", emptyList(), "", "", listOf("research")))
        assertEquals("student", recoverPath("business", "UFS", "12", listOf("Maths"), "", "", emptyList()))
        assertEquals("business", recoverPath("student", "", "", emptyList(), "Cuvella", "Technology", emptyList()))
        assertEquals("developer", recoverPath("developer", "", "", emptyList(), "", "", listOf("Kotlin")))
    }

    private fun recoverPath(
        selectedPath: String,
        institution: String,
        grade: String,
        subjects: List<String>,
        organisation: String,
        industry: String,
        focusAreas: List<String>,
    ): String = when {
        institution.isNotBlank() || grade.isNotBlank() || subjects.isNotEmpty() -> "student"
        organisation.isNotBlank() || industry.isNotBlank() -> "business"
        selectedPath == "developer" && focusAreas.isNotEmpty() -> "developer"
        selectedPath == "professional" -> "professional"
        else -> "professional"
    }
}
