package com.guru.android.account

import com.guru.android.domain.AccountProfile
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class OnboardingRulesTest {
    private fun profile(
        type: String = "free",
        version: Int = OnboardingRules.CURRENT_VERSION,
        complete: Boolean = true,
    ) = AccountProfile(
        uid = "user-1",
        email = "user@example.com",
        displayName = "User",
        accountType = type,
        onboardingVersion = version,
        onboardingComplete = complete,
    )

    @Test
    fun existing_profiles_are_migrated_once() {
        assertTrue(OnboardingRules.needsOnboarding(profile(version = 0)))
        assertFalse(OnboardingRules.needsOnboarding(profile()))
    }

    @Test
    fun every_unpaid_paid_path_opens_payment_only_after_entitlement_loads() {
        listOf("student", "developer", "business").forEach { type ->
            assertFalse(OnboardingRules.shouldOpenPayment(profile(type), "free", false))
            assertTrue(OnboardingRules.shouldOpenPayment(profile(type), "free", true))
            assertFalse(OnboardingRules.shouldOpenPayment(profile(type), type, true))
        }
        assertFalse(OnboardingRules.shouldOpenPayment(profile("free"), "free", true))
    }

    @Test
    fun changing_requested_paid_plan_can_route_to_payment_again() {
        val student = profile("student")
        val developer = profile("developer")
        assertTrue(OnboardingRules.paymentRouteKey(student) != OnboardingRules.paymentRouteKey(developer))
    }

    @Test
    fun caps_is_not_carried_into_college_or_university() {
        assertEquals("CAPS", OnboardingRules.curriculumForLevel("High school", " CAPS "))
        assertEquals("", OnboardingRules.curriculumForLevel("College", "CAPS"))
        assertEquals("", OnboardingRules.curriculumForLevel("University", "CAPS"))
    }

    @Test
    fun all_four_profile_paths_validate_their_own_fields() {
        assertEquals(null, OnboardingRules.validationError("student", "School", "High school", "Grade 8", listOf("Maths"), "", "", emptyList()))
        assertEquals(null, OnboardingRules.validationError("developer", "", "", "", emptyList(), "Android developer", "", listOf("Kotlin")))
        assertEquals(null, OnboardingRules.validationError("business", "", "", "", emptyList(), "", "Sfumato", listOf("Operations")))
        assertEquals(null, OnboardingRules.validationError("free", "", "", "", emptyList(), "", "", listOf("Job search")))

        assertTrue(OnboardingRules.validationError("student", "", "High school", "", emptyList(), "", "", emptyList()) != null)
        assertTrue(OnboardingRules.validationError("developer", "", "", "", emptyList(), "", "", listOf("Kotlin")) != null)
        assertTrue(OnboardingRules.validationError("business", "", "", "", emptyList(), "", "", listOf("Sales")) != null)
        assertTrue(OnboardingRules.validationError("free", "", "", "", emptyList(), "", "", emptyList()) != null)
    }

    @Test
    fun signed_in_startup_waits_for_profile_and_security_before_routing() {
        assertEquals(
            StartupRoute.LOADING,
            OnboardingRules.signedInRoute(
                profileLoaded = false,
                securityLoaded = false,
                isEmailVerified = true,
                profile = profile(),
                destination = "chat",
            ),
        )
        assertEquals(
            StartupRoute.LOADING,
            OnboardingRules.signedInRoute(
                profileLoaded = true,
                securityLoaded = false,
                isEmailVerified = true,
                profile = profile(),
                destination = "chat",
            ),
        )
    }

    @Test
    fun completed_signed_in_profile_opens_home_without_reentering_onboarding() {
        assertEquals(
            StartupRoute.HOME,
            OnboardingRules.signedInRoute(
                profileLoaded = true,
                securityLoaded = true,
                isEmailVerified = true,
                profile = profile(),
                destination = "chat",
            ),
        )
        assertEquals(
            StartupRoute.ACCOUNT,
            OnboardingRules.signedInRoute(
                profileLoaded = true,
                securityLoaded = true,
                isEmailVerified = true,
                profile = profile(),
                destination = "account",
            ),
        )
        assertEquals(
            StartupRoute.VERIFY_EMAIL,
            OnboardingRules.signedInRoute(
                profileLoaded = true,
                securityLoaded = true,
                isEmailVerified = false,
                profile = profile(version = 0, complete = false),
                destination = "chat",
            ),
        )
        assertEquals(
            StartupRoute.VERIFY_EMAIL,
            OnboardingRules.signedInRoute(
                profileLoaded = true,
                securityLoaded = true,
                isEmailVerified = false,
                profile = profile(),
                destination = "chat",
            ),
        )
    }


    @Test
    fun paid_paths_default_to_the_matching_plan() {
        assertEquals("student", OnboardingRules.defaultPaidPlanForPath("student"))
        assertEquals("developer", OnboardingRules.defaultPaidPlanForPath("developer"))
        assertEquals("business", OnboardingRules.defaultPaidPlanForPath("business"))
        assertEquals("", OnboardingRules.defaultPaidPlanForPath("free"))
        assertEquals("", OnboardingRules.defaultPaidPlanForPath(null))
    }

    @Test
    fun payment_continue_requires_a_real_paid_plan() {
        assertTrue(OnboardingRules.canContinueToPayment("student"))
        assertTrue(OnboardingRules.canContinueToPayment("developer"))
        assertTrue(OnboardingRules.canContinueToPayment("business"))
        assertFalse(OnboardingRules.canContinueToPayment("free"))
        assertFalse(OnboardingRules.canContinueToPayment(""))
    }


}
