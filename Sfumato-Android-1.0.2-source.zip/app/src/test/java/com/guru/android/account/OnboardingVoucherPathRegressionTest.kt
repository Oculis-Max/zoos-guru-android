package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingVoucherPathRegressionTest {
    @Test
    fun sponsoredStudentProfileCanCompleteBeforeVoucherRedemption() {
        val error = OnboardingRules.validationError(
            plan = "student",
            institution = "University of the Free State",
            educationLevel = "University",
            grade = "1",
            subjects = listOf("Computer Science"),
            role = "",
            organisation = "",
            focusAreas = emptyList(),
        )
        assertNull(error)
    }
}
