package com.guru.android.account

import org.junit.Assert.assertNull
import org.junit.Test

class OnboardingPaidPlanRegressionTest {
    @Test
    fun professionalProfileIsNotValidatedAsBusinessJustBecauseBusinessPlanWasSelected() {
        val error = OnboardingRules.validationError(
            plan = "professional",
            institution = "",
            educationLevel = "High school",
            grade = "",
            subjects = emptyList(),
            role = "Operations manager",
            organisation = "",
            focusAreas = listOf("research"),
        )
        assertNull(error)
    }
}
