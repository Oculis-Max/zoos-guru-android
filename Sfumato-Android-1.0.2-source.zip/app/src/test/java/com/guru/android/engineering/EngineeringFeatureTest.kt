package com.guru.android.engineering

import org.junit.Assert.assertEquals
import org.junit.Test

class EngineeringFeatureTest {
    @Test
    fun removes_raw_markdown_without_changing_engineering_values() {
        assertEquals(
            "Calculation\n\nForce = 25 kN",
            cleanEngineeringText("## **Calculation**\n```\nForce = 25 kN\n```"),
        )
    }
}
