package com.guru.android.di

import com.guru.android.BuildConfig
import com.guru.android.assistant.AdvancedAssistantService
import com.guru.android.billing.BillingService
import com.guru.android.business.BusinessService
import com.guru.android.data.remote.AiService
import com.guru.android.data.remote.BackendConfig
import com.guru.android.design.DesignStudioService
import com.guru.android.engineering.EngineeringService
import com.guru.android.education.EducationService
import com.guru.android.coding.CodingService
import com.guru.android.learning.LearningService
import com.guru.android.scholarship.ScholarshipService
import com.guru.android.progress.ProgressService
import com.guru.android.journalist.JournalistService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            redactHeader("Authorization")
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BASIC
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(45, TimeUnit.SECONDS)
            .readTimeout(360, TimeUnit.SECONDS)
            .callTimeout(360, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BackendConfig.baseUrl())
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideAdvancedAssistantService(retrofit: Retrofit): AdvancedAssistantService =
        retrofit.create(AdvancedAssistantService::class.java)

    @Provides
    @Singleton
    fun provideAiService(retrofit: Retrofit): AiService = retrofit.create(AiService::class.java)

    @Provides
    @Singleton
    fun provideCodingService(retrofit: Retrofit): CodingService = retrofit.create(CodingService::class.java)

    @Provides
    @Singleton
    fun provideLearningService(retrofit: Retrofit): LearningService = retrofit.create(LearningService::class.java)

    @Provides
    @Singleton
    fun provideBillingService(retrofit: Retrofit): BillingService = retrofit.create(BillingService::class.java)

    @Provides
    @Singleton
    fun provideJournalistService(retrofit: Retrofit): JournalistService =
        retrofit.create(JournalistService::class.java)

    @Provides
    @Singleton
    fun provideProgressService(retrofit: Retrofit): ProgressService =
        retrofit.create(ProgressService::class.java)

    @Provides
    @Singleton
    fun provideScholarshipService(retrofit: Retrofit): ScholarshipService =
        retrofit.create(ScholarshipService::class.java)

    @Provides
    @Singleton
    fun provideBusinessService(retrofit: Retrofit): BusinessService =
        retrofit.create(BusinessService::class.java)

    @Provides
    @Singleton
    fun provideEducationService(retrofit: Retrofit): EducationService =
        retrofit.create(EducationService::class.java)

    @Provides
    @Singleton
    fun provideEngineeringService(retrofit: Retrofit): EngineeringService =
        retrofit.create(EngineeringService::class.java)

    @Provides
    @Singleton
    fun provideDesignStudioService(retrofit: Retrofit): DesignStudioService =
        retrofit.create(DesignStudioService::class.java)
}
