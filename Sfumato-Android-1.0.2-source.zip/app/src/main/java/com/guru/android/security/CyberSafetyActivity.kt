package com.guru.android.security

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.JsonParser
import com.guru.android.data.remote.BackendConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Date

private sealed interface SafetyAccess {
    data object Checking : SafetyAccess
    data class Allowed(val tier: String) : SafetyAccess
    data class Locked(val tier: String) : SafetyAccess
    data class Error(val message: String) : SafetyAccess
}

private enum class SafetySection(val label: String) { LINK("Links"), DEVICE("Device"), APPS("Apps"), CALLS("Calls") }

class CyberSafetyActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        setContent {
            MaterialTheme(colorScheme = CyberSafetyColors) {
                CyberSafetyRoute(onBack = { finish() })
            }
        }
    }
}

@Composable
private fun CyberSafetyRoute(onBack: () -> Unit) {
    var access by remember { mutableStateOf<SafetyAccess>(SafetyAccess.Checking) }
    var retry by remember { mutableStateOf(0) }
    LaunchedEffect(retry) { access = verifyCyberSafetyAccess() }
    when (val state = access) {
        SafetyAccess.Checking -> Box(Modifier.fillMaxSize().background(Color(0xFF080A0D)), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        is SafetyAccess.Allowed -> CyberSafetyScreen(state.tier, onBack)
        is SafetyAccess.Locked -> AccessLockedScreen(state.tier, onBack)
        is SafetyAccess.Error -> ErrorScreen(state.message, onBack) { retry++ }
    }
}

private suspend fun verifyCyberSafetyAccess(): SafetyAccess = withContext(Dispatchers.IO) {
    try {
        val user = FirebaseAuth.getInstance().currentUser ?: return@withContext SafetyAccess.Locked("free")
        val token = user.getIdToken(false).await().token ?: return@withContext SafetyAccess.Error("Your secure session could not be verified.")
        val request = Request.Builder().url("${BackendConfig.baseUrl()}v1/billing/entitlement").header("Authorization", "Bearer $token").get().build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext SafetyAccess.Error("Sfumato could not verify your plan right now.")
            val body = response.body?.string().orEmpty()
            val json = JsonParser.parseString(body).asJsonObject
            val tier = json.get("tier")?.asString ?: "free"
            val status = json.get("status")?.asString ?: "inactive"
            if ((tier == "developer" || tier == "business") && status == "active") SafetyAccess.Allowed(tier) else SafetyAccess.Locked(tier)
        }
    } catch (error: Exception) {
        SafetyAccess.Error(error.message ?: "Sfumato could not verify your access.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CyberSafetyScreen(tier: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("higuru_cyber_safety", Context.MODE_PRIVATE) }
    var section by remember { mutableStateOf(SafetySection.LINK) }
    var emergencyMode by remember { mutableStateOf(prefs.getBoolean("emergency_mode", false)) }
    var confirmEmergency by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column { Text("Cyber Safety Guru", fontWeight = FontWeight.Bold); Text("${tier.replaceFirstChar(Char::uppercase)} protection", fontSize = 11.sp, color = Color(0xFF94A0AE)) } },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
                actions = { Icon(Icons.Default.Security, null, tint = Color(0xFF69E69A), modifier = Modifier.padding(end = 18.dp)) },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ProtectionBanner(emergencyMode)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                SafetySection.entries.forEach { item ->
                    val selected = item == section
                    OutlinedButton(onClick = { section = item }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selected) Color(0xFF173A2A) else Color.Transparent)) { Text(item.label, fontSize = 10.sp) }
                }
            }
            when (section) {
                SafetySection.LINK -> LinkSafetyPanel()
                SafetySection.DEVICE -> DeviceSafetyPanel()
                SafetySection.APPS -> AppSafetyPanel()
                SafetySection.CALLS -> CallSafetyPanel(emergencyMode) { confirmEmergency = true }
            }
            IncidentHistory()
        }
    }

    if (confirmEmergency) {
        AlertDialog(
            onDismissRequest = { confirmEmergency = false },
            title = { Text(if (emergencyMode) "Turn off Emergency Protection?" else "Approve Emergency Protection?") },
            text = { Text(if (emergencyMode) "Automatic protective rules will stop. Existing blocked-number choices remain saved until you remove them." else "Sfumato may automatically block a critical link inside Sfumato, silence callers already on your approved emergency blocklist and record a critical safety alert. It cannot uninstall apps, report people, lock the whole phone or change unrestricted phone settings.") },
            confirmButton = {
                Button(onClick = {
                    emergencyMode = !emergencyMode
                    prefs.edit().putBoolean("emergency_mode", emergencyMode).apply()
                    logIncident(context, if (emergencyMode) "Emergency Protection approved" else "Emergency Protection disabled")
                    confirmEmergency = false
                }) { Text(if (emergencyMode) "Turn off" else "Approve") }
            },
            dismissButton = { OutlinedButton(onClick = { confirmEmergency = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ProtectionBanner(enabled: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = if (enabled) Color(0xFF102B1D) else Color(0xFF20242A)), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (enabled) Icons.Default.CheckCircle else Icons.Default.Warning, null, tint = if (enabled) Color(0xFF69E69A) else Color(0xFFFFC857))
            Spacer(Modifier.width(12.dp))
            Column { Text(if (enabled) "Emergency Protection active" else "Review-first protection", fontWeight = FontWeight.Bold); Text(if (enabled) "Only actions you approved in advance may run automatically." else "Sfumato warns first and waits for your approval.", color = Color(0xFFAAB2BC), fontSize = 12.sp) }
        }
    }
}

@Composable
private fun LinkSafetyPanel() {
    val context = LocalContext.current
    var link by remember { mutableStateOf("") }
    var assessment by remember { mutableStateOf<SafetyAssessment?>(null) }
    var confirmOpen by remember { mutableStateOf(false) }
    SafetyCard("Check a suspicious link", "Sfumato checks common phishing and disguise patterns locally before anything opens.") {
        OutlinedTextField(link, { link = it.take(2048) }, Modifier.fillMaxWidth(), label = { Text("Paste link") }, singleLine = true)
        Button(onClick = { assessment = CyberSafetyEngine.assessLink(link); assessment?.let { logAssessment(context, "Link check", it) } }, enabled = link.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Rate this link") }
        assessment?.let { result ->
            AssessmentView(result)
            if (result.mayProceed) OutlinedButton(onClick = { confirmOpen = true }, Modifier.fillMaxWidth()) { Text("Review and open") }
            else Text("Sfumato blocked opening this critical link inside the app.", color = Color(0xFFFF7A86), fontWeight = FontWeight.Bold)
        }
    }
    if (confirmOpen) AlertDialog(
        onDismissRequest = { confirmOpen = false },
        title = { Text("Open this external link?") },
        text = { Text("You reviewed Sfumato's rating. The destination can still change or contain risks Sfumato cannot detect locally.") },
        confirmButton = { Button(onClick = { confirmOpen = false; val value = if ("://" in link) link else "https://$link"; context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value))); logIncident(context, "User approved external link") }) { Text("Approve and open") } },
        dismissButton = { OutlinedButton(onClick = { confirmOpen = false }) { Text("Cancel") } },
    )
}

@Composable
private fun DeviceSafetyPanel() {
    val context = LocalContext.current
    var assessment by remember { mutableStateOf<SafetyAssessment?>(null) }
    SafetyCard("Device and network posture", "The device ID is private, app-scoped and resets when Sfumato is reinstalled. Sfumato does not read an IMEI.") {
        Text("Sfumato device ID: ${remember { CyberSafetyEngine.shortDeviceFingerprint(context) }}", color = Color(0xFF69E69A), fontSize = 12.sp)
        Button(onClick = { assessment = CyberSafetyEngine.assessDevice(context); assessment?.let { logAssessment(context, "Device check", it) } }, Modifier.fillMaxWidth()) { Text("Check device and network") }
        assessment?.let { result -> AssessmentView(result) }
        OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Review Android security settings") }
    }
}

@Composable
private fun AppSafetyPanel() {
    val context = LocalContext.current
    var packages by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var selectedPackage by remember { mutableStateOf<String?>(null) }
    var assessment by remember { mutableStateOf<SafetyAssessment?>(null) }
    SafetyCard("Review an installed app", "Only apps Android allows Sfumato to see are listed. Selecting an app does not uninstall or modify it.") {
        Button(onClick = {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            packages = context.packageManager.queryIntentActivities(intent, 0).map { it.loadLabel(context.packageManager).toString() to it.activityInfo.packageName }.distinctBy { it.second }.sortedBy { it.first.lowercase() }
        }, Modifier.fillMaxWidth()) { Text("Choose a visible app") }
        packages.take(30).forEach { (label, packageName) ->
            OutlinedButton(onClick = { selectedPackage = packageName; assessment = runCatching { CyberSafetyEngine.assessApp(context, packageName) }.getOrNull(); assessment?.let { logAssessment(context, "App check: $label", it) } }, Modifier.fillMaxWidth()) { Text(label, maxLines = 1) }
        }
        assessment?.let { result -> AssessmentView(result) }
        selectedPackage?.let { packageName -> OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }, Modifier.fillMaxWidth()) { Text("Review this app in Android settings") } }
    }
}

@Composable
private fun CallSafetyPanel(emergencyMode: Boolean, requestEmergencyChange: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("higuru_cyber_safety", Context.MODE_PRIVATE) }
    var roleGranted by remember { mutableStateOf(isCallScreeningRoleHeld(context)) }
    var number by remember { mutableStateOf("") }
    var pendingNumber by remember { mutableStateOf<String?>(null) }
    var approvedNumbers by remember {
        mutableStateOf(prefs.getStringSet("approved_blocked_numbers", emptySet()).orEmpty().sorted())
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { roleGranted = it.resultCode == Activity.RESULT_OK || isCallScreeningRoleHeld(context) }
    SafetyCard("Spam-call protection", "Android requires you to deliberately choose Sfumato as the call-screening app. Only approved emergency rules may silence a call.") {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Button(onClick = { val manager = context.getSystemService(RoleManager::class.java); launcher.launch(manager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)) }, Modifier.fillMaxWidth()) { Text(if (roleGranted) "Call screening approved" else "Choose Sfumato for call screening") }
        else Text("Call screening requires Android 10 or newer.", color = Color(0xFFFFC857))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Emergency Protection", fontWeight = FontWeight.Bold); Text("Uses only rules approved beforehand", color = Color(0xFFAAB2BC), fontSize = 11.sp) }; Switch(emergencyMode, onCheckedChange = { requestEmergencyChange() }) }
        OutlinedTextField(number, { number = it.filter { character -> character.isDigit() || character == '+' }.take(20) }, Modifier.fillMaxWidth(), label = { Text("Number to block in emergencies") }, singleLine = true)
        OutlinedButton(onClick = { pendingNumber = number }, enabled = number.length >= 7, modifier = Modifier.fillMaxWidth()) { Text("Review blocklist addition") }
        if (approvedNumbers.isNotEmpty()) {
            Text("Approved emergency blocklist", fontWeight = FontWeight.Bold)
            approvedNumbers.forEach { approved ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        approved.takeLast(4).padStart(approved.length.coerceAtMost(12), '*'),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedButton(onClick = {
                        approvedNumbers = approvedNumbers - approved
                        prefs.edit().putStringSet("approved_blocked_numbers", approvedNumbers.toSet()).apply()
                        logIncident(context, "User removed an emergency call-block approval")
                    }) { Text("Remove") }
                }
            }
        }
    }
    pendingNumber?.let { value -> AlertDialog(
        onDismissRequest = { pendingNumber = null },
        title = { Text("Approve future call blocking?") },
        text = { Text("When Emergency Protection is active, Sfumato may silently reject future calls from $value. You can remove this approval later.") },
        confirmButton = { Button(onClick = { approvedNumbers = (approvedNumbers + value).distinct().sorted(); prefs.edit().putStringSet("approved_blocked_numbers", approvedNumbers.toSet()).apply(); logIncident(context, "User approved emergency block for ${value.takeLast(4).padStart(value.length, '*')}"); pendingNumber = null; number = "" }) { Text("Approve") } },
        dismissButton = { OutlinedButton(onClick = { pendingNumber = null }) { Text("Cancel") } },
    ) }
}

@Composable
private fun SafetyCard(title: String, description: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF15191E)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(description, color = Color(0xFFAAB2BC), fontSize = 12.sp)
            content()
        }
    }
}

@Composable
private fun AssessmentView(assessment: SafetyAssessment) {
    val colour = when (assessment.severity) { SafetySeverity.SAFE -> Color(0xFF69E69A); SafetySeverity.CAUTION -> Color(0xFFFFC857); SafetySeverity.HIGH -> Color(0xFFFF9A5C); SafetySeverity.CRITICAL -> Color(0xFFFF6575) }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(assessment.severity.label, color = colour, fontWeight = FontWeight.Black, fontSize = 19.sp); Spacer(Modifier.weight(1f)); Text("Risk ${assessment.score}/100", color = colour, fontWeight = FontWeight.Bold) }
        Text("Checked: ${assessment.subject}", color = Color(0xFFAAB2BC), fontSize = 11.sp)
        assessment.findings.forEach { finding -> Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20252B))) { Column(Modifier.padding(13.dp)) { Text(finding.title, fontWeight = FontWeight.Bold); Text("What Sfumato detected", color = colour, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp)); Text(finding.detail, color = Color(0xFFB4BCC6), fontSize = 12.sp); Text("How to protect yourself", color = colour, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)); Text(finding.recommendedAction, color = Color(0xFFE1E7EC), fontSize = 11.sp) } } }
    }
}

@Composable
private fun IncidentHistory() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("higuru_cyber_safety", Context.MODE_PRIVATE) }
    var incidents by remember {
        mutableStateOf(prefs.getStringSet("incident_log", emptySet()).orEmpty().sortedDescending().take(8))
    }
    if (incidents.isNotEmpty()) SafetyCard("Recent safety activity", "Stored only on this device.") {
        incidents.forEach { Text(it, color = Color(0xFFB4BCC6), fontSize = 11.sp) }
        OutlinedButton(
            onClick = {
                prefs.edit().remove("incident_log").apply()
                incidents = emptyList()
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Clear safety history") }
    }
}

private fun logIncident(context: Context, message: String) {
    val prefs = context.getSharedPreferences("higuru_cyber_safety", Context.MODE_PRIVATE)
    val entry = "${Date()} · ${message.replace("\n", " ").take(240)}"
    prefs.edit().putStringSet("incident_log", (prefs.getStringSet("incident_log", emptySet()).orEmpty() + entry).sortedDescending().take(50).toSet()).apply()
}

private fun logAssessment(context: Context, category: String, assessment: SafetyAssessment) {
    val finding = assessment.findings.maxByOrNull { it.severity.score } ?: return
    logIncident(
        context,
        "$category · ${finding.severity.label} · ${finding.title} · Detected: ${finding.detail} · Action: ${finding.recommendedAction}",
    )
}

private fun isCallScreeningRoleHeld(context: Context): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && context.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccessLockedScreen(tier: String, onBack: () -> Unit) = Scaffold(topBar = { TopAppBar(title = { Text("Cyber Safety Guru") }, navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") } }) }) { padding -> Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) { Icon(Icons.Default.Security, null, tint = Color(0xFF69E69A)); Text("Developer or Business plan required", fontWeight = FontWeight.Black, fontSize = 28.sp); Text("Your current ${tier.replaceFirstChar(Char::uppercase)} plan does not include Cyber Safety Guru.", color = Color(0xFFAAB2BC)); Button(onClick = onBack) { Text("Return to Sfumato") } } } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ErrorScreen(message: String, onBack: () -> Unit, retry: () -> Unit) = Scaffold(topBar = { TopAppBar(title = { Text("Cyber Safety Guru") }, navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") } }) }) { padding -> Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("Access check unavailable", fontWeight = FontWeight.Bold, fontSize = 24.sp); Text(message, color = Color(0xFFAAB2BC)); Button(onClick = retry) { Text("Try again") } } } }

private val CyberSafetyColors: ColorScheme = darkColorScheme(
    primary = Color(0xFF69E69A), onPrimary = Color(0xFF06130B), background = Color(0xFF080A0D), onBackground = Color(0xFFF5F7F8), surface = Color(0xFF101419), onSurface = Color(0xFFF5F7F8), surfaceVariant = Color(0xFF20252B), onSurfaceVariant = Color(0xFFD2D8DE), outline = Color(0xFF5D6975), error = Color(0xFFFF6575),
)
