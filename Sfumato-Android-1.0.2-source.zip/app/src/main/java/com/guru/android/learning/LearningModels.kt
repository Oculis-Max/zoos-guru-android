package com.guru.android.learning

import com.google.gson.annotations.SerializedName

data class TutorSessionRequest(
    val mode: String,
    val subject: String,
    val topic: String,
    val grade: String?,
    val curriculum: String? = null,
)

data class TutorFollowUpRequest(
    val mode: String,
    val subject: String,
    val topic: String,
    val grade: String?,
    val curriculum: String? = null,
    @SerializedName("lesson_context") val lessonContext: String,
    @SerializedName("learner_message") val learnerMessage: String,
)

data class TutorFinishRequest(
    val mode: String,
    val subject: String,
    val topic: String,
    val grade: String?,
    val curriculum: String? = null,
    @SerializedName("lesson_context") val lessonContext: String,
)

data class TutorTurn(
    val role: String,
    val content: String,
)

data class DebateAttemptRequest(
    val topic: String,
    val stage: Int,
    val position: String,
)

data class DebateFollowUpRequest(
    val topic: String,
    val stage: Int,
    @SerializedName("user_position") val userPosition: String,
    @SerializedName("debate_context") val debateContext: String,
    @SerializedName("learner_argument") val learnerArgument: String,
)

data class DebateFinishRequest(
    val topic: String,
    val stage: Int,
    @SerializedName("user_position") val userPosition: String,
    @SerializedName("debate_context") val debateContext: String,
)

data class GeneratedLearningResponse(
    val content: String,
    val score: Int? = null,
    val passed: Boolean? = null,
    @SerializedName("highest_unlocked_stage") val highestUnlockedStage: Int? = null,
)

data class LearningRecord(
    val id: String,
    @SerializedName("user_id") val userId: String,
    val data: Map<String, Any?> = emptyMap(),
)

data class ArenaStatus(
    @SerializedName("highest_unlocked_stage") val highestUnlockedStage: Int = 1,
    @SerializedName("best_debate_score") val bestDebateScore: Int = 0,
    @SerializedName("overall_higuru_score") val overallHiGuruScore: Int = 0,
)

internal fun stageName(stage: Int): String = when (stage) {
    1 -> "Foundation"
    2 -> "Challenger"
    3 -> "Advanced"
    4 -> "Expert"
    5 -> "Grandmaster"
    else -> "Unknown"
}

internal fun stagePassScore(stage: Int): Int = when (stage) {
    1 -> 60
    2 -> 70
    3 -> 80
    4 -> 90
    5 -> 95
    else -> 60
}

internal fun stageFocus(stage: Int): String = when (stage) {
    1 -> "Clear claims and reasons"
    2 -> "Evidence and weak-point challenges"
    3 -> "Nuance and hidden assumptions"
    4 -> "Expert logic and anticipated rebuttals"
    5 -> "Steelman, rebuttal and difficult dilemmas"
    else -> "Structured argument"
}
