package com.guru.android.data.remote

import com.google.gson.annotations.SerializedName

data class ChatRequest(
    val messages: List<MessagePayload>,
)

data class MessagePayload(
    val role: String,
    val content: String,
)

data class TokenUsage(
    @SerializedName("prompt_tokens") val promptTokens: Int = 0,
    @SerializedName("completion_tokens") val completionTokens: Int = 0,
    @SerializedName("total_tokens") val totalTokens: Int = 0,
)

data class ChatResponse(
    val message: MessagePayload,
    val usage: TokenUsage = TokenUsage(),
    @SerializedName("remaining_tokens") val remainingTokens: Int? = null,
)
