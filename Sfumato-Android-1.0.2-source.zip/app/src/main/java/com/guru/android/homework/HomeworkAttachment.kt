package com.guru.android.homework

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class HomeworkSource(
    val name: String,
    val text: String,
)

private const val MAX_FILE_BYTES = 10_000_000L
private const val MAX_PDF_PAGES = 6
private const val MAX_EXTRACTED_CHARS = 12_000

@Composable
fun HomeworkAttachmentButton(
    onLoaded: (HomeworkSource) -> Unit,
    onError: (String) -> Unit,
    contentDescription: String = "Attach or scan homework",
    documentLabel: String = "Upload PDF or document",
    photoLabel: String = "Choose homework photo",
    scanLabel: String = "Scan homework with camera",
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }

    fun load(uri: Uri) {
        if (processing) return
        processing = true
        scope.launch {
            runCatching { extractHomework(context, uri) }
                .onSuccess(onLoaded)
                .onFailure { onError(it.message ?: "Could not read that homework") }
            processing = false
        }
    }

    val documentPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> uri?.let(::load) }
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent(),
    ) { uri -> uri?.let(::load) }
    val scannerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scan = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            val firstPage = scan?.pages?.firstOrNull()?.imageUri
            if (firstPage != null) load(firstPage) else onError("The scan did not contain a page")
        }
    }
    val scanner = remember {
        GmsDocumentScanning.getClient(
            GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(MAX_PDF_PAGES)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
        )
    }

    Box {
        IconButton(
            onClick = { menuOpen = true },
            enabled = !processing,
        ) {
            Icon(Icons.Default.Add, contentDescription = contentDescription)
        }
        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = { menuOpen = false },
        ) {
            DropdownMenuItem(
                text = { Text(documentLabel) },
                onClick = {
                    menuOpen = false
                    documentPicker.launch(arrayOf("application/pdf", "text/plain"))
                },
            )
            DropdownMenuItem(
                text = { Text(photoLabel) },
                onClick = {
                    menuOpen = false
                    photoPicker.launch("image/*")
                },
            )
            DropdownMenuItem(
                text = { Text(scanLabel) },
                onClick = {
                    menuOpen = false
                    if (activity == null) {
                        onError("Camera scanner is unavailable")
                    } else {
                        scanner.getStartScanIntent(activity)
                            .addOnSuccessListener { sender ->
                                scannerLauncher.launch(IntentSenderRequest.Builder(sender).build())
                            }
                            .addOnFailureListener {
                                onError("Could not start the homework scanner")
                            }
                    }
                },
            )
        }
    }
}

private suspend fun extractHomework(context: Context, uri: Uri): HomeworkSource {
    val resolver = context.contentResolver
    val name = resolver.query(
        uri,
        arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
        null,
        null,
        null,
    )?.use { cursor ->
        if (!cursor.moveToFirst()) null else {
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                require(cursor.getLong(sizeIndex) <= MAX_FILE_BYTES) {
                    "Homework file is larger than 10 MB"
                }
            }
            cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
        }
    } ?: "Scanned homework"

    val mime = resolver.getType(uri).orEmpty()
    val text = when {
        mime == "application/pdf" || name.endsWith(".pdf", ignoreCase = true) ->
            extractPdf(context, uri)
        mime.startsWith("image/") -> extractImage(context, uri)
        else -> resolver.openInputStream(uri)?.use { stream ->
            val bytes = stream.readBytes()
            require(bytes.size <= MAX_FILE_BYTES) { "Homework file is larger than 10 MB" }
            bytes.toString(Charsets.UTF_8)
        }.orEmpty()
    }.trim().take(MAX_EXTRACTED_CHARS)

    require(text.isNotBlank()) {
        "No readable homework text was found. Try a clearer photo with good lighting."
    }
    return HomeworkSource(name = name, text = text)
}

private suspend fun extractImage(context: Context, uri: Uri): String {
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    return try {
        recognizer.process(InputImage.fromFilePath(context, uri)).await().text
    } finally {
        recognizer.close()
    }
}

private suspend fun extractPdf(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
    val descriptor = context.contentResolver.openFileDescriptor(uri, "r")
        ?: error("Unable to open PDF")
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    descriptor.use { file ->
        PdfRenderer(file).use { renderer ->
            buildString {
                val count = minOf(renderer.pageCount, MAX_PDF_PAGES)
                for (index in 0 until count) {
                    renderer.openPage(index).use { page ->
                        val scale = minOf(2f, 1600f / page.width.toFloat())
                        val width = maxOf(page.width, (page.width * scale).toInt())
                        val height = maxOf(page.height, (page.height * scale).toInt())
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        try {
                            val recognized = recognizer
                                .process(InputImage.fromBitmap(bitmap, 0))
                                .await()
                                .text
                            if (recognized.isNotBlank()) {
                                append("\nPage ").append(index + 1).append("\n")
                                append(recognized)
                            }
                        } finally {
                            bitmap.recycle()
                        }
                    }
                }
            }
        }
    }.also { recognizer.close() }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
