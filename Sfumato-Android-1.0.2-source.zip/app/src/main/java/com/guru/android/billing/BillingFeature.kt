package com.guru.android.billing

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton

data class SubscriptionPlan(
    val tier: String,
    val name: String,
    @SerializedName("amount_zar") val amountZar: Int,
    val interval: String,
    @SerializedName("autonomous_coding") val autonomousCoding: Boolean = false,
)

data class CheckoutRequest(val tier: String)
data class CheckoutResponse(
    val tier: String,
    @SerializedName("checkout_url") val checkoutUrl: String,
    val reference: String,
)
data class EntitlementResponse(
    val tier: String = "free",
    val status: String = "inactive",
    @SerializedName("autonomous_coding") val autonomousCoding: Boolean = false,
    val source: String? = null,
    @SerializedName("campaign_id") val campaignId: String? = null,
    val sponsor: String? = null,
    @SerializedName("sponsored_until") val sponsoredUntil: String? = null,
)
data class VoucherRedemptionRequest(
    val code: String,
    val institution: String,
    @SerializedName("education_level") val educationLevel: String,
    val grade: String,
    val curriculum: String,
    val subjects: List<String>,
)
data class VoucherRedemptionResponse(
    val tier: String,
    val status: String,
    @SerializedName("campaign_id") val campaignId: String? = null,
    val sponsor: String? = null,
    @SerializedName("sponsored_until") val sponsoredUntil: String? = null,
)

interface BillingService {
    @GET("v1/billing/plans")
    suspend fun plans(): List<SubscriptionPlan>

    @POST("v1/billing/checkout")
    suspend fun checkout(
        @Header("Authorization") authorization: String,
        @Body request: CheckoutRequest,
    ): CheckoutResponse

    @GET("v1/billing/entitlement")
    suspend fun entitlement(@Header("Authorization") authorization: String): EntitlementResponse

    @POST("v1/billing/vouchers/redeem")
    suspend fun redeemVoucher(
        @Header("Authorization") authorization: String,
        @Body request: VoucherRedemptionRequest,
    ): VoucherRedemptionResponse
}

@Singleton
class BillingRepository @Inject constructor(private val service: BillingService) {
    private val auth = FirebaseAuth.getInstance()

    suspend fun plans(): List<SubscriptionPlan> = service.plans()
    suspend fun checkout(tier: String) = service.checkout(bearerToken(), CheckoutRequest(tier))
    suspend fun entitlement() = service.entitlement(bearerToken(forceRefresh = true))
    suspend fun redeemVoucher(request: VoucherRedemptionRequest) =
        service.redeemVoucher(bearerToken(forceRefresh = true), request)

    private suspend fun bearerToken(forceRefresh: Boolean = false): String {
        val user = checkNotNull(auth.currentUser) { "Sign in to manage your subscription." }
        val token = checkNotNull(user.getIdToken(forceRefresh).await().token) {
            "Firebase did not return an ID token."
        }
        return "Bearer " + token
    }
}

data class BillingUiState(
    val isWorking: Boolean = false,
    val plans: List<SubscriptionPlan> = emptyList(),
    val entitlement: EntitlementResponse = EntitlementResponse(),
    val checkoutUrl: String? = null,
    val error: String? = null,
)

@HiltViewModel
class BillingViewModel @Inject constructor(private val repository: BillingRepository) : ViewModel() {
    private val mutableState = MutableStateFlow(BillingUiState())
    val state: StateFlow<BillingUiState> = mutableState.asStateFlow()

    init { refresh() }

    fun subscribe(tier: String) {
        if (mutableState.value.isWorking) return
        viewModelScope.launch {
            mutableState.update { it.copy(isWorking = true, checkoutUrl = null, error = null) }
            try {
                val checkout = repository.checkout(tier)
                mutableState.update { it.copy(checkoutUrl = checkout.checkoutUrl) }
            } catch (error: Exception) {
                mutableState.update { it.copy(error = friendlyError(error)) }
            } finally {
                mutableState.update { it.copy(isWorking = false) }
            }
        }
    }

    fun checkoutOpened() = mutableState.update { it.copy(checkoutUrl = null) }

    fun refresh() {
        if (mutableState.value.isWorking) return
        viewModelScope.launch {
            mutableState.update { it.copy(isWorking = true, error = null) }
            try {
                val plans = repository.plans()
                val entitlement = repository.entitlement()
                mutableState.update { it.copy(plans = plans, entitlement = entitlement) }
            } catch (error: Exception) {
                mutableState.update { it.copy(error = friendlyError(error)) }
            } finally {
                mutableState.update { it.copy(isWorking = false) }
            }
        }
    }

    private fun friendlyError(error: Exception): String =
        if (error is HttpException) when (error.code()) {
            401 -> "Your session expired. Sign in again."
            502 -> "Paystack is temporarily unavailable. Please try again."
            503 -> "Payments are being configured. Please try again shortly."
            else -> "Subscription service error (HTTP " + error.code() + ")."
        } else error.message ?: "Could not load your subscription."
}

@Composable
fun BillingScreen(viewModel: BillingViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && state.checkoutUrl == null) viewModel.refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(state.checkoutUrl) {
        state.checkoutUrl?.let {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)))
            viewModel.checkoutOpened()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Choose your Sfumato plan", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Start free, then upgrade when you need deeper learning, autonomous coding, or business capacity.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        CurrentPlanCard(state.entitlement)

        if (state.plans.isEmpty() && state.isWorking) {
            CircularProgressIndicator()
        } else {
            state.plans.forEach { plan ->
                PlanCard(
                    plan = plan,
                    current = plan.tier == state.entitlement.tier &&
                        (plan.tier == "free" || state.entitlement.status == "active"),
                    enabled = !state.isWorking,
                    onSubscribe = { viewModel.subscribe(plan.tier) },
                )
            }
        }

        state.error?.let {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text(it, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        OutlinedButton(
            onClick = viewModel::refresh,
            enabled = !state.isWorking,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Refresh payment and access")
        }
        Text(
            "Checkout is handled securely by Paystack. Sfumato never stores card details. Access activates only after Paystack verifies payment.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun CurrentPlanCard(entitlement: EntitlementResponse) {
    val active = entitlement.status == "active" || entitlement.tier == "free"
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Current plan", style = MaterialTheme.typography.labelLarge)
            Text(planTitle(entitlement.tier), style = MaterialTheme.typography.headlineSmall)
            Text(if (active) "Access active" else "Payment not active")
            if (entitlement.autonomousCoding) {
                Text("Autonomous Coding unlocked", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun PlanCard(
    plan: SubscriptionPlan,
    current: Boolean,
    enabled: Boolean,
    onSubscribe: () -> Unit,
) {
    val features = when (plan.tier) {
        "free" -> listOf("Core Sfumato chat", "20 prompts per day", "Upgrade at any time")
        "student" -> listOf(
            "AI Tutor and five-stage Debate Arena",
            "Scholarship Guru",
            "Classes, courses and education dashboards",
        )
        "developer" -> listOf(
            "Enoch voice intelligence",
            "Autonomous Coding Agent",
            "GitHub draft PRs and Cyber Safety",
        )
        "business" -> listOf(
            "Enoch voice intelligence",
            "Business and Advanced Assistants",
            "Engineering, Design, Journalist and Cyber Safety",
        )
        else -> emptyList()
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(plan.name, style = MaterialTheme.typography.titleLarge)
                Text(
                    if (plan.amountZar == 0) "Free" else "R" + "%,d".format(plan.amountZar) + "/month",
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            features.forEach { Text("✓  " + it) }
            when {
                current -> FilledTonalButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
                    Text("Current plan")
                }
                plan.tier == "free" -> OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
                    Text("Included")
                }
                else -> Button(onClick = onSubscribe, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                    Text("Choose " + planTitle(plan.tier))
                }
            }
        }
    }
}

private fun planTitle(tier: String): String = when (tier) {
    "student" -> "Student Pro"
    "developer" -> "Developer"
    "business" -> "Business"
    else -> "Free"
}
