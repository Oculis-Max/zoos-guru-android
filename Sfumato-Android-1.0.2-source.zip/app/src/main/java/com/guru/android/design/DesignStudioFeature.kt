package com.guru.android.design

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import kotlin.math.max

data class DesignRoom(
    val id: String,
    val name: String,
    val x: Double,
    val y: Double,
    val width: Double,
    val height: Double,
)

data class MaterialQuantity(
    val item: String,
    val quantity: Double,
    val unit: String,
    val basis: String,
)

data class DesignProject(
    @SerializedName("project_id") val projectId: String,
    val name: String,
    val version: Int,
    val units: String,
    val rooms: List<DesignRoom>,
    @SerializedName("site_width_m") val siteWidthM: Double,
    @SerializedName("site_depth_m") val siteDepthM: Double,
    @SerializedName("total_floor_area_m2") val totalFloorAreaM2: Double,
    val quantities: List<MaterialQuantity>,
    val assumptions: List<String>,
    val warnings: List<String>,
    val status: String,
)

data class GenerateDesignRequest(
    val prompt: String,
    @SerializedName("project_name") val projectName: String,
    @SerializedName("site_width_m") val siteWidthM: Double,
    @SerializedName("site_depth_m") val siteDepthM: Double,
)

data class SaveDesignVersionRequest(
    val name: String,
    val rooms: List<DesignRoom>,
    @SerializedName("previous_version") val previousVersion: Int,
)

interface DesignStudioService {
    @POST("v1/design/generate")
    suspend fun generate(
        @Header("Authorization") authorization: String,
        @Body request: GenerateDesignRequest,
    ): DesignProject

    @POST("v1/design/projects/{projectId}/versions")
    suspend fun saveVersion(
        @Header("Authorization") authorization: String,
        @Path("projectId") projectId: String,
        @Body request: SaveDesignVersionRequest,
    ): DesignProject
}

@Singleton
class DesignStudioRepository @Inject constructor(private val service: DesignStudioService) {
    private suspend fun token(): String {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        return checkNotNull(user.getIdToken(false).await().token) { "Session expired." }
    }

    suspend fun generate(request: GenerateDesignRequest): DesignProject =
        service.generate("Bearer " + token(), request)

    suspend fun save(project: DesignProject): DesignProject =
        service.saveVersion(
            "Bearer " + token(),
            project.projectId,
            SaveDesignVersionRequest(project.name, project.rooms, project.version),
        )
}

data class DesignStudioState(
    val projectName: String = "",
    val prompt: String = "",
    val siteWidth: String = "12",
    val siteDepth: String = "15",
    val project: DesignProject? = null,
    val selectedRoomId: String? = null,
    val busy: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

@HiltViewModel
class DesignStudioViewModel @Inject constructor(
    private val repository: DesignStudioRepository,
) : ViewModel() {
    private val mutableState = MutableStateFlow(DesignStudioState())
    val state = mutableState.asStateFlow()

    fun projectName(value: String) = mutableState.update { it.copy(projectName = value) }
    fun prompt(value: String) = mutableState.update { it.copy(prompt = value) }
    fun siteWidth(value: String) = mutableState.update { it.copy(siteWidth = value) }
    fun siteDepth(value: String) = mutableState.update { it.copy(siteDepth = value) }
    fun selectRoom(id: String) = mutableState.update { it.copy(selectedRoomId = id) }
    fun newProject() = mutableState.update {
        DesignStudioState(
            siteWidth = it.project?.siteWidthM?.toString() ?: it.siteWidth,
            siteDepth = it.project?.siteDepthM?.toString() ?: it.siteDepth,
        )
    }

    fun generate() {
        val current = mutableState.value
        val width = current.siteWidth.toDoubleOrNull()
        val depth = current.siteDepth.toDoubleOrNull()
        if (current.projectName.trim().length < 2 || current.prompt.trim().length < 15) {
            mutableState.update { it.copy(error = "Add a project name and a detailed layout request.") }
            return
        }
        if (width == null || depth == null || width !in 3.0..50.0 || depth !in 3.0..50.0) {
            mutableState.update { it.copy(error = "Site dimensions must be between 3 m and 50 m.") }
            return
        }
        launch {
            repository.generate(
                GenerateDesignRequest(
                    prompt = current.prompt.trim(),
                    projectName = current.projectName.trim(),
                    siteWidthM = width,
                    siteDepthM = depth,
                )
            )
        }
    }

    fun adjustSelected(dx: Double = 0.0, dy: Double = 0.0, dw: Double = 0.0, dh: Double = 0.0) {
        val current = mutableState.value
        val project = current.project ?: return
        val selected = current.selectedRoomId ?: return
        val edited = updateRoomGeometry(project, selected, dx, dy, dw, dh)
        mutableState.update {
            it.copy(
                project = edited,
                error = if (edited == project) "Rooms cannot overlap or leave the project site." else null,
                notice = if (edited == project) it.notice else "Unsaved edit",
            )
        }
    }

    fun addRoom() {
        val project = mutableState.value.project ?: return
        if (project.rooms.size >= 40) {
            mutableState.update { it.copy(error = "This concept already has the maximum 40 rooms.") }
            return
        }
        val room = findAvailableRoom(project)
        if (room == null) {
            mutableState.update {
                it.copy(error = "No clear 3 m × 3 m space is available. Move or resize a room first.")
            }
            return
        }
        mutableState.update {
            it.copy(
                project = recalculateDesignProject(project.copy(rooms = project.rooms + room)),
                selectedRoomId = room.id,
                error = null,
                notice = "Unsaved edit",
            )
        }
    }

    fun deleteSelected() {
        val current = mutableState.value
        val project = current.project ?: return
        val selected = current.selectedRoomId ?: return
        if (project.rooms.size <= 1) {
            mutableState.update { it.copy(error = "A design must contain at least one room.") }
            return
        }
        val rooms = project.rooms.filterNot { it.id == selected }
        mutableState.update {
            it.copy(
                project = recalculateDesignProject(project.copy(rooms = rooms)),
                selectedRoomId = rooms.firstOrNull()?.id,
                error = null,
                notice = "Unsaved edit",
            )
        }
    }

    fun saveVersion() {
        val project = mutableState.value.project ?: return
        launch { repository.save(project) }
    }

    private fun launch(block: suspend () -> DesignProject) {
        if (mutableState.value.busy) return
        viewModelScope.launch {
            mutableState.update { it.copy(busy = true, error = null, notice = null) }
            try {
                val project = block()
                mutableState.update {
                    it.copy(
                        project = project,
                        selectedRoomId = project.rooms.firstOrNull()?.id,
                        notice = "Version " + project.version + " saved",
                    )
                }
            } catch (error: Exception) {
                val message = if (error is HttpException) when (error.code()) {
                    401 -> "Your session expired. Sign in again."
                    403 -> "Design Studio requires the Business plan."
                    409 -> "This project changed or needs regeneration. Start a new concept."
                    429 -> "Design Studio is busy. Try again shortly."
                    502 -> "The generated layout was unsafe or malformed. Try a clearer request."
                    503 -> "Design Studio is temporarily unavailable."
                    else -> "Server error (HTTP " + error.code() + ")."
                } else error.message ?: "Could not complete the design request."
                mutableState.update { it.copy(error = message) }
            } finally {
                mutableState.update { it.copy(busy = false) }
            }
        }
    }
}

internal fun roomsOverlap(first: DesignRoom, second: DesignRoom): Boolean =
    first.x < second.x + second.width &&
        first.x + first.width > second.x &&
        first.y < second.y + second.height &&
        first.y + first.height > second.y

internal fun recalculateDesignProject(project: DesignProject): DesignProject {
    val area = project.rooms.sumOf { it.width * it.height }
    val perimeter = project.rooms.sumOf { 2 * (it.width + it.height) }
    return project.copy(
        totalFloorAreaM2 = kotlin.math.round(area * 100) / 100,
        quantities = listOf(
            MaterialQuantity(
                "Floor finish",
                kotlin.math.round(area * 1.10 * 100) / 100,
                "m²",
                "Room area plus 10% preliminary waste allowance",
            ),
            MaterialQuantity(
                "Concept wall length",
                kotlin.math.round(perimeter * 100) / 100,
                "m",
                "Sum of room perimeters; shared walls have not been deducted",
            ),
        ),
    )
}

internal fun updateRoomGeometry(
    project: DesignProject,
    selectedId: String,
    dx: Double = 0.0,
    dy: Double = 0.0,
    dw: Double = 0.0,
    dh: Double = 0.0,
): DesignProject {
    val rooms = project.rooms.map { room ->
        if (room.id != selectedId) room else {
            val width = (room.width + dw).coerceIn(0.5, minOf(30.0, project.siteWidthM))
            val height = (room.height + dh).coerceIn(0.5, minOf(30.0, project.siteDepthM))
            room.copy(
                x = (room.x + dx).coerceIn(0.0, project.siteWidthM - width),
                y = (room.y + dy).coerceIn(0.0, project.siteDepthM - height),
                width = width,
                height = height,
            )
        }
    }
    val selected = rooms.firstOrNull { it.id == selectedId } ?: return project
    if (rooms.any { it.id != selectedId && roomsOverlap(selected, it) }) return project
    return recalculateDesignProject(project.copy(rooms = rooms))
}

internal fun findAvailableRoom(project: DesignProject): DesignRoom? {
    val width = minOf(3.0, project.siteWidthM)
    val height = minOf(3.0, project.siteDepthM)
    val maxX = ((project.siteWidthM - width) * 2).toInt()
    val maxY = ((project.siteDepthM - height) * 2).toInt()
    for (yStep in 0..maxY) {
        for (xStep in 0..maxX) {
            val candidate = DesignRoom(
                id = "room-" + System.currentTimeMillis(),
                name = "Room " + (project.rooms.size + 1),
                x = xStep / 2.0,
                y = yStep / 2.0,
                width = width,
                height = height,
            )
            if (project.rooms.none { roomsOverlap(candidate, it) }) return candidate
        }
    }
    return null
}

@Composable
fun DesignStudioScreen(viewModel: DesignStudioViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Sfumato Design Studio", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Create, edit and export validated metric 2D concept layouts.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (state.project == null) {
            OutlinedTextField(
                value = state.projectName,
                onValueChange = viewModel::projectName,
                label = { Text("Project name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = state.siteWidth,
                    onValueChange = viewModel::siteWidth,
                    label = { Text("Width (m)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                )
                OutlinedTextField(
                    value = state.siteDepth,
                    onValueChange = viewModel::siteDepth,
                    label = { Text("Depth (m)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                )
            }
            OutlinedTextField(
                value = state.prompt,
                onValueChange = viewModel::prompt,
                label = { Text("Describe the layout") },
                placeholder = {
                    Text("A three-bedroom home with an open kitchen, two bathrooms and a garage")
                },
                minLines = 5,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = viewModel::generate,
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Generate editable concept") }
        }

        if (state.busy) {
            CircularProgressIndicator()
            Text("Validating geometry and preparing the concept…")
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        state.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

        state.project?.let { project ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text(project.name, style = MaterialTheme.typography.titleLarge)
                    Text("Version " + project.version + " · Concept only")
                }
                Text(
                    String.format(Locale.US, "%.1f m²", project.rooms.sumOf { it.width * it.height }),
                    color = MaterialTheme.colorScheme.primary,
                )
            }

            DesignCanvas(project)

            Text("Select a room", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                project.rooms.forEach { room ->
                    if (state.selectedRoomId == room.id) {
                        Button(onClick = { viewModel.selectRoom(room.id) }) { Text(room.name) }
                    } else {
                        OutlinedButton(onClick = { viewModel.selectRoom(room.id) }) {
                            Text(room.name)
                        }
                    }
                }
            }

            project.rooms.firstOrNull { it.id == state.selectedRoomId }?.let { room ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(room.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            String.format(
                                Locale.US,
                                "Position %.2f, %.2f m · Size %.2f × %.2f m",
                                room.x,
                                room.y,
                                room.width,
                                room.height,
                            )
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { viewModel.adjustSelected(dx = -0.25) }) {
                                Text("←")
                            }
                            OutlinedButton(onClick = { viewModel.adjustSelected(dx = 0.25) }) {
                                Text("→")
                            }
                            OutlinedButton(onClick = { viewModel.adjustSelected(dy = -0.25) }) {
                                Text("↑")
                            }
                            OutlinedButton(onClick = { viewModel.adjustSelected(dy = 0.25) }) {
                                Text("↓")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { viewModel.adjustSelected(dw = -0.25) }) {
                                Text("Narrower")
                            }
                            OutlinedButton(onClick = { viewModel.adjustSelected(dw = 0.25) }) {
                                Text("Wider")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { viewModel.adjustSelected(dh = -0.25) }) {
                                Text("Shorter")
                            }
                            OutlinedButton(onClick = { viewModel.adjustSelected(dh = 0.25) }) {
                                Text("Taller")
                            }
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = viewModel::addRoom, modifier = Modifier.weight(1f)) {
                    Text("Add room")
                }
                OutlinedButton(onClick = viewModel::deleteSelected, modifier = Modifier.weight(1f)) {
                    Text("Delete")
                }
            }
            Button(
                onClick = viewModel::saveVersion,
                enabled = !state.busy && state.notice == "Unsaved edit",
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Save new version") }
            OutlinedButton(
                onClick = viewModel::newProject,
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Start another project") }

            val svg = remember(project) { designSvg(project) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(svg)) },
                    modifier = Modifier.weight(1f),
                ) { Text("Copy SVG") }
                Button(
                    onClick = {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "image/svg+xml"
                            putExtra(Intent.EXTRA_SUBJECT, project.name + " concept")
                            putExtra(Intent.EXTRA_TEXT, svg)
                        }
                        context.startActivity(Intent.createChooser(share, "Export SVG"))
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Share SVG source") }
            }

            Text("Preliminary quantities", style = MaterialTheme.typography.titleLarge)
            project.quantities.forEach {
                Text(
                    it.item + ": " + it.quantity + " " + it.unit,
                    style = MaterialTheme.typography.bodyLarge,
                )
                Text(it.basis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Concept only", style = MaterialTheme.typography.titleMedium)
                    (project.warnings + project.assumptions).forEach { Text("• " + it) }
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun DesignCanvas(project: DesignProject) {
    val rooms = project.rooms
    val extent = max(5.0, max(project.siteWidthM, project.siteDepthM))
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .background(Color(0xFF17181B)),
    ) {
        val padding = 24f
        val scale = (minOf(size.width, size.height) - padding * 2) / extent.toFloat()
        drawRect(
            color = Color(0xFF9AA0A6),
            topLeft = Offset(padding, padding),
            size = Size(project.siteWidthM.toFloat() * scale, project.siteDepthM.toFloat() * scale),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f),
        )
        rooms.forEachIndexed { index, room ->
            val colors = listOf(
                Color(0xFF4D9BFF),
                Color(0xFF69E69A),
                Color(0xFFFFC857),
                Color(0xFFFF7A90),
            )
            drawRect(
                color = colors[index % colors.size].copy(alpha = 0.35f),
                topLeft = Offset(
                    padding + room.x.toFloat() * scale,
                    padding + room.y.toFloat() * scale,
                ),
                size = Size(room.width.toFloat() * scale, room.height.toFloat() * scale),
            )
            drawRect(
                color = colors[index % colors.size],
                topLeft = Offset(
                    padding + room.x.toFloat() * scale,
                    padding + room.y.toFloat() * scale,
                ),
                size = Size(room.width.toFloat() * scale, room.height.toFloat() * scale),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f),
            )
        }
    }
}

internal fun designSvg(project: DesignProject): String {
    fun escape(value: String) = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    val canvasWidth = max(200.0, project.siteWidthM * 40 + 40)
    val canvasHeight = max(200.0, project.siteDepthM * 40 + 40)
    val roomSvg = project.rooms.joinToString("\n") { room ->
        val label = escape(room.name)
        "<rect x=\"" + (room.x * 40 + 20) + "\" y=\"" + (room.y * 40 + 20) +
            "\" width=\"" + room.width * 40 + "\" height=\"" + room.height * 40 +
            "\" fill=\"none\" stroke=\"#9DDC25\" stroke-width=\"3\"/>" +
            "<text x=\"" + (room.x * 40 + 28) + "\" y=\"" + (room.y * 40 + 42) +
            "\" fill=\"#EAF7D0\" font-size=\"14\">" + label + "</text>"
    }
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + canvasWidth +
        "\" height=\"" + canvasHeight + "\" viewBox=\"0 0 " + canvasWidth + " " +
        canvasHeight + "\"><title>" + escape(project.name) + "</title>" +
        "<rect x=\"20\" y=\"20\" width=\"" + project.siteWidthM * 40 +
        "\" height=\"" + project.siteDepthM * 40 +
        "\" fill=\"#111409\" stroke=\"#AAB2A0\" stroke-width=\"2\"/>" +
        roomSvg + "</svg>"
}
