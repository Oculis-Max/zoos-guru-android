package com.guru.android.domain

enum class AnalyticsEvent {
    ONBOARDING_COMPLETED,
    CHAT_SEND_SUCCEEDED,
    CHAT_SEND_FAILED,
    OFFLINE_RETRY_SUCCEEDED,
    SCHOLARSHIP_VIEWED,
    SCHOLARSHIP_BOOKMARKED,
    APPLICATION_STATUS_CHANGED,
    ENTITLEMENT_VIEWED,
}

interface PrivacySafeAnalytics {
    /** Properties must be allow-listed categorical values; never prompts, answers, documents, or PII. */
    fun record(event: AnalyticsEvent, properties: Map<String, String> = emptyMap())
}

object NoOpAnalytics : PrivacySafeAnalytics {
    override fun record(event: AnalyticsEvent, properties: Map<String, String>) = Unit
}

enum class PlanId { FREE, STUDENT, PLUS, SPONSORED }

data class Entitlement(
    val plan: PlanId = PlanId.FREE,
    val aiMessagesPerMonth: Int = 30,
    val advancedMatching: Boolean = false,
    val cloudSync: Boolean = false,
)

interface EntitlementRepository {
    suspend fun current(identityId: IdentityId): Entitlement
    suspend fun restorePurchases(): Result<Entitlement>
}

/** Implement only after Play product IDs and server-side verification are approved. */
interface PlayBillingGateway {
    suspend fun purchase(productId: String): Result<Entitlement>
}
