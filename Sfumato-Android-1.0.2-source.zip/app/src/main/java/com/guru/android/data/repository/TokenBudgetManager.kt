package com.guru.android.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.tokenBudgetDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "token_budget"
)

class TokenBudgetManager(context: Context) {
    private val dataStore: DataStore<Preferences> = context.tokenBudgetDataStore

    companion object {
        val TOKENS_USED = intPreferencesKey("tokens_used")
        const val MAX_MONTHLY_COST_CENTS = 80
        const val COST_PER_1K = 0.05f
    }

    val tokensUsed: Flow<Int> = dataStore.data.map { preferences ->
        preferences[TOKENS_USED] ?: 0
    }

    private fun calculateMaxTokens(): Int {
        return (MAX_MONTHLY_COST_CENTS / (COST_PER_1K * 100)).toInt() * 1000
    }

    suspend fun canMakeRequest(estimatedTokens: Int = 500): Boolean {
        val current = tokensUsed.first()
        val budget = calculateMaxTokens()
        return (current + estimatedTokens) <= budget
    }

    suspend fun recordTokensUsed(tokens: Int) {
        dataStore.edit { preferences ->
            preferences[TOKENS_USED] = (preferences[TOKENS_USED] ?: 0) + tokens
        }
    }
}
