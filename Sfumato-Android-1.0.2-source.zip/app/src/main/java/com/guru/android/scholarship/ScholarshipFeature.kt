package com.guru.android.scholarship

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Scholarship(
    val id: String,
    val name: String,
    val provider: String,
    val countries: List<String>,
    val levels: List<String>,
    val fields: List<String>,
    val deadline: String?,
    val status: String,
    @SerializedName("official_url") val officialUrl: String,
    @SerializedName("eligibility_summary") val eligibility: String,
    @SerializedName("last_verified") val lastVerified: String,
)

data class ReadinessRequest(
    val grades: Int,
    @SerializedName("study_consistency") val studyConsistency: Int,
    val leadership: Int,
    @SerializedName("community_service") val communityService: Int,
    @SerializedName("digital_skills") val digitalSkills: Int,
    val certificates: Int,
    @SerializedName("career_goal") val careerGoal: Int,
    @SerializedName("personal_statement") val personalStatement: Int,
)
data class ReadinessResult(
    val score: Int,
    val label: String,
    val improvements: List<String>,
    val disclaimer: String,
)
data class ApplicationRequest(
    @SerializedName("scholarship_id") val scholarshipId: String,
    val status: String = "saved",
    @SerializedName("next_step") val nextStep: String = "Review official eligibility and prepare documents",
    val deadline: String? = null,
)
data class SavedApplication(
    val id: String,
    @SerializedName("scholarship_id") val scholarshipId: String,
    @SerializedName("scholarship_name") val scholarshipName: String? = null,
    val status: String,
    @SerializedName("next_step") val nextStep: String? = null,
)

interface ScholarshipService {
    @GET("v1/scholarships")
    suspend fun scholarships(
        @Header("Authorization") token: String,
        @Query("country") country: String = "ZA",
        @Query("level") level: String? = null,
        @Query("include_closed") includeClosed: Boolean = false,
    ): List<Scholarship>
    @POST("v1/scholarships/readiness")
    suspend fun readiness(@Header("Authorization") token: String, @Body body: ReadinessRequest): ReadinessResult
    @GET("v1/scholarships/applications")
    suspend fun applications(@Header("Authorization") token: String): List<SavedApplication>
    @POST("v1/scholarships/applications")
    suspend fun save(@Header("Authorization") token: String, @Body body: ApplicationRequest): SavedApplication
}

@Singleton
class ScholarshipRepository @Inject constructor(private val service: ScholarshipService) {
    private suspend fun token(): String {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        val token = checkNotNull(user.getIdToken(false).await().token) { "Session expired." }
        return "Bearer " + token
    }
    suspend fun scholarships(level: String?) = service.scholarships(token(), level = level)
    suspend fun readiness(request: ReadinessRequest) = service.readiness(token(), request)
    suspend fun applications() = service.applications(token())
    suspend fun save(item: Scholarship) =
        service.save(token(), ApplicationRequest(item.id, deadline = item.deadline))
}

data class ScholarshipState(
    val busy: Boolean = false,
    val opportunities: List<Scholarship> = emptyList(),
    val applications: List<SavedApplication> = emptyList(),
    val selectedLevel: String? = null,
    val scores: List<Int> = List(8) { 50 },
    val readiness: ReadinessResult? = null,
    val error: String? = null,
)

@HiltViewModel
class ScholarshipViewModel @Inject constructor(private val repository: ScholarshipRepository) : ViewModel() {
    private val mutableState = MutableStateFlow(ScholarshipState())
    val state = mutableState.asStateFlow()

    init { load() }

    fun setScore(index: Int, value: Int) = mutableState.update {
        it.copy(scores = it.scores.toMutableList().also { values -> values[index] = value })
    }

    fun selectLevel(value: String?) {
        mutableState.update { it.copy(selectedLevel = value) }
        load()
    }

    fun load() = launch {
        val opportunities = repository.scholarships(mutableState.value.selectedLevel)
        val applications = runCatching { repository.applications() }.getOrDefault(emptyList())
        mutableState.update { it.copy(opportunities = opportunities, applications = applications) }
    }

    fun calculate() = launch {
        val v = mutableState.value.scores
        mutableState.update {
            it.copy(readiness = repository.readiness(
                ReadinessRequest(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7])
            ))
        }
    }

    fun save(item: Scholarship) = launch {
        val saved = repository.save(item)
        mutableState.update {
            it.copy(
                applications = listOf(saved) +
                    it.applications.filterNot { application ->
                        application.scholarshipId == saved.scholarshipId
                    },
            )
        }
    }

    private fun launch(block: suspend () -> Unit) {
        if (mutableState.value.busy) return
        viewModelScope.launch {
            mutableState.update { it.copy(busy = true, error = null) }
            try { block() } catch (error: Exception) {
                val message = if (error is HttpException) when (error.code()) {
                    401 -> "Session expired. Sign in again."
                    403 -> "An active Student Pro plan is required for Scholarship Guru."
                    422 -> "Only scholarships from verified official sources can be tracked."
                    else -> "Scholarship service error (HTTP " + error.code() + ")."
                } else error.message ?: "Scholarship Guru is unavailable."
                mutableState.update { it.copy(error = message) }
            } finally { mutableState.update { it.copy(busy = false) } }
        }
    }
}

internal fun scholarshipDeadlineLabel(
    deadline: String?,
    today: LocalDate = LocalDate.now(),
): String? {
    if (deadline.isNullOrBlank()) return null
    val closingDate = runCatching { LocalDate.parse(deadline) }.getOrNull() ?: return "Deadline: $deadline"
    val days = ChronoUnit.DAYS.between(today, closingDate)
    return when {
        days < 0 -> "Closed"
        days == 0L -> "Closes today"
        days == 1L -> "Closes tomorrow"
        days <= 30 -> "Closes in $days days · $deadline"
        else -> "Deadline: $deadline"
    }
}

private val scholarshipLevels = linkedMapOf<String?, String>(
    null to "All",
    "high_school" to "High school",
    "tvet" to "TVET",
    "undergraduate" to "Undergraduate",
    "honours" to "Honours",
    "masters" to "Masters",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScholarshipScreen(viewModel: ScholarshipViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val labels = listOf(
        "Grades", "Study consistency", "Leadership", "Community service",
        "Digital skills", "Certificates", "Career goal", "Personal statement",
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Scholarship Guru", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Find verified opportunities, measure readiness and keep applications organised.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Scholarship Readiness Score", style = MaterialTheme.typography.titleLarge)
                Text("Estimate your current profile honestly. This is guidance, never a guarantee.")
                labels.forEachIndexed { index, label ->
                    Text(label + ": " + state.scores[index])
                    Slider(
                        value = state.scores[index].toFloat(),
                        onValueChange = { viewModel.setScore(index, it.toInt()) },
                        valueRange = 0f..100f,
                    )
                }
                Button(onClick = viewModel::calculate, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Calculate readiness")
                }
                state.readiness?.let {
                    Text(it.score.toString() + "/100 — " + it.label, style = MaterialTheme.typography.headlineSmall)
                    if (it.improvements.isNotEmpty()) Text("Focus next: " + it.improvements.joinToString())
                    Text(it.disclaimer, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text("Matched opportunities", style = MaterialTheme.typography.titleLarge)
        Text(
            "Verified against official government, university, foundation or corporate programme sources.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text("Study level", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            scholarshipLevels.forEach { (value, label) ->
                FilterChip(
                    selected = state.selectedLevel == value,
                    onClick = { viewModel.selectLevel(value) },
                    label = { Text(label) },
                    enabled = !state.busy,
                )
            }
        }
        if (state.opportunities.isEmpty() && !state.busy) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No open matches right now", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Try another study level. Scholarship Guru excludes expired opportunities automatically.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        state.opportunities.forEach { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(item.name, style = MaterialTheme.typography.titleMedium)
                    Text(item.provider)
                    Text(item.eligibility)
                    Text("Status: " + item.status.replace("_", " "))
                    scholarshipDeadlineLabel(item.deadline)?.let {
                        Text(it, color = MaterialTheme.colorScheme.primary)
                    }
                    Text("Verified: " + item.lastVerified, style = MaterialTheme.typography.bodySmall)
                    val tracked = state.applications.any { it.scholarshipId == item.id }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.officialUrl)))
                        }) { Text("Official page") }
                        Button(
                            onClick = { viewModel.save(item) },
                            enabled = !state.busy && !tracked,
                        ) { Text(if (tracked) "Tracking" else "Track application") }
                    }
                }
            }
        }

        if (state.applications.isNotEmpty()) {
            Text("My applications", style = MaterialTheme.typography.titleLarge)
            state.applications.forEach { application ->
                val opportunity = state.opportunities.firstOrNull {
                    it.id == application.scholarshipId
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            application.scholarshipName ?: opportunity?.name ?: "Scholarship application",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(application.status.replaceFirstChar(Char::uppercase))
                        application.nextStep?.takeIf(String::isNotBlank)?.let {
                            Text("Next step: $it", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (state.busy) CircularProgressIndicator()
        Spacer(Modifier.height(24.dp))
    }
}
