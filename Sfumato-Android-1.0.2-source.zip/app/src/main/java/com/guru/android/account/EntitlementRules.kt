package com.guru.android.account

import com.guru.android.billing.EntitlementResponse

internal data class ResolvedEntitlement(
    val tier: String,
    val active: Boolean,
    val autonomousCoding: Boolean,
    val source: String?,
    val sponsor: String?,
    val sponsoredUntil: String?,
)

internal object EntitlementRules {
    private val knownTiers = setOf("free", "student_pro", "developer", "business")

    fun resolve(response: EntitlementResponse): ResolvedEntitlement {
        val tier = response.tier.trim().lowercase().takeIf { it in knownTiers } ?: "free"
        val active = tier == "free" || response.status.equals("active", ignoreCase = true)
        return ResolvedEntitlement(
            tier = tier,
            active = active,
            autonomousCoding = active && tier == "developer" && response.autonomousCoding,
            source = response.source,
            sponsor = response.sponsor,
            sponsoredUntil = response.sponsoredUntil,
        )
    }
}
