package com.guru.android.account

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.guru.android.R
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.guru.android.assistant.AdvancedAssistantScreen
import com.guru.android.billing.BillingScreen
import com.guru.android.business.BusinessScreen
import com.guru.android.domain.AccountSession
import com.guru.android.design.DesignStudioScreen
import com.guru.android.engineering.EngineeringScreen
import com.guru.android.enoch.EnochGeneralAssistantScreen
import com.guru.android.education.EducationScreen
import com.guru.android.coding.CodingScreen
import com.guru.android.learning.ArenaScreen
import com.guru.android.learning.TutorScreen
import com.guru.android.journalist.JournalistScreen
import com.guru.android.scholarship.ScholarshipScreen
import com.guru.android.security.CyberSafetyActivity
import com.guru.android.security.SecondLayerProtectionActivity
import com.guru.android.progress.ProgressScreen
import com.guru.android.ui.chat.ChatScreen
import kotlinx.coroutines.launch

@Composable
fun HiGuruAccountApp(viewModel: AccountViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    var destination by remember { mutableStateOf("chat") }
    var routedPaidSetupFor by remember { mutableStateOf<String?>(null) }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner, state.session) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && state.session is AccountSession.SignedIn) {
                viewModel.refreshPlan()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(state.session) {
        if (state.session !is AccountSession.SignedIn) destination = "chat"
    }
    LaunchedEffect(state.profile, state.planTier, state.planLoaded) {
        val profile = state.profile ?: return@LaunchedEffect
        val routeKey = OnboardingRules.paymentRouteKey(profile)
        if (
            profile.onboardingComplete &&
            OnboardingRules.shouldOpenPayment(profile, state.planTier, state.planLoaded) &&
            routedPaidSetupFor != routeKey
        ) {
            destination = "billing"
            routedPaidSetupFor = routeKey
        }
    }

    when (state.session) {
        AccountSession.Loading -> LoadingScreen()
        AccountSession.SignedOut -> AuthScreen(state, viewModel)
        is AccountSession.SignedIn -> when (
            OnboardingRules.signedInRoute(
                profileLoaded = state.profileLoaded,
                securityLoaded = state.securityLoaded,
                isEmailVerified = state.isEmailVerified,
                profile = state.profile,
                destination = destination,
            )
        ) {
            StartupRoute.LOADING -> LoadingScreen()
            StartupRoute.VERIFY_EMAIL -> EmailVerificationScreen(state, viewModel)
            StartupRoute.ONBOARDING -> QuickStartScreen(state, viewModel)
            StartupRoute.ACCOUNT -> AccountScreen(
                state = state,
                onBack = { destination = "chat" },
                onPlans = { destination = "billing" },
                onEditSetup = viewModel::restartOnboarding,
                onSave = viewModel::saveProfile,
                onSignOut = viewModel::signOut,
                onPasswordReset = viewModel::sendPasswordReset,
                onVerifyEmail = viewModel::sendVerificationEmail,
                onRefreshSecurity = viewModel::refreshSecurity,
                onDismissMessage = viewModel::clearMessage,
            )
            StartupRoute.HOME -> LearningHome(
                state = state,
                destination = destination,
                onDestination = { destination = it },
            )
        }
    }
}

@Composable
private fun LearningHome(
    state: AccountUiState,
    destination: String,
    onDestination: (String) -> Unit,
) {
    val drawerState = androidx.compose.material3.rememberDrawerState(
        initialValue = androidx.compose.material3.DrawerValue.Closed,
    )
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val studentAccess = state.planLoaded && state.planActive && state.planTier == "student"
    val developerAccess = state.planLoaded && state.planActive && state.planTier == "developer"
    val businessAccess = state.planLoaded && state.planActive && state.planTier == "business"
    val effectiveDestination = when (destination) {
        "tutor", "arena", "scholarship", "education", "progress" -> if (studentAccess) destination else "billing"
        "coding" -> if (developerAccess && state.autonomousCoding) destination else "billing"
        "enoch" -> if (developerAccess || businessAccess) destination else "billing"
        "business", "advanced_assistant", "engineering", "design", "journalist" -> if (businessAccess) destination else "billing"
        else -> destination
    }
    val openDrawer: () -> Unit = { scope.launch { drawerState.open() } }
    val selectDestination: (String) -> Unit = { selected ->
        val permitted = when (selected) {
            "tutor", "arena", "scholarship", "education", "progress" -> studentAccess
            "coding" -> developerAccess && state.autonomousCoding
            "enoch" -> developerAccess || businessAccess
            "business", "advanced_assistant", "engineering", "design", "journalist" -> businessAccess
            else -> true
        }
        onDestination(if (permitted) selected else "billing")
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 24.dp),
                ) {
                    Text(
                        text = "Sfumato",
                        style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    )
                    Text(
                        text = "Your intelligence workspace",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                    Spacer(Modifier.height(20.dp))
                    DrawerDestination(
                        label = "Home",
                        icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                        selected = destination == "chat",
                        onClick = { selectDestination("chat") },
                    )
                    if (studentAccess) {
                        DrawerDestination("AI Tutor", { Icon(Icons.Default.School, null) }, destination == "tutor") { selectDestination("tutor") }
                        DrawerDestination("Debate Arena", { Icon(Icons.Default.EmojiEvents, null) }, destination == "arena") { selectDestination("arena") }
                        DrawerDestination("Scholarship Guru", { Icon(Icons.Default.School, null) }, destination == "scholarship") { selectDestination("scholarship") }
                        DrawerDestination("Classes & Courses", { Icon(Icons.Default.School, null) }, destination == "education") { selectDestination("education") }
                        DrawerDestination("Education Dashboards", { Icon(Icons.Default.AccountCircle, null) }, destination == "progress") { selectDestination("progress") }
                    }
                    if (developerAccess && state.autonomousCoding) {
                        DrawerDestination("Coding Agent", { Icon(Icons.Default.Code, null) }, destination == "coding") { selectDestination("coding") }
                    }
                    if (businessAccess) {
                        DrawerDestination("Business Assistant", { Icon(Icons.Default.Business, null) }, destination == "business") { selectDestination("business") }
                        DrawerDestination("Advanced Assistant", { Icon(Icons.Default.Person, null) }, destination == "advanced_assistant") { selectDestination("advanced_assistant") }
                        DrawerDestination("Engineering Guru", { Icon(Icons.Default.Build, null) }, destination == "engineering") { selectDestination("engineering") }
                        DrawerDestination("Design Studio Beta", { Icon(Icons.Default.Build, null) }, destination == "design") { selectDestination("design") }
                        DrawerDestination("Journalist", { Icon(Icons.Default.NoteAlt, null) }, destination == "journalist") { selectDestination("journalist") }
                    }
                    if (developerAccess || businessAccess) {
                        DrawerDestination(
                            label = "Enoch Voice",
                            icon = { Icon(Icons.Default.Mic, contentDescription = null) },
                            selected = destination == "enoch",
                            onClick = { selectDestination("enoch") },
                        )
                        DrawerDestination(
                            label = "Cyber Safety Guru",
                            icon = { Icon(Icons.Default.Security, contentDescription = null) },
                            selected = false,
                            onClick = {
                                context.startActivity(Intent(context, CyberSafetyActivity::class.java))
                                scope.launch { drawerState.close() }
                            },
                        )
                        DrawerDestination(
                            label = "Device Protection",
                            icon = { Icon(Icons.Default.VpnLock, contentDescription = null) },
                            selected = false,
                            onClick = {
                                context.startActivity(
                                    Intent(context, SecondLayerProtectionActivity::class.java)
                                )
                                scope.launch { drawerState.close() }
                            },
                        )
                    }
                    DrawerDestination(
                        label = "Plans",
                        icon = { Icon(Icons.Default.CreditCard, contentDescription = null) },
                        selected = destination == "billing",
                        onClick = { selectDestination("billing") },
                    )
                    DrawerDestination(
                        label = "Account",
                        icon = { Icon(Icons.Default.AccountCircle, contentDescription = null) },
                        selected = false,
                        onClick = { selectDestination("account") },
                    )
                }
            }
        },
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (effectiveDestination) {
                "tutor" -> DrawerSection("AI Tutor", openDrawer) { TutorScreen(profile = state.profile) }
                "arena" -> DrawerSection("Debate Arena", openDrawer) { ArenaScreen() }
                "scholarship" -> DrawerSection("Scholarships", openDrawer) { ScholarshipScreen() }
                "progress" -> DrawerSection("Dashboards", openDrawer) { ProgressScreen() }
                "billing" -> DrawerSection("Plans", openDrawer) { BillingScreen() }
                "business" -> DrawerSection("Business", openDrawer) { BusinessScreen() }
                "advanced_assistant" -> DrawerSection("Assistant", openDrawer) { AdvancedAssistantScreen() }
                "engineering" -> DrawerSection("Engineering", openDrawer) { EngineeringScreen() }
                "education" -> DrawerSection("Courses", openDrawer) { EducationScreen() }
                "design" -> DrawerSection("Design Studio", openDrawer) { DesignStudioScreen() }
                "journalist" -> DrawerSection("Journalist", openDrawer) { JournalistScreen() }
                "enoch" -> DrawerSection("Enoch", openDrawer) { EnochGeneralAssistantScreen() }
                "coding" -> DrawerSection("Coding Agent", openDrawer) {
                    CodingScreen(hasAccess = state.autonomousCoding, planTier = state.planTier)
                }
                else -> ChatScreen(
                    onAccountClick = { onDestination("account") },
                    onMenuClick = openDrawer,
                    onQuickAction = selectDestination,
                    planTier = state.planTier,
                    profile = state.profile,
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickStartScreen(state: AccountUiState, viewModel: AccountViewModel) {
    val existing = state.profile
    var step by remember { mutableStateOf(0) }
    var selectedPath by remember(existing?.uid) {
        mutableStateOf(
            existing?.accountType?.takeIf { it in setOf("student", "developer", "business") }
                ?: existing?.schoolLevel?.takeIf { it in setOf("High school", "College", "University") }?.let { "student" }
        )
    }
    var selectedPlan by remember(existing?.uid) {
        mutableStateOf(OnboardingRules.defaultPaidPlanForPath(selectedPath))
    }
    var showPlans by remember { mutableStateOf(false) }
    var voucher by remember { mutableStateOf("") }
    var institution by remember(existing?.uid) { mutableStateOf(existing?.institution.orEmpty()) }
    var educationLevel by remember(existing?.uid) {
        mutableStateOf(existing?.schoolLevel?.takeIf { it in setOf("High school", "College", "University") } ?: "High school")
    }
    var grade by remember(existing?.uid) { mutableStateOf(existing?.grade.orEmpty()) }
    var curriculum by remember(existing?.uid) {
        mutableStateOf(existing?.curriculum?.takeIf(String::isNotBlank) ?: if (educationLevel == "High school") "CAPS" else "")
    }
    var subjects by remember(existing?.uid) { mutableStateOf(existing?.subjects?.joinToString(", ").orEmpty()) }
    var role by remember(existing?.uid) { mutableStateOf(existing?.role.orEmpty()) }
    var organisation by remember(existing?.uid) { mutableStateOf(existing?.organisation.orEmpty()) }
    var industry by remember(existing?.uid) { mutableStateOf(existing?.industry.orEmpty()) }
    var focusAreas by remember(existing?.uid) { mutableStateOf(existing?.focusAreas?.joinToString(", ").orEmpty()) }
    val context = LocalContext.current
    var microphoneGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var notificationsGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val microphoneLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { microphoneGranted = it }
    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { notificationsGranted = it }

    fun finish(plan: String, voucherCode: String? = null) {
        viewModel.clearMessage()
        viewModel.completeOnboarding(
            selectedPlan = plan,
            selectedPath = selectedPath ?: "professional",
            voucherCode = voucherCode,
            institution = institution,
            educationLevel = educationLevel,
            grade = grade,
            curriculum = curriculum,
            subjectsText = subjects,
            role = role,
            organisation = organisation,
            industry = industry,
            focusText = focusAreas,
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        OnboardingHeader(step)
        when (step) {
            0 -> WelcomeStep(onNext = { step = 1 }, onSignOut = viewModel::signOut)
            1 -> PathStep(
                selected = selectedPath,
                onSelect = {
                    selectedPath = it
                    selectedPlan = OnboardingRules.defaultPaidPlanForPath(it)
                },
                onBack = { step = 0 },
                onNext = { if (selectedPath != null) step = 2 },
            )
            2 -> PersonalizeStep(
                path = selectedPath ?: "professional",
                institution = institution,
                onInstitution = { institution = it.take(120) },
                educationLevel = educationLevel,
                onEducationLevel = {
                    educationLevel = it
                    grade = ""
                    curriculum = OnboardingRules.curriculumForLevel(it, curriculum)
                },
                grade = grade,
                onGrade = { grade = it.take(40) },
                curriculum = curriculum,
                onCurriculum = { curriculum = it.take(60) },
                subjects = subjects,
                onSubjects = { subjects = it.take(500) },
                role = role,
                onRole = { role = it.take(80) },
                organisation = organisation,
                onOrganisation = { organisation = it.take(120) },
                industry = industry,
                onIndustry = { industry = it.take(80) },
                focusAreas = focusAreas,
                onFocusAreas = { focusAreas = it.take(500) },
                onBack = { step = 1 },
                onNext = { step = 3 },
            )
            3 -> GurusStep(
                path = selectedPath ?: "professional",
                onBack = { step = 2 },
                onNext = { step = 4 },
            )
            4 -> PermissionsStep(
                microphoneGranted = microphoneGranted,
                notificationsGranted = notificationsGranted,
                onMicrophone = { microphoneLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                onNotifications = {
                    if (Build.VERSION.SDK_INT >= 33) {
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else notificationsGranted = true
                },
                onBack = { step = 3 },
                onNext = { step = 5 },
            )
            else -> AccessStep(
                path = selectedPath ?: "professional",
                voucher = voucher,
                onVoucher = { voucher = it.uppercase().take(40) },
                showPlans = showPlans,
                selectedPlan = selectedPlan,
                onShowPlans = { showPlans = !showPlans },
                onSelectPlan = {
                    selectedPlan = it
                    selectedPath = it
                },
                state = state,
                onBack = { step = 4 },
                onContinueFree = { finish("free") },
                onRedeem = { finish("student", voucher) },
                onPaidContinue = {
                    if (OnboardingRules.canContinueToPayment(selectedPlan)) finish(selectedPlan)
                },
            )
        }
    }
}

@Composable
private fun OnboardingHeader(step: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "Sfumato  >  ONBOARDING",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            repeat(6) { index ->
                Surface(
                    modifier = Modifier.weight(1f).height(3.dp),
                    color = if (index <= step) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outline,
                    shape = CircleShape,
                ) {}
            }
        }
        Text(
            "[0${step + 1}]  ${listOf("WELCOME", "CHOOSE YOUR PATH", "PERSONALIZE", "MEET YOUR GURUS", "PERMISSIONS", "ACCESS & START")[step]}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
        )
    }
}

@Composable
private fun WelcomeStep(onNext: () -> Unit, onSignOut: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(12.dp))
        Image(
            painter = painterResource(R.drawable.ic_launcher_foreground),
            contentDescription = "Sfumato",
            modifier = Modifier.size(118.dp),
            contentScale = ContentScale.Fit,
        )
        Text("Sfumato", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
        Text("AI LEARNING. REAL RESULTS.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "ONE APP.\nENDLESS\nPOSSIBILITIES.",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "Your all-in-one AI companion for learning, productivity and real-world success.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
        )
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("GET STARTED  >") }
        TextButton(onClick = onSignOut) { Text("Already have another account? Sign in") }
    }
}

@Composable
private fun PathStep(
    selected: String?,
    onSelect: (String) -> Unit,
    onBack: () -> Unit,
    onNext: () -> Unit,
) {
    Text("We'll personalize your experience for you.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    listOf(
        PathOption("student", "STUDENT", "Learn, study and prepare.", Icons.Default.School),
        PathOption("developer", "DEVELOPER", "Build, debug and ship.", Icons.Default.Code),
        PathOption("professional", "PROFESSIONAL", "Work smarter and get things done.", Icons.Default.Person),
        PathOption("business", "BUSINESS", "AI assistance for your organisation.", Icons.Default.Business),
    ).forEach { option ->
        SelectableOnboardingCard(
            title = option.title,
            description = option.description,
            selected = selected == option.id,
            icon = { Icon(option.icon, contentDescription = null) },
            onClick = { onSelect(option.id) },
        )
    }
    Text("Your data is private and secure.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    OnboardingNav(onBack, onNext, nextEnabled = selected != null)
}

private data class PathOption(
    val id: String,
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
)

@Composable
private fun PersonalizeStep(
    path: String,
    institution: String,
    onInstitution: (String) -> Unit,
    educationLevel: String,
    onEducationLevel: (String) -> Unit,
    grade: String,
    onGrade: (String) -> Unit,
    curriculum: String,
    onCurriculum: (String) -> Unit,
    subjects: String,
    onSubjects: (String) -> Unit,
    role: String,
    onRole: (String) -> Unit,
    organisation: String,
    onOrganisation: (String) -> Unit,
    industry: String,
    onIndustry: (String) -> Unit,
    focusAreas: String,
    onFocusAreas: (String) -> Unit,
    onBack: () -> Unit,
    onNext: () -> Unit,
) {
    Text("Tell us about your ${if (path == "student") "learning journey" else "goals"}.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (path == "student") {
        Text("> EDUCATION LEVEL", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        listOf("High school", "College", "University").forEach { level ->
            SelectableOnboardingCard(
                title = level.uppercase(),
                description = if (level == "High school") "CAPS and school subjects" else "Courses and study areas",
                selected = educationLevel == level,
                icon = { Icon(Icons.Default.School, contentDescription = null) },
                onClick = { onEducationLevel(level) },
            )
        }
        OnboardingField(institution, onInstitution, "School, college or university")
        OnboardingField(grade, onGrade, if (educationLevel == "High school") "Grade" else "Study year (optional)")
        OnboardingField(curriculum, onCurriculum, if (educationLevel == "High school") "Curriculum (for example CAPS)" else "Course framework (optional)")
        OnboardingField(subjects, onSubjects, "Subjects or course areas, separated by commas", minLines = 2)
    } else {
        if (path == "business") {
            OnboardingField(organisation, onOrganisation, "Business or organisation")
            OnboardingField(industry, onIndustry, "Industry")
        }
        OnboardingField(role, onRole, if (path == "developer") "Developer role or experience level" else "Role or occupation")
        OnboardingField(
            focusAreas,
            onFocusAreas,
            when (path) {
                "developer" -> "Languages, projects and coding goals"
                "business" -> "Business needs and priorities"
                else -> "Goals and interests"
            },
            minLines = 2,
        )
    }
    OnboardingNav(onBack, onNext)
}

@Composable
private fun GurusStep(path: String, onBack: () -> Unit, onNext: () -> Unit) {
    Text("Your AI Gurus are ready to help you succeed.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    val gurus = when (path) {
        "student" -> listOf(
            Triple("AI TUTOR", "Understand anything. Learn faster.", Icons.Default.School),
            Triple("DEBATE ARENA", "Challenge ideas. Sharpen thinking.", Icons.Default.EmojiEvents),
            Triple("SMART NOTES", "Capture, organise and remember.", Icons.Default.NoteAlt),
            Triple("SCHOLARSHIP GURU", "Find verified opportunities.", Icons.Default.School),
        )
        "developer" -> listOf(
            Triple("CODING AGENT", "Build, debug and automate safely.", Icons.Default.Code),
            Triple("CYBER SAFETY", "Review risks before you act.", Icons.Default.Security),
            Triple("SMART NOTES", "Turn technical work into knowledge.", Icons.Default.NoteAlt),
        )
        "business" -> listOf(
            Triple("BUSINESS ASSISTANT", "Plan, analyse and coordinate.", Icons.Default.Business),
            Triple("ADVANCED ASSISTANT", "Manage complex team workflows.", Icons.Default.Person),
            Triple("SMART NOTES", "Capture decisions and action items.", Icons.Default.NoteAlt),
        )
        else -> listOf(
            Triple("GENERAL ASSISTANT", "Research, write and plan everyday work.", Icons.Default.Person),
            Triple("SMART NOTES", "Capture and organise your work.", Icons.Default.NoteAlt),
        )
    }
    gurus.forEach { (title, description, icon) ->
        OnboardingCard(title, description) { Icon(icon, contentDescription = null) }
    }
    if (path == "developer") {
        Text("Coding Agent requires an active Developer plan.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    OnboardingNav(onBack, onNext)
}

@Composable
private fun PermissionsStep(
    microphoneGranted: Boolean,
    notificationsGranted: Boolean,
    onMicrophone: () -> Unit,
    onNotifications: () -> Unit,
    onBack: () -> Unit,
    onNext: () -> Unit,
) {
    Text("We only ask for permissions when you need a feature.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    SelectableOnboardingCard("MICROPHONE", "Voice conversations and notes.", microphoneGranted, { Icon(Icons.Default.Mic, null) }, onMicrophone)
    SelectableOnboardingCard("NOTIFICATIONS", "Important tasks and updates.", notificationsGranted, { Icon(Icons.Default.Notifications, null) }, onNotifications)
    OnboardingCard("SECURITY (CYBER SAFETY)", "Available with Developer and Business plans. You approve every action.") { Icon(Icons.Default.Security, null) }
    Text("You can enable or manage these anytime in Settings.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    OnboardingNav(onBack, onNext)
}

@Composable
private fun AccessStep(
    path: String,
    voucher: String,
    onVoucher: (String) -> Unit,
    showPlans: Boolean,
    selectedPlan: String,
    onShowPlans: () -> Unit,
    onSelectPlan: (String) -> Unit,
    state: AccountUiState,
    onBack: () -> Unit,
    onContinueFree: () -> Unit,
    onRedeem: () -> Unit,
    onPaidContinue: () -> Unit,
) {
    Text("How would you like to access Sfumato?", color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (path == "student") {
        OnboardingCard("REDEEM VOUCHER", "Unlock 90 days of sponsored Student Pro.") { Icon(Icons.Default.Redeem, null) }
        OnboardingField(voucher, onVoucher, "Sponsored voucher code")
        Button(
            onClick = onRedeem,
            enabled = voucher.isNotBlank() && state.isOnline && !state.isWorking,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("REDEEM & UNLOCK") }
    }
    OnboardingCard("CONTINUE FREE", "Limited access to core features.", onContinueFree) { Icon(Icons.Default.Person, null) }
    OnboardingCard("VIEW PLANS", "Student Pro, Developer and Business plans.", onShowPlans) { Icon(Icons.Default.CreditCard, null) }
    if (showPlans) {
        listOf(
            Triple("student", "STUDENT PRO · R200/MONTH", "Tutor, Debate Arena and scholarships"),
            Triple("developer", "DEVELOPER · R1,000/MONTH", "Autonomous coding workspace"),
            Triple("business", "BUSINESS · R5,000/MONTH", "Business Gurus and team workflows"),
        ).forEach { (plan, title, description) ->
            SelectableOnboardingCard(title, description, selectedPlan == plan, { Icon(Icons.Default.Check, null) }) { onSelectPlan(plan) }
        }
        Button(
            onClick = onPaidContinue,
            enabled = OnboardingRules.canContinueToPayment(selectedPlan) && state.isOnline && !state.isWorking,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Text("CONTINUE TO PAYMENT")
        }
    }
    state.error?.let { StatusMessage(it, true) }
    state.notice?.let { StatusMessage(it, false) }
    if (state.isWorking) CircularProgressIndicator()
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("< BACK") }
}

@Composable
private fun OnboardingField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        minLines = minLines,
        singleLine = minLines == 1,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
    )
}

@Composable
private fun OnboardingCard(
    title: String,
    description: String,
    onClick: (() -> Unit)? = null,
    icon: @Composable () -> Unit,
) {
    val modifier = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Surface(
        modifier = modifier,
        color = Color(0xFF0B1008),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.42f)),
        shape = RoundedCornerShape(8.dp),
    ) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFF11180A), shape = RoundedCornerShape(6.dp)) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { icon() }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
            if (onClick != null) Text(">", color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun SelectableOnboardingCard(
    title: String,
    description: String,
    selected: Boolean,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = if (selected) Color(0xFF111A08) else Color(0xFF090909),
        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
        shape = RoundedCornerShape(8.dp),
    ) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) { icon() }
            Column(Modifier.weight(1f)) {
                Text("[ $title ]", color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
            if (selected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun OnboardingNav(onBack: () -> Unit, onNext: () -> Unit, nextEnabled: Boolean = true) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f).height(52.dp)) { Text("< BACK") }
        Button(onClick = onNext, enabled = nextEnabled, modifier = Modifier.weight(1f).height(52.dp)) { Text("NEXT >") }
    }
}

@Composable
private fun DrawerDestination(
    label: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit,
) {
    NavigationDrawerItem(
        label = { Text(label) },
        icon = icon,
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp),
    )
}

@Composable
private fun DrawerSection(
    title: String,
    onMenuClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Scaffold(
        topBar = {
            ModernPageHeader(
                title = title,
                navigationIcon = {
                    Icon(Icons.Default.Menu, contentDescription = "Open navigation")
                },
                onNavigationClick = onMenuClick,
            )
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            content()
        }
    }
}

@Composable
private fun ModernPageHeader(
    title: String,
    navigationIcon: @Composable () -> Unit,
    onNavigationClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(72.dp)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            modifier = Modifier.size(56.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
            IconButton(onClick = onNavigationClick) {
                navigationIcon()
            }
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.size(56.dp))
    }
}

@Composable
private fun LoadingScreen() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun EmailVerificationScreen(state: AccountUiState, viewModel: AccountViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Verify your email",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(12.dp))
        val signedInUser = (state.session as? AccountSession.SignedIn)?.user
        Text(
            "Firebase accepted a verification request for:",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        signedInUser?.email?.takeIf(String::isNotBlank)?.let { email ->
            Text(
                email,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Delivery can take a few minutes. Check Spam, Junk and Promotions. Open the link, return here, then tap the button below.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        state.error?.let { StatusMessage(it, true) }
        state.notice?.let { StatusMessage(it, false) }
        Button(
            onClick = viewModel::refreshSecurity,
            enabled = !state.isWorking && state.isOnline,
            modifier = Modifier.fillMaxWidth().height(54.dp),
        ) {
            Text("I verified my email")
        }
        OutlinedButton(
            onClick = viewModel::sendVerificationEmail,
            enabled = !state.isWorking && state.isOnline,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Request another verification email")
        }
        TextButton(onClick = viewModel::signOut) {
            Text("Use another account")
        }
    }
}

@Composable
private fun AuthScreen(state: AccountUiState, viewModel: AccountViewModel) {
    var creatingAccount by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var acceptedTerms by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 24.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        "H",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
            Column {
                Text(
                    "Sfumato",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    "Your intelligence workspace",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(44.dp))
        Text(
            if (creatingAccount) "Create your account" else "Welcome back",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (creatingAccount) {
                "One secure account for every Sfumato experience."
            } else {
                "Sign in to continue learning, building and creating."
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Row(modifier = Modifier.padding(5.dp)) {
                if (!creatingAccount) {
                    Button(
                        onClick = { },
                        modifier = Modifier.weight(1f),
                    ) { Text("Sign in") }
                    TextButton(
                        onClick = {
                            creatingAccount = true
                            viewModel.clearMessage()
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Create account") }
                } else {
                    TextButton(
                        onClick = {
                            creatingAccount = false
                            viewModel.clearMessage()
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Sign in") }
                    Button(
                        onClick = { },
                        modifier = Modifier.weight(1f),
                    ) { Text("Create account") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        if (!state.isOnline) {
            StatusMessage("You are offline. Account changes need an internet connection.", true)
            Spacer(Modifier.height(12.dp))
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            ),
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (creatingAccount) {
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Your name") },
                        singleLine = true,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it.trim() },
                    label = { Text("Email address") },
                    singleLine = true,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    supportingText = if (creatingAccount) {
                        { Text("Use at least 8 characters") }
                    } else null,
                    singleLine = true,
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Default.VisibilityOff
                                else Icons.Default.Visibility,
                                contentDescription = if (passwordVisible) "Hide password" else "Show password",
                            )
                        }
                    },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (creatingAccount) {
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("Confirm password") },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = acceptedTerms,
                            onCheckedChange = { acceptedTerms = it },
                        )
                        Text(
                            "I agree to the Sfumato Terms and Privacy Policy.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                state.error?.let { StatusMessage(it, true) }
                state.notice?.let { StatusMessage(it, false) }
                Button(
                    onClick = {
                        viewModel.clearMessage()
                        if (creatingAccount) {
                            viewModel.createAccount(
                                email = email,
                                password = password,
                                confirmPassword = confirmPassword,
                                displayName = displayName,
                                acceptedTerms = acceptedTerms,
                            )
                        } else viewModel.signIn(email, password)
                    },
                    enabled = !state.isWorking && state.isOnline,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                ) {
                    if (state.isWorking) {
                        CircularProgressIndicator(modifier = Modifier.height(20.dp))
                    } else {
                        Text(if (creatingAccount) "Create Sfumato account" else "Continue to Sfumato")
                    }
                }
                if (!creatingAccount) {
                    TextButton(
                        onClick = { viewModel.sendPasswordReset(email) },
                        enabled = !state.isWorking && state.isOnline && email.isNotBlank(),
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    ) {
                        Text("Forgot your password?")
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "Your account keeps your conversations, learning progress and plan securely connected.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountScreen(
    state: AccountUiState,
    onBack: () -> Unit,
    onPlans: () -> Unit,
    onEditSetup: () -> Unit,
    onSave: (String, String, String) -> Unit,
    onSignOut: () -> Unit,
    onPasswordReset: (String) -> Unit,
    onVerifyEmail: () -> Unit,
    onRefreshSecurity: () -> Unit,
    onDismissMessage: () -> Unit,
) {
    val user = (state.session as AccountSession.SignedIn).user
    var displayName by remember { mutableStateOf(user.displayName) }
    var countryCode by remember { mutableStateOf("") }
    var schoolLevel by remember { mutableStateOf("") }

    LaunchedEffect(state.profile) {
        state.profile?.let {
            displayName = it.displayName
            countryCode = it.countryCode
            schoolLevel = it.schoolLevel
        }
    }

    Scaffold(
        topBar = {
            ModernPageHeader(
                title = "Account",
                navigationIcon = {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                },
                onNavigationClick = onBack,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        if (displayName.isBlank()) "Your Sfumato account" else displayName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        user.email,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    if (state.isOnline) "Online" else "Offline",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (state.isOnline) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (!state.isOnline) {
                StatusMessage(
                    "You are offline. Your saved details remain available; reconnect to sync changes.",
                    false,
                )
            }
            state.error?.let { StatusMessage(it, true) }
            state.notice?.let { StatusMessage(it, false) }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                ),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Profile", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Personalise tutoring, scholarships and recommendations.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = countryCode,
                        onValueChange = { countryCode = it.uppercase().take(2) },
                        label = { Text("Country code") },
                        supportingText = { Text("For example, ZA") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = schoolLevel,
                        onValueChange = { schoolLevel = it },
                        label = { Text("Learning level") },
                        placeholder = { Text("High school, university or professional") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = {
                            onDismissMessage()
                            onSave(displayName, countryCode, schoolLevel)
                        },
                        enabled = !state.isWorking && state.isOnline,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (state.isWorking) {
                            CircularProgressIndicator(modifier = Modifier.height(20.dp))
                        } else {
                            Text(if (state.isOnline) "Save profile" else "Reconnect to save")
                        }
                    }
                    OutlinedButton(onClick = onEditSetup, modifier = Modifier.fillMaxWidth()) {
                        Text("Edit plan-specific profile")
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                ),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Plan", style = MaterialTheme.typography.titleLarge)
                    Text(
                        when (state.planTier) {
                            "student" -> "Student Pro · R200/month"
                            "developer" -> "Developer · R1,000/month"
                            "business" -> "Business · R5,000/month"
                            else -> "Free"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    if (state.autonomousCoding) {
                        Text(
                            "Autonomous Coding is active",
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    if (state.planSource == "sponsored_voucher") {
                        Text(
                            buildString {
                                append("Sponsored Student Pro")
                                state.sponsor?.takeIf(String::isNotBlank)?.let { append(" by $it") }
                            },
                            color = MaterialTheme.colorScheme.primary,
                        )
                        state.sponsoredUntil?.let {
                            Text("Sponsored access ends: ${it.take(10)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    OutlinedButton(onClick = onPlans, modifier = Modifier.fillMaxWidth()) {
                        Text("View and manage plans")
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                ),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Security", style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (state.isEmailVerified) "Email verified"
                        else "Verify your email to strengthen account recovery.",
                        color = if (state.isEmailVerified) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!state.isEmailVerified) {
                        Button(
                            onClick = onVerifyEmail,
                            enabled = !state.isWorking && state.isOnline,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Send verification email") }
                        TextButton(
                            onClick = onRefreshSecurity,
                            enabled = !state.isWorking && state.isOnline,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("I verified my email — refresh status") }
                    }
                    OutlinedButton(
                        onClick = { onPasswordReset(user.email) },
                        enabled = !state.isWorking && state.isOnline,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Reset password") }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                ),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Session", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Sign out when using a shared phone or computer.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(
                        onClick = onSignOut,
                        enabled = !state.isWorking,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = null)
                        Text("  Sign out")
                    }
                }
            }
            Spacer(Modifier.height(80.dp))
        }
    }
}

@Composable
private fun StatusMessage(text: String, isError: Boolean) {
    Snackbar(
        containerColor = if (isError) MaterialTheme.colorScheme.errorContainer
        else MaterialTheme.colorScheme.secondaryContainer,
        contentColor = if (isError) MaterialTheme.colorScheme.onErrorContainer
        else MaterialTheme.colorScheme.onSecondaryContainer,
    ) {
        Text(text)
    }
}
