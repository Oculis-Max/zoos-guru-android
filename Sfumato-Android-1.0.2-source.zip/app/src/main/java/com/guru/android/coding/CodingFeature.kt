package com.guru.android.coding

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton

data class GitHubStatus(val connected: Boolean, val login: String? = null)
data class GitHubConnect(@SerializedName("authorize_url") val authorizeUrl: String)
data class CodingRepo(
    @SerializedName("full_name") val fullName: String,
    val private: Boolean,
    @SerializedName("default_branch") val defaultBranch: String,
    val permissions: Map<String, Boolean> = emptyMap(),
)
data class PlanRequest(
    val repository: String,
    val task: String,
    @SerializedName("base_branch") val baseBranch: String? = null,
)
data class ProposedFilePreview(
    val path: String,
    val operation: String = "upsert",
    val content: String = "",
)
data class PlanResponse(
    @SerializedName("task_id") val taskId: String,
    val repository: String,
    @SerializedName("base_branch") val baseBranch: String,
    @SerializedName("base_sha") val baseSha: String,
    val plan: String,
    @SerializedName("proposed_changes") val proposedChanges: List<ProposedFilePreview> = emptyList(),
    @SerializedName("expires_at") val expiresAt: String,
)
data class ApplyRequest(
    @SerializedName("task_id") val taskId: String,
    val approved: Boolean,
)
data class ApplyResponse(
    val branch: String,
    @SerializedName("commit_sha") val commitSha: String,
    @SerializedName("pull_request_url") val pullRequestUrl: String,
    @SerializedName("files_changed") val filesChanged: List<String>,
    @SerializedName("verification_status") val verificationStatus: String = "pending",
)
data class RepositoryFile(val path: String, val size: Int, val sha: String)
data class RepositoryFileContent(
    val path: String,
    val content: String,
    val sha: String,
    val truncated: Boolean = false,
)
data class TaskHistoryItem(
    val id: String,
    val repository: String,
    val task: String,
    val status: String,
    @SerializedName("base_branch") val baseBranch: String,
    @SerializedName("pull_request_url") val pullRequestUrl: String? = null,
    val files: List<String> = emptyList(),
)
data class CancelResponse(@SerializedName("task_id") val taskId: String, val status: String)

interface CodingService {
    @GET("v1/coding/github/status")
    suspend fun status(@Header("Authorization") token: String): GitHubStatus
    @GET("v1/coding/github/connect")
    suspend fun connect(@Header("Authorization") token: String): GitHubConnect
    @GET("v1/coding/github/repos")
    suspend fun repos(@Header("Authorization") token: String): List<CodingRepo>
    @DELETE("v1/coding/github/connection")
    suspend fun disconnect(@Header("Authorization") token: String): GitHubStatus
    @GET("v1/coding/github/repos/{owner}/{repo}/tree")
    suspend fun tree(
        @Header("Authorization") token: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("ref") ref: String,
    ): List<RepositoryFile>
    @GET("v1/coding/github/repos/{owner}/{repo}/file")
    suspend fun file(
        @Header("Authorization") token: String,
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("path") path: String,
        @Query("ref") ref: String,
    ): RepositoryFileContent
    @GET("v1/coding/tasks/history")
    suspend fun history(@Header("Authorization") token: String): List<TaskHistoryItem>
    @POST("v1/coding/tasks/{taskId}/cancel")
    suspend fun cancel(
        @Header("Authorization") token: String,
        @Path("taskId") taskId: String,
    ): CancelResponse
    @POST("v1/coding/tasks/plan")
    suspend fun plan(@Header("Authorization") token: String, @Body body: PlanRequest): PlanResponse
    @POST("v1/coding/tasks/apply")
    suspend fun apply(@Header("Authorization") token: String, @Body body: ApplyRequest): ApplyResponse
}

@Singleton
class CodingRepository @Inject constructor(private val api: CodingService) {
    private suspend fun token(): String {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        val value = checkNotNull(user.getIdToken(false).await().token) { "Session expired." }
        return "Bearer " + value
    }
    suspend fun status() = api.status(token())
    suspend fun connect() = api.connect(token())
    suspend fun repos() = api.repos(token())
    suspend fun disconnect() = api.disconnect(token())
    private fun parts(repo: CodingRepo): Pair<String, String> {
        val values = repo.fullName.split("/", limit = 2)
        check(values.size == 2) { "Invalid repository name." }
        return values[0] to values[1]
    }
    suspend fun tree(repo: CodingRepo): List<RepositoryFile> {
        val (owner, name) = parts(repo)
        return api.tree(token(), owner, name, repo.defaultBranch)
    }
    suspend fun file(repo: CodingRepo, path: String): RepositoryFileContent {
        val (owner, name) = parts(repo)
        return api.file(token(), owner, name, path, repo.defaultBranch)
    }
    suspend fun history() = api.history(token())
    suspend fun cancel(plan: PlanResponse) = api.cancel(token(), plan.taskId)
    suspend fun plan(repo: CodingRepo, task: String) =
        api.plan(token(), PlanRequest(repo.fullName, task, repo.defaultBranch))
    suspend fun apply(plan: PlanResponse) =
        api.apply(token(), ApplyRequest(plan.taskId, true))
}

data class CodingState(
    val busy: Boolean = false,
    val connected: Boolean = false,
    val login: String? = null,
    val repos: List<CodingRepo> = emptyList(),
    val selected: CodingRepo? = null,
    val task: String = "",
    val plan: PlanResponse? = null,
    val authorizeUrl: String? = null,
    val result: ApplyResponse? = null,
    val approved: Boolean = false,
    val files: List<RepositoryFile> = emptyList(),
    val selectedFile: RepositoryFileContent? = null,
    val history: List<TaskHistoryItem> = emptyList(),
    val activity: List<String> = listOf("Coding Agent opened."),
    val currentAction: String? = null,
    val operationStartedAt: Long? = null,
    val lastOperationSeconds: Long? = null,
    val error: String? = null,
)

@HiltViewModel
class CodingViewModel @Inject constructor(private val repository: CodingRepository) : ViewModel() {
    private val data = MutableStateFlow(CodingState())
    val state = data.asStateFlow()

    init { refresh() }

    fun refresh() = launch("Refreshing your GitHub workspace") {
        val status = repository.status()
        data.update {
            it.copy(
                connected = status.connected,
                login = status.login,
                repos = if (status.connected) it.repos else emptyList(),
                selected = if (status.connected) it.selected else null,
            )
        }
        if (status.connected) {
            val repos = repository.repos()
            val selected = data.value.selected?.takeIf { selectedRepo ->
                repos.any { repo -> repo.fullName == selectedRepo.fullName }
            } ?: repos.firstOrNull()
            data.update {
                it.copy(
                    repos = repos,
                    selected = selected,
                    activity = it.activity + "GitHub repositories loaded.",
                )
            }
            selected?.let { loadWorkspace(it) }
            data.update { it.copy(history = repository.history()) }
        }
    }
    fun connect() = launch("Opening secure GitHub connection") {
        data.update { it.copy(authorizeUrl = repository.connect().authorizeUrl) }
    }
    fun disconnect() = launch("Disconnecting GitHub") {
        repository.disconnect()
        data.value = CodingState()
    }
    fun consumedUrl() = data.update { it.copy(authorizeUrl = null) }
    fun chooseRepositoryInput(value: String) {
        val normalized = normalizeRepositoryInput(value)
        val repo = data.value.repos.firstOrNull {
            it.fullName.equals(normalized, ignoreCase = true)
        }
        if (repo == null) {
            data.update {
                it.copy(
                    error = "Repository not found. Check that the link is correct and your connected GitHub account has write access.",
                )
            }
            return
        }
        choose(repo)
    }
    fun choose(repo: CodingRepo) = launch("Loading " + repo.fullName) {
        data.update {
            it.copy(
                selected = repo,
                plan = null,
                result = null,
                approved = false,
                files = emptyList(),
                selectedFile = null,
                activity = it.activity + "Selected " + repo.fullName,
            )
        }
        loadWorkspace(repo)
    }
    private suspend fun loadWorkspace(repo: CodingRepo) {
        val files = repository.tree(repo)
        data.update {
            it.copy(
                files = files,
                selectedFile = null,
                activity = it.activity + (files.size.toString() + " safe files indexed."),
            )
        }
    }
    fun openFile(file: RepositoryFile) = launch("Opening " + file.path) {
        val repo = checkNotNull(data.value.selected) { "Choose a repository." }
        data.update { it.copy(selectedFile = repository.file(repo, file.path)) }
    }
    fun closeFile() = data.update { it.copy(selectedFile = null) }
    fun reloadHistory() = launch("Refreshing task history") {
        data.update { it.copy(history = repository.history()) }
    }
    fun setTask(value: String) = data.update {
        it.copy(task = value, plan = null, result = null, approved = false)
    }
    fun approve(value: Boolean) = data.update { it.copy(approved = value) }
    fun plan() = launch("Preparing your plan and exact changes") {
        val current = data.value
        val repo = checkNotNull(current.selected) { "Choose a repository." }
        require(current.task.trim().length >= 8) { "Describe the change in more detail." }
        data.update {
            it.copy(
                plan = repository.plan(repo, current.task.trim()),
                approved = false,
                activity = it.activity + "Safe plan generated and awaiting approval.",
            )
        }
        data.update { it.copy(history = repository.history()) }
    }
    fun cancelPlan() = launch("Cancelling the plan safely") {
        val plan = checkNotNull(data.value.plan) { "There is no active plan." }
        repository.cancel(plan)
        data.update {
            it.copy(
                plan = null,
                approved = false,
                activity = it.activity + "Plan cancelled before any files were changed.",
                history = repository.history(),
            )
        }
    }
    fun retry() {
        if (data.value.task.trim().length >= 8 && data.value.selected != null) plan() else refresh()
    }
    fun apply() = launch("Creating your safe draft PR") {
        val current = data.value
        check(current.approved) { "Review and approve the plan first." }
        checkNotNull(current.selected) { "Choose a repository." }
        val plan = checkNotNull(current.plan) { "Generate a plan first." }
        data.update {
            it.copy(
                result = repository.apply(plan),
                approved = false,
                activity = it.activity + "Draft pull request created. Repository CI must verify it.",
                history = repository.history(),
            )
        }
    }
    private fun launch(action: String, block: suspend () -> Unit) {
        if (data.value.busy) return
        viewModelScope.launch {
            val startedAt = System.currentTimeMillis()
            data.update {
                it.copy(
                    busy = true,
                    error = null,
                    currentAction = action,
                    operationStartedAt = startedAt,
                )
            }
            try { block() } catch (e: Exception) {
                val details = if (e is HttpException) {
                    runCatching { e.response()?.errorBody()?.string().orEmpty() }.getOrDefault("")
                } else {
                    ""
                }
                val message = if (e is HttpException) when {
                    e.code() == 401 -> "Your session or GitHub connection expired. Sign in and reconnect."
                    e.code() == 403 -> "An active Developer plan and repository write access are required."
                    details.contains("repository_changed_replan") ->
                        "The repository changed after your preview. Generate a fresh plan before approving."
                    details.contains("coding_task_expired_replan") ->
                        "This approval expired for safety. Generate a fresh plan."
                    details.contains("finish_existing_coding_tasks") ->
                        "Finish or cancel an existing coding plan before creating another."
                    details.contains("github_not_connected") ->
                        "Connect GitHub before starting a coding task."
                    details.contains("coding_task_already_used") ->
                        "This approval was already used. Start a new task."
                    e.code() == 409 -> "This coding plan cannot continue. Refresh and generate a fresh plan."
                    e.code() == 422 -> "Sfumato blocked a protected file, secret, or unsafe change."
                    e.code() == 429 -> "You reached the safe planning limit. Try again in one hour."
                    e.code() == 503 -> "Autonomous Coding is temporarily unavailable. Retry shortly."
                    else -> "Server error (HTTP " + e.code() + ")."
                } else e.message ?: "The coding task failed."
                data.update { it.copy(error = message) }
            } finally {
                val elapsedSeconds = ((System.currentTimeMillis() - startedAt) / 1000).coerceAtLeast(0)
                data.update {
                    it.copy(
                        busy = false,
                        currentAction = null,
                        operationStartedAt = null,
                        lastOperationSeconds = elapsedSeconds,
                    )
                }
            }
        }
    }
}

internal fun normalizeRepositoryInput(value: String): String =
    value.trim()
        .substringBefore('?')
        .substringBefore('#')
        .removePrefix("https://github.com/")
        .removePrefix("http://github.com/")
        .removePrefix("github.com/")
        .removeSuffix("/")
        .removeSuffix(".git")

private fun codingElapsedLabel(totalSeconds: Long): String {
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return if (minutes > 0) minutes.toString() + "m " + seconds.toString() + "s" else seconds.toString() + "s"
}

private fun codingLiveDetail(action: String?, elapsedSeconds: Long): String = when {
    action?.startsWith("Preparing") == true && elapsedSeconds < 4 ->
        "Sending your task securely and checking the selected repository."
    action?.startsWith("Preparing") == true && elapsedSeconds < 15 ->
        "Inspecting relevant files and preparing a safe implementation plan."
    action?.startsWith("Preparing") == true ->
        "Generating the exact file changes for your review. Larger repositories can take a little longer."
    action?.startsWith("Creating") == true && elapsedSeconds < 5 ->
        "Confirming your approval and the protected base version."
    action?.startsWith("Creating") == true ->
        "Creating a separate branch, commit and draft pull request. Main remains untouched."
    action?.startsWith("Loading") == true ->
        "Loading safe repository information. Secrets and protected files remain hidden."
    else -> "This page will update automatically when the action finishes."
}

@Composable
fun CodingScreen(
    hasAccess: Boolean = true,
    planTier: String = "free",
    viewModel: CodingViewModel = hiltViewModel(),
) {
    if (!hasAccess) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Autonomous Coding", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "The ${planTier.replaceFirstChar(Char::uppercase)} plan does not include Autonomous Coding.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Upgrade to the Developer plan to connect GitHub, review exact changes and create draft pull requests.",
                color = MaterialTheme.colorScheme.primary,
            )
        }
        return
    }
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var repositoryInput by remember { mutableStateOf("") }
    var previewPath by remember { mutableStateOf<String?>(null) }
    var showFiles by remember { mutableStateOf(false) }
    var showSafetyDetails by remember { mutableStateOf(false) }
    var showActivity by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var clockMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(state.plan?.taskId) {
        previewPath = null
    }

    LaunchedEffect(state.busy, state.operationStartedAt) {
        while (state.busy) {
            clockMillis = System.currentTimeMillis()
            delay(1_000)
        }
    }

    val elapsedSeconds = state.operationStartedAt
        ?.let { ((clockMillis - it) / 1_000).coerceAtLeast(0) }
        ?: 0

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && state.authorizeUrl == null) {
                viewModel.refresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(state.authorizeUrl) {
        state.authorizeUrl?.let {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)))
            viewModel.consumedUrl()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Coding Agent", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Describe what you need. Sfumato prepares the exact changes for you to review before anything is created.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Your progress", style = MaterialTheme.typography.titleMedium)
                Text(
                    (if (state.connected) "✓" else "1") + "  Connect GitHub",
                    color = if (state.connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    (if (state.plan != null || state.result != null) "✓" else "2") + "  Describe the task",
                    color = if (state.connected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    (if (state.result != null) "✓" else "3") + "  Review and create a draft PR",
                    color = if (state.plan != null || state.result != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (state.busy || state.activity.size > 1) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
            ) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            if (state.busy) "Sfumato is working" else "Latest updates",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            if (state.busy) {
                                codingElapsedLabel(elapsedSeconds)
                            } else {
                                state.lastOperationSeconds?.let(::codingElapsedLabel) ?: ""
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (state.busy) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                            )
                            Text(
                                state.currentAction ?: "Working on your request",
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                        Text(
                            codingLiveDetail(state.currentAction, elapsedSeconds),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    state.activity
                        .drop(1)
                        .takeLast(5)
                        .asReversed()
                        .forEach { update ->
                            Text("✓  " + update)
                        }
                    if (!state.busy && state.result != null) {
                        Text(
                            "Next: open the draft PR, wait for its checks to pass, then review before merging.",
                            color = MaterialTheme.colorScheme.primary,
                        )
                    } else if (!state.busy && state.plan != null) {
                        Text(
                            "Next: review the plan and exact file changes below.",
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (state.connected) "Step 1 complete · Connected as " + state.login else "Step 1 of 3 · Connect GitHub",
                    style = MaterialTheme.typography.titleMedium,
                )
                if (!state.connected) {
                    Button(
                        onClick = viewModel::connect,
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Connect GitHub") }
                    OutlinedButton(
                        onClick = viewModel::refresh,
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("I finished connecting") }
                } else {
                    OutlinedButton(
                        onClick = viewModel::refresh,
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Refresh repositories") }
                    TextButton(
                        onClick = viewModel::disconnect,
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Disconnect GitHub") }
                }
            }
        }

        if (state.connected) {
            Text("Step 2 of 3 · Describe the task", style = MaterialTheme.typography.titleLarge)
            if (state.repos.isEmpty() && !state.busy) {
                Card(Modifier.fillMaxWidth()) {
                    Column(
                        Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("No writable repositories loaded", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Sfumato is connected, but it could not find a repository it can safely create a branch in.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedButton(onClick = viewModel::refresh) { Text("Try loading repositories again") }
                    }
                }
            }
            Box {
                OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(state.selected?.fullName ?: "Choose repository")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    state.repos.forEach { repo ->
                        DropdownMenuItem(
                            text = { Text(repo.fullName + if (repo.private) " · Private" else "") },
                            onClick = { viewModel.choose(repo); menu = false },
                        )
                    }
                }
            }
            Text(
                "Or paste a GitHub repository link",
                style = MaterialTheme.typography.labelLarge,
            )
            OutlinedTextField(
                value = repositoryInput,
                onValueChange = { repositoryInput = it },
                placeholder = { Text("https://github.com/owner/repository") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(
                onClick = { viewModel.chooseRepositoryInput(repositoryInput) },
                enabled = !state.busy && repositoryInput.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Use pasted repository")
            }
            OutlinedTextField(
                value = state.task, onValueChange = viewModel::setTask,
                label = { Text("What should Sfumato build or fix?") },
                placeholder = { Text("Add password reset validation and tests") },
                supportingText = { Text("Say what should change and how you will know it works. Sfumato will inspect the repository before proposing anything.") },
                minLines = 4, modifier = Modifier.fillMaxWidth(),
            )
            Text("Quick starts", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = { viewModel.setTask("Fix this bug: [describe the problem]. Add tests so it does not happen again.") },
                    label = { Text("Fix a bug") },
                )
                AssistChip(
                    onClick = { viewModel.setTask("Build this feature: [describe what users should be able to do]. Add tests.") },
                    label = { Text("Build a feature") },
                )
            }
            AssistChip(
                onClick = { viewModel.setTask("Review the current code for this area: [name the area]. Improve it safely and add missing tests.") },
                label = { Text("Improve existing code") },
            )
            Button(
                onClick = viewModel::plan,
                enabled = !state.busy && state.selected != null && state.task.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Review plan and exact changes") }
        }

        if (state.connected && state.selected != null) {
            OutlinedButton(
                onClick = { showFiles = !showFiles },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (showFiles) "Hide repository files" else "Browse repository files (" + state.files.size + ")")
            }
            if (showFiles) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Repository files", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Read-only preview. Secrets and protected files stay hidden.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (state.files.isEmpty()) Text("No safe text files loaded.")
                        state.files.take(20).forEach { file ->
                            TextButton(onClick = { viewModel.openFile(file) }) {
                                Text(file.path + " · " + file.size + " bytes")
                            }
                        }
                        if (state.files.size > 20) Text("+ " + (state.files.size - 20) + " more indexed files")
                    }
                }
            }
        }

        state.selectedFile?.let { file ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(file.path, style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = viewModel::closeFile) { Text("Close") }
                    }
                    if (file.truncated) Text("Preview limited to the first 30,000 characters.")
                    SelectionContainer {
                        Text(file.content, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        state.plan?.let { plan ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Step 3 of 3 · Review and approve", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Nothing has been changed yet. Check the plan and open any file below to see its complete proposed content.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(plan.plan)
                    TextButton(onClick = { showSafetyDetails = !showSafetyDetails }) {
                        Text(if (showSafetyDetails) "Hide safety details" else "Show safety details")
                    }
                    if (showSafetyDetails) {
                        Text("Protected base: " + plan.baseSha.take(12))
                        Text("Approval expires at " + plan.expiresAt)
                        Text("Sfumato creates a new branch and draft PR only. It never writes to main or merges.")
                    }
                    Text("Exact proposed changes", style = MaterialTheme.typography.titleMedium)
                    plan.proposedChanges.forEach { change ->
                        OutlinedButton(
                            onClick = { previewPath = change.path },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                (if (change.operation == "delete") "DELETE · " else "EDIT · ") +
                                    change.path
                            )
                        }
                    }
                    plan.proposedChanges.firstOrNull { it.path == previewPath }?.let { change ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(
                                    if (change.operation == "delete") {
                                        "This existing file will be deleted."
                                    } else {
                                        "Complete proposed content"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                )
                                if (change.operation != "delete") {
                                    SelectionContainer {
                                        Text(change.content, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                TextButton(onClick = { previewPath = null }) {
                                    Text("Close preview")
                                }
                            }
                        }
                    }
                    Row {
                        Checkbox(state.approved, viewModel::approve)
                        Text(
                            "I reviewed this plan and its exact file changes. Create a new branch and safe draft PR for me to review on GitHub.",
                            Modifier.padding(top = 10.dp),
                        )
                    }
                    Button(onClick = viewModel::apply, enabled = state.approved && !state.busy,
                        modifier = Modifier.fillMaxWidth()) { Text("Create safe draft PR") }
                    OutlinedButton(
                        onClick = viewModel::cancelPlan,
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Cancel this plan") }
                }
            }
        }

        state.result?.let { result ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Draft PR created", style = MaterialTheme.typography.titleLarge)
                    Text("Your changes are on a separate branch. Main was not changed.")
                    Text(result.filesChanged.size.toString() + " file(s) included")
                    TextButton(onClick = { showSafetyDetails = !showSafetyDetails }) {
                        Text(if (showSafetyDetails) "Hide technical details" else "Show technical details")
                    }
                    if (showSafetyDetails) {
                        Text("Branch: " + result.branch)
                        Text("Commit: " + result.commitSha.take(12))
                    }
                    Text(
                        if (result.verificationStatus == "pending") {
                            "Repository CI verification is pending. Do not merge until its checks pass."
                        } else {
                            "Verification: " + result.verificationStatus
                        },
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Button(onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(result.pullRequestUrl)))
                    }) { Text("Review on GitHub") }
                }
            }
        }
        TextButton(onClick = { showActivity = !showActivity }) {
            Text(if (showActivity) "Hide agent activity" else "Show agent activity")
        }
        if (showActivity) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Agent activity", style = MaterialTheme.typography.titleLarge)
                    state.activity.takeLast(8).forEach { Text("• " + it) }
                    Text(
                        "Tests run in repository CI. Sfumato never runs arbitrary commands on your phone or production backend.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        TextButton(onClick = { showHistory = !showHistory }) {
            Text(if (showHistory) "Hide task history" else "Show task history")
        }
        if (showHistory) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Task history", style = MaterialTheme.typography.titleLarge)
                        TextButton(onClick = viewModel::reloadHistory, enabled = !state.busy) {
                            Text("Refresh")
                        }
                    }
                    if (state.history.isEmpty()) Text("No coding tasks yet.")
                    state.history.take(10).forEach { item ->
                        Text(item.status.uppercase() + " · " + item.repository)
                        Text(item.task, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        item.pullRequestUrl?.let { url ->
                            TextButton(onClick = {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            }) { Text("Open draft PR") }
                        }
                    }
                }
            }
        }

        state.error?.let {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(it, color = MaterialTheme.colorScheme.error)
                OutlinedButton(onClick = viewModel::retry, enabled = !state.busy) {
                    Text("Retry")
                }
            }
        }
        if (state.busy) {
            Text(
                "You can stay on this screen; progress updates automatically.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
