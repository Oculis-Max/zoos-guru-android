package com.guru.android.journalist

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import retrofit2.http.*
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class JournalistNotes(
    val transcript: String,
    val summary: String,
    @SerializedName("key_quotes") val keyQuotes: List<String> = emptyList(),
    @SerializedName("facts_to_verify") val factsToVerify: List<String> = emptyList(),
    @SerializedName("follow_up_questions") val followUpQuestions: List<String> = emptyList(),
    @SerializedName("article_outline") val articleOutline: List<String> = emptyList(),
    @SerializedName("headline_suggestions") val headlineSuggestions: List<String> = emptyList(),
    @SerializedName("privacy_notice") val privacyNotice: String = "",
)

interface JournalistService {
    @Multipart
    @POST("v1/journalist/transcribe")
    suspend fun transcribe(
        @Header("Authorization") token: String,
        @Part audio: MultipartBody.Part,
        @Part("consent_confirmed") consent: okhttp3.RequestBody,
        @Part("save_notes") saveNotes: okhttp3.RequestBody,
    ): JournalistNotes
}

@Singleton
class JournalistRepository @Inject constructor(private val service: JournalistService) {
    suspend fun transcribe(file: File): JournalistNotes {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        val token = checkNotNull(user.getIdToken(false).await().token) { "Session expired." }
        val body = file.asRequestBody("audio/mp4".toMediaType())
        return service.transcribe(
            "Bearer " + token,
            MultipartBody.Part.createFormData("audio", file.name, body),
            "true".toRequestBody("text/plain".toMediaType()),
            "true".toRequestBody("text/plain".toMediaType()),
        )
    }
}

data class JournalistState(
    val busy: Boolean = false,
    val notes: JournalistNotes? = null,
    val error: String? = null,
)

@HiltViewModel
class JournalistViewModel @Inject constructor(private val repository: JournalistRepository) : ViewModel() {
    private val mutableState = MutableStateFlow(JournalistState())
    val state = mutableState.asStateFlow()

    fun process(file: File) {
        if (mutableState.value.busy) return
        viewModelScope.launch {
            mutableState.update { it.copy(busy = true, error = null, notes = null) }
            try {
                mutableState.update { it.copy(notes = repository.transcribe(file)) }
            } catch (error: Exception) {
                val message = if (error is HttpException) when (error.code()) {
                    400 -> "Recording consent must be confirmed."
                    403 -> "Journalist Studio currently requires the Business plan."
                    413 -> "This interview is too large. Record it in shorter parts."
                    415 -> "This audio format is not supported."
                    429 -> "Transcription is busy. Please try again shortly."
                    503 -> "Secure interview transcription is awaiting production activation."
                    else -> "Transcription failed (HTTP " + error.code() + ")."
                } else error.message ?: "Could not process this interview."
                mutableState.update { it.copy(error = message) }
            } finally {
                mutableState.update { it.copy(busy = false) }
            }
        }
    }
}

private class InterviewRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null

    @Suppress("DEPRECATION")
    fun start(): File {
        val directory = File(context.filesDir, "interviews").apply { mkdirs() }
        val file = File(directory, "interview-" + System.currentTimeMillis() + ".m4a")
        val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            MediaRecorder()
        }
        mediaRecorder.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(64_000)
            setAudioSamplingRate(44_100)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        recorder = mediaRecorder
        return file
    }

    fun stop() {
        val active = recorder ?: return
        try { active.stop() } finally {
            active.release()
            recorder = null
        }
    }
}

@Composable
fun JournalistScreen(viewModel: JournalistViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val recorder = remember { InterviewRecorder(context.applicationContext) }
    var consent by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var audioFile by remember { mutableStateOf<File?>(null) }
    var status by remember { mutableStateOf("Ready to record") }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted && consent) {
            runCatching {
                audioFile = recorder.start()
                recording = true
                status = "Recording interview…"
            }.onFailure { status = "Could not start recording: " + (it.message ?: "unknown error") }
        } else if (!granted) {
            status = "Microphone permission is required."
        }
    }

    DisposableEffect(Unit) {
        onDispose { recorder.stop() }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Journalist Studio", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Record an interview, create a faithful transcript, and turn hours of editing into structured notes.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Recording consent", style = MaterialTheme.typography.titleLarge)
                Row {
                    Checkbox(checked = consent, onCheckedChange = { if (!recording) consent = it })
                    Text(
                        "I confirm everyone being recorded has been informed and has consented where legally required.",
                        modifier = Modifier.padding(top = 10.dp),
                    )
                }
                Text(status, color = if (recording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                if (!recording) {
                    Button(
                        onClick = {
                            if (!consent) {
                                status = "Confirm recording consent first."
                            } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                                PackageManager.PERMISSION_GRANTED
                            ) {
                                runCatching {
                                    audioFile = recorder.start()
                                    recording = true
                                    status = "Recording interview…"
                                }.onFailure { status = "Could not start recording: " + (it.message ?: "unknown error") }
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Start interview") }
                } else {
                    Button(
                        onClick = {
                            runCatching { recorder.stop() }
                                .onSuccess {
                                    recording = false
                                    status = "Recording saved securely on this phone."
                                }
                                .onFailure {
                                    recording = false
                                    status = "Recording stopped, but the file may be incomplete."
                                }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Stop recording") }
                }

                audioFile?.takeIf { it.exists() && !recording }?.let { file ->
                    Text("Saved: " + file.name + " · " + (file.length() / 1024) + " KB")
                    Button(
                        onClick = { viewModel.process(file) },
                        enabled = !state.busy && consent,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(if (state.busy) "Transcribing…" else "Create transcript and notes") }
                    TextButton(
                        onClick = {
                            if (file.delete()) {
                                audioFile = null
                                status = "Local recording deleted."
                            }
                        },
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Delete recording from phone") }
                }
            }
        }

        if (state.busy) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("Uploading securely and processing the interview. Keep HiGURU open.")
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        state.notes?.let { notes ->
            NoteSection("Summary", notes.summary, clipboard)
            NoteSection("Transcript", notes.transcript, clipboard)
            ListSection("Key quotes", notes.keyQuotes, clipboard)
            ListSection("Facts to verify", notes.factsToVerify, clipboard)
            ListSection("Follow-up questions", notes.followUpQuestions, clipboard)
            ListSection("Article outline", notes.articleOutline, clipboard)
            ListSection("Headline suggestions", notes.headlineSuggestions, clipboard)
            Text(notes.privacyNotice, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun NoteSection(title: String, value: String, clipboard: androidx.compose.ui.platform.ClipboardManager) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(value)
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(value)) }) { Text("Copy " + title.lowercase()) }
        }
    }
}

@Composable
private fun ListSection(title: String, values: List<String>, clipboard: androidx.compose.ui.platform.ClipboardManager) {
    if (values.isEmpty()) return
    val text = values.joinToString("\n") { "• " + it }
    NoteSection(title, text, clipboard)
}
