package com.guru.android.data.remote

import com.guru.android.BuildConfig

object BackendConfig {
    private const val UNCONFIGURED_HOST = "example.invalid"

    fun baseUrl(rawValue: String = BuildConfig.HIGURU_BACKEND_BASE_URL): String {
        val trimmed = rawValue.trim()
        require(trimmed.startsWith("https://")) {
            "Sfumato backend URL must use HTTPS"
        }
        return if (trimmed.endsWith("/")) trimmed else "$trimmed/"
    }

    fun isConfigured(rawValue: String = BuildConfig.HIGURU_BACKEND_BASE_URL): Boolean {
        return runCatching {
            val normalized = baseUrl(rawValue)
            !normalized.contains(UNCONFIGURED_HOST)
        }.getOrDefault(false)
    }
}
