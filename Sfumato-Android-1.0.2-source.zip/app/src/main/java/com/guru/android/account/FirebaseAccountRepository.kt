package com.guru.android.account

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.guru.android.domain.AccountProfile
import com.guru.android.domain.AccountRepository
import com.guru.android.domain.AccountSession
import com.guru.android.domain.AccountUser
import com.guru.android.domain.GuestIdentity
import com.guru.android.domain.IdentityId
import com.guru.android.domain.StudentProfile
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

@Singleton
class FirebaseAccountRepository @Inject constructor(
    @ApplicationContext context: Context,
) : AccountRepository {
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()
    private val preferences = context.getSharedPreferences("higuru_account", Context.MODE_PRIVATE)

    private val _session = MutableStateFlow<AccountSession>(AccountSession.Loading)
    override val session: StateFlow<AccountSession> = _session.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            _session.value = firebaseAuth.currentUser?.let { user ->
                AccountSession.SignedIn(
                    AccountUser(
                        uid = user.uid,
                        email = user.email.orEmpty(),
                        displayName = user.displayName.orEmpty(),
                    )
                )
            } ?: AccountSession.SignedOut
        }
    }

    override suspend fun currentGuest(): GuestIdentity {
        val signedIn = auth.currentUser
        if (signedIn != null) return GuestIdentity(IdentityId(signedIn.uid), localOnly = false)

        val existing = preferences.getString(GUEST_ID_KEY, null)
        val guestId = existing ?: ("guest-" + UUID.randomUUID()).also {
            preferences.edit().putString(GUEST_ID_KEY, it).apply()
        }
        return GuestIdentity(IdentityId(guestId))
    }

    override suspend fun createAccount(email: String, password: String, displayName: String) {
        val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val user = requireNotNull(result.user) { "Firebase did not return a user." }
        user.updateProfile(
            UserProfileChangeRequest.Builder()
                .setDisplayName(displayName.trim())
                .build()
        ).await()
        saveAccountProfile(
            AccountProfile(
                uid = user.uid,
                email = user.email.orEmpty(),
                displayName = displayName.trim(),
            )
        )
        // New accounts verify ownership before entering personalised onboarding.
        if (!user.isEmailVerified) user.sendEmailVerification().await()
    }

    override suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    override suspend fun signOut() {
        auth.signOut()
    }

    override suspend fun sendPasswordReset(email: String) {
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    suspend fun sendEmailVerification() {
        val user = requireNotNull(auth.currentUser) { "Sign in before verifying your email." }
        if (!user.isEmailVerified) user.sendEmailVerification().await()
    }

    suspend fun isEmailVerified(): Boolean {
        val user = requireNotNull(auth.currentUser) { "Sign in to check your account." }
        user.reload().await()
        return user.isEmailVerified
    }

    override suspend fun loadProfile(): AccountProfile? {
        val user = auth.currentUser ?: return null
        val local = cachedProfile(
            uid = user.uid,
            email = user.email.orEmpty(),
            displayName = user.displayName.orEmpty(),
        )
        return runCatching {
            val snapshot = profileDocument(user.uid).get().await()
            if (!snapshot.exists()) {
                local
            } else {
                val remote = AccountProfile(
                    uid = user.uid,
                    email = snapshot.getString("email") ?: user.email.orEmpty(),
                    displayName = snapshot.getString("displayName") ?: user.displayName.orEmpty(),
                    countryCode = snapshot.getString("countryCode").orEmpty(),
                    schoolLevel = snapshot.getString("schoolLevel").orEmpty(),
                    institution = snapshot.getString("institution").orEmpty(),
                    grade = snapshot.getString("grade").orEmpty(),
                    curriculum = snapshot.getString("curriculum").orEmpty(),
                    subjects = (snapshot.get("subjects") as? List<*>)?.filterIsInstance<String>().orEmpty(),
                    accountType = snapshot.getString("accountType") ?: "free",
                    role = snapshot.getString("role").orEmpty(),
                    organisation = snapshot.getString("organisation").orEmpty(),
                    industry = snapshot.getString("industry").orEmpty(),
                    focusAreas = (snapshot.get("focusAreas") as? List<*>)?.filterIsInstance<String>().orEmpty(),
                    onboardingVersion = snapshot.getLong("onboardingVersion")?.toInt() ?: 0,
                    onboardingComplete = snapshot.getBoolean("onboardingComplete") ?: false,
                )
                // Onboarding is a non-security UI preference. A just-completed local
                // profile must win over a stale Firestore read so the app cannot bounce
                // between onboarding and the home screen during auth/profile refreshes.
                if (
                    (local.onboardingComplete && !remote.onboardingComplete) ||
                    local.onboardingVersion > remote.onboardingVersion
                ) local
                else remote.also(::cacheProfile)
            }
        }.getOrElse { local }
    }

    override suspend fun saveAccountProfile(profile: AccountProfile) {
        val user = requireNotNull(auth.currentUser) { "Sign in before saving a profile." }
        require(profile.uid == user.uid) { "A profile can only be saved by its owner." }
        val savedProfile = profile.copy(
            email = user.email.orEmpty(),
            displayName = profile.displayName.trim(),
            countryCode = profile.countryCode.trim().uppercase(),
            schoolLevel = profile.schoolLevel.trim(),
            institution = profile.institution.trim(),
            grade = profile.grade.trim(),
            curriculum = profile.curriculum.trim(),
            subjects = profile.subjects.map(String::trim).filter(String::isNotBlank).distinct().take(12),
            accountType = profile.accountType.trim().lowercase(),
            role = profile.role.trim(),
            organisation = profile.organisation.trim(),
            industry = profile.industry.trim(),
            focusAreas = profile.focusAreas.map(String::trim).filter(String::isNotBlank).distinct().take(12),
        )
        // Persist navigation-critical state before network/Auth callbacks can reload it.
        cacheProfile(savedProfile)
        try {
            profileDocument(user.uid).set(
                mapOf(
                    "uid" to user.uid,
                    "email" to user.email.orEmpty(),
                    "displayName" to profile.displayName.trim(),
                    "countryCode" to profile.countryCode.trim().uppercase(),
                    "schoolLevel" to profile.schoolLevel.trim(),
                    "institution" to profile.institution.trim(),
                    "grade" to profile.grade.trim(),
                    "curriculum" to profile.curriculum.trim(),
                    "subjects" to profile.subjects.map(String::trim).filter(String::isNotBlank).distinct().take(12),
                    "accountType" to savedProfile.accountType,
                    "role" to savedProfile.role,
                    "organisation" to savedProfile.organisation,
                    "industry" to savedProfile.industry,
                    "focusAreas" to savedProfile.focusAreas,
                    "onboardingVersion" to savedProfile.onboardingVersion,
                    "onboardingComplete" to profile.onboardingComplete,
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
                SetOptions.merge(),
            ).await()
        } catch (error: FirebaseFirestoreException) {
            // Firestore profile metadata is not an entitlement source. If production
            // rules temporarily reject this optional sync, keep the owner-validated
            // local profile so onboarding and secure backend checkout can continue.
            if (error.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw error
        }
        if (user.displayName.orEmpty() != savedProfile.displayName) {
            user.updateProfile(
                UserProfileChangeRequest.Builder()
                    .setDisplayName(savedProfile.displayName)
                    .build()
            ).await()
        }
    }

    override suspend fun saveProfile(profile: StudentProfile) {
        val user = requireNotNull(auth.currentUser) { "Sign in before saving a profile." }
        require(profile.identityId.value == user.uid) { "A profile can only be saved by its owner." }
        val existing = loadProfile()
        saveAccountProfile(
            AccountProfile(
                uid = user.uid,
                email = user.email.orEmpty(),
                displayName = existing?.displayName ?: user.displayName.orEmpty(),
                countryCode = profile.countryCode,
                schoolLevel = profile.schoolLevel,
                institution = existing?.institution.orEmpty(),
                grade = existing?.grade.orEmpty(),
                curriculum = existing?.curriculum.orEmpty(),
                subjects = profile.subjects.ifEmpty { existing?.subjects.orEmpty() },
                accountType = existing?.accountType ?: "free",
                role = existing?.role.orEmpty(),
                organisation = existing?.organisation.orEmpty(),
                industry = existing?.industry.orEmpty(),
                focusAreas = existing?.focusAreas.orEmpty(),
                onboardingVersion = existing?.onboardingVersion ?: 0,
                onboardingComplete = existing?.onboardingComplete ?: false,
            )
        )
    }

    private fun profileDocument(uid: String) = firestore.collection("users").document(uid)

    private fun cachedProfile(uid: String, email: String, displayName: String): AccountProfile =
        AccountProfile(
            uid = uid,
            email = email,
            displayName = preferences.getString(PROFILE_NAME_KEY + uid, null) ?: displayName,
            countryCode = preferences.getString(PROFILE_COUNTRY_KEY + uid, "").orEmpty(),
            schoolLevel = preferences.getString(PROFILE_LEVEL_KEY + uid, "").orEmpty(),
            institution = preferences.getString(PROFILE_INSTITUTION_KEY + uid, "").orEmpty(),
            grade = preferences.getString(PROFILE_GRADE_KEY + uid, "").orEmpty(),
            curriculum = preferences.getString(PROFILE_CURRICULUM_KEY + uid, "").orEmpty(),
            subjects = preferences.getStringSet(PROFILE_SUBJECTS_KEY + uid, emptySet()).orEmpty().sorted(),
            accountType = preferences.getString(PROFILE_ACCOUNT_TYPE_KEY + uid, "free") ?: "free",
            role = preferences.getString(PROFILE_ROLE_KEY + uid, "").orEmpty(),
            organisation = preferences.getString(PROFILE_ORGANISATION_KEY + uid, "").orEmpty(),
            industry = preferences.getString(PROFILE_INDUSTRY_KEY + uid, "").orEmpty(),
            focusAreas = preferences.getStringSet(PROFILE_FOCUS_KEY + uid, emptySet()).orEmpty().sorted(),
            onboardingVersion = preferences.getInt(PROFILE_ONBOARDING_VERSION_KEY + uid, 0),
            onboardingComplete = preferences.getBoolean(PROFILE_ONBOARDING_KEY + uid, false),
        )

    private fun cacheProfile(profile: AccountProfile) {
        preferences.edit()
            .putString(PROFILE_NAME_KEY + profile.uid, profile.displayName)
            .putString(PROFILE_COUNTRY_KEY + profile.uid, profile.countryCode)
            .putString(PROFILE_LEVEL_KEY + profile.uid, profile.schoolLevel)
            .putString(PROFILE_INSTITUTION_KEY + profile.uid, profile.institution)
            .putString(PROFILE_GRADE_KEY + profile.uid, profile.grade)
            .putString(PROFILE_CURRICULUM_KEY + profile.uid, profile.curriculum)
            .putStringSet(PROFILE_SUBJECTS_KEY + profile.uid, profile.subjects.toSet())
            .putString(PROFILE_ACCOUNT_TYPE_KEY + profile.uid, profile.accountType)
            .putString(PROFILE_ROLE_KEY + profile.uid, profile.role)
            .putString(PROFILE_ORGANISATION_KEY + profile.uid, profile.organisation)
            .putString(PROFILE_INDUSTRY_KEY + profile.uid, profile.industry)
            .putStringSet(PROFILE_FOCUS_KEY + profile.uid, profile.focusAreas.toSet())
            .putInt(PROFILE_ONBOARDING_VERSION_KEY + profile.uid, profile.onboardingVersion)
            .putBoolean(PROFILE_ONBOARDING_KEY + profile.uid, profile.onboardingComplete)
            .apply()
    }

    private companion object {
        const val GUEST_ID_KEY = "guest_identity_id"
        const val PROFILE_NAME_KEY = "profile_name_"
        const val PROFILE_COUNTRY_KEY = "profile_country_"
        const val PROFILE_LEVEL_KEY = "profile_level_"
        const val PROFILE_INSTITUTION_KEY = "profile_institution_"
        const val PROFILE_GRADE_KEY = "profile_grade_"
        const val PROFILE_CURRICULUM_KEY = "profile_curriculum_"
        const val PROFILE_SUBJECTS_KEY = "profile_subjects_"
        const val PROFILE_ACCOUNT_TYPE_KEY = "profile_account_type_"
        const val PROFILE_ROLE_KEY = "profile_role_"
        const val PROFILE_ORGANISATION_KEY = "profile_organisation_"
        const val PROFILE_INDUSTRY_KEY = "profile_industry_"
        const val PROFILE_FOCUS_KEY = "profile_focus_"
        const val PROFILE_ONBOARDING_VERSION_KEY = "profile_onboarding_version_"
        const val PROFILE_ONBOARDING_KEY = "profile_onboarding_"
    }
}
