package com.guru.android.security

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.Connection
import java.util.Date

class HiGuruCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val prefs = getSharedPreferences("higuru_cyber_safety", MODE_PRIVATE)
        val emergencyApproved = prefs.getBoolean("emergency_mode", false)
        val number = callDetails.handle?.schemeSpecificPart.orEmpty()
        val approvedNumbers = prefs.getStringSet("approved_blocked_numbers", emptySet()).orEmpty()
        val userApprovedBlock = approvedNumbers.any { normaliseNumber(it) == normaliseNumber(number) }
        val carrierVerificationFailed = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            callDetails.callerNumberVerificationStatus == Connection.VERIFICATION_STATUS_FAILED

        // A carrier warning raises the risk rating, but never blocks by itself. Automatic rejection
        // requires both Emergency Protection and a number the user approved beforehand.
        val shouldBlock = emergencyApproved && userApprovedBlock
        val responseBuilder = CallResponse.Builder()
            .setDisallowCall(shouldBlock)
            .setRejectCall(shouldBlock)
            .setSkipCallLog(false)
            .setSkipNotification(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            responseBuilder.setSilenceCall(shouldBlock)
        }
        val response = responseBuilder.build()
        respondToCall(callDetails, response)

        val rating = when {
            shouldBlock -> "Critical · approved number blocked"
            carrierVerificationFailed -> "High risk · carrier verification failed"
            else -> "Unrated caller allowed"
        }
        val masked = number.takeLast(4).padStart(number.length.coerceAtMost(12), '*')
        val entry = "${Date()} · Call $masked · $rating"
        val existing = prefs.getStringSet("incident_log", emptySet()).orEmpty()
        prefs.edit().putStringSet("incident_log", (existing + entry).sortedDescending().take(50).toSet()).apply()
    }

    private fun normaliseNumber(value: String): String = value.filter(Char::isDigit).takeLast(12)
}
