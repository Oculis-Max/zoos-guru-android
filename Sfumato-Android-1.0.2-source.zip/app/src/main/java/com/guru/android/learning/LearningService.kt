package com.guru.android.learning

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface LearningService {
    @POST("v1/learning-ai/tutor")
    suspend fun generateTutorSession(
        @Header("Authorization") authorization: String,
        @Body request: TutorSessionRequest,
    ): GeneratedLearningResponse

    @POST("v1/learning-ai/tutor/respond")
    suspend fun continueTutorSession(
        @Header("Authorization") authorization: String,
        @Body request: TutorFollowUpRequest,
    ): GeneratedLearningResponse

    @POST("v1/learning-ai/tutor/finish")
    suspend fun finishTutorSession(
        @Header("Authorization") authorization: String,
        @Body request: TutorFinishRequest,
    ): GeneratedLearningResponse

    @POST("v1/learning-ai/arena")
    suspend fun generateDebateOpening(
        @Header("Authorization") authorization: String,
        @Body request: DebateAttemptRequest,
    ): GeneratedLearningResponse

    @POST("v1/learning-ai/arena/respond")
    suspend fun continueDebate(
        @Header("Authorization") authorization: String,
        @Body request: DebateFollowUpRequest,
    ): GeneratedLearningResponse

    @POST("v1/learning-ai/arena/finish")
    suspend fun judgeDebate(
        @Header("Authorization") authorization: String,
        @Body request: DebateFinishRequest,
    ): GeneratedLearningResponse

    @GET("v1/learning/arena/status")
    suspend fun getArenaStatus(
        @Header("Authorization") authorization: String,
    ): ArenaStatus
}
