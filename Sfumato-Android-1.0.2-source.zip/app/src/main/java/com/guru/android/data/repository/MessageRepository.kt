package com.guru.android.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.guru.android.data.local.Message
import com.guru.android.data.local.MessageDao
import com.guru.android.data.remote.AiService
import com.guru.android.data.remote.BackendConfig
import com.guru.android.data.remote.ChatRequest
import com.guru.android.data.remote.MessagePayload
import com.guru.android.domain.AccountProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessageRepository @Inject constructor(
    private val messageDao: MessageDao,
    private val aiService: AiService,
) {
    private val auth = FirebaseAuth.getInstance()

    fun getAllMessages(): Flow<List<Message>> = messageDao.getAllMessages()

    suspend fun seedWelcomeMessage() {
        val count = messageDao.getAllMessages().firstOrNull()?.size ?: 0
        if (count == 0) {
            messageDao.insertMessage(
                Message(
                    text = "Welcome to Sfumato. Choose a workspace and ask a question, start research, analyse material, or create a draft.",
                    isUser = false,
                    isSynced = true,
                    timestamp = System.currentTimeMillis(),
                )
            )
        }
    }

    suspend fun sendMessage(
        userText: String,
        workspace: String = "General workspace",
        mode: String = "ASK",
        sourceName: String? = null,
        sourceContent: String? = null,
        planTier: String = "free",
        profile: AccountProfile? = null,
    ) {
        val cleanedText = userText.trim().ifBlank {
            if (!sourceContent.isNullOrBlank()) {
                "Please analyse this homework and teach me how to solve it step by step."
            } else {
                return
            }
        }

        messageDao.insertMessage(
            Message(text = cleanedText, isUser = true, isSynced = true)
        )
        val loadingMessage = Message(
            text = when (mode) {
                "RESEARCH" -> "Researching..."
                "ANALYSE" -> "Analysing..."
                "DRAFT" -> "Drafting..."
                else -> "Thinking..."
            },
            isUser = false,
            isSynced = true,
        )
        messageDao.insertMessage(loadingMessage)

        try {
            check(BackendConfig.isConfigured()) {
                "Sfumato backend is not configured"
            }
            val firebaseUser = checkNotNull(auth.currentUser) {
                "Sign in before using online chat"
            }
            val idToken = checkNotNull(
                firebaseUser.getIdToken(false).await().token
            ) {
                "Firebase did not return an ID token"
            }
            val conversation = messageDao.getAllMessages()
                .firstOrNull()
                .orEmpty()
                .filter { message ->
                    !message.isError &&
                        message.text !in setOf("Thinking...", "Researching...", "Analysing...", "Drafting...") &&
                        message.text.isNotBlank()
                }
                .takeLast(20)
                .map { message ->
                    MessagePayload(
                        role = if (message.isUser) "user" else "assistant",
                        content = message.text,
                    )
                }
            val developerWorkspace = workspace.equals("Developer workspace", ignoreCase = true)
            val modeInstruction = if (developerWorkspace) {
                when (mode) {
                    "DRAFT" -> "BUILD MODE: Design the solution and provide complete, runnable code. Label every file path and include setup and verification commands."
                    "ANALYSE" -> "DEBUG MODE: Identify the root cause from the evidence, explain it briefly, and provide the smallest safe fix with exact code changes."
                    "RESEARCH" -> "REVIEW MODE: Review the code for correctness, security, performance, maintainability, and missing tests. Prioritise findings by severity."
                    else -> "AUTONOMOUS CODING MODE: Infer whether the request needs building, debugging, reviewing, or explaining. Produce an execution plan first, then complete copy-ready changes, tests, and verification steps."
                }
            } else {
                when (mode) {
                    "RESEARCH" -> "Research the question. Prefer current, authoritative sources; distinguish facts from inference; and include source names."
                    "ANALYSE" -> "Analyse the material rigorously. Surface assumptions, risks, contradictions, evidence, and practical implications."
                    "DRAFT" -> "Produce a polished professional draft that is ready to use. Use clear labels and preserve any constraints from the user."
                    else -> "Answer directly and accurately. Ask one concise clarifying question only when the missing detail would materially change the answer."
                }
            }
            val cleanedSourceName = sourceName?.trim()?.take(120)
            val cleanedSourceContent = sourceContent?.trim()?.take(6000)
            val sourceInstruction = if (
                !cleanedSourceName.isNullOrBlank() &&
                !cleanedSourceContent.isNullOrBlank()
            ) {
                """
                    The user attached the source "$cleanedSourceName".
                    Ground source-related claims in the content below. Cite it inline as [$cleanedSourceName].
                    If the requested answer is not supported by the source, say what is missing instead of inventing it.
                    <attached_source name="$cleanedSourceName">
                    $cleanedSourceContent
                    </attached_source>
                """.trimIndent()
            } else {
                "No source file is attached to this request."
            }
            val profileInstruction = buildString {
                append("Current plan context for response personalisation: $planTier. ")
                if (profile != null) {
                    append("Chosen account path: ${profile.accountType}. ")
                    append("Education level: ${profile.schoolLevel.ifBlank { "not supplied" }}. ")
                    append("Grade or study year: ${profile.grade.ifBlank { "not supplied" }}. ")
                    append("Curriculum: ${profile.curriculum.ifBlank { "not supplied" }}. ")
                    append("Subjects: ${profile.subjects.joinToString().ifBlank { "not supplied" }}. ")
                    append("Professional role: ${profile.role.ifBlank { "not supplied" }}. ")
                    append("Organisation: ${profile.organisation.ifBlank { "not supplied" }}. ")
                    append("Industry: ${profile.industry.ifBlank { "not supplied" }}. ")
                    append("Focus areas: ${profile.focusAreas.joinToString().ifBlank { "not supplied" }}. ")
                }
                append("For a student, keep explanations, examples and quizzes within the supplied grade/year and curriculum unless the learner explicitly asks to go beyond it. For developers and businesses, use their role, industry and focus areas instead of student framing. Adapt vocabulary, examples, difficulty and recommendations to this context. Do not claim the profile proves ability. This context is not authorization; paid feature access remains enforced by the server.")
            }
            val response = aiService.getChatCompletion(
                firebaseBearerToken = "Bearer $idToken",
                request = ChatRequest(
                    messages = listOf(
                        MessagePayload(
                            role = "system",
                            content = """
                                You are the Sfumato Intelligence Engine, a professional AI work assistant for students, developers, professionals, and organisations.
                                Current workspace: $workspace.
                                Current task mode: $mode.
                                $modeInstruction
                                $sourceInstruction
                                $profileInstruction
                                Give structured, decision-useful answers. Never invent facts or sources. State important uncertainty clearly.
                                In the Developer workspace, act as Sfumato Coding Guru: preserve existing code unless necessary, never expose secrets, never claim code ran when it did not, include relevant tests, and prefer complete copy-ready replacements.
                            """.trimIndent(),
                        )
                    ) + conversation,
                ),
            )
            messageDao.deleteMessage(loadingMessage.id)
            messageDao.insertMessage(
                Message(
                    text = response.message.content,
                    isUser = false,
                    isSynced = true,
                )
            )
        } catch (error: Exception) {
            messageDao.deleteMessage(loadingMessage.id)
            val explanation = when (error) {
                is HttpException -> when (error.code()) {
                    401 -> "Your session expired. Sign out and sign in again."
                    402 -> "AI provider credits are unavailable."
                    429 -> "AI is busy or the free limit was reached. Try again shortly."
                    502, 503 -> "The AI service is temporarily unavailable. Try again shortly."
                    else -> "Sfumato server error (HTTP ${error.code()})."
                }
                is IOException -> "No network connection. Your message was queued."
                else -> error.message ?: "Sfumato could not answer this message."
            }
            messageDao.insertMessage(
                Message(
                    text = "⚠️ $explanation",
                    isUser = false,
                    isSynced = false,
                    isError = true,
                )
            )
        }
    }
}
