package com.guru.android.account

import com.guru.android.domain.AccountProfile

internal enum class StartupRoute {
    LOADING,
    VERIFY_EMAIL,
    ONBOARDING,
    ACCOUNT,
    HOME,
}

internal object OnboardingRules {
    const val CURRENT_VERSION = 2
    val paidPlans = setOf("student", "developer", "business")

    fun needsOnboarding(profile: AccountProfile?): Boolean =
        profile?.onboardingComplete != true || profile.onboardingVersion < CURRENT_VERSION

    fun signedInRoute(
        profileLoaded: Boolean,
        securityLoaded: Boolean,
        isEmailVerified: Boolean,
        profile: AccountProfile?,
        destination: String,
    ): StartupRoute = when {
        !profileLoaded || !securityLoaded -> StartupRoute.LOADING
        !isEmailVerified -> StartupRoute.VERIFY_EMAIL
        needsOnboarding(profile) -> StartupRoute.ONBOARDING
        destination == "account" -> StartupRoute.ACCOUNT
        else -> StartupRoute.HOME
    }

    fun defaultPaidPlanForPath(path: String?): String = when (path) {
        "student" -> "student"
        "developer" -> "developer"
        "business" -> "business"
        else -> ""
    }

    fun canContinueToPayment(selectedPlan: String): Boolean =
        selectedPlan in paidPlans

    fun curriculumForLevel(level: String, curriculum: String): String =
        if (level == "High school") curriculum.trim() else ""

    fun shouldOpenPayment(profile: AccountProfile, activePlan: String, planLoaded: Boolean): Boolean =
        planLoaded && profile.accountType in paidPlans && profile.accountType != activePlan

    fun paymentRouteKey(profile: AccountProfile): String = "${profile.uid}:${profile.accountType}"

    fun validationError(
        plan: String,
        institution: String,
        educationLevel: String,
        grade: String,
        subjects: List<String>,
        role: String,
        organisation: String,
        focusAreas: List<String>,
    ): String? = when {
        plan == "student" && institution.trim().length < 2 -> "Enter your school, college or university."
        plan == "student" && educationLevel.isBlank() -> "Choose your education level."
        plan == "student" && educationLevel == "High school" && grade.isBlank() -> "Enter your current grade."
        plan == "student" && subjects.isEmpty() -> "Add at least one subject, separated by commas."
        plan == "developer" && role.trim().length < 2 -> "Enter your developer role or experience level."
        plan == "business" && organisation.trim().length < 2 -> "Enter your business or organisation name."
        plan != "student" && focusAreas.isEmpty() -> "Add at least one goal or focus area."
        else -> null
    }
}
