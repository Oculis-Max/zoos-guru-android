package com.guru.android.education

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton

data class EducationClass(
    val id: String,
    val name: String,
    val institution: String,
    val level: String,
    @SerializedName("educator_role") val educatorRole: String,
    @SerializedName("join_code") val joinCode: String,
    @SerializedName("owner_uid") val ownerUid: String,
    @SerializedName("educator_email") val educatorEmail: String,
)
data class ClassCreate(
    val name: String,
    val institution: String,
    val level: String,
    @SerializedName("educator_role") val educatorRole: String,
)
data class JoinRequest(@SerializedName("join_code") val joinCode: String)
data class ClassMember(
    val id: String,
    @SerializedName("class_id") val classId: String,
    @SerializedName("student_uid") val studentUid: String,
    @SerializedName("student_email") val studentEmail: String,
    @SerializedName("display_name") val displayName: String,
)
data class AssignmentCreate(
    val title: String,
    val instructions: String,
    @SerializedName("max_score") val maxScore: Int = 100,
)
data class EducationAssignment(
    val id: String,
    @SerializedName("class_id") val classId: String,
    val title: String,
    val instructions: String,
    @SerializedName("max_score") val maxScore: Int,
)
data class SubmissionCreate(val content: String)
data class MarkRequest(val score: Int, val feedback: String)
data class EducationSubmission(
    val id: String,
    @SerializedName("assignment_id") val assignmentId: String,
    @SerializedName("student_email") val studentEmail: String,
    val content: String,
    val status: String,
    val score: Int? = null,
    val feedback: String? = null,
    @SerializedName("ai_suggestion") val aiSuggestion: String? = null,
)
data class AnnouncementCreate(val message: String)
data class EducationAnnouncement(
    val id: String,
    @SerializedName("class_id") val classId: String,
    @SerializedName("author_email") val authorEmail: String,
    val message: String,
)

interface EducationService {
    @GET("v1/education/classes")
    suspend fun classes(@Header("Authorization") token: String): List<EducationClass>
    @POST("v1/education/classes")
    suspend fun createClass(@Header("Authorization") token: String, @Body body: ClassCreate): EducationClass
    @POST("v1/education/classes/join")
    suspend fun join(@Header("Authorization") token: String, @Body body: JoinRequest): ClassMember
    @GET("v1/education/classes/{id}/members")
    suspend fun members(@Header("Authorization") token: String, @Path("id") id: String): List<ClassMember>
    @GET("v1/education/classes/{id}/assignments")
    suspend fun assignments(@Header("Authorization") token: String, @Path("id") id: String): List<EducationAssignment>
    @POST("v1/education/classes/{id}/assignments")
    suspend fun createAssignment(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body body: AssignmentCreate,
    ): EducationAssignment
    @POST("v1/education/assignments/{id}/submit")
    suspend fun submit(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body body: SubmissionCreate,
    ): EducationSubmission
    @GET("v1/education/assignments/{id}/submissions")
    suspend fun submissions(@Header("Authorization") token: String, @Path("id") id: String): List<EducationSubmission>
    @POST("v1/education/submissions/{id}/suggest-mark")
    suspend fun suggestMark(@Header("Authorization") token: String, @Path("id") id: String): EducationSubmission
    @POST("v1/education/submissions/{id}/mark")
    suspend fun mark(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body body: MarkRequest,
    ): EducationSubmission
    @GET("v1/education/classes/{id}/announcements")
    suspend fun announcements(@Header("Authorization") token: String, @Path("id") id: String): List<EducationAnnouncement>
    @POST("v1/education/classes/{id}/announcements")
    suspend fun announce(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body body: AnnouncementCreate,
    ): EducationAnnouncement
}

@Singleton
class EducationRepository @Inject constructor(private val api: EducationService) {
    private suspend fun token(): String {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        return "Bearer " + checkNotNull(user.getIdToken(false).await().token) { "Session expired." }
    }
    suspend fun classes() = api.classes(token())
    suspend fun createClass(value: ClassCreate) = api.createClass(token(), value)
    suspend fun join(code: String) = api.join(token(), JoinRequest(code))
    suspend fun members(id: String) = runCatching { api.members(token(), id) }.getOrDefault(emptyList())
    suspend fun assignments(id: String) = api.assignments(token(), id)
    suspend fun createAssignment(id: String, value: AssignmentCreate) = api.createAssignment(token(), id, value)
    suspend fun submit(id: String, content: String) = api.submit(token(), id, SubmissionCreate(content))
    suspend fun submissions(id: String) = api.submissions(token(), id)
    suspend fun suggestMark(id: String) = api.suggestMark(token(), id)
    suspend fun mark(id: String, score: Int, feedback: String) = api.mark(token(), id, MarkRequest(score, feedback))
    suspend fun announcements(id: String) = api.announcements(token(), id)
    suspend fun announce(id: String, message: String) = api.announce(token(), id, AnnouncementCreate(message))
}

data class EducationState(
    val busy: Boolean = false,
    val classes: List<EducationClass> = emptyList(),
    val selected: EducationClass? = null,
    val members: List<ClassMember> = emptyList(),
    val assignments: List<EducationAssignment> = emptyList(),
    val selectedAssignment: EducationAssignment? = null,
    val submissions: List<EducationSubmission> = emptyList(),
    val announcements: List<EducationAnnouncement> = emptyList(),
    val notice: String? = null,
    val error: String? = null,
)

@HiltViewModel
class EducationViewModel @Inject constructor(private val repository: EducationRepository) : ViewModel() {
    private val data = MutableStateFlow(EducationState())
    val state = data.asStateFlow()

    init { refresh() }

    fun refresh() = execute {
        val classes = repository.classes()
        data.update { it.copy(classes = classes) }
        val current = data.value.selected?.let { selected -> classes.firstOrNull { it.id == selected.id } }
            ?: classes.firstOrNull()
        current?.let { loadClass(it) }
    }

    fun createClass(name: String, institution: String, level: String, role: String) = execute {
        require(name.isNotBlank() && institution.isNotBlank() && level.isNotBlank()) { "Complete the class details." }
        val saved = repository.createClass(ClassCreate(name.trim(), institution.trim(), level.trim(), role))
        data.update { it.copy(classes = listOf(saved) + it.classes, notice = "Class created. Share code " + saved.joinCode) }
        loadClass(saved)
    }

    fun join(code: String) = execute {
        require(code.trim().length >= 6) { "Enter the six-character class code." }
        repository.join(code.trim())
        data.update { it.copy(notice = "Joined successfully.") }
        val classes = repository.classes()
        data.update { it.copy(classes = classes) }
        classes.firstOrNull()?.let { loadClass(it) }
    }

    fun select(value: EducationClass) = execute { loadClass(value) }

    private suspend fun loadClass(value: EducationClass) {
        val members = repository.members(value.id)
        val assignments = repository.assignments(value.id)
        val announcements = repository.announcements(value.id)
        data.update {
            it.copy(
                selected = value,
                members = members,
                assignments = assignments,
                selectedAssignment = null,
                submissions = emptyList(),
                announcements = announcements,
            )
        }
    }

    fun createAssignment(title: String, instructions: String, maxScore: Int) = execute {
        val classroom = checkNotNull(data.value.selected) { "Choose a class." }
        require(title.isNotBlank() && instructions.isNotBlank()) { "Complete the assignment." }
        val saved = repository.createAssignment(classroom.id, AssignmentCreate(title.trim(), instructions.trim(), maxScore))
        data.update { it.copy(assignments = listOf(saved) + it.assignments, notice = "Assignment published.") }
    }

    fun submit(assignment: EducationAssignment, content: String) = execute {
        require(content.isNotBlank()) { "Add your answer or homework text." }
        repository.submit(assignment.id, content.trim())
        data.update { it.copy(notice = "Assignment submitted.") }
    }

    fun review(assignment: EducationAssignment) = execute {
        data.update { it.copy(selectedAssignment = assignment, submissions = repository.submissions(assignment.id)) }
    }

    fun suggest(submission: EducationSubmission) = execute {
        val updated = repository.suggestMark(submission.id)
        data.update { state ->
            state.copy(submissions = state.submissions.map { if (it.id == updated.id) updated else it })
        }
    }

    fun mark(submission: EducationSubmission, score: Int, feedback: String) = execute {
        require(feedback.isNotBlank()) { "Add educator feedback." }
        val updated = repository.mark(submission.id, score, feedback.trim())
        data.update { state ->
            state.copy(
                submissions = state.submissions.map { if (it.id == updated.id) updated else it },
                notice = "Mark approved and released.",
            )
        }
    }

    fun announce(message: String) = execute {
        val classroom = checkNotNull(data.value.selected) { "Choose a class." }
        require(message.isNotBlank()) { "Write an announcement." }
        val saved = repository.announce(classroom.id, message.trim())
        data.update { it.copy(announcements = listOf(saved) + it.announcements, notice = "Announcement posted.") }
    }

    private fun execute(block: suspend () -> Unit) {
        if (data.value.busy) return
        viewModelScope.launch {
            data.update { it.copy(busy = true, error = null, notice = null) }
            try { block() } catch (error: Exception) {
                data.update { it.copy(error = error.message ?: "Education workspace is unavailable.") }
            } finally { data.update { it.copy(busy = false) } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EducationScreen(viewModel: EducationViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    var className by remember { mutableStateOf("") }
    var institution by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("teacher") }
    var joinCode by remember { mutableStateOf("") }
    var assignmentTitle by remember { mutableStateOf("") }
    var instructions by remember { mutableStateOf("") }
    var submissionText by remember { mutableStateOf("") }
    var announcement by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Classes & Courses", style = MaterialTheme.typography.headlineMedium)
        Text("Manage teaching, learning, assignments and announcements in one workspace.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Join with class code", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(joinCode, { joinCode = it.uppercase() }, label = { Text("Class code") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { viewModel.join(joinCode) }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Join class or course")
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Create class or course", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(className, { className = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(institution, { institution = it }, label = { Text("School or institution") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(level, { level = it }, label = { Text("Grade, year or level") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(role == "teacher", { role = "teacher" }, label = { Text("Teacher") })
                    FilterChip(role == "professor", { role = "professor" }, label = { Text("Professor") })
                }
                Button(
                    onClick = { viewModel.createClass(className, institution, level, role) },
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Create workspace") }
            }
        }

        if (state.classes.isNotEmpty()) {
            Text("My classes and courses", style = MaterialTheme.typography.titleLarge)
            state.classes.forEach { classroom ->
                OutlinedButton(onClick = { viewModel.select(classroom) }, modifier = Modifier.fillMaxWidth()) {
                    Text(classroom.name + " · " + classroom.level)
                }
            }
        }

        state.selected?.let { classroom ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text(classroom.name, style = MaterialTheme.typography.titleLarge)
                    Text(classroom.institution + " · " + classroom.level)
                    Text("Join code: " + classroom.joinCode, style = MaterialTheme.typography.headlineSmall)
                    Text(state.members.size.toString() + " learners")
                }
            }

            if (state.members.isNotEmpty()) {
                Text("Roster", style = MaterialTheme.typography.titleLarge)
                state.members.forEach { Text("• " + it.displayName + " · " + it.studentEmail) }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Publish assignment", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(assignmentTitle, { assignmentTitle = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(instructions, { instructions = it }, label = { Text("Instructions") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = { viewModel.createAssignment(assignmentTitle, instructions, 100) },
                        enabled = !state.busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Publish assignment") }
                }
            }

            state.assignments.forEach { assignment ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(assignment.title, style = MaterialTheme.typography.titleLarge)
                        Text(assignment.instructions)
                        Text("Maximum: " + assignment.maxScore)
                        OutlinedTextField(
                            submissionText,
                            { submissionText = it },
                            label = { Text("Student submission") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Button(onClick = { viewModel.submit(assignment, submissionText) }, enabled = !state.busy) {
                            Text("Submit homework")
                        }
                        OutlinedButton(onClick = { viewModel.review(assignment) }, enabled = !state.busy) {
                            Text("Review submissions")
                        }
                    }
                }
            }

            state.selectedAssignment?.let {
                Text("Marking workspace", style = MaterialTheme.typography.titleLarge)
                if (state.submissions.isEmpty()) Text("No submissions yet.")
                state.submissions.forEach { submission ->
                    SubmissionCard(submission, state.busy, viewModel)
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Announcements", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(announcement, { announcement = it }, label = { Text("Announcement") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { viewModel.announce(announcement) }, enabled = !state.busy) {
                        Text("Post announcement")
                    }
                    state.announcements.forEach { Text("• " + it.message) }
                }
            }
        }

        state.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (state.busy) CircularProgressIndicator()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SubmissionCard(
    submission: EducationSubmission,
    busy: Boolean,
    viewModel: EducationViewModel,
) {
    var score by remember(submission.id) { mutableStateOf(submission.score?.toString().orEmpty()) }
    var feedback by remember(submission.id) { mutableStateOf(submission.feedback.orEmpty()) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(submission.studentEmail, style = MaterialTheme.typography.titleMedium)
            Text(submission.content)
            submission.aiSuggestion?.let {
                Text("AI marking suggestion", style = MaterialTheme.typography.titleMedium)
                Text(it)
                Text("Educator approval is still required.", color = MaterialTheme.colorScheme.primary)
            }
            OutlinedButton(onClick = { viewModel.suggest(submission) }, enabled = !busy) {
                Text("Generate AI feedback")
            }
            OutlinedTextField(score, { score = it.filter(Char::isDigit) }, label = { Text("Final score") })
            OutlinedTextField(feedback, { feedback = it }, label = { Text("Educator feedback") }, minLines = 2)
            Button(
                onClick = { viewModel.mark(submission, score.toIntOrNull() ?: 0, feedback) },
                enabled = !busy && score.isNotBlank() && feedback.isNotBlank(),
            ) { Text("Approve and release mark") }
        }
    }
}
