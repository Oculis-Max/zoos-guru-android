package com.guru.android.security

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.guru.android.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Opt-in DNS protection. Only DNS packets addressed to Sfumato's virtual DNS server enter the
 * tunnel; normal app traffic keeps using Android's network stack. Allowed queries are forwarded
 * over authenticated DNS-over-TLS to Cloudflare's malware-blocking resolver. Private DNS and in-app DNS-over-HTTPS can bypass a
 * device VPN DNS setting, so this is a protective layer rather than an antivirus guarantee.
 */
class HiGuruDnsVpnService : VpnService() {
    private var tunnel: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopProtection()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, protectionNotification())
        if (running.compareAndSet(false, true)) startDnsProxy()
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, true).apply()
        return START_STICKY
    }

    private fun startDnsProxy() {
        tunnel = Builder()
            .setSession("Sfumato Cyber Safety")
            .setMtu(1500)
            .addAddress(CLIENT_ADDRESS, 32)
            .addDnsServer(VIRTUAL_DNS)
            .addRoute(VIRTUAL_DNS, 32)
            .setConfigureIntent(
                PendingIntent.getActivity(
                    this,
                    0,
                    Intent(this, SecondLayerProtectionActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                ),
            )
            .establish()

        val descriptor = tunnel ?: run {
            running.set(false)
            stopSelf()
            return
        }
        worker = Thread({ proxyLoop(descriptor) }, "Sfumato-DNS-Protection").apply { start() }
    }

    private fun proxyLoop(descriptor: ParcelFileDescriptor) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val request = parseDnsRequest(buffer, length) ?: continue
                val blocked = isBlocked(request.domain)
                val dnsResponse = if (blocked) {
                    nxdomainResponse(request.payload)
                } else {
                    forwardToProtectedResolver(request.payload) ?: servfailResponse(request.payload)
                }
                output.write(buildIpv4UdpResponse(request, dnsResponse))
                if (blocked) recordBlockedDomain(request.domain)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
        runCatching { input.close() }
        runCatching { output.close() }
    }

    private fun forwardToProtectedResolver(query: ByteArray): ByteArray? {
        val rawSocket = Socket()
        return try {
            // Keep the resolver connection outside the VPN and encrypt every upstream query.
            protect(rawSocket)
            rawSocket.connect(InetSocketAddress(InetAddress.getByName(UPSTREAM_DNS), DNS_TLS_PORT), DNS_TIMEOUT_MS)
            rawSocket.soTimeout = DNS_TIMEOUT_MS
            val tlsFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val socket = tlsFactory
                .createSocket(rawSocket, UPSTREAM_TLS_HOST, DNS_TLS_PORT, true) as SSLSocket
            socket.sslParameters = socket.sslParameters.apply {
                endpointIdentificationAlgorithm = "HTTPS"
            }
            socket.startHandshake()
            DataOutputStream(socket.outputStream).use { output ->
                output.writeShort(query.size)
                output.write(query)
                output.flush()
                DataInputStream(socket.inputStream).use { input ->
                    val length = input.readUnsignedShort()
                    if (length !in 1..MAX_DNS_RESPONSE_BYTES) return null
                    ByteArray(length).also { input.readFully(it) }
                }
            }
        } catch (_: Exception) {
            null
        } finally {
            runCatching { rawSocket.close() }
        }
    }

    private fun isBlocked(domain: String): Boolean {
        val normalised = domain.lowercase(Locale.ROOT).trimEnd('.')
        val userRules = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getStringSet(KEY_BLOCKED_DOMAINS, emptySet())
            .orEmpty()
            .map { it.lowercase(Locale.ROOT).trim().trimStart('.').trimEnd('.') }
            .filter { it.isNotBlank() }
        return userRules.any { normalised == it || normalised.endsWith(".$it") }
    }

    private fun recordBlockedDomain(domain: String) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val entry = "${System.currentTimeMillis()} · Critical · Blocked domain: ${domain.take(160)} · Prevented: Sfumato stopped the DNS lookup. Action: do not retry or open this domain unless you deliberately added it and have independently verified it."
        val existing = prefs.getStringSet(KEY_INCIDENT_LOG, emptySet()).orEmpty()
        prefs.edit().putStringSet(KEY_INCIDENT_LOG, (existing + entry).sortedDescending().take(50).toSet()).apply()
    }

    private fun stopProtection() {
        running.set(false)
        runCatching { tunnel?.close() }
        tunnel = null
        worker?.interrupt()
        worker = null
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopProtection()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopProtection()
        super.onDestroy()
    }

    private fun protectionNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Sfumato device protection is active")
            .setContentText("Encrypted malware-blocking DNS and your approved domain rules are enabled.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    1,
                    Intent(this, SecondLayerProtectionActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                ),
            )
            .addAction(
                0,
                "Stop",
                PendingIntent.getService(
                    this,
                    2,
                    Intent(this, HiGuruDnsVpnService::class.java).setAction(ACTION_STOP),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                ),
            )
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Cyber Safety protection",
                    NotificationManager.IMPORTANCE_LOW,
                ).apply {
                    description = "Shows when Sfumato device DNS protection is running."
                    setShowBadge(false)
                },
            )
        }
    }

    private data class DnsRequest(
        val sourceAddress: ByteArray,
        val destinationAddress: ByteArray,
        val sourcePort: Int,
        val destinationPort: Int,
        val payload: ByteArray,
        val domain: String,
    )

    private fun parseDnsRequest(packet: ByteArray, length: Int): DnsRequest? {
        if (length < 28 || (packet[0].toInt() ushr 4) != 4) return null
        val headerLength = (packet[0].toInt() and 0x0F) * 4
        if (headerLength < 20 || length < headerLength + 8) return null
        if ((packet[6].toInt() and 0x20) != 0 || packet[9].toInt() and 0xFF != 17) return null
        val udpLength = readU16(packet, headerLength + 4)
        if (udpLength < 20 || headerLength + udpLength > length) return null
        val destinationPort = readU16(packet, headerLength + 2)
        if (destinationPort != 53) return null
        val payload = packet.copyOfRange(headerLength + 8, headerLength + udpLength)
        val domain = parseQuestionName(payload) ?: return null
        return DnsRequest(
            sourceAddress = packet.copyOfRange(12, 16),
            destinationAddress = packet.copyOfRange(16, 20),
            sourcePort = readU16(packet, headerLength),
            destinationPort = destinationPort,
            payload = payload,
            domain = domain,
        )
    }

    private fun parseQuestionName(dns: ByteArray): String? {
        if (dns.size < 17 || readU16(dns, 4) < 1) return null
        var index = 12
        val labels = mutableListOf<String>()
        while (index < dns.size) {
            val size = dns[index].toInt() and 0xFF
            if (size == 0) break
            if (size > 63 || index + 1 + size > dns.size) return null
            labels += dns.copyOfRange(index + 1, index + 1 + size).toString(Charsets.US_ASCII)
            index += size + 1
        }
        return labels.joinToString(".").takeIf { it.isNotBlank() }
    }

    private fun nxdomainResponse(query: ByteArray): ByteArray {
        val response = query.copyOf()
        if (response.size >= 12) {
            response[2] = ((response[2].toInt() and 0x7F) or 0x80).toByte()
            response[3] = ((response[3].toInt() and 0xF0) or 0x03).toByte()
            for (index in 6..11) response[index] = 0
        }
        return response
    }

    private fun servfailResponse(query: ByteArray): ByteArray {
        val response = query.copyOf()
        if (response.size >= 12) {
            response[2] = ((response[2].toInt() and 0x7F) or 0x80).toByte()
            response[3] = ((response[3].toInt() and 0xF0) or 0x02).toByte()
            for (index in 6..11) response[index] = 0
        }
        return response
    }

    private fun buildIpv4UdpResponse(request: DnsRequest, dns: ByteArray): ByteArray {
        val udpLength = 8 + dns.size
        val totalLength = 20 + udpLength
        val packet = ByteArray(totalLength)
        val buffer = ByteBuffer.wrap(packet).order(ByteOrder.BIG_ENDIAN)
        buffer.put(0x45.toByte())
        buffer.put(0)
        buffer.putShort(totalLength.toShort())
        buffer.putShort(0)
        buffer.putShort(0x4000.toShort())
        buffer.put(64)
        buffer.put(17)
        buffer.putShort(0)
        buffer.put(request.destinationAddress)
        buffer.put(request.sourceAddress)
        buffer.putShort(request.destinationPort.toShort())
        buffer.putShort(request.sourcePort.toShort())
        buffer.putShort(udpLength.toShort())
        buffer.putShort(0)
        buffer.put(dns)
        writeU16(packet, 10, checksum(packet, 0, 20))
        val udpChecksum = udpChecksum(
            request.destinationAddress,
            request.sourceAddress,
            packet,
            20,
            udpLength,
        )
        writeU16(packet, 26, if (udpChecksum == 0) 0xFFFF else udpChecksum)
        return packet
    }

    private fun udpChecksum(
        source: ByteArray,
        destination: ByteArray,
        packet: ByteArray,
        offset: Int,
        length: Int,
    ): Int {
        var sum = 0L
        fun addWord(high: Int, low: Int) { sum += ((high and 0xFF) shl 8) or (low and 0xFF) }
        for (index in 0 until 4 step 2) addWord(source[index].toInt(), source[index + 1].toInt())
        for (index in 0 until 4 step 2) addWord(destination[index].toInt(), destination[index + 1].toInt())
        addWord(0, 17)
        addWord(length ushr 8, length)
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            addWord(packet[index].toInt(), packet[index + 1].toInt())
            index += 2
        }
        if (index < end) addWord(packet[index].toInt(), 0)
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun checksum(bytes: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var index = offset
        val end = offset + length
        while (index + 1 < end) {
            sum += ((bytes[index].toInt() and 0xFF) shl 8) or (bytes[index + 1].toInt() and 0xFF)
            index += 2
        }
        if (index < end) sum += (bytes[index].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xFF) shl 8) or (bytes[offset + 1].toInt() and 0xFF)

    private fun writeU16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value ushr 8).toByte()
        bytes[offset + 1] = value.toByte()
    }

    companion object {
        const val PREFS = "higuru_cyber_safety"
        const val KEY_ACTIVE = "device_dns_active"
        const val KEY_BLOCKED_DOMAINS = "device_blocked_domains"
        const val KEY_INCIDENT_LOG = "incident_log"
        const val ACTION_STOP = "com.guru.android.security.STOP_DNS_PROTECTION"
        private const val CLIENT_ADDRESS = "10.73.0.1"
        private const val VIRTUAL_DNS = "10.73.0.2"
        private const val UPSTREAM_DNS = "1.1.1.2"
        private const val UPSTREAM_TLS_HOST = "security.cloudflare-dns.com"
        private const val DNS_TLS_PORT = 853
        private const val MAX_DNS_RESPONSE_BYTES = 65535
        private const val CHANNEL_ID = "higuru_cyber_protection"
        private const val NOTIFICATION_ID = 7301
        private const val DNS_TIMEOUT_MS = 3000
    }
}
