package com.guru.android.learning

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LearningUiState(
    val isWorking: Boolean = false,
    val arenaStatus: ArenaStatus = ArenaStatus(),
    val tutorContent: String? = null,
    val tutorTurns: List<TutorTurn> = emptyList(),
    val tutorResult: String? = null,
    val tutorMastery: Int? = null,
    val debateContent: String? = null,
    val debateTurns: List<TutorTurn> = emptyList(),
    val debateResult: String? = null,
    val debateScore: Int? = null,
    val debatePassed: Boolean? = null,
    val notice: String? = null,
    val error: String? = null,
)

@HiltViewModel
class LearningViewModel @Inject constructor(
    private val repository: LearningRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(LearningUiState())
    val state: StateFlow<LearningUiState> = _state.asStateFlow()

    init { refreshArenaStatus() }

    fun startTutor(mode: String, subject: String, topic: String, grade: String?, curriculum: String?) {
        val cleanMode = mode.trim().lowercase(); val cleanSubject = subject.trim(); val cleanTopic = topic.trim()
        if (_state.value.isWorking) return
        if (cleanMode !in setOf("diagnostic", "lesson", "practice", "revision") || cleanSubject.isBlank() || cleanTopic.isBlank()) {
            _state.value = _state.value.copy(error = "Choose a valid mode and enter both a subject and topic.", notice = null); return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(isWorking = true, tutorContent = null, tutorTurns = emptyList(), tutorResult = null, tutorMastery = null, notice = null, error = null)
            runCatching { repository.startTutor(cleanMode, cleanSubject, cleanTopic, grade?.trim()?.takeIf { it.isNotBlank() }, curriculum?.trim()?.takeIf { it.isNotBlank() }) }
                .onSuccess { response -> if (response.content.isBlank()) _state.value = _state.value.copy(isWorking = false, error = "Tutor returned an empty lesson. Please try again.") else _state.value = _state.value.copy(isWorking = false, tutorContent = response.content, tutorTurns = listOf(TutorTurn("tutor", response.content)), notice = "Tutor session ready.") }
                .onFailure { error -> _state.value = _state.value.copy(isWorking = false, error = error.message ?: "Tutor service is unavailable.") }
        }
    }

    fun continueTutor(mode: String, subject: String, topic: String, grade: String?, curriculum: String?, learnerMessage: String) {
        val message = learnerMessage.trim(); val current = _state.value
        if (current.isWorking || current.tutorResult != null || message.isBlank() || current.tutorTurns.isEmpty()) return
        val context = current.tutorTurns.joinToString("\n\n") { "${it.role.uppercase()}: ${it.content}" }.takeLast(12_000)
        _state.value = current.copy(isWorking = true, tutorTurns = current.tutorTurns + TutorTurn("learner", message), notice = null, error = null)
        viewModelScope.launch {
            runCatching { repository.continueTutor(mode.trim().lowercase(), subject.trim(), topic.trim(), grade?.trim()?.takeIf { it.isNotBlank() }, curriculum?.trim()?.takeIf { it.isNotBlank() }, context, message) }
                .onSuccess { response -> if (response.content.isBlank()) _state.value = _state.value.copy(isWorking = false, error = "Tutor returned an empty reply. Please try again.") else _state.value = _state.value.copy(isWorking = false, tutorContent = response.content, tutorTurns = _state.value.tutorTurns + TutorTurn("tutor", response.content)) }
                .onFailure { error -> _state.value = _state.value.copy(isWorking = false, error = error.message ?: "Tutor could not continue this session.") }
        }
    }

    fun finishTutor(mode: String, subject: String, topic: String, grade: String?, curriculum: String?) {
        val current = _state.value
        if (current.isWorking || current.tutorResult != null || current.tutorTurns.count { it.role == "learner" } < 1) return
        val context = current.tutorTurns.joinToString("\n\n") { it.role.uppercase() + ": " + it.content }.takeLast(16_000)
        _state.value = current.copy(isWorking = true, notice = null, error = null)
        viewModelScope.launch {
            runCatching { repository.finishTutor(mode.trim().lowercase(), subject.trim(), topic.trim(), grade?.trim()?.takeIf { it.isNotBlank() }, curriculum?.trim()?.takeIf { it.isNotBlank() }, context) }
                .onSuccess { response -> _state.value = _state.value.copy(isWorking = false, tutorResult = response.content, tutorMastery = response.score?.coerceIn(0, 100), notice = if (response.passed == true) "Topic mastered. Your result is saved." else "Progress saved. Follow the next study plan and try again.") }
                .onFailure { error -> _state.value = _state.value.copy(isWorking = false, error = error.message ?: "Tutor assessment is unavailable.") }
        }
    }

    fun resetTutor() { if (!_state.value.isWorking) _state.value = _state.value.copy(tutorContent = null, tutorTurns = emptyList(), tutorResult = null, tutorMastery = null, notice = null, error = null) }

    fun startDebate(topic: String, stage: Int, position: String) {
        val cleanTopic = topic.trim(); val cleanPosition = position.trim().lowercase(); val current = _state.value
        if (current.isWorking || current.debateTurns.isNotEmpty()) return
        if (cleanTopic.length < 3 || stage !in 1..5 || stage > current.arenaStatus.highestUnlockedStage || cleanPosition !in setOf("for", "against")) {
            _state.value = current.copy(error = "Choose an unlocked stage, a side, and a valid debate topic.", notice = null); return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(isWorking = true, debateContent = null, debateTurns = emptyList(), debateResult = null, debateScore = null, debatePassed = null, notice = null, error = null)
            runCatching { repository.startDebate(cleanTopic, stage, cleanPosition) }
                .onSuccess { response -> if (response.content.isBlank()) _state.value = _state.value.copy(isWorking = false, error = "Enoch returned an empty opening. Please try again.") else _state.value = _state.value.copy(isWorking = false, debateContent = response.content, debateTurns = listOf(TutorTurn("opponent", response.content)), notice = "Your AI opponent is ready.") }
                .onFailure { error -> _state.value = _state.value.copy(isWorking = false, error = error.message ?: "Debate service is unavailable.") }
        }
    }

    fun continueDebate(topic: String, stage: Int, position: String, learnerArgument: String) {
        val argument = learnerArgument.trim(); val cleanTopic = topic.trim(); val cleanPosition = position.trim().lowercase(); val current = _state.value
        if (current.isWorking || current.debateResult != null || argument.isBlank() || cleanTopic.isBlank() || stage !in 1..5 || cleanPosition !in setOf("for", "against") || current.debateTurns.isEmpty()) return
        val context = current.debateTurns.joinToString("\n\n") { "${it.role.uppercase()}: ${it.content}" }.takeLast(12_000)
        _state.value = current.copy(isWorking = true, debateTurns = current.debateTurns + TutorTurn("learner", argument), notice = null, error = null)
        viewModelScope.launch {
            runCatching { repository.continueDebate(cleanTopic, stage, cleanPosition, context, argument) }
                .onSuccess { response -> if (response.content.isBlank()) _state.value = _state.value.copy(isWorking = false, error = "Enoch returned an empty reply. Your argument is preserved; please try again.") else _state.value = _state.value.copy(isWorking = false, debateContent = response.content, debateTurns = _state.value.debateTurns + TutorTurn("opponent", response.content)) }
                .onFailure { error -> _state.value = _state.value.copy(isWorking = false, error = error.message ?: "The opponent could not answer right now.") }
        }
    }

    fun recordLiveDebateTurn(role: String, content: String) {
        val cleanRole = role.trim().lowercase(); val cleanContent = content.trim(); val current = _state.value
        if (cleanRole !in setOf("learner", "opponent") || cleanContent.isBlank() || current.isWorking || current.debateResult != null || current.debateTurns.isEmpty()) return
        val last = current.debateTurns.lastOrNull()
        if (last?.role == cleanRole && last.content.trim() == cleanContent) return
        _state.value = current.copy(debateTurns = current.debateTurns + TutorTurn(cleanRole, cleanContent), debateContent = if (cleanRole == "opponent") cleanContent else current.debateContent, notice = null, error = null)
    }

    fun finishDebate(topic: String, stage: Int, position: String) {
        val current = _state.value; val cleanTopic = topic.trim(); val cleanPosition = position.trim().lowercase()
        if (current.isWorking || current.debateResult != null || cleanTopic.isBlank() || stage !in 1..5 || cleanPosition !in setOf("for", "against") || current.debateTurns.count { it.role == "learner" } < 2) return
        val context = current.debateTurns.joinToString("\n\n") { "${it.role.uppercase()}: ${it.content}" }.takeLast(16_000)
        _state.value = current.copy(isWorking = true, notice = null, error = null)
        viewModelScope.launch {
            runCatching { repository.judgeDebate(cleanTopic, stage, cleanPosition, context) }
                .onSuccess { response ->
                    if (response.content.isBlank()) { _state.value = _state.value.copy(isWorking = false, error = "The judge returned an empty result. Please try judging again."); return@onSuccess }
                    val score = response.score?.coerceIn(0, 100); val s = _state.value.arenaStatus
                    val updated = s.copy(highestUnlockedStage = (response.highestUnlockedStage ?: s.highestUnlockedStage).coerceIn(1, 5), bestDebateScore = maxOf(s.bestDebateScore, score ?: 0), overallHiGuruScore = maxOf(s.overallHiGuruScore, ((score ?: 0) * 0.85).toInt()))
                    _state.value = _state.value.copy(isWorking = false, debateResult = response.content, debateScore = score, debatePassed = response.passed, arenaStatus = updated, notice = if (response.passed == true) "Stage passed. Your Arena progress is saved." else "Result saved. Strengthen your case and try again.")
                    refreshArenaStatus()
                }
                .onFailure { error -> _state.value = _state.value.copy(isWorking = false, error = error.message ?: "The judge is unavailable right now.") }
        }
    }

    fun resetDebate() { if (!_state.value.isWorking) _state.value = _state.value.copy(debateContent = null, debateTurns = emptyList(), debateResult = null, debateScore = null, debatePassed = null, notice = null, error = null) }
    fun refreshArenaStatus() { viewModelScope.launch { runCatching { repository.arenaStatus() }.onSuccess { _state.value = _state.value.copy(arenaStatus = it.copy(highestUnlockedStage = it.highestUnlockedStage.coerceIn(1, 5), bestDebateScore = it.bestDebateScore.coerceIn(0, 100))) }.onFailure { /* status refresh is non-fatal */ } } }
    fun clearMessage() { _state.value = _state.value.copy(notice = null, error = null) }
}