package com.guru.android.ui.chat

import android.Manifest
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.Locale
import com.guru.android.data.local.Message
import com.guru.android.homework.HomeworkAttachmentButton
import com.guru.android.domain.AccountProfile

private val workspaces = listOf(
    "General workspace",
    "Legal matter",
    "Business project",
    "Developer workspace",
    "Study workspace",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    onAccountClick: () -> Unit = {},
    onMenuClick: () -> Unit = {},
    onQuickAction: (String) -> Unit = {},
    initialWorkspace: String = workspaces.first(),
    planTier: String = "free",
    profile: AccountProfile? = null,
    viewModel: ChatViewModel = hiltViewModel(),
) {
    val messages by viewModel.messages.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val listState = rememberLazyListState()
    var textInput by remember { mutableStateOf("") }
    var workspace by remember(initialWorkspace) { mutableStateOf(initialWorkspace) }
    var workspaceMenuOpen by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(AssistantMode.ASK) }
    var sourceName by remember { mutableStateOf<String?>(null) }
    var sourceContent by remember { mutableStateOf<String?>(null) }
    var sourceError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val suggestions = remember(planTier, profile) { personalisedSuggestions(planTier, profile) }
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) textInput = spoken
        }
    }
    val launchSpeech = {
        speechLauncher.launch(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Sfumato")
            }
        )
    }
    val microphonePermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) launchSpeech()
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .height(72.dp)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Surface(
                        modifier = Modifier.size(56.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.outline,
                        ),
                    ) {
                        IconButton(onClick = onMenuClick) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = "Open navigation",
                                tint = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.Center,
                    ) {
                        TextButton(onClick = { workspaceMenuOpen = true }) {
                            Text(
                                text = workspace
                                    .removeSuffix(" workspace")
                                    .removeSuffix(" project")
                                    .removeSuffix(" matter"),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                        MaterialTheme(
                            colorScheme = MaterialTheme.colorScheme.copy(
                                surface = MaterialTheme.colorScheme.surfaceVariant,
                            ),
                        ) {
                            DropdownMenu(
                                expanded = workspaceMenuOpen,
                                onDismissRequest = { workspaceMenuOpen = false },
                            ) {
                            workspaces.forEach { option ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            option,
                                            color = if (option == workspace) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.onSurface
                                            },
                                        )
                                    },
                                    onClick = {
                                        workspace = option
                                        workspaceMenuOpen = false
                                    },
                                )
                            }
                        }
                        }
                    }
                    if (!isOnline) {
                        Icon(
                            Icons.Default.WifiOff,
                            contentDescription = "Offline",
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.outline,
                        ),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    textInput = ""
                                    sourceName = null
                                    sourceContent = null
                                    sourceError = null
                                },
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = "Start a new message",
                                )
                            }
                            IconButton(onClick = onAccountClick) {
                                Icon(
                                    Icons.Default.MoreVert,
                                    contentDescription = "Account and more",
                                )
                            }
                        }
                    }
                }
                if (!isOnline) {
                    Text(
                        text = "Offline — messages will resume when connected",
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                sourceName?.let { name ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(name, modifier = Modifier.weight(1f), maxLines = 1)
                            TextButton(
                                onClick = {
                                    sourceName = null
                                    sourceContent = null
                                },
                            ) { Text("Remove") }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                sourceError?.let { error ->
                    Text(
                        error,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                    Spacer(Modifier.height(4.dp))
                }
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(32.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    tonalElevation = 3.dp,
                    shadowElevation = 8.dp,
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        HomeworkAttachmentButton(
                            onLoaded = { source ->
                                sourceName = source.name
                                sourceContent = source.text
                                sourceError = null
                            },
                            onError = { message ->
                                sourceName = null
                                sourceContent = null
                                sourceError = message
                            },
                        )
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            modifier = Modifier.weight(1f),
                            placeholder = {
                                Text(
                                    if (workspace == "Developer workspace") {
                                        "Give Coding Guru a task…"
                                    } else {
                                        "Follow up"
                                    }
                                )
                            },
                            maxLines = 5,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                            ),
                        )
                        IconButton(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO,
                                    ) == PackageManager.PERMISSION_GRANTED
                                ) {
                                    launchSpeech()
                                } else {
                                    microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Speak")
                        }
                        FilledIconButton(
                            onClick = {
                                viewModel.sendMessage(
                                    text = textInput,
                                    workspace = workspace,
                                    mode = mode,
                                    sourceName = sourceName,
                                    sourceContent = sourceContent,
                                    planTier = planTier,
                                    profile = profile,
                                )
                                textInput = ""
                                sourceName = null
                                sourceContent = null
                            },
                            enabled = textInput.isNotBlank() || !sourceContent.isNullOrBlank(),
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send")
                        }
                    }
                }
            }
        },
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 22.dp, vertical = 8.dp),
            state = listState,
            contentPadding = PaddingValues(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillParentMaxHeight(0.72f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Text(
                                text = "H",
                                modifier = Modifier.padding(horizontal = 22.dp, vertical = 14.dp),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Spacer(Modifier.height(22.dp))
                        Text(
                            text = "What would you like to do today?",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Medium,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Ask a question or choose a Guru below.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            if (messages.none { it.isUser }) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        val learningContext = listOfNotNull(
                            profile?.grade?.takeIf(String::isNotBlank),
                            profile?.schoolLevel?.takeIf(String::isNotBlank),
                        ).joinToString(" · ")
                        Text(
                            if (learningContext.isBlank()) "Suggestions for your ${planTitle(planTier)} plan"
                            else "$learningContext suggestions",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(suggestions) { suggestion ->
                                SuggestionChip(
                                    onClick = { textInput = suggestion },
                                    label = { Text(suggestion, maxLines = 2) },
                                )
                            }
                        }
                    }
                }
            }
            items(messages, key = { it.id }) { message ->
                if (!message.isUser && message.text in chatThinkingStates) {
                    AnimatedThinkingIndicator(message.text)
                } else {
                    MessageBubble(message = message)
                }
            }
        }
    }
}

private val chatThinkingStates = setOf(
    "Thinking...",
    "Researching...",
    "Analysing...",
    "Drafting...",
)

@Composable
private fun AnimatedThinkingIndicator(state: String) {
    val motion = rememberInfiniteTransition(label = "Sfumato thinking")
    val scale by motion.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "Thinking emoji pulse",
    )
    val lift by motion.animateFloat(
        initialValue = 3f,
        targetValue = -7f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "Thinking emoji float",
    )
    val tilt by motion.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "Thinking emoji tilt",
    )
    val label = when (state) {
        "Researching..." -> "Sfumato is researching"
        "Analysing..." -> "Sfumato is analysing"
        "Drafting..." -> "Sfumato is drafting"
        else -> "Sfumato is thinking"
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = "🤔",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationY = lift
                    rotationZ = tilt
                },
            )
            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    text = "Working on your answer…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                )
            }
        }
    }
}

private fun personalisedSuggestions(planTier: String, profile: AccountProfile?): List<String> {
    val subject = profile?.subjects?.firstOrNull().orEmpty()
    val level = profile?.grade?.ifBlank { profile.schoolLevel }.orEmpty()
    val personalisedTier = if (planTier == "free") profile?.accountType ?: planTier else planTier
    return when (personalisedTier) {
        "student" -> listOf(
            "Create a $level ${subject.ifBlank { "study" }} quiz and explain every answer",
            "Make a weekly study plan for ${profile?.subjects?.joinToString().orEmpty().ifBlank { "my subjects" }}",
            "Teach me the hardest $subject topic at my level, step by step",
            "Help me prepare for my next $level test",
        )
        "developer" -> listOf(
            "Review my code and identify the highest-risk bug",
            "Plan and build a production-ready feature with tests",
            "Explain this architecture and suggest improvements",
            "Help me debug an error step by step",
        )
        "business" -> listOf(
            "Summarise today's priorities and recommended actions",
            "Draft a professional proposal for my business",
            "Analyse a business risk and create a mitigation plan",
            "Prepare an executive decision brief",
        )
        else -> if (profile?.schoolLevel?.isNotBlank() == true) listOf(
            "Explain a $subject topic at $level level",
            "Give me a short $subject practice quiz",
            "Help me plan today's homework",
            "Teach me one concept step by step",
        ) else listOf(
            "Explain a difficult topic simply",
            "Help me plan my day",
            "Summarise information I provide",
            "Draft a clear professional message",
        )
    }
}

private fun planTitle(tier: String): String = when (tier) {
    "student" -> "Student Pro"
    "developer" -> "Developer"
    "business" -> "Business"
    else -> "Free"
}

@Composable
fun MessageBubble(message: Message) {
    val isUser = message.isUser
    val clipboard = LocalClipboardManager.current
    val displayText = cleanChatText(message.text)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        if (isUser) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth(0.82f),
            ) {
                Text(
                    text = displayText,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        } else {
            Text(
                text = displayText,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.bodyLarge,
            )
            if (!message.isError && !displayText.endsWith("...")) {
                TextButton(
                    onClick = { clipboard.setText(AnnotatedString(displayText)) },
                    contentPadding = PaddingValues(horizontal = 2.dp),
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy AI answer")
                    Spacer(Modifier.width(6.dp))
                    Text("Copy")
                }
            }
        }
        if (message.isError) {
            Text(
                text = if (message.text.contains("network", ignoreCase = true)) {
                    "Queued for retry"
                } else {
                    "Could not complete"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(vertical = 2.dp),
            )
        }
    }
}

private fun cleanChatText(content: String): String =
    content
        .replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        .replace("**", "")
        .replace("__", "")
        .replace(Regex("\\n{3,}"), "\\n\\n")
        .trim()
