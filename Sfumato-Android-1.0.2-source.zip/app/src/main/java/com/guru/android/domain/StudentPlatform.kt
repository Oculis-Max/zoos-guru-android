package com.guru.android.domain

import java.time.LocalDate
import kotlinx.coroutines.flow.StateFlow

@JvmInline
value class IdentityId(val value: String)

data class GuestIdentity(
    val id: IdentityId,
    val localOnly: Boolean = true,
)

data class StudentProfile(
    val identityId: IdentityId,
    val countryCode: String,
    val schoolLevel: String,
    val subjects: List<String> = emptyList(),
    val careerInterests: List<String> = emptyList(),
)

data class AccountUser(
    val uid: String,
    val email: String,
    val displayName: String,
)

sealed interface AccountSession {
    data object Loading : AccountSession
    data object SignedOut : AccountSession
    data class SignedIn(val user: AccountUser) : AccountSession
}

data class AccountProfile(
    val uid: String,
    val email: String,
    val displayName: String,
    val countryCode: String = "",
    val schoolLevel: String = "",
    val institution: String = "",
    val grade: String = "",
    val curriculum: String = "",
    val subjects: List<String> = emptyList(),
    val accountType: String = "free",
    val role: String = "",
    val organisation: String = "",
    val industry: String = "",
    val focusAreas: List<String> = emptyList(),
    val onboardingVersion: Int = 0,
    val onboardingComplete: Boolean = false,
)

data class ScholarshipSummary(
    val id: String,
    val title: String,
    val provider: String,
    val deadline: LocalDate,
)

enum class ApplicationStatus { DISCOVERED, ELIGIBLE, PREPARING, SUBMITTED, RESULT }

data class MatchFactor(val label: String, val weight: Int, val earned: Int, val explanation: String)
data class ScholarshipMatch(val score: Int, val factors: List<MatchFactor>, val disclaimer: String)

interface AccountRepository {
    val session: StateFlow<AccountSession>

    suspend fun currentGuest(): GuestIdentity
    suspend fun createAccount(email: String, password: String, displayName: String)
    suspend fun signIn(email: String, password: String)
    suspend fun signOut()
    suspend fun sendPasswordReset(email: String)
    suspend fun loadProfile(): AccountProfile?
    suspend fun saveAccountProfile(profile: AccountProfile)
    suspend fun saveProfile(profile: StudentProfile)
}

interface ScholarshipRepository {
    suspend fun search(countryCode: String?, schoolLevel: String?, subject: String?): List<ScholarshipSummary>
    suspend fun match(identityId: IdentityId, scholarshipId: String): ScholarshipMatch
    suspend fun bookmark(identityId: IdentityId, scholarshipId: String, bookmarked: Boolean)
    suspend fun updateStatus(identityId: IdentityId, scholarshipId: String, status: ApplicationStatus)
}
