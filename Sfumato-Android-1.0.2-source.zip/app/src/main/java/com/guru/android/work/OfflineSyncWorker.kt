package com.guru.android.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.auth.FirebaseAuth
import com.guru.android.data.local.Message
import com.guru.android.data.local.MessageDao
import com.guru.android.data.remote.AiService
import com.guru.android.data.remote.ChatRequest
import com.guru.android.data.remote.MessagePayload
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.tasks.await

@HiltWorker
class OfflineSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val messageDao: MessageDao,
    private val aiService: AiService
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val unsyncedMessages = messageDao.getUnsyncedMessages()

        if (unsyncedMessages.isEmpty()) {
            return Result.success()
        }

        val user = FirebaseAuth.getInstance().currentUser ?: return Result.retry()
        val idToken = user.getIdToken(false).await().token ?: return Result.retry()
        val authorization = "Bearer $idToken"

        for (message in unsyncedMessages) {
            try {
                val request = ChatRequest(
                    messages = listOf(
                        MessagePayload(role = "system", content = "You are Sfumato, a helpful AI tutor."),
                        MessagePayload(role = "user", content = message.text)
                    )
                )

                val response = aiService.getChatCompletion(
                    firebaseBearerToken = authorization,
                    request = request
                )

                val aiText = response.message.content.ifBlank {
                    "Sorry, I couldn't process that."
                }

                messageDao.updateMessageStatus(message.id, isSynced = true, isError = false)

                val aiMessage = Message(
                    text = aiText,
                    isUser = false,
                    isSynced = true,
                    timestamp = System.currentTimeMillis()
                )
                messageDao.insertMessage(aiMessage)
            } catch (_: Exception) {
                messageDao.updateMessageStatus(message.id, isSynced = false, isError = true)
                return Result.retry()
            }
        }

        return Result.success()
    }
}
