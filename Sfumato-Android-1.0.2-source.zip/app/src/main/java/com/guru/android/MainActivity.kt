package com.guru.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.guru.android.account.HiGuruAccountApp
import com.guru.android.data.remote.BackendConfig
import dagger.hilt.android.AndroidEntryPoint
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        prewarmBackend()
        setContent {
            MaterialTheme(colorScheme = HiGuruDarkColors) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HiGuruAccountApp()
                }
            }
        }
    }

    private fun prewarmBackend() {
        val request = Request.Builder().url("${BackendConfig.baseUrl()}health").get().build()
        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) = Unit
            override fun onResponse(call: Call, response: Response) { response.close() }
        })
    }
}

private val HiGuruDarkColors = darkColorScheme(
    primary = Color(0xFFD7FF3F),
    onPrimary = Color(0xFF0A0A0A),
    primaryContainer = Color(0xFF29320D),
    onPrimaryContainer = Color(0xFFE9FFA1),
    secondary = Color(0xFFC7E83B),
    onSecondary = Color(0xFF101400),
    secondaryContainer = Color(0xFF242713),
    onSecondaryContainer = Color(0xFFE7F5AD),
    background = Color(0xFF050505),
    onBackground = Color(0xFFF7F7F4),
    surface = Color(0xFF0A0A0A),
    onSurface = Color(0xFFF7F7F4),
    surfaceVariant = Color(0xFF222222),
    onSurfaceVariant = Color(0xFFB7B7B2),
    outline = Color(0xFF454545),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF4A1F24),
    onErrorContainer = Color(0xFFFFDADD),
)
