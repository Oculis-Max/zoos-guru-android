package com.guru.android.security

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.JsonParser
import com.guru.android.data.remote.BackendConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

private data class ProtectedDevice(
    val id: String,
    val name: String,
    val enabled: Boolean,
    val thisDevice: Boolean,
)

class RemoteDeviceProtectionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                RemoteDeviceProtectionScreen(onBack = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemoteDeviceProtectionScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val policyManager = remember { context.getSystemService(DevicePolicyManager::class.java) }
    val admin = remember { ComponentName(context, HiGuruDeviceAdminReceiver::class.java) }
    var adminActive by remember { mutableStateOf(policyManager.isAdminActive(admin)) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var devices by remember { mutableStateOf<List<ProtectedDevice>>(emptyList()) }
    var pendingLock by remember { mutableStateOf<ProtectedDevice?>(null) }
    var pendingRemoval by remember { mutableStateOf<ProtectedDevice?>(null) }

    val adminLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        adminActive = policyManager.isAdminActive(admin)
        if (adminActive) refresh++
    }

    LaunchedEffect(refresh, adminActive) {
        if (!adminActive) return@LaunchedEffect
        busy = true
        val result = runCatching {
            registerCurrentDevice(context)
            scheduleRemoteLockPolling(context)
            fetchProtectedDevices(context)
        }
        result.onSuccess {
            devices = it
            message = "Remote Lock is ready."
        }.onFailure {
            message = it.message ?: "Remote Lock could not connect."
        }
        busy = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Remote Lock") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
                shape = RoundedCornerShape(18.dp),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.Lock, null, tint = Color(0xFF69E69A))
                    Text("Protect a lost or stolen phone", fontWeight = FontWeight.Bold)
                    Text(
                        "Enable this once on every phone you want to protect. From another signed-in device, select the missing phone and send an expiring lock command.",
                        color = Color(0xFFB3BDC7),
                    )
                    if (!adminActive) {
                        Button(
                            onClick = {
                                adminLauncher.launch(
                                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                                        putExtra(
                                            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                            "Allows Sfumato to lock this phone only after you enable Remote Lock.",
                                        )
                                    },
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Enable Remote Lock on this phone") }
                    } else {
                        Text("Administrator permission enabled", color = Color(0xFF69E69A))
                        OutlinedButton(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) {
                            Text("Refresh my devices")
                        }
                    }
                }
            }

            message?.let { Text(it, color = if (it.contains("ready")) Color(0xFF69E69A) else Color(0xFFFFC857)) }
            if (busy) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }

            if (adminActive) {
                Text("My protected devices", fontWeight = FontWeight.Bold)
                devices.forEach { device ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(device.name, fontWeight = FontWeight.Bold)
                                Text(
                                    when {
                                        device.thisDevice -> "This phone"
                                        device.enabled -> "Remote Lock ready"
                                        else -> "Remote Lock unavailable"
                                    },
                                    color = Color(0xFFB3BDC7),
                                )
                            }
                            if (!device.thisDevice) {
                                Column(horizontalAlignment = Alignment.End) {
                                    if (device.enabled) {
                                        Button(onClick = { pendingLock = device }) { Text("Lock") }
                                    }
                                    OutlinedButton(onClick = { pendingRemoval = device }) {
                                        Text("Remove")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Text(
                "Sfumato never wipes the phone. Commands expire after 15 minutes and the missing phone must reconnect to the internet. Google Find Hub remains the backup if Sfumato was removed.",
                color = Color(0xFFFFC857),
            )
        }
    }

    pendingLock?.let { device ->
        AlertDialog(
            onDismissRequest = { pendingLock = null },
            title = { Text("Lock ${device.name}?") },
            text = { Text("The entire phone will lock when it receives this command. You may be asked to sign in again for security.") },
            confirmButton = {
                Button(onClick = {
                    pendingLock = null
                    busy = true
                    message = null
                    kotlinx.coroutines.CoroutineScope(Dispatchers.Main).launch {
                        val result = runCatching { sendRemoteLock(context, device.id) }
                        message = result.fold(
                            onSuccess = { "Lock command sent. It expires in 15 minutes." },
                            onFailure = { it.message ?: "Lock command failed." },
                        )
                        busy = false
                    }
                }) { Text("Lock phone") }
            },
            dismissButton = { OutlinedButton(onClick = { pendingLock = null }) { Text("Cancel") } },
        )
    }

    pendingRemoval?.let { device ->
        AlertDialog(
            onDismissRequest = { pendingRemoval = null },
            title = { Text("Remove ${device.name}?") },
            text = { Text("Sfumato will revoke this phone's Remote Lock registration and delete its pending lock commands. This does not erase or change the phone.") },
            confirmButton = {
                Button(onClick = {
                    pendingRemoval = null
                    busy = true
                    message = null
                    kotlinx.coroutines.CoroutineScope(Dispatchers.Main).launch {
                        val result = runCatching { removeRemoteDevice(device.id) }
                        result.onSuccess {
                            devices = devices.filterNot { it.id == device.id }
                            message = "Protected device removed."
                        }.onFailure {
                            message = it.message ?: "Device removal failed."
                        }
                        busy = false
                    }
                }) { Text("Remove device") }
            },
            dismissButton = { OutlinedButton(onClick = { pendingRemoval = null }) { Text("Cancel") } },
        )
    }
}

private suspend fun credentials(): Pair<String, String> {
    val user = FirebaseAuth.getInstance().currentUser ?: error("Sign in to Sfumato first.")
    val token = user.getIdToken(false).await().token ?: error("Secure session unavailable.")
    return user.uid to token
}

private suspend fun registerCurrentDevice(context: Context) = withContext(Dispatchers.IO) {
    val (_, token) = credentials()
    val prefs = RemoteLockPreferences(context)
    val fcmToken = FirebaseMessaging.getInstance().token.await()
    val json = """{"device_id":"${prefs.deviceId}","name":${jsonString(prefs.deviceName)},"platform":"android","fcm_token":${jsonString(fcmToken)},"remote_lock_enabled":true}"""
    val request = Request.Builder()
        .url("${BackendConfig.baseUrl()}v1/device-protection/devices")
        .header("Authorization", "Bearer $token")
        .post(json.toRequestBody("application/json".toMediaType()))
        .build()
    OkHttpClient().newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) error(apiMessage(response.code, body))
        prefs.deviceSecret = JsonParser.parseString(body).asJsonObject.get("device_secret").asString
    }
}

private suspend fun fetchProtectedDevices(context: Context): List<ProtectedDevice> = withContext(Dispatchers.IO) {
    val (_, token) = credentials()
    val prefs = RemoteLockPreferences(context)
    val request = Request.Builder()
        .url("${BackendConfig.baseUrl()}v1/device-protection/devices")
        .header("Authorization", "Bearer $token")
        .header("X-Sfumato-Device-Id", prefs.deviceId)
        .get()
        .build()
    OkHttpClient().newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) error(apiMessage(response.code, body))
        JsonParser.parseString(body).asJsonArray.map { element ->
            val item = element.asJsonObject
            ProtectedDevice(
                id = item.get("id").asString,
                name = item.get("name").asString,
                enabled = item.get("remote_lock_enabled")?.asBoolean == true,
                thisDevice = item.get("this_device")?.asBoolean == true,
            )
        }
    }
}

private suspend fun sendRemoteLock(context: Context, deviceId: String) = withContext(Dispatchers.IO) {
    val (_, token) = credentials()
    val json = """{"reason":"Owner reported this phone lost or stolen"}"""
    val request = Request.Builder()
        .url("${BackendConfig.baseUrl()}v1/device-protection/devices/$deviceId/lock")
        .header("Authorization", "Bearer $token")
        .post(json.toRequestBody("application/json".toMediaType()))
        .build()
    OkHttpClient().newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) error(apiMessage(response.code, body))
    }
}

private suspend fun removeRemoteDevice(deviceId: String) = withContext(Dispatchers.IO) {
    val (_, token) = credentials()
    val request = Request.Builder()
        .url("${BackendConfig.baseUrl()}v1/device-protection/devices/$deviceId")
        .header("Authorization", "Bearer $token")
        .delete()
        .build()
    OkHttpClient().newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) error(apiMessage(response.code, body))
    }
}

private fun apiMessage(code: Int, body: String): String {
    if (code == 403 && body.contains("recent_authentication_required")) {
        return "For security, sign out and sign back in before sending a remote lock."
    }
    return "Remote Lock request failed ($code)."
}

private fun jsonString(value: String): String =
    com.google.gson.Gson().toJson(value)

private fun scheduleRemoteLockPolling(context: Context) {
    val request = PeriodicWorkRequestBuilder<RemoteLockWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        RemoteLockWorker.UNIQUE_PERIODIC_WORK,
        ExistingPeriodicWorkPolicy.UPDATE,
        request,
    )
}
