package com.guru.android.security

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.guru.android.R

class DevicePostureWorker(
    appContext: Context,
    params: WorkerParameters,
) : Worker(appContext, params) {
    override fun doWork(): Result {
        return try {
            val assessment = CyberSafetyEngine.assessDevice(applicationContext)
            val prefs = applicationContext.getSharedPreferences(
                HiGuruDnsVpnService.PREFS,
                Context.MODE_PRIVATE,
            )
            val dnsActive = prefs.getBoolean(HiGuruDnsVpnService.KEY_ACTIVE, false)
            val needsAttention = !dnsActive || assessment.severity.score >= SafetySeverity.CAUTION.score
            if (needsAttention) {
                val finding = assessment.findings
                    .filter { it.severity.score >= SafetySeverity.CAUTION.score }
                    .maxByOrNull { it.severity.score }
                val prioritiseFinding = finding != null &&
                    (dnsActive || finding.severity.score >= SafetySeverity.HIGH.score)
                showNotification(
                    if (prioritiseFinding) {
                        "${finding?.severity?.label}: ${finding?.title}"
                    } else if (!dnsActive) {
                        "Protection off: malicious-domain filtering disabled"
                    } else {
                        "${finding?.severity?.label ?: "Safety warning"}: ${finding?.title ?: "Review needed"}"
                    },
                    if (prioritiseFinding) {
                        "Detected: ${finding?.detail} What to do: ${finding?.recommendedAction}" +
                            if (!dnsActive) " Also: malicious-domain protection is off; enable it in Device Protection." else ""
                    } else if (!dnsActive) {
                        "Detected: Sfumato's encrypted DNS protection is not running. Risk: known blocked domains will not be filtered. What to do: tap to enable Device Protection."
                    } else {
                        finding?.let {
                            "Detected: ${it.detail} What to do: ${it.recommendedAction}"
                        } ?: "Tap to review the complete device safety report."
                    },
                )
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun showNotification(title: String, detail: String) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Cyber Safety alerts",
                    NotificationManager.IMPORTANCE_DEFAULT,
                ).apply {
                    description = "Alerts when Sfumato device protection or security posture needs attention."
                },
            )
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            8101,
            Intent(applicationContext, SecondLayerProtectionActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        manager.notify(
            NOTIFICATION_ID,
            NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .setContentText(detail)
                .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .build(),
        )
    }

    companion object {
        const val UNIQUE_WORK = "higuru_device_posture_monitor"
        private const val CHANNEL_ID = "higuru_cyber_alerts"
        private const val NOTIFICATION_ID = 8101
    }
}
