package com.guru.android.security

import android.content.Context
import android.os.Build
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.SecureRandom
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class RemoteLockPreferences(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val deviceId: String
        get() {
            val existing = prefs.getString(KEY_DEVICE_ID, null)
            if (!existing.isNullOrBlank()) return existing
            val bytes = ByteArray(24).also(SecureRandom()::nextBytes)
            val generated = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            prefs.edit().putString(KEY_DEVICE_ID, generated).apply()
            return generated
        }

    val deviceName: String
        get() = "${Build.MANUFACTURER.replaceFirstChar(Char::uppercase)} ${Build.MODEL}".trim()

    var deviceSecret: String?
        get() {
            val stored = prefs.getString(KEY_DEVICE_SECRET, null) ?: return null
            if (!stored.startsWith(ENCRYPTED_PREFIX)) {
                // One-time migration from releases that stored the server secret as plain text.
                return runCatching {
                    deviceSecret = stored
                    stored
                }.getOrElse {
                    prefs.edit().remove(KEY_DEVICE_SECRET).apply()
                    null
                }
            }
            return runCatching { decrypt(stored.removePrefix(ENCRYPTED_PREFIX)) }
                .getOrElse {
                    prefs.edit().remove(KEY_DEVICE_SECRET).apply()
                    null
                }
        }
        set(value) {
            if (value == null) {
                prefs.edit().remove(KEY_DEVICE_SECRET).apply()
            } else {
                prefs.edit().putString(KEY_DEVICE_SECRET, ENCRYPTED_PREFIX + encrypt(value)).apply()
            }
        }

    fun clearRegistration() {
        prefs.edit().remove(KEY_DEVICE_SECRET).apply()
    }

    private fun encryptionKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE).run {
            init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build(),
            )
            generateKey()
        }
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, encryptionKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val payload = ByteArray(1 + cipher.iv.size + encrypted.size)
        payload[0] = cipher.iv.size.toByte()
        cipher.iv.copyInto(payload, 1)
        encrypted.copyInto(payload, 1 + cipher.iv.size)
        return Base64.encodeToString(payload, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val payload = Base64.decode(value, Base64.NO_WRAP)
        val ivLength = payload.firstOrNull()?.toInt()?.and(0xFF) ?: error("Invalid secret")
        require(ivLength in 12..16 && payload.size > 1 + ivLength) { "Invalid secret" }
        val iv = payload.copyOfRange(1, 1 + ivLength)
        val encrypted = payload.copyOfRange(1 + ivLength, payload.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, encryptionKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }

    companion object {
        private const val PREFS = "higuru_remote_lock"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_DEVICE_SECRET = "device_secret"
        private const val ENCRYPTED_PREFIX = "v1:"
        private const val KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "higuru_remote_lock_secret"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
