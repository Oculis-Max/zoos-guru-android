package com.guru.android.security

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.JsonParser
import com.guru.android.data.remote.BackendConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

class SharedLinkScanActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedText = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            else -> intent?.dataString
        }.orEmpty().take(2048)
        setContent {
            MaterialTheme(colorScheme = SharedScanColors) {
                SharedLinkRoute(sharedText, onClose = { finish() })
            }
        }
    }
}

private sealed interface SharedScanState {
    data object Checking : SharedScanState
    data class Ready(val assessment: SafetyAssessment) : SharedScanState
    data class Locked(val message: String) : SharedScanState
}

@Composable
private fun SharedLinkRoute(link: String, onClose: () -> Unit) {
    var state by remember { mutableStateOf<SharedScanState>(SharedScanState.Checking) }
    LaunchedEffect(link) {
        state = if (!hasCyberSafetyEntitlement()) {
            SharedScanState.Locked("Cyber Safety link scanning requires an active Developer or Business plan.")
        } else if (link.isBlank()) {
            SharedScanState.Locked("No link was shared with Sfumato.")
        } else {
            SharedScanState.Ready(CyberSafetyEngine.assessLink(extractFirstLink(link)))
        }
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xFF080A0D)).padding(22.dp),
        contentAlignment = Alignment.Center,
    ) {
        when (val value = state) {
            SharedScanState.Checking -> CircularProgressIndicator()
            is SharedScanState.Locked -> Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Icon(Icons.Default.Security, null, tint = Color(0xFF69E69A))
                Text(value.message, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Button(onClick = onClose) { Text("Close") }
            }
            is SharedScanState.Ready -> SharedAssessment(value.assessment, onClose)
        }
    }
}

@Composable
private fun SharedAssessment(assessment: SafetyAssessment, onClose: () -> Unit) {
    val colour = when (assessment.severity) {
        SafetySeverity.SAFE -> Color(0xFF69E69A)
        SafetySeverity.CAUTION -> Color(0xFFFFC857)
        SafetySeverity.HIGH -> Color(0xFFFF9A5C)
        SafetySeverity.CRITICAL -> Color(0xFFFF6575)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(Icons.Default.Security, null, tint = colour)
        Text("Sfumato shared-link check", fontWeight = FontWeight.Black, fontSize = 25.sp)
        Text(assessment.subject, color = Color(0xFFB3BDC7))
        Text(assessment.severity.label, color = colour, fontWeight = FontWeight.Black, fontSize = 30.sp)
        Text("Risk ${assessment.score}/100", color = colour, fontWeight = FontWeight.Bold)
        assessment.findings.forEach { finding ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF151A20)),
                shape = RoundedCornerShape(16.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(finding.title, fontWeight = FontWeight.Bold)
                    Text(finding.detail, color = Color(0xFFB3BDC7))
                    Text(finding.recommendedAction, color = colour, fontSize = 12.sp)
                }
            }
        }
        Text(
            "Sfumato checks warning patterns locally. A safe rating is not a guarantee that a destination is harmless.",
            color = Color(0xFFFFC857),
            fontSize = 12.sp,
        )
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Close") }
    }
}

private fun extractFirstLink(text: String): String =
    Regex("""https?://[^\s]+""").find(text)?.value?.trimEnd('.', ',', ')', ']', '}') ?: text.trim()

private suspend fun hasCyberSafetyEntitlement(): Boolean = withContext(Dispatchers.IO) {
    try {
        val user = FirebaseAuth.getInstance().currentUser ?: return@withContext false
        val token = user.getIdToken(false).await().token ?: return@withContext false
        val request = Request.Builder()
            .url("${BackendConfig.baseUrl()}v1/billing/entitlement")
            .header("Authorization", "Bearer $token")
            .get()
            .build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext false
            val json = JsonParser.parseString(response.body?.string().orEmpty()).asJsonObject
            val tier = json.get("tier")?.asString ?: "free"
            val status = json.get("status")?.asString ?: "inactive"
            (tier == "developer" || tier == "business") && status == "active"
        }
    } catch (_: Exception) {
        false
    }
}

private val SharedScanColors = darkColorScheme(
    primary = Color(0xFF69E69A),
    onPrimary = Color(0xFF06130B),
    background = Color(0xFF080A0D),
    onBackground = Color(0xFFF5F7F8),
    surface = Color(0xFF101419),
    onSurface = Color(0xFFF5F7F8),
)
