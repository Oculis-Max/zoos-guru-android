package com.guru.android.security

import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class RemoteLockMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        if (message.data["type"] != "HIGURU_REMOTE_LOCK") return
        val expected = RemoteLockPreferences(this).deviceId
        if (message.data["device_id"] != expected) return
        WorkManager.getInstance(this).enqueueUniqueWork(
            RemoteLockWorker.UNIQUE_PUSH_WORK,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<RemoteLockWorker>().build(),
        )
    }

    override fun onNewToken(token: String) {
        // Periodic authenticated polling remains active. Opening Device Protection
        // refreshes this token on the server without weakening the existing device secret.
    }
}
