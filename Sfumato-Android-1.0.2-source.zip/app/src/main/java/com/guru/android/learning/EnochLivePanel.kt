package com.guru.android.learning

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
internal fun EnochLivePanel(
    topic: String,
    stage: Int,
    learnerPosition: String,
    opening: String,
    debateFinished: Boolean,
    onTurn: (role: String, text: String) -> Unit,
    onLiveState: (active: Boolean, speaking: Boolean) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentOnTurn by rememberUpdatedState(onTurn)
    val currentOnLiveState by rememberUpdatedState(onLiveState)
    var active by remember { mutableStateOf(false) }
    var connecting by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var startJob by remember { mutableStateOf<Job?>(null) }
    var status by remember {
        mutableStateOf("Start a natural voice debate with Enoch. Standard Sfumato voice remains available.")
    }

    // A debate's topic/stage/side are immutable while turns exist, so one controller/session
    // can safely own the complete live round. It is deliberately not recreated on recomposition.
    val controller = remember {
        EnochLiveController(
            onStatus = { status = it },
            onTurn = { role, text -> currentOnTurn(role, text) },
            onSpeaking = {
                speaking = it
                currentOnLiveState(active, it)
            },
            onEnded = {
                active = false
                connecting = false
                speaking = false
                currentOnLiveState(false, false)
            },
        )
    }

    fun startLive() {
        if (active || connecting || debateFinished) return
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO,
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            status = "Microphone permission is required · standard voice remains available"
            return
        }
        connecting = true
        status = "Connecting Enoch Live…"
        startJob = scope.launch {
            runCatching {
                controller.start(topic, stage, learnerPosition, opening)
            }.onSuccess {
                active = true
                status = "Enoch Live is listening · speak naturally"
                currentOnLiveState(true, false)
            }.onFailure { error ->
                active = false
                speaking = false
                if (error !is CancellationException) {
                    status = error.message
                        ?.takeIf { it.isNotBlank() }
                        ?.let { "Live voice unavailable · $it" }
                        ?: "Live voice unavailable · standard Sfumato voice is ready"
                }
                currentOnLiveState(false, false)
            }
            connecting = false
            startJob = null
        }
    }

    val permission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) startLive()
        else status = "Microphone permission is required · standard voice remains available"
    }

    LaunchedEffect(debateFinished) {
        if (debateFinished) controller.stop("Live debate complete")
    }
    DisposableEffect(Unit) {
        onDispose {
            startJob?.cancel()
            controller.close()
        }
    }

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("Enoch Live", style = MaterialTheme.typography.titleMedium)
            Text(
                status,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Live sessions stop after ${ENOCH_LIVE_LIMIT_SECONDS / 60} minutes to protect your plan allowance.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = {
                        if (ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO,
                            ) == PackageManager.PERMISSION_GRANTED
                        ) startLive()
                        else permission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    enabled = !active && !connecting && !debateFinished,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (connecting) "Connecting…" else "Start live voice")
                }
                OutlinedButton(
                    onClick = {
                        startJob?.cancel()
                        startJob = null
                        controller.stop()
                    },
                    enabled = active || connecting,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("Stop live")
                }
            }
            if (active) {
                Text(
                    if (speaking) "Enoch is speaking" else "Listening — make your argument",
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}
