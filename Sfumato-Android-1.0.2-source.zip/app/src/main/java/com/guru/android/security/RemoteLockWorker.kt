package com.guru.android.security

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.JsonParser
import com.guru.android.data.remote.BackendConfig
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@HiltWorker
class RemoteLockWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val preferences = RemoteLockPreferences(applicationContext)
        val secret = preferences.deviceSecret ?: return@withContext Result.success()
        val user = FirebaseAuth.getInstance().currentUser ?: return@withContext Result.retry()
        val token = runCatching { user.getIdToken(false).await().token }.getOrNull()
            ?: return@withContext Result.retry()
        val request = Request.Builder()
            .url("${BackendConfig.baseUrl()}v1/device-protection/devices/${preferences.deviceId}/commands/pending")
            .header("Authorization", "Bearer $token")
            .header("X-Sfumato-Device-Secret", secret)
            .get()
            .build()
        val body = runCatching {
            OkHttpClient().newCall(request).execute().use {
                if (!it.isSuccessful) return@use null
                it.body?.string()
            }
        }.getOrNull() ?: return@withContext Result.retry()
        val commands = runCatching { JsonParser.parseString(body).asJsonArray }.getOrNull()
            ?: return@withContext Result.failure()
        if (commands.isEmpty) return@withContext Result.success()

        val manager = applicationContext.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(applicationContext, HiGuruDeviceAdminReceiver::class.java)
        if (!manager.isAdminActive(admin)) return@withContext Result.failure()

        val commandId = commands.firstOrNull()
            ?.asJsonObject
            ?.get("id")
            ?.asString
            ?: return@withContext Result.success()
        return@withContext try {
            // Never report success before Android has accepted the lock operation.
            manager.lockNow()
            if (acknowledge(token, secret, preferences.deviceId, commandId)) {
                Result.success()
            } else {
                Result.retry()
            }
        } catch (_: SecurityException) {
            Result.failure()
        }
    }

    private fun acknowledge(token: String, secret: String, deviceId: String, commandId: String): Boolean {
        val request = Request.Builder()
            .url("${BackendConfig.baseUrl()}v1/device-protection/devices/$deviceId/commands/$commandId/executed")
            .header("Authorization", "Bearer $token")
            .header("X-Sfumato-Device-Secret", secret)
            .post("".toRequestBody("application/json".toMediaType()))
            .build()
        return runCatching {
            OkHttpClient().newCall(request).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    companion object {
        const val UNIQUE_PERIODIC_WORK = "higuru_remote_lock_poll"
        const val UNIQUE_PUSH_WORK = "higuru_remote_lock_push"
    }
}
