package com.guru.android.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.guru.android.data.local.Message
import com.guru.android.data.repository.MessageRepository
import com.guru.android.network.NetworkMonitor
import com.guru.android.work.SyncScheduler
import com.guru.android.domain.AccountProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class AssistantMode(val label: String) {
    ASK("Ask"), RESEARCH("Research"), ANALYSE("Analyse"), DRAFT("Draft")
}

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val networkMonitor: NetworkMonitor,
    private val syncScheduler: SyncScheduler
) : ViewModel() {
    val messages: StateFlow<List<Message>> = repository.getAllMessages().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _chatNotice = MutableStateFlow<String?>(null)
    val chatNotice: StateFlow<String?> = _chatNotice.asStateFlow()

    init {
        viewModelScope.launch {
            if (messages.value.isEmpty()) repository.seedWelcomeMessage()
        }
        viewModelScope.launch {
            networkMonitor.observeNetworkStatus().collect { online ->
                _isOnline.value = online
                if (online) syncScheduler.scheduleSync()
            }
        }
    }

    fun clearNotice() { _chatNotice.value = null }

    fun sendMessage(
        text: String,
        workspace: String = "General workspace",
        mode: AssistantMode = AssistantMode.ASK,
        sourceName: String? = null,
        sourceContent: String? = null,
        planTier: String = "free",
        profile: AccountProfile? = null,
    ) {
        if (text.isBlank() && sourceContent.isNullOrBlank()) return
        if (_isSending.value) return
        if (!_isOnline.value) {
            _chatNotice.value = "You're offline. Reconnect before sending this message."
            return
        }
        _isSending.value = true
        _chatNotice.value = null
        viewModelScope.launch {
            try {
                repository.sendMessage(
                    userText = text.trim(),
                    workspace = workspace,
                    mode = mode.name,
                    sourceName = sourceName,
                    sourceContent = sourceContent,
                    planTier = planTier,
                    profile = profile,
                )
            } finally {
                _isSending.value = false
            }
        }
    }
}