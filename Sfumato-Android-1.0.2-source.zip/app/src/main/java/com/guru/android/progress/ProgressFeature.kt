package com.guru.android.progress

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton

data class ProgressMetric(val key: String, val label: String, val count: Int)
data class RecentActivity(val type: String, val at: String)
data class ProgressSummary(@SerializedName("subject_name") val subjectName: String, @SerializedName("total_activities") val totalActivities: Int, val metrics: List<ProgressMetric>, @SerializedName("recent_activity") val recentActivity: List<RecentActivity> = emptyList(), @SerializedName("engagement_status") val engagementStatus: String = "Getting started", val alerts: List<String> = emptyList(), val recommendations: List<String> = emptyList(), @SerializedName("privacy_notice") val privacyNotice: String)
data class ProgressShareRequest(@SerializedName("viewer_email") val viewerEmail: String, @SerializedName("viewer_role") val viewerRole: String, @SerializedName("subject_name") val subjectName: String, val categories: List<String>)
data class ProgressShare(val id: String, @SerializedName("viewer_email") val viewerEmail: String, @SerializedName("viewer_role") val viewerRole: String, @SerializedName("subject_name") val subjectName: String, val categories: List<String>, val status: String)
data class FeedbackRequest(val message: String, val action: String? = null)
data class EducationFeedback(val id: String, @SerializedName("share_id") val shareId: String, @SerializedName("author_email") val authorEmail: String, @SerializedName("author_role") val authorRole: String, val message: String, val action: String? = null)

interface ProgressService {
    @GET("v1/progress/summary") suspend fun summary(@Header("Authorization") token: String): ProgressSummary
    @POST("v1/progress/shares") suspend fun share(@Header("Authorization") token: String, @Body request: ProgressShareRequest): ProgressShare
    @GET("v1/progress/shares") suspend fun shares(@Header("Authorization") token: String): List<ProgressShare>
    @DELETE("v1/progress/shares/{id}") suspend fun revoke(@Header("Authorization") token: String, @Path("id") id: String)
    @GET("v1/progress/viewer") suspend fun viewerAccess(@Header("Authorization") token: String): List<ProgressShare>
    @GET("v1/progress/viewer/{id}/summary") suspend fun sharedSummary(@Header("Authorization") token: String, @Path("id") id: String): ProgressSummary
    @GET("v1/progress/feedback") suspend fun learnerFeedback(@Header("Authorization") token: String): List<EducationFeedback>
    @GET("v1/progress/viewer/{id}/feedback") suspend fun viewerFeedback(@Header("Authorization") token: String, @Path("id") id: String): List<EducationFeedback>
    @POST("v1/progress/viewer/{id}/feedback") suspend fun sendFeedback(@Header("Authorization") token: String, @Path("id") id: String, @Body request: FeedbackRequest): EducationFeedback
}

@Singleton
class ProgressRepository @Inject constructor(private val service: ProgressService) {
    private suspend fun token(): String {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        return "Bearer " + checkNotNull(user.getIdToken(true).await().token) { "Session expired." }
    }
    suspend fun summary() = service.summary(token()); suspend fun shares() = service.shares(token()); suspend fun viewerAccess() = service.viewerAccess(token())
    suspend fun sharedSummary(id: String) = service.sharedSummary(token(), id); suspend fun learnerFeedback() = service.learnerFeedback(token()); suspend fun viewerFeedback(id: String) = service.viewerFeedback(token(), id)
    suspend fun sendFeedback(id: String, message: String, action: String?) = service.sendFeedback(token(), id, FeedbackRequest(message, action))
    suspend fun share(request: ProgressShareRequest) = service.share(token(), request); suspend fun revoke(id: String) = service.revoke(token(), id)
}

data class ProgressState(val busy: Boolean = false, val ownSummary: ProgressSummary? = null, val viewedSummary: ProgressSummary? = null, val selectedShare: ProgressShare? = null, val shares: List<ProgressShare> = emptyList(), val viewerAccess: List<ProgressShare> = emptyList(), val learnerFeedback: List<EducationFeedback> = emptyList(), val viewerFeedback: List<EducationFeedback> = emptyList(), val notice: String? = null, val error: String? = null)

@HiltViewModel
class ProgressViewModel @Inject constructor(private val repository: ProgressRepository) : ViewModel() {
    private val mutableState = MutableStateFlow(ProgressState()); val state = mutableState.asStateFlow()
    init { refresh() }
    fun refresh() = execute { val own = repository.summary(); val shares = repository.shares(); val access = repository.viewerAccess(); val feedback = repository.learnerFeedback(); mutableState.update { it.copy(ownSummary = own, shares = shares.filter { s -> s.status == "active" }, viewerAccess = access.filter { s -> s.status == "active" }, learnerFeedback = feedback) } }
    fun share(email: String, role: String, name: String, categories: List<String>) = execute {
        require(email.isNotBlank() && name.isNotBlank()) { "Enter the viewer email and learner name." }; require(categories.isNotEmpty()) { "Choose at least one approved information category." }
        val saved = repository.share(ProgressShareRequest(email.trim(), role, name.trim(), categories)); mutableState.update { it.copy(shares = listOf(saved) + it.shares.filterNot { old -> old.id == saved.id }, notice = saved.viewerRole.replaceFirstChar { c -> c.uppercase() } + " access granted to " + saved.viewerEmail) }
    }
    fun revoke(id: String) = execute { repository.revoke(id); mutableState.update { it.copy(shares = it.shares.filterNot { s -> s.id == id }, notice = "Access revoked.") } }
    fun view(share: ProgressShare) = execute { val summary = repository.sharedSummary(share.id); val feedback = repository.viewerFeedback(share.id); mutableState.update { it.copy(selectedShare = share, viewedSummary = summary, viewerFeedback = feedback) } }
    fun sendFeedback(message: String, action: String?, onSuccess: () -> Unit = {}) = execute {
        val share = checkNotNull(mutableState.value.selectedShare) { "Choose a learner first." }; require(message.trim().length >= 3) { "Write at least 3 characters of feedback." }
        val saved = repository.sendFeedback(share.id, message.trim(), action?.trim()?.ifBlank { null }); mutableState.update { it.copy(viewerFeedback = listOf(saved) + it.viewerFeedback, notice = "Feedback sent privately.") }; onSuccess()
    }
    fun closeViewed() = mutableState.update { it.copy(selectedShare = null, viewedSummary = null, viewerFeedback = emptyList()) }
    private fun execute(block: suspend () -> Unit) { if (mutableState.value.busy) return; viewModelScope.launch { mutableState.update { it.copy(busy = true, error = null, notice = null) }; try { block() } catch (error: Exception) { val message = if (error is HttpException) when (error.code()) { 400 -> "Check the email and sharing details."; 401 -> "Your session expired. Sign in again."; 403 -> "This education dashboard has not been shared with your account."; 409 -> "That person already has this dashboard role. Revoke the existing access before creating another."; 422 -> "Check the dashboard details and try again."; else -> "Education dashboard error (HTTP ${error.code()})." } else error.message ?: "Education dashboards are temporarily unavailable."; mutableState.update { it.copy(error = message) } } finally { mutableState.update { it.copy(busy = false) } } } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(viewModel: ProgressViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState(); var email by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var role by remember { mutableStateOf("parent") }; var categories by remember { mutableStateOf(setOf("learning", "debate", "scholarships")) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Education Dashboards", style = MaterialTheme.typography.headlineMedium)
        Text("Parent, Teacher and Professor views powered by student-approved progress—not private conversations.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        state.selectedShare?.let { share -> state.viewedSummary?.let { RoleDashboard(share, it, state.viewerFeedback, state.busy, viewModel) }; OutlinedButton(onClick = viewModel::closeViewed) { Text("Back to dashboards") } } ?: run {
            state.ownSummary?.let { SummaryCard(it, "My learning overview") }
            if (state.learnerFeedback.isNotEmpty()) { Text("Educator feedback", style = MaterialTheme.typography.titleLarge); state.learnerFeedback.take(10).forEach { FeedbackCard(it) } }
            if (state.viewerAccess.isNotEmpty()) {
                Text("Dashboards shared with me", style = MaterialTheme.typography.titleLarge)
                listOf("parent", "teacher", "professor", "employer").forEach { dashboardRole -> val access = state.viewerAccess.filter { it.viewerRole == dashboardRole }; if (access.isNotEmpty()) { Text(dashboardRole.replaceFirstChar { it.uppercase() } + " Dashboard"); access.forEach { share -> OutlinedButton(onClick = { viewModel.view(share) }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Open " + share.subjectName) } } } }
            }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Grant dashboard access", style = MaterialTheme.typography.titleLarge); Text("The learner controls the role, categories and revocation.")
                OutlinedTextField(name, { name = it.take(100) }, label = { Text("Learner name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(email, { email = it.take(254) }, label = { Text("Parent, teacher, professor or employer email") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(role == "parent", { role = "parent" }, label = { Text("Parent") }); FilterChip(role == "teacher", { role = "teacher" }, label = { Text("Teacher") }) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(role == "professor", { role = "professor" }, label = { Text("Professor") }); FilterChip(role == "employer", { role = "employer" }, label = { Text("Employer") }) }
                Text("Approved information")
                listOf("learning" to "Tutor", "debate" to "Debates", "scholarships" to "Scholarships", "coding" to "Coding", "business" to "Business").forEach { (key, label) -> FilterChip(selected = key in categories, onClick = { categories = if (key in categories) categories - key else categories + key }, label = { Text(label) }) }
                Button(onClick = { viewModel.share(email, role, name, categories.toList()) }, enabled = !state.busy && email.isNotBlank() && name.isNotBlank() && categories.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Grant " + role.replaceFirstChar { it.uppercase() } + " access") }
            } }
            if (state.shares.isNotEmpty()) { Text("People with access", style = MaterialTheme.typography.titleLarge); state.shares.filter { it.status == "active" }.forEach { share -> Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(share.viewerEmail, style = MaterialTheme.typography.titleMedium); Text(share.viewerRole.replaceFirstChar { it.uppercase() } + " · " + share.categories.joinToString()) }; TextButton(onClick = { viewModel.revoke(share.id) }, enabled = !state.busy) { Text("Revoke") } } } } }
        }
        state.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }; state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }; if (state.busy) CircularProgressIndicator()
        OutlinedButton(onClick = viewModel::refresh, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Refresh dashboards") }; Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RoleDashboard(share: ProgressShare, summary: ProgressSummary, feedback: List<EducationFeedback>, busy: Boolean, viewModel: ProgressViewModel) {
    var message by remember(share.id) { mutableStateOf("") }; var action by remember(share.id) { mutableStateOf("") }; val roleTitle = share.viewerRole.replaceFirstChar { it.uppercase() } + " Dashboard"
    Text(roleTitle, style = MaterialTheme.typography.headlineSmall); SummaryCard(summary, share.subjectName)
    if (summary.alerts.isNotEmpty()) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text("Attention", style = MaterialTheme.typography.titleMedium); summary.alerts.forEach { Text("• $it") } } } }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Recommended next steps", style = MaterialTheme.typography.titleMedium); summary.recommendations.forEach { Text("• $it") } } }
    if (share.viewerRole in setOf("teacher", "professor")) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Private educator feedback", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(message, { message = it.take(1000) }, label = { Text("Feedback for learner") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        OutlinedTextField(action, { action = it.take(300) }, label = { Text("Suggested action or goal") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { viewModel.sendFeedback(message, action) { message = ""; action = "" } }, enabled = !busy && message.trim().length >= 3, modifier = Modifier.fillMaxWidth()) { Text("Send feedback") }
    } } }
    if (feedback.isNotEmpty()) { Text("Feedback history", style = MaterialTheme.typography.titleLarge); feedback.forEach { FeedbackCard(it) } }
}

@Composable
private fun SummaryCard(summary: ProgressSummary, title: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge); Text(summary.subjectName, style = MaterialTheme.typography.titleLarge); Text(summary.engagementStatus, color = MaterialTheme.colorScheme.primary); Text(summary.totalActivities.toString() + " approved activities", style = MaterialTheme.typography.headlineSmall)
        summary.metrics.forEach { Text(it.label + ": " + it.count) }; if (summary.recentActivity.isNotEmpty()) { Text("Recent activity", style = MaterialTheme.typography.titleMedium); summary.recentActivity.take(5).forEach { Text(it.type + " · " + it.at.take(10)) } }; Text(summary.privacyNotice, style = MaterialTheme.typography.bodySmall)
    } }
}

@Composable
private fun FeedbackCard(feedback: EducationFeedback) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(feedback.authorRole.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.labelLarge); Text(feedback.message); feedback.action?.let { Text("Next action: $it", color = MaterialTheme.colorScheme.primary) } } } }
