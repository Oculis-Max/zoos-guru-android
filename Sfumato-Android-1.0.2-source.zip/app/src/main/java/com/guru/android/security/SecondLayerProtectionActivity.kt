package com.guru.android.security

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.JsonParser
import com.guru.android.data.remote.BackendConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.IDN
import java.util.Locale
import java.util.concurrent.TimeUnit

private sealed interface DeviceLayerAccess {
    data object Checking : DeviceLayerAccess
    data class Allowed(val tier: String) : DeviceLayerAccess
    data class Locked(val tier: String) : DeviceLayerAccess
    data class Error(val message: String) : DeviceLayerAccess
}

class SecondLayerProtectionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = SecondLayerColors) {
                SecondLayerRoute(onBack = { finish() })
            }
        }
    }
}

@Composable
private fun SecondLayerRoute(onBack: () -> Unit) {
    var access by remember { mutableStateOf<DeviceLayerAccess>(DeviceLayerAccess.Checking) }
    var retry by remember { mutableStateOf(0) }
    LaunchedEffect(retry) { access = verifyDeviceLayerAccess() }
    when (val state = access) {
        DeviceLayerAccess.Checking -> Box(
            Modifier.fillMaxSize().background(Color(0xFF080A0D)),
            contentAlignment = Alignment.Center,
        ) { CircularProgressIndicator() }
        is DeviceLayerAccess.Allowed -> SecondLayerScreen(state.tier, onBack)
        is DeviceLayerAccess.Locked -> DeviceLayerLocked(state.tier, onBack)
        is DeviceLayerAccess.Error -> DeviceLayerError(state.message, onBack) { retry++ }
    }
}

private suspend fun verifyDeviceLayerAccess(): DeviceLayerAccess = withContext(Dispatchers.IO) {
    try {
        val user = FirebaseAuth.getInstance().currentUser
            ?: return@withContext DeviceLayerAccess.Locked("free")
        val token = user.getIdToken(false).await().token
            ?: return@withContext DeviceLayerAccess.Error("Your secure session could not be verified.")
        val request = Request.Builder()
            .url("${BackendConfig.baseUrl()}v1/billing/entitlement")
            .header("Authorization", "Bearer $token")
            .get()
            .build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return@withContext DeviceLayerAccess.Error("Sfumato could not verify your plan right now.")
            }
            val json = JsonParser.parseString(response.body?.string().orEmpty()).asJsonObject
            val tier = json.get("tier")?.asString ?: "free"
            val status = json.get("status")?.asString ?: "inactive"
            if ((tier == "developer" || tier == "business") && status == "active") {
                DeviceLayerAccess.Allowed(tier)
            } else {
                DeviceLayerAccess.Locked(tier)
            }
        }
    } catch (error: Exception) {
        DeviceLayerAccess.Error(error.message ?: "Sfumato could not verify your access.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SecondLayerScreen(tier: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(HiGuruDnsVpnService.PREFS, Context.MODE_PRIVATE) }
    var active by remember { mutableStateOf(prefs.getBoolean(HiGuruDnsVpnService.KEY_ACTIVE, false)) }
    var showConsent by remember { mutableStateOf(false) }
    var domain by remember { mutableStateOf("") }
    var domains by remember {
        mutableStateOf(
            prefs.getStringSet(HiGuruDnsVpnService.KEY_BLOCKED_DOMAINS, emptySet())
                .orEmpty()
                .sorted(),
        )
    }
    var validationMessage by remember { mutableStateOf<String?>(null) }
    var assessment by remember { mutableStateOf(CyberSafetyEngine.assessDevice(context)) }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    fun startProtection() {
        ContextCompat.startForegroundService(
            context,
            Intent(context, HiGuruDnsVpnService::class.java),
        )
        active = true
        schedulePostureMonitoring(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val vpnPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startProtection()
    }

    fun requestVpn() {
        val permissionIntent = VpnService.prepare(context)
        if (permissionIntent == null) startProtection() else vpnPermission.launch(permissionIntent)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Device Protection", fontWeight = FontWeight.Bold)
                        Text("${tier.replaceFirstChar(Char::uppercase)} plan", fontSize = 11.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                },
                actions = {
                    Icon(Icons.Default.Security, null, tint = Color(0xFF69E69A), modifier = Modifier.padding(end = 18.dp))
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ProtectionStatusCard(active)
            DeviceSafetyReport(
                assessment = assessment,
                protectionActive = active,
                onScanAgain = { assessment = CyberSafetyEngine.assessDevice(context) },
            )
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
                shape = RoundedCornerShape(18.dp),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Malicious-domain protection", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(
                        "Sfumato uses Android's VPN permission only to process DNS requests. Upstream DNS is encrypted with TLS; normal app traffic is not sent through Sfumato.",
                        color = Color(0xFFB3BDC7),
                    )
                    if (active) {
                        Button(
                            onClick = {
                                context.startService(
                                    Intent(context, HiGuruDnsVpnService::class.java)
                                        .setAction(HiGuruDnsVpnService.ACTION_STOP),
                                )
                                active = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Stop device protection") }
                    } else {
                        Button(onClick = { showConsent = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Enable device protection")
                        }
                    }
                    Text(
                        "Android Private DNS and apps using their own encrypted DNS may bypass this filter. Sfumato never decrypts messages, passwords or web content.",
                        color = Color(0xFFFFC857),
                        fontSize = 12.sp,
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
                shape = RoundedCornerShape(18.dp),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Your blocked domains", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text("Add domains only—never paste passwords, messages or full private URLs.", color = Color(0xFFB3BDC7))
                    OutlinedTextField(
                        value = domain,
                        onValueChange = { domain = it.take(253); validationMessage = null },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("example.com") },
                        singleLine = true,
                    )
                    validationMessage?.let { Text(it, color = Color(0xFFFF7A86), fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = {
                            val cleaned = normaliseDomain(domain)
                            if (cleaned == null) {
                                validationMessage = "Enter a valid domain such as example.com."
                            } else {
                                val updated = (domains + cleaned).distinct().sorted()
                                prefs.edit().putStringSet(HiGuruDnsVpnService.KEY_BLOCKED_DOMAINS, updated.toSet()).apply()
                                domains = updated
                                domain = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Add blocking rule") }
                    domains.forEach { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(item, modifier = Modifier.weight(1f), color = Color(0xFFDDE4EA))
                            OutlinedButton(
                                onClick = {
                                    val updated = domains - item
                                    prefs.edit().putStringSet(HiGuruDnsVpnService.KEY_BLOCKED_DOMAINS, updated.toSet()).apply()
                                    domains = updated
                                },
                            ) { Text("Remove", fontSize = 11.sp) }
                        }
                    }
                    if (domains.isEmpty()) Text(
                        "No personal rules. The upstream resolver still blocks known malware domains while protection is active.",
                        color = Color(0xFF8F9AA5),
                        fontSize = 12.sp,
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
                shape = RoundedCornerShape(18.dp),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Continuous safety checks", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(
                        "Sfumato checks device security posture periodically and warns when protection, screen lock or security updates need attention.",
                        color = Color(0xFFB3BDC7),
                    )
                    Button(
                        onClick = { schedulePostureMonitoring(context) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Enable periodic checks") }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
                shape = RoundedCornerShape(18.dp),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Remote Lock", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text(
                        "Prepare this phone so you can lock it from another signed-in device if it is lost or stolen.",
                        color = Color(0xFFB3BDC7),
                    )
                    Button(
                        onClick = {
                            context.startActivity(
                                Intent(context, RemoteDeviceProtectionActivity::class.java),
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Set up Remote Lock") }
                }
            }

            OutlinedButton(
                onClick = { context.startActivity(Intent(context, CyberSafetyActivity::class.java)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Open Cyber Safety dashboard") }
        }
    }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Enable device DNS protection?") },
            text = {
                Text(
                    "Android will show its VPN approval screen. Sfumato will receive DNS domain requests so it can block known malware and your approved rules. It does not decrypt page contents. You can stop protection at any time.",
                )
            },
            confirmButton = {
                Button(onClick = { showConsent = false; requestVpn() }) { Text("Continue") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConsent = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun DeviceSafetyReport(
    assessment: SafetyAssessment,
    protectionActive: Boolean,
    onScanAgain: () -> Unit,
) {
    val displayedSeverity = if (!protectionActive && assessment.severity == SafetySeverity.SAFE) SafetySeverity.CAUTION else assessment.severity
    val displayedScore = maxOf(assessment.score, if (protectionActive) 0 else SafetySeverity.CAUTION.score)
    val colour = when (displayedSeverity) {
        SafetySeverity.SAFE -> Color(0xFF69E69A)
        SafetySeverity.CAUTION -> Color(0xFFFFC857)
        SafetySeverity.HIGH -> Color(0xFFFF9A5C)
        SafetySeverity.CRITICAL -> Color(0xFFFF6575)
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF11171C)),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Device safety report", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            if (!protectionActive) {
                Text("Protection off", color = Color(0xFFFF9A5C), fontWeight = FontWeight.Bold)
                Text(
                    "Detected: encrypted malicious-domain filtering is not running. This does not mean your phone is infected, but known blocked domains will not be filtered.",
                    color = Color(0xFFB3BDC7),
                )
                Text("How to prevent risk: enable Device Protection below.", color = Color(0xFFFFC857), fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(displayedSeverity.label, color = colour, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Text("Risk $displayedScore/100", color = colour, fontWeight = FontWeight.Bold)
            }
            assessment.findings.forEach { finding ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF20272D))) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(finding.title, fontWeight = FontWeight.Bold)
                        Text("What Sfumato detected", color = colour, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(finding.detail, color = Color(0xFFB3BDC7), fontSize = 12.sp)
                        Text("How to protect yourself", color = colour, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(finding.recommendedAction, color = Color(0xFFE1E7EC), fontSize = 12.sp)
                    }
                }
            }
            Text(
                "A caution or high-risk result is a safety signal, not proof that your phone was hacked. Sfumato states when it cannot confirm something.",
                color = Color(0xFF9FAAB5),
                fontSize = 11.sp,
            )
            OutlinedButton(onClick = onScanAgain, modifier = Modifier.fillMaxWidth()) { Text("Scan again") }
        }
    }
}

@Composable
private fun ProtectionStatusCard(active: Boolean) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (active) Color(0xFF102B1D) else Color(0xFF2A2112),
        ),
        shape = RoundedCornerShape(18.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (active) Icons.Default.CheckCircle else Icons.Default.Warning,
                null,
                tint = if (active) Color(0xFF69E69A) else Color(0xFFFFC857),
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    if (active) "Device DNS protection active" else "Device DNS protection off",
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    if (active) "A persistent Android notification confirms protection." else "Link sharing and the Cyber Safety dashboard remain available.",
                    color = Color(0xFFB3BDC7),
                    fontSize = 12.sp,
                )
            }
        }
    }
}

private fun normaliseDomain(value: String): String? {
    val raw = value.trim().lowercase(Locale.ROOT)
        .removePrefix("https://")
        .removePrefix("http://")
        .substringBefore('/')
        .substringBefore(':')
        .trim('.')
    if (raw.isBlank() || raw.length > 253 || " " in raw) return null
    val ascii = runCatching { IDN.toASCII(raw) }.getOrNull() ?: return null
    if (!ascii.contains('.') || ascii.split('.').any { it.isBlank() || it.length > 63 }) return null
    return ascii
}

private fun schedulePostureMonitoring(context: Context) {
    val work = PeriodicWorkRequestBuilder<DevicePostureWorker>(12, TimeUnit.HOURS).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        DevicePostureWorker.UNIQUE_WORK,
        ExistingPeriodicWorkPolicy.UPDATE,
        work,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeviceLayerLocked(tier: String, onBack: () -> Unit) = Scaffold(
    topBar = {
        TopAppBar(
            title = { Text("Device Protection") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
        )
    },
) { padding ->
    Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(Icons.Default.Security, null, tint = Color(0xFF69E69A))
            Text("Developer or Business plan required", fontWeight = FontWeight.Bold, fontSize = 25.sp)
            Text("Your current ${tier.replaceFirstChar(Char::uppercase)} plan does not include device protection.")
            Button(onClick = onBack) { Text("Return") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeviceLayerError(message: String, onBack: () -> Unit, retry: () -> Unit) = Scaffold(
    topBar = {
        TopAppBar(
            title = { Text("Device Protection") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
        )
    },
) { padding ->
    Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Protection check unavailable", fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text(message)
            Button(onClick = retry) { Text("Try again") }
        }
    }
}

private val SecondLayerColors = darkColorScheme(
    primary = Color(0xFF69E69A),
    onPrimary = Color(0xFF06130B),
    background = Color(0xFF080A0D),
    onBackground = Color(0xFFF5F7F8),
    surface = Color(0xFF101419),
    onSurface = Color(0xFFF5F7F8),
    surfaceVariant = Color(0xFF20252B),
    onSurfaceVariant = Color(0xFFD2D8DE),
    outline = Color(0xFF5D6975),
    error = Color(0xFFFF6575),
)
