package com.guru.android.learning

import com.google.firebase.auth.FirebaseAuth
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.tasks.await

@Singleton
class LearningRepository @Inject constructor(
    private val service: LearningService,
) {
    private val auth = FirebaseAuth.getInstance()

    suspend fun startTutor(
        mode: String,
        subject: String,
        topic: String,
        grade: String?,
        curriculum: String?,
    ): GeneratedLearningResponse = service.generateTutorSession(
        authorization = bearerToken(),
        request = TutorSessionRequest(mode, subject, topic, grade, curriculum),
    )

    suspend fun continueTutor(
        mode: String,
        subject: String,
        topic: String,
        grade: String?,
        curriculum: String?,
        lessonContext: String,
        learnerMessage: String,
    ): GeneratedLearningResponse = service.continueTutorSession(
        authorization = bearerToken(),
        request = TutorFollowUpRequest(
            mode = mode,
            subject = subject,
            topic = topic,
            grade = grade,
            curriculum = curriculum,
            lessonContext = lessonContext,
            learnerMessage = learnerMessage,
        ),
    )

    suspend fun finishTutor(
        mode: String,
        subject: String,
        topic: String,
        grade: String?,
        curriculum: String?,
        lessonContext: String,
    ): GeneratedLearningResponse = service.finishTutorSession(
        authorization = bearerToken(),
        request = TutorFinishRequest(
            mode = mode,
            subject = subject,
            topic = topic,
            grade = grade,
            curriculum = curriculum,
            lessonContext = lessonContext,
        ),
    )

    suspend fun arenaStatus(): ArenaStatus = service.getArenaStatus(bearerToken())

    suspend fun startDebate(
        topic: String,
        stage: Int,
        position: String,
    ): GeneratedLearningResponse = service.generateDebateOpening(
        authorization = bearerToken(),
        request = DebateAttemptRequest(topic, stage, position),
    )

    suspend fun continueDebate(
        topic: String,
        stage: Int,
        position: String,
        debateContext: String,
        learnerArgument: String,
    ): GeneratedLearningResponse = service.continueDebate(
        authorization = bearerToken(),
        request = DebateFollowUpRequest(
            topic = topic,
            stage = stage,
            userPosition = position,
            debateContext = debateContext,
            learnerArgument = learnerArgument,
        ),
    )

    suspend fun judgeDebate(
        topic: String,
        stage: Int,
        position: String,
        debateContext: String,
    ): GeneratedLearningResponse = service.judgeDebate(
        authorization = bearerToken(),
        request = DebateFinishRequest(
            topic = topic,
            stage = stage,
            userPosition = position,
            debateContext = debateContext,
        ),
    )

    private suspend fun bearerToken(): String {
        val user = checkNotNull(auth.currentUser) { "Sign in to use learning features." }
        val token = checkNotNull(user.getIdToken(false).await().token) {
            "Firebase did not return an ID token."
        }
        return "Bearer $token"
    }
}
