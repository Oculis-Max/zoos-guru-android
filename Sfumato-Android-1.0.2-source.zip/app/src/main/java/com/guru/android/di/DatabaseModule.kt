package com.guru.android.di

import android.content.Context
import androidx.room.Room
import com.guru.android.data.local.GuruDatabase
import com.guru.android.data.local.MessageDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): GuruDatabase {
        return Room.databaseBuilder(
            context,
            GuruDatabase::class.java,
            "guru_database"
        ).build()
    }

    @Provides
    fun provideMessageDao(database: GuruDatabase): MessageDao {
        return database.messageDao()
    }
}
