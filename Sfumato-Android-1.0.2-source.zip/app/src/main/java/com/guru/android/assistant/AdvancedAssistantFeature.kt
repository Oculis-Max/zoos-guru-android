package com.guru.android.assistant

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton

data class OAuthStart(@SerializedName("authorization_url") val authorizationUrl: String)
data class ChannelConnection(val channel: String, val connected: Boolean, val detail: String)
data class EmailAlert(
    val id: String,
    @SerializedName("message_id") val messageId: String,
    @SerializedName("thread_id") val threadId: String,
    val sender: String,
    @SerializedName("sender_email") val senderEmail: String = "",
    val subject: String,
    val snippet: String,
    val priority: String,
    val reason: String,
    @SerializedName("suggested_action") val suggestedAction: String,
    val status: String,
)
data class AssistantAction(
    val id: String, val channel: String, val recipient: String? = null,
    val subject: String? = null, val content: String, val instruction: String,
    val status: String, val error: String? = null,
)
data class DraftRequest(val channel: String, val instruction: String, val recipient: String?, val context: String?)
data class ActionEdit(val recipient: String?, val subject: String?, val content: String)
data class ReportRequest(
    val title: String, val objective: String,
    @SerializedName("source_material") val sourceMaterial: String,
    @SerializedName("report_type") val reportType: String,
)
data class AssistantReport(val id: String, val title: String, val content: String, val status: String)
data class AdminTaskCreate(val title: String, val description: String)
data class AdminTaskUpdate(val status: String)
data class AssistantAdminTask(val id: String, val title: String, val description: String, val status: String)

interface AdvancedAssistantService {
    @GET("v1/advanced-assistant/oauth/google/start") suspend fun startGoogleOAuth(@Header("Authorization") token: String): OAuthStart
    @GET("v1/advanced-assistant/connections") suspend fun connections(@Header("Authorization") token: String): List<ChannelConnection>
    @POST("v1/advanced-assistant/inbox/scan") suspend fun scanInbox(@Header("Authorization") token: String): List<EmailAlert>
    @GET("v1/advanced-assistant/notifications") suspend fun notifications(@Header("Authorization") token: String): List<EmailAlert>
    @POST("v1/advanced-assistant/notifications/{id}/reviewed") suspend fun reviewAlert(@Header("Authorization") token: String, @Path("id") id: String): EmailAlert
    @GET("v1/advanced-assistant/actions") suspend fun actions(@Header("Authorization") token: String): List<AssistantAction>
    @POST("v1/advanced-assistant/actions/draft") suspend fun draft(@Header("Authorization") token: String, @Body body: DraftRequest): AssistantAction
    @PUT("v1/advanced-assistant/actions/{id}") suspend fun edit(@Header("Authorization") token: String, @Path("id") id: String, @Body body: ActionEdit): AssistantAction
    @POST("v1/advanced-assistant/actions/{id}/approve") suspend fun approve(@Header("Authorization") token: String, @Path("id") id: String): AssistantAction
    @POST("v1/advanced-assistant/actions/{id}/dispatch") suspend fun dispatch(@Header("Authorization") token: String, @Path("id") id: String): AssistantAction
    @POST("v1/advanced-assistant/actions/{id}/cancel") suspend fun cancel(@Header("Authorization") token: String, @Path("id") id: String): AssistantAction
    @GET("v1/advanced-assistant/reports") suspend fun reports(@Header("Authorization") token: String): List<AssistantReport>
    @POST("v1/advanced-assistant/reports") suspend fun report(@Header("Authorization") token: String, @Body body: ReportRequest): AssistantReport
    @POST("v1/advanced-assistant/reports/{id}/approve") suspend fun approveReport(@Header("Authorization") token: String, @Path("id") id: String): AssistantReport
    @GET("v1/advanced-assistant/admin-tasks") suspend fun tasks(@Header("Authorization") token: String): List<AssistantAdminTask>
    @POST("v1/advanced-assistant/admin-tasks") suspend fun task(@Header("Authorization") token: String, @Body body: AdminTaskCreate): AssistantAdminTask
    @PATCH("v1/advanced-assistant/admin-tasks/{id}") suspend fun updateTask(@Header("Authorization") token: String, @Path("id") id: String, @Body body: AdminTaskUpdate): AssistantAdminTask
}

@Singleton
class AdvancedAssistantRepository @Inject constructor(private val api: AdvancedAssistantService) {
    private suspend fun token(): String {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        return "Bearer " + checkNotNull(user.getIdToken(false).await().token) { "Session expired." }
    }
    suspend fun startGoogleOAuth() = api.startGoogleOAuth(token())
    suspend fun connections() = api.connections(token())
    suspend fun scanInbox() = api.scanInbox(token())
    suspend fun notifications() = api.notifications(token())
    suspend fun reviewAlert(id: String) = api.reviewAlert(token(), id)
    suspend fun actions() = api.actions(token())
    suspend fun draft(value: DraftRequest) = api.draft(token(), value)
    suspend fun edit(id: String, value: ActionEdit) = api.edit(token(), id, value)
    suspend fun approve(id: String) = api.approve(token(), id)
    suspend fun dispatch(id: String) = api.dispatch(token(), id)
    suspend fun cancel(id: String) = api.cancel(token(), id)
    suspend fun reports() = api.reports(token())
    suspend fun report(value: ReportRequest) = api.report(token(), value)
    suspend fun approveReport(id: String) = api.approveReport(token(), id)
    suspend fun tasks() = api.tasks(token())
    suspend fun task(value: AdminTaskCreate) = api.task(token(), value)
    suspend fun updateTask(id: String, status: String) = api.updateTask(token(), id, AdminTaskUpdate(status))
}

data class AssistantState(
    val busy: Boolean = false,
    val connections: List<ChannelConnection> = emptyList(),
    val emailAlerts: List<EmailAlert> = emptyList(),
    val actions: List<AssistantAction> = emptyList(),
    val reports: List<AssistantReport> = emptyList(),
    val tasks: List<AssistantAdminTask> = emptyList(),
    val connectUrl: String? = null,
    val notice: String? = null, val error: String? = null,
)

@HiltViewModel
class AdvancedAssistantViewModel @Inject constructor(private val repo: AdvancedAssistantRepository) : ViewModel() {
    private val data = MutableStateFlow(AssistantState())
    val state = data.asStateFlow()
    init { refresh() }

    fun refresh() = run {
        val connections = repo.connections()
        val gmailConnected = connections.any { it.channel == "email" && it.connected }
        val alerts = if (gmailConnected) repo.scanInbox() else repo.notifications()
        data.update {
            it.copy(
                connections = connections,
                emailAlerts = alerts,
                actions = repo.actions(),
                reports = repo.reports(),
                tasks = repo.tasks(),
            )
        }
    }
    fun scanInbox() = run {
        val alerts = repo.scanInbox()
        data.update {
            it.copy(
                emailAlerts = alerts,
                notice = if (alerts.any { alert -> alert.status == "new" }) {
                    "Inbox checked. Messages needing attention are ready."
                } else {
                    "Inbox checked. No new action is needed."
                },
            )
        }
    }
    fun reviewAlert(alert: EmailAlert) = run {
        val saved = repo.reviewAlert(alert.id)
        data.update {
            it.copy(emailAlerts = it.emailAlerts.map { old -> if (old.id == saved.id) saved else old })
        }
    }
    fun draftReply(alert: EmailAlert) = run {
        val saved = repo.draft(
            DraftRequest(
                channel = "email",
                instruction = "Draft a concise reply to this email. Do not invent facts or commitments.",
                recipient = alert.senderEmail.ifBlank { null },
                context = "Subject: " + alert.subject + "\nSender: " + alert.sender +
                    "\nEmail preview: " + alert.snippet,
            )
        )
        repo.reviewAlert(alert.id)
        data.update {
            it.copy(
                actions = listOf(saved) + it.actions,
                emailAlerts = it.emailAlerts.map { old ->
                    if (old.id == alert.id) old.copy(status = "reviewed") else old
                },
                notice = "Suggested reply prepared. Review and approve it before sending.",
            )
        }
    }
    fun connectGmail() = run { data.update { it.copy(connectUrl = repo.startGoogleOAuth().authorizationUrl) } }
    fun clearConnectUrl() { data.update { it.copy(connectUrl = null) } }
    fun draft(channel: String, recipient: String, instruction: String, context: String) = run {
        require(instruction.isNotBlank()) { "Tell the assistant what to prepare." }
        val saved = repo.draft(DraftRequest(channel, instruction.trim(), recipient.ifBlank { null }, context.ifBlank { null }))
        data.update { it.copy(actions = listOf(saved) + it.actions, notice = "Draft prepared for review.") }
    }
    fun edit(action: AssistantAction, recipient: String, subject: String, content: String) = run {
        val saved = repo.edit(action.id, ActionEdit(recipient.ifBlank { null }, subject.ifBlank { null }, content.trim()))
        replace(saved, "Saved. Fresh approval is required.")
    }
    fun approve(action: AssistantAction) = run { replace(repo.approve(action.id), "Approved. It can now be sent.") }
    fun dispatch(action: AssistantAction) = run { replace(repo.dispatch(action.id), "Sent successfully.") }
    fun cancel(action: AssistantAction) = run { replace(repo.cancel(action.id), "Action cancelled.") }
    fun report(title: String, objective: String, sources: String, type: String) = run {
        require(title.isNotBlank() && objective.isNotBlank() && sources.isNotBlank()) { "Complete all report fields." }
        val saved = repo.report(ReportRequest(title, objective, sources, type))
        data.update { it.copy(reports = listOf(saved) + it.reports, notice = "Report draft generated.") }
    }
    fun approveReport(value: AssistantReport) = run {
        val saved = repo.approveReport(value.id)
        data.update { it.copy(reports = it.reports.map { old -> if (old.id == saved.id) saved else old }, notice = "Report approved.") }
    }
    fun task(title: String, description: String) = run {
        val saved = repo.task(AdminTaskCreate(title, description))
        data.update { it.copy(tasks = listOf(saved) + it.tasks, notice = "Task planned.") }
    }
    fun advance(value: AssistantAdminTask) = run {
        val next = when (value.status) { "planned" -> "approved"; "approved" -> "in_progress"; else -> "completed" }
        val saved = repo.updateTask(value.id, next)
        data.update { it.copy(tasks = it.tasks.map { old -> if (old.id == saved.id) saved else old }) }
    }
    private fun replace(saved: AssistantAction, notice: String) {
        data.update { it.copy(actions = it.actions.map { old -> if (old.id == saved.id) saved else old }, notice = notice) }
    }
    private fun run(block: suspend () -> Unit) {
        if (data.value.busy) return
        viewModelScope.launch {
            data.update { it.copy(busy = true, error = null, notice = null) }
            try { block() } catch (error: Exception) {
                data.update { it.copy(error = error.message ?: "Advanced Assistant is unavailable.") }
            } finally { data.update { it.copy(busy = false) } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedAssistantScreen(viewModel: AdvancedAssistantViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    LaunchedEffect(state.connectUrl) {
        state.connectUrl?.let {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)))
            viewModel.clearConnectUrl()
        }
    }
    var section by remember { mutableStateOf("communications") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Advanced Assistant", style = MaterialTheme.typography.headlineMedium)
        Text("The AI does the work. You review and approve every external action.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("communications", "reports", "admin").forEach { value ->
                FilterChip(section == value, { section = value }, label = { Text(value.replaceFirstChar(Char::uppercase)) })
            }
        }
        when (section) {
            "reports" -> Reports(state, viewModel)
            "admin" -> Admin(state, viewModel)
            else -> Communications(state, viewModel)
        }
        state.notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun Communications(state: AssistantState, vm: AdvancedAssistantViewModel) {
    var channel by remember { mutableStateOf("email") }; var recipient by remember { mutableStateOf("") }
    var instruction by remember { mutableStateOf("") }; var context by remember { mutableStateOf("") }
    InboxAssistant(state, vm)
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Prepare communication", style = MaterialTheme.typography.titleLarge)
        Text("Nothing is sent or posted until you approve it.")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("email", "sms", "whatsapp", "facebook", "instagram").forEach { value ->
                FilterChip(channel == value, { channel = value }, label = { Text(value.replaceFirstChar(Char::uppercase)) })
            }
        }
        OutlinedTextField(recipient, { recipient = it }, label = { Text("Recipient or account") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(instruction, { instruction = it }, label = { Text("What should Sfumato prepare?") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(context, { context = it }, label = { Text("Context and facts") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Button({ vm.draft(channel, recipient, instruction, context) }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Generate draft") }
    } }
    Text("Review queue", style = MaterialTheme.typography.titleLarge)
    if (state.actions.isEmpty()) Text("No drafts yet.")
    state.actions.forEach { ActionCard(it, state.busy, vm) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(16.dp)) {
            Text("Official connections", fontWeight = FontWeight.Bold)
            if (state.connections.isEmpty()) Text("Checking secure backend connections…")
            state.connections.forEach { connection ->
                Text(
                    connection.channel.replaceFirstChar(Char::uppercase) + ": " +
                        if (connection.connected) "Connected" else connection.detail
                )
                if (connection.channel == "email" && !connection.connected) {
                    OutlinedButton(onClick = vm::connectGmail, enabled = !state.busy) {
                        Text("Connect Gmail securely")
                    }
                }
            }
            Text("Credentials remain encrypted on the secure backend. Unconnected channels never report false success.")
        }
    }
}

@Composable
private fun InboxAssistant(state: AssistantState, vm: AdvancedAssistantViewModel) {
    val connected = state.connections.any { it.channel == "email" && it.connected }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Autonomous Gmail assistant", style = MaterialTheme.typography.titleLarge)
            Text(
                if (connected) {
                    "Sfumato checks unread Gmail, flags action-needed messages, and suggests what to do. Nothing is sent without your approval."
                } else {
                    "Connect Gmail to monitor unread messages and receive action-needed suggestions."
                }
            )
            if (connected) {
                Button(
                    onClick = vm::scanInbox,
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Check inbox now") }
            } else {
                OutlinedButton(
                    onClick = vm::connectGmail,
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Connect or reconnect Gmail") }
            }
            val active = state.emailAlerts.filter { it.status == "new" }
            if (connected && active.isEmpty()) {
                Text("No unread emails currently need your attention.")
            }
            active.forEach { alert ->
                Divider()
                Text(
                    (if (alert.priority == "high") "URGENT · " else "") + alert.subject,
                    fontWeight = FontWeight.Bold,
                    color = if (alert.priority == "high") {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                )
                Text("From " + alert.sender)
                Text(alert.reason)
                Text(alert.suggestedAction, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.draftReply(alert) },
                        enabled = !state.busy && alert.senderEmail.isNotBlank(),
                    ) { Text("Draft reply") }
                    TextButton(
                        onClick = { vm.reviewAlert(alert) },
                        enabled = !state.busy,
                    ) { Text("Mark reviewed") }
                }
            }
        }
    }
}

@Composable
private fun ActionCard(action: AssistantAction, busy: Boolean, vm: AdvancedAssistantViewModel) {
    var recipient by remember(action.id, action.recipient) { mutableStateOf(action.recipient.orEmpty()) }
    var subject by remember(action.id, action.subject) { mutableStateOf(action.subject.orEmpty()) }
    var content by remember(action.id, action.content) { mutableStateOf(action.content) }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(action.channel.uppercase() + " · " + action.status.replace('_', ' '), fontWeight = FontWeight.Bold)
        OutlinedTextField(recipient, { recipient = it }, label = { Text("Recipient or account") }, modifier = Modifier.fillMaxWidth())
        if (action.channel == "email") OutlinedTextField(subject, { subject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(content, { content = it }, label = { Text("Draft") }, minLines = 4, modifier = Modifier.fillMaxWidth())
        if (action.status in listOf("awaiting_approval", "approved")) OutlinedButton({ vm.edit(action, recipient, subject, content) }, enabled = !busy) { Text("Save changes") }
        if (action.status == "awaiting_approval") Button({ vm.approve(action) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Approve this exact draft") }
        if (action.status == "approved") Button({ vm.dispatch(action) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (action.channel in listOf("facebook", "instagram")) "Publish approved post" else "Send approved message") }
        if (action.status !in listOf("sent", "cancelled")) TextButton({ vm.cancel(action) }, enabled = !busy) { Text("Cancel") }
        action.error?.let { Text(it.replace('_', ' '), color = MaterialTheme.colorScheme.error) }
    } }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun Reports(state: AssistantState, vm: AdvancedAssistantViewModel) {
    var title by remember { mutableStateOf("") }; var objective by remember { mutableStateOf("") }
    var sources by remember { mutableStateOf("") }; var type by remember { mutableStateOf("business") }
    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Create long report", style = MaterialTheme.typography.titleLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("business", "academic", "operations", "incident", "progress").forEach { value -> FilterChip(type == value, { type = value }, label = { Text(value.replaceFirstChar(Char::uppercase)) }) } }
        OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(objective, { objective = it }, label = { Text("Objective") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(sources, { sources = it }, label = { Text("Notes, facts and source material") }, minLines = 6, modifier = Modifier.fillMaxWidth())
        Button({ vm.report(title, objective, sources, type) }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Generate report draft") }
    } }
    state.reports.forEach { report -> Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(report.title, style = MaterialTheme.typography.titleLarge); Text(report.status); Text(report.content)
        if (report.status == "draft") Button({ vm.approveReport(report) }, enabled = !state.busy) { Text("Approve report") }
    } } }
}

@Composable
private fun Admin(state: AssistantState, vm: AdvancedAssistantViewModel) {
    var title by remember { mutableStateOf("") }; var description by remember { mutableStateOf("") }
    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Administration task", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(title, { title = it }, label = { Text("Task") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("Instructions") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Button({ vm.task(title, description) }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Plan task") }
    } }
    state.tasks.forEach { task -> Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(task.title, fontWeight = FontWeight.Bold); Text(task.description); Text(task.status.replace('_', ' '))
        if (task.status != "completed") Button({ vm.advance(task) }, enabled = !state.busy) { Text(when (task.status) { "planned" -> "Approve task"; "approved" -> "Start task"; else -> "Mark completed" }) }
    } } }
}
