package com.guru.android.security

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import java.net.URI
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

enum class SafetySeverity(val label: String, val score: Int) {
    SAFE("Safe", 0), CAUTION("Caution", 30), HIGH("High risk", 65), CRITICAL("Critical", 90),
}

data class SafetyFinding(
    val title: String,
    val detail: String,
    val severity: SafetySeverity,
    val recommendedAction: String,
)

data class SafetyAssessment(
    val subject: String,
    val score: Int,
    val severity: SafetySeverity,
    val findings: List<SafetyFinding>,
    val mayProceed: Boolean,
) {
    companion object {
        fun from(subject: String, findings: List<SafetyFinding>): SafetyAssessment {
            val score = findings.maxOfOrNull { it.severity.score } ?: 0
            val severity = SafetySeverity.entries.last { score >= it.score }
            return SafetyAssessment(
                subject = subject,
                score = score,
                severity = severity,
                findings = findings.ifEmpty {
                    listOf(
                        SafetyFinding(
                            "No immediate warning signs",
                            "Sfumato did not detect common local warning signs. This is not a guarantee that the item is harmless.",
                            SafetySeverity.SAFE,
                            "Continue carefully and verify unexpected requests independently.",
                        ),
                    )
                },
                mayProceed = severity != SafetySeverity.CRITICAL,
            )
        }
    }
}

object CyberSafetyEngine {
    private val shorteners = setOf("bit.ly", "tinyurl.com", "t.co", "cutt.ly", "is.gd", "rb.gy")
    private val urgentWords = setOf("verify", "suspend", "urgent", "password", "wallet", "prize", "claim", "invoice", "login")
    private val highRiskPermissions = setOf(
        "android.permission.BIND_ACCESSIBILITY_SERVICE",
        "android.permission.REQUEST_INSTALL_PACKAGES",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.READ_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.READ_CALL_LOG",
        "android.permission.WRITE_CALL_LOG",
    )
    private val permissionLabels = mapOf(
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to "Accessibility service control",
        "android.permission.REQUEST_INSTALL_PACKAGES" to "install unknown apps",
        "android.permission.SYSTEM_ALERT_WINDOW" to "draw over other apps",
        "android.permission.READ_SMS" to "read SMS messages",
        "android.permission.RECEIVE_SMS" to "receive SMS messages",
        "android.permission.READ_CALL_LOG" to "read call history",
        "android.permission.WRITE_CALL_LOG" to "change call history",
    )

    fun assessLink(rawInput: String): SafetyAssessment {
        val input = rawInput.trim()
        val findings = mutableListOf<SafetyFinding>()
        val uri = runCatching { URI(if ("://" in input) input else "https://$input") }.getOrNull()
        if (uri == null || uri.host.isNullOrBlank()) {
            return SafetyAssessment.from(
                input.ifBlank { "Link" },
                listOf(SafetyFinding("Invalid or disguised link", "The address could not be parsed as a normal website link.", SafetySeverity.CRITICAL, "Do not open it. Ask the sender for the official website address.")),
            )
        }

        val host = uri.host.lowercase(Locale.ROOT).trimEnd('.')
        if (uri.scheme.lowercase(Locale.ROOT) != "https") findings += SafetyFinding("Connection is not encrypted", "The link does not use HTTPS.", SafetySeverity.HIGH, "Do not enter passwords, payment details or personal information.")
        if (host.startsWith("xn--") || host.contains(".xn--")) findings += SafetyFinding("Internationalised look-alike domain", "The domain uses encoded characters that can imitate a trusted brand.", SafetySeverity.HIGH, "Open the organisation's official app or type its address manually.")
        if (host.matches(Regex("""\d{1,3}(\.\d{1,3}){3}"""))) findings += SafetyFinding("Raw IP address", "Legitimate customer services rarely send sign-in links using a bare IP address.", SafetySeverity.HIGH, "Do not continue unless your verified administrator confirms this address.")
        if (host in shorteners) findings += SafetyFinding("Destination is hidden", "This shortened address conceals the final website.", SafetySeverity.CAUTION, "Verify the sender and preview the final destination before opening.")
        if (host.split('.').size > 4 || host.count { it == '-' } >= 3) findings += SafetyFinding("Unusual domain structure", "The domain contains many subdomains or separators, a pattern sometimes used by phishing pages.", SafetySeverity.CAUTION, "Compare the registered domain with the organisation's official website.")
        if (urgentWords.count { it in input.lowercase(Locale.ROOT) } >= 2) findings += SafetyFinding("Pressure or credential language", "The link contains several words commonly used in urgent phishing messages.", SafetySeverity.CAUTION, "Contact the organisation through a known number before responding.")
        if (uri.userInfo != null) findings += SafetyFinding("Misleading address format", "The link contains syntax that can hide the real destination.", SafetySeverity.CRITICAL, "Do not open this link.")
        return SafetyAssessment.from(host, findings)
    }

    fun assessDevice(context: Context): SafetyAssessment {
        val findings = mutableListOf<SafetyFinding>()
        val patch = Build.VERSION.SECURITY_PATCH
        if (patch.isBlank()) {
            findings += SafetyFinding("Security patch date unavailable", "Sfumato could not confirm the device security-patch level.", SafetySeverity.CAUTION, "Open Android security settings and check for an update.")
        } else {
            runCatching {
                val patchDate = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).parse(patch) ?: return@runCatching
                val patchCalendar = Calendar.getInstance().apply { time = patchDate }
                val now = Calendar.getInstance()
                val months = (now.get(Calendar.YEAR) - patchCalendar.get(Calendar.YEAR)) * 12L + now.get(Calendar.MONTH) - patchCalendar.get(Calendar.MONTH)
                when {
                    months >= 12 -> findings += SafetyFinding("Security patch is very old", "The last reported Android security patch is $patch.", SafetySeverity.HIGH, "Install the latest manufacturer security update as soon as possible.")
                    months >= 6 -> findings += SafetyFinding("Security patch needs attention", "The last reported Android security patch is $patch.", SafetySeverity.CAUTION, "Check for a newer system update.")
                }
            }
        }
        val keyguard = context.getSystemService(KeyguardManager::class.java)
        if (keyguard?.isDeviceSecure != true) findings += SafetyFinding("No secure screen lock detected", "The phone does not appear to use a secure PIN, password or biometric lock.", SafetySeverity.HIGH, "Set a secure screen lock before storing business or developer information.")
        val developerMode = runCatching { Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1 }.getOrDefault(false)
        if (developerMode) findings += SafetyFinding("Developer options are enabled", "Developer options can increase risk when USB debugging or unsafe settings are left active.", SafetySeverity.CAUTION, "Review Developer options and disable anything you do not actively need.")
        val adbEnabled = runCatching {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        }.getOrDefault(false)
        if (adbEnabled) findings += SafetyFinding(
            "USB debugging is enabled",
            "A computer authorised for Android debugging can perform powerful actions on this phone.",
            SafetySeverity.HIGH,
            "Disable USB debugging when you are not actively developing and revoke computers you do not recognise.",
        )
        val remoteLockConfigured = RemoteLockPreferences(context).deviceSecret != null
        if (remoteLockConfigured) {
            val policyManager = context.getSystemService(DevicePolicyManager::class.java)
            val admin = ComponentName(context, HiGuruDeviceAdminReceiver::class.java)
            if (!policyManager.isAdminActive(admin)) findings += SafetyFinding(
                "Remote Lock permission was removed",
                "This phone is registered for Remote Lock, but Android no longer allows Sfumato to lock it.",
                SafetySeverity.HIGH,
                "Open Device Protection and re-enable Remote Lock or remove this phone from protected devices.",
            )
        }
        val connectivity = context.getSystemService(ConnectivityManager::class.java)
        val capabilities = connectivity?.activeNetwork?.let(connectivity::getNetworkCapabilities)
        if (capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) != true) findings += SafetyFinding("Network is not validated", "Android has not confirmed that the current connection reaches the internet safely.", SafetySeverity.CAUTION, "Avoid sensitive work until you connect to a trusted network.")
        if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) findings += SafetyFinding("VPN is active", "Traffic is currently routed through a VPN. This may be expected on a company device.", SafetySeverity.SAFE, "Confirm that the VPN belongs to you or your organisation.")
        return SafetyAssessment.from("This device", findings)
    }

    fun assessApp(context: Context, packageName: String): SafetyAssessment {
        @Suppress("DEPRECATION")
        val signingFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES else android.content.pm.PackageManager.GET_SIGNATURES
        val packageInfo = context.packageManager.getPackageInfo(packageName, android.content.pm.PackageManager.GET_PERMISSIONS or signingFlag)
        return assessPackageInfo(packageInfo)
    }

    fun assessPackageInfo(packageInfo: PackageInfo): SafetyAssessment {
        val findings = mutableListOf<SafetyFinding>()
        val risky = packageInfo.requestedPermissions?.toSet().orEmpty().intersect(highRiskPermissions)
        if (risky.isNotEmpty()) {
            val namedPermissions = risky.map { permissionLabels[it] ?: it.substringAfterLast('.') }.sorted().joinToString(", ")
            findings += SafetyFinding(
                "Sensitive capabilities requested",
                "This app requests: $namedPermissions. A permission request alone does not prove malicious intent.",
                if (risky.size >= 3) SafetySeverity.HIGH else SafetySeverity.CAUTION,
                "Open Android Settings > Apps > this app > Permissions. Allow only capabilities required for a feature you trust; deny or uninstall the app if its purpose does not justify them.",
            )
        }
        val appInfo = packageInfo.applicationInfo
        if (appInfo != null && appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) findings += SafetyFinding("Debuggable production app", "The installed app allows debugging, which is unusual for a public production release.", SafetySeverity.HIGH, "Confirm that this is an intentional development build.")
        if (appInfo != null && appInfo.targetSdkVersion < Build.VERSION.SDK_INT - 4) findings += SafetyFinding("Targets an old Android version", "The app targets Android API ${appInfo.targetSdkVersion}, so newer platform protections may not fully apply.", SafetySeverity.CAUTION, "Check for an updated version from the official developer.")
        @Suppress("DEPRECATION")
        val signatureCount = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) packageInfo.signingInfo?.apkContentsSigners?.size ?: 0 else packageInfo.signatures?.size ?: 0
        if (signatureCount == 0) findings += SafetyFinding("Signing identity unavailable", "Sfumato could not confirm the installed package signing information.", SafetySeverity.HIGH, "Avoid using the app for sensitive information until its source is verified.")
        return SafetyAssessment.from(packageInfo.packageName, findings)
    }

    fun installationId(context: Context): String {
        val prefs = context.getSharedPreferences("higuru_cyber_safety", Context.MODE_PRIVATE)
        val existing = prefs.getString("installation_id", null)
        if (existing != null) return existing
        val generated = UUID.randomUUID().toString()
        prefs.edit().putString("installation_id", generated).apply()
        return generated
    }

    fun shortDeviceFingerprint(context: Context): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(installationId(context).toByteArray()).joinToString("") { "%02x".format(it) }
        return digest.take(12).uppercase(Locale.ROOT)
    }
}
