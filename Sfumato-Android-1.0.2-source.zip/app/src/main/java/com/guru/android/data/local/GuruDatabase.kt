package com.guru.android.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Message::class], version = 1, exportSchema = false)
abstract class GuruDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile
        private var INSTANCE: GuruDatabase? = null

        fun getDatabase(context: Context): GuruDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GuruDatabase::class.java,
                    "guru_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
