package com.guru.android.business

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.IOException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import javax.inject.Inject
import javax.inject.Singleton

private const val MIN_TASK_LENGTH = 8
private const val MAX_TASK_LENGTH = 4000
private const val MAX_CONTEXT_LENGTH = 6000

data class BusinessRequest(val mode: String, val area: String, val task: String, @SerializedName("organization_context") val organizationContext: String?, @SerializedName("document_type") val documentType: String?)
data class BusinessResponse(@SerializedName("run_id") val runId: String, val mode: String, val area: String, val content: String, @SerializedName("approvals_required") val approvalsRequired: List<String>, @SerializedName("execution_status") val executionStatus: String)

interface BusinessService {
    @POST("v1/business/assistant")
    suspend fun assist(@Header("Authorization") authorization: String, @Body request: BusinessRequest): BusinessResponse
}

@Singleton
class BusinessRepository @Inject constructor(private val service: BusinessService) {
    suspend fun assist(request: BusinessRequest): BusinessResponse {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        val token = checkNotNull(user.getIdToken(true).await().token) { "Session expired." }
        return service.assist("Bearer $token", request)
    }
}

data class BusinessState(val mode: String = "standard", val area: String = "general_admin", val documentType: String = "action_plan", val task: String = "", val context: String = "", val busy: Boolean = false, val result: BusinessResponse? = null, val error: String? = null)

@HiltViewModel
class BusinessViewModel @Inject constructor(private val repository: BusinessRepository) : ViewModel() {
    private val mutableState = MutableStateFlow(BusinessState())
    val state = mutableState.asStateFlow()
    private fun edit(transform: (BusinessState) -> BusinessState) = mutableState.update { transform(it).copy(result = null, error = null) }
    fun mode(value: String) = edit { it.copy(mode = value) }
    fun area(value: String) = edit { it.copy(area = value) }
    fun document(value: String) = edit { it.copy(documentType = value) }
    fun task(value: String) = edit { it.copy(task = value.take(MAX_TASK_LENGTH)) }
    fun context(value: String) = edit { it.copy(context = value.take(MAX_CONTEXT_LENGTH)) }

    fun generate() {
        val current = mutableState.value
        if (current.busy) return
        val task = current.task.trim()
        if (task.length < MIN_TASK_LENGTH) {
            mutableState.update { it.copy(error = "Describe the business task in at least $MIN_TASK_LENGTH characters.") }
            return
        }
        viewModelScope.launch {
            mutableState.update { it.copy(busy = true, error = null, result = null) }
            try {
                val result = repository.assist(BusinessRequest(current.mode, current.area, task, current.context.trim().takeIf(String::isNotBlank), current.documentType))
                require(result.content.isNotBlank()) { "The assistant returned an empty draft. Please try again." }
                require(result.executionStatus == "draft_only") { "Unexpected execution status. Nothing was shared or executed." }
                mutableState.update { it.copy(result = result) }
            } catch (error: Exception) {
                val message = when (error) {
                    is HttpException -> when (error.code()) {
                        401 -> "Your session expired. Sign in again."
                        403 -> "An active Business plan is required for Business Assistant."
                        422 -> "Please check the task and organisation context and try again."
                        429 -> "Enoch is busy. Try again shortly."
                        503 -> "Business Assistant is temporarily unavailable."
                        else -> "Business Assistant could not complete the request (HTTP ${error.code()})."
                    }
                    is IOException -> "No network connection. Check your internet connection and try again."
                    else -> error.message ?: "Could not generate the business document."
                }
                mutableState.update { it.copy(error = message) }
            } finally { mutableState.update { it.copy(busy = false) } }
        }
    }
}

internal const val BUSINESS_PRIVACY_NOTICE = "Privacy: Sfumato processes only the information you deliberately enter to prepare your requested draft. Human approval is required before communications, payments, contracts, employment actions, filings, deletion, publication or security changes."

private val areas = linkedMapOf("general_admin" to "General administration", "executive" to "Executive management", "operations" to "Operations", "finance" to "Finance and accounting", "human_resources" to "Human resources", "sales" to "Sales", "marketing" to "Marketing", "customer_service" to "Customer service", "procurement" to "Procurement", "projects" to "Projects", "legal_compliance" to "Legal and compliance", "risk" to "Risk management", "it_cybersecurity" to "IT and cybersecurity", "records" to "Records and documentation")
private val documents = linkedMapOf("action_plan" to "Action plan", "business_plan" to "Business plan", "proposal" to "Proposal", "report" to "Business report", "policy" to "Policy", "sop" to "Standard operating procedure", "meeting_minutes" to "Meeting minutes", "email" to "Professional email", "memo" to "Memo", "agenda" to "Meeting agenda", "project_plan" to "Project plan", "budget_brief" to "Budget brief", "risk_register" to "Risk register", "job_description" to "Job description", "performance_plan" to "Performance plan", "marketing_plan" to "Marketing plan", "sales_plan" to "Sales plan", "customer_response" to "Customer response", "procurement_brief" to "Procurement brief", "compliance_checklist" to "Compliance checklist", "incident_brief" to "Emergency incident brief")

@Composable
fun BusinessScreen(viewModel: BusinessViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var areaMenu by remember { mutableStateOf(false) }
    var documentMenu by remember { mutableStateOf(false) }
    val taskValid = state.task.trim().length >= MIN_TASK_LENGTH
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Enoch Business Assistant", style = MaterialTheme.typography.headlineMedium)
        Text("Complete business administration, professional documents and approval-ready decisions.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModeButton("standard", "Standard", state.mode, viewModel::mode); ModeButton("advanced", "Advanced", state.mode, viewModel::mode); ModeButton("emergency", "Emergency", state.mode, viewModel::mode)
        }
        Text(when (state.mode) { "advanced" -> "Coordinates departments, priorities, owners and deadlines in parallel."; "emergency" -> "Damage control for cyber, legal, operational, financial or public crises."; else -> "Monitors, analyses and drafts work for your approval." }, color = MaterialTheme.colorScheme.onSurfaceVariant)
        DropdownField("Business area", areas[state.area].orEmpty(), areaMenu, { areaMenu = true }, { areaMenu = false }, areas) { viewModel.area(it); areaMenu = false }
        DropdownField("Document or output", documents[state.documentType].orEmpty(), documentMenu, { documentMenu = true }, { documentMenu = false }, documents) { viewModel.document(it); documentMenu = false }
        OutlinedTextField(state.context, viewModel::context, label = { Text("Organisation context (optional)") }, placeholder = { Text("Industry, size, goals, policies, deadlines and relevant facts") }, supportingText = { Text("${state.context.length}/$MAX_CONTEXT_LENGTH") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.task, viewModel::task, label = { Text("What must Enoch prepare?") }, placeholder = { Text("Create a complete onboarding SOP for new employees") }, supportingText = { Text("${state.task.length}/$MAX_TASK_LENGTH") }, isError = state.task.isNotBlank() && !taskValid, minLines = 4, modifier = Modifier.fillMaxWidth())
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) { Text(BUSINESS_PRIVACY_NOTICE, Modifier.padding(14.dp)) }
        Button(viewModel::generate, enabled = !state.busy && taskValid, modifier = Modifier.fillMaxWidth()) { Text("Generate business document") }
        if (state.busy) { CircularProgressIndicator(); Text("Enoch is coordinating the business work...") }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        state.result?.let { result ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Approval-ready draft", style = MaterialTheme.typography.titleLarge); Text(result.content)
                Text("Draft only — no external action was performed.", color = MaterialTheme.colorScheme.primary)
                if (result.approvalsRequired.isNotEmpty()) { Text("Human approval required before:", style = MaterialTheme.typography.titleMedium); result.approvalsRequired.forEach { Text("• $it") } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ clipboard.setText(AnnotatedString(result.content)) }) { Text("Copy") }
                    Button({ val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, documents[state.documentType]); putExtra(Intent.EXTRA_TEXT, result.content) }; context.startActivity(Intent.createChooser(share, "Share business draft")) }) { Text("Share") }
                }
            } }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun ModeButton(value: String, label: String, selected: String, onSelect: (String) -> Unit) { if (value == selected) Button({ onSelect(value) }) { Text(label) } else OutlinedButton({ onSelect(value) }) { Text(label) } }
@Composable private fun DropdownField(label: String, value: String, expanded: Boolean, onExpand: () -> Unit, onDismiss: () -> Unit, options: Map<String, String>, onSelect: (String) -> Unit) { Column { Text(label, style = MaterialTheme.typography.labelLarge); Box { OutlinedButton(onExpand, modifier = Modifier.fillMaxWidth()) { Text(value) }; DropdownMenu(expanded, onDismissRequest = onDismiss) { options.forEach { (key, name) -> DropdownMenuItem(text = { Text(name) }, onClick = { onSelect(key) }) } } } } }
