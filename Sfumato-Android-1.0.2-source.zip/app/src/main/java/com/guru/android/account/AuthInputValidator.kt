package com.guru.android.account

object AuthInputValidator {
    private val emailPattern = Regex("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", RegexOption.IGNORE_CASE)

    fun emailError(email: String): String? = when {
        email.isBlank() -> "Email is required."
        !emailPattern.matches(email.trim()) -> "Enter a valid email address."
        else -> null
    }

    fun passwordError(password: String): String? = when {
        password.isBlank() -> "Password is required."
        password.length < 8 -> "Use at least 8 characters."
        else -> null
    }

    fun passwordConfirmationError(password: String, confirmation: String): String? = when {
        confirmation.isBlank() -> "Confirm your password."
        confirmation != password -> "The passwords do not match."
        else -> null
    }

    fun displayNameError(displayName: String): String? =
        if (displayName.trim().length < 2) "Enter your name." else null

    fun termsError(accepted: Boolean): String? =
        if (accepted) null else "Accept the Terms and Privacy Policy to create an account."
}
