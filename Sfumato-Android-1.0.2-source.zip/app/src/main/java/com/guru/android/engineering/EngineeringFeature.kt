package com.guru.android.engineering

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.annotations.SerializedName
import com.guru.android.homework.HomeworkAttachmentButton
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import retrofit2.HttpException
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

private const val MAX_TASK = 5_000
private const val MAX_CONTEXT = 7_000
private const val MAX_DRAWING = 12_000
private const val MAX_JURISDICTION = 160
private const val MAX_STANDARDS = 800

data class EngineeringRequest(
    val discipline: String,
    val mode: String,
    val task: String,
    @SerializedName("project_context") val projectContext: String?,
    @SerializedName("drawing_notes") val drawingNotes: String?,
    val jurisdiction: String?,
    val standards: String?,
    val units: String,
)

data class EngineeringResponse(
    @SerializedName("run_id") val runId: String,
    val discipline: String,
    val mode: String,
    val content: String,
    @SerializedName("safety_status") val safetyStatus: String,
    val limitations: List<String>,
)

interface EngineeringService {
    @POST("v1/engineering/assist")
    suspend fun assist(@Header("Authorization") authorization: String, @Body request: EngineeringRequest): EngineeringResponse
}

@Singleton
class EngineeringRepository @Inject constructor(private val service: EngineeringService) {
    suspend fun assist(request: EngineeringRequest): EngineeringResponse {
        val user = checkNotNull(FirebaseAuth.getInstance().currentUser) { "Sign in first." }
        val token = checkNotNull(user.getIdToken(true).await().token) { "Session expired." }
        return service.assist("Bearer $token", request)
    }
}

data class EngineeringState(
    val discipline: String = "general", val mode: String = "explain", val units: String = "metric",
    val task: String = "", val projectContext: String = "", val drawingNotes: String = "",
    val jurisdiction: String = "", val standards: String = "", val attachmentName: String? = null,
    val attachmentError: String? = null, val busy: Boolean = false, val result: EngineeringResponse? = null,
    val error: String? = null,
)

@HiltViewModel
class EngineeringViewModel @Inject constructor(private val repository: EngineeringRepository) : ViewModel() {
    private val mutableState = MutableStateFlow(EngineeringState())
    val state = mutableState.asStateFlow()
    private fun changed(block: (EngineeringState) -> EngineeringState) = mutableState.update { block(it).copy(result = null, error = null) }
    fun discipline(value: String) = changed { it.copy(discipline = value) }
    fun mode(value: String) = changed { it.copy(mode = value) }
    fun units(value: String) = changed { it.copy(units = value) }
    fun task(value: String) = changed { it.copy(task = value.take(MAX_TASK)) }
    fun context(value: String) = changed { it.copy(projectContext = value.take(MAX_CONTEXT)) }
    fun drawingNotes(value: String) = changed { it.copy(drawingNotes = value.take(MAX_DRAWING), attachmentName = null) }
    fun jurisdiction(value: String) = changed { it.copy(jurisdiction = value.take(MAX_JURISDICTION)) }
    fun standards(value: String) = changed { it.copy(standards = value.take(MAX_STANDARDS)) }
    fun attachDrawing(name: String, text: String) = changed {
        val prefix = "Extracted from $name:\n"
        it.copy(drawingNotes = (prefix + text).take(MAX_DRAWING), attachmentName = name, attachmentError = null)
    }
    fun attachmentError(message: String) = mutableState.update { it.copy(attachmentError = message, error = null) }

    fun analyse() {
        val current = mutableState.value
        if (current.busy) return
        if (current.task.trim().length < 10) {
            mutableState.update { it.copy(error = "Describe the engineering question in more detail.") }
            return
        }
        viewModelScope.launch {
            mutableState.update { it.copy(busy = true, error = null, result = null) }
            try {
                val response = repository.assist(EngineeringRequest(
                    current.discipline, current.mode, current.task.trim(),
                    current.projectContext.trim().takeIf(String::isNotBlank),
                    current.drawingNotes.trim().takeIf(String::isNotBlank),
                    current.jurisdiction.trim().takeIf(String::isNotBlank),
                    current.standards.trim().takeIf(String::isNotBlank), current.units,
                ))
                if (response.content.isBlank()) throw IllegalStateException("Engineering Guru returned an empty response. Please try again.")
                mutableState.update { it.copy(result = response) }
            } catch (error: Exception) {
                val message = when (error) {
                    is HttpException -> when (error.code()) {
                        401 -> "Your session expired. Sign in again."
                        403 -> "Engineering Guru is available on the Business plan."
                        422 -> "One of the engineering inputs is invalid or too long. Please shorten it and try again."
                        429 -> "Engineering Guru is busy. Try again shortly."
                        503 -> "Engineering Guru is temporarily unavailable. Try again shortly."
                        else -> "Engineering Guru could not complete the request (HTTP ${error.code()})."
                    }
                    is IOException -> "No connection to Engineering Guru. Check your internet connection and try again."
                    else -> error.message ?: "Could not complete the engineering review."
                }
                mutableState.update { it.copy(error = message) }
            } finally { mutableState.update { it.copy(busy = false) } }
        }
    }
}

internal fun cleanEngineeringText(value: String): String = value
    .replace(Regex("^#{1,6}\\s*", setOf(RegexOption.MULTILINE)), "").replace("**", "")
    .replace("```", "").replace("`", "").trim()

private val disciplines = linkedMapOf("general" to "General engineering", "civil" to "Civil", "structural" to "Structural", "mechanical" to "Mechanical", "electrical" to "Electrical", "architectural" to "Architectural concepts")
private val modes = linkedMapOf("explain" to "Explain a concept", "calculation_review" to "Review calculations", "design_review" to "Review a design", "materials_estimate" to "Estimate materials", "codes_checklist" to "Codes and standards checklist")

@Composable
fun EngineeringScreen(viewModel: EngineeringViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState(); val context = LocalContext.current; val clipboard = LocalClipboardManager.current
    var disciplineMenu by remember { mutableStateOf(false) }; var modeMenu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Engineering Guru", style = MaterialTheme.typography.headlineMedium)
        Text("Engineering explanations, calculation checks, drawing reviews and transparent estimates.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        EngineeringDropdown("Discipline", disciplines[state.discipline].orEmpty(), disciplineMenu, { disciplineMenu = true }, { disciplineMenu = false }, disciplines) { viewModel.discipline(it); disciplineMenu = false }
        EngineeringDropdown("Task", modes[state.mode].orEmpty(), modeMenu, { modeMenu = true }, { modeMenu = false }, modes) { viewModel.mode(it); modeMenu = false }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("metric" to "Metric", "imperial" to "Imperial", "mixed" to "Mixed").forEach { if (state.units == it.first) Button({ viewModel.units(it.first) }) { Text(it.second) } else OutlinedButton({ viewModel.units(it.first) }) { Text(it.second) } }
        }
        OutlinedTextField(state.projectContext, viewModel::context, label = { Text("Project context (optional)") }, placeholder = { Text("Location, project type, use, environment and design stage") }, minLines = 3, supportingText = { Text("${state.projectContext.length}/$MAX_CONTEXT") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.jurisdiction, viewModel::jurisdiction, label = { Text("Project jurisdiction (recommended)") }, placeholder = { Text("South Africa, Gauteng municipality, or applicable authority") }, singleLine = true, supportingText = { Text("${state.jurisdiction.length}/$MAX_JURISDICTION") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.standards, viewModel::standards, label = { Text("Known standards and editions (optional)") }, placeholder = { Text("Only enter standards you have confirmed for this project") }, minLines = 2, supportingText = { Text("${state.standards.length}/$MAX_STANDARDS") }, modifier = Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HomeworkAttachmentButton(onLoaded = { viewModel.attachDrawing(it.name, it.text) }, onError = viewModel::attachmentError, contentDescription = "Attach or scan engineering drawing", documentLabel = "Upload drawing PDF or document", photoLabel = "Choose drawing photo", scanLabel = "Scan drawing with camera")
                Text(state.attachmentName ?: "Attach PDF, photo or scan drawing notes")
            }
            Text("Uploading another drawing replaces the previous extracted drawing text.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            state.attachmentError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } }
        OutlinedTextField(state.drawingNotes, viewModel::drawingNotes, label = { Text("Drawing or CAD notes (optional)") }, placeholder = { Text("Dimensions, materials, loads, supports and details visible in the drawing") }, minLines = 3, supportingText = { Text("${state.drawingNotes.length}/$MAX_DRAWING") }, modifier = Modifier.fillMaxWidth())
        Text("Quick engineering tasks", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip({ viewModel.task("Review the supplied concept and identify missing inputs, assumptions, safety risks and professional checks.") }, label = { Text("Review concept") })
            AssistChip({ viewModel.task("Check the supplied calculation step by step, verify units and flag assumptions or missing load cases.") }, label = { Text("Check calculation") })
            AssistChip({ viewModel.task("Prepare a transparent preliminary material estimate with formulas, units, waste assumptions and exclusions.") }, label = { Text("Estimate materials") })
        }
        OutlinedTextField(state.task, viewModel::task, label = { Text("Engineering question") }, placeholder = { Text("Review this concept, show the method and identify missing safety information") }, minLines = 4, supportingText = { Text("${state.task.length}/$MAX_TASK") }, modifier = Modifier.fillMaxWidth())
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Professional review required", style = MaterialTheme.typography.titleMedium)
            Text("Sfumato provides concept and decision support. It does not certify, stamp, approve or submit engineering designs. Safety-critical work must be verified by a qualified professional.")
        } }
        Button(viewModel::analyse, enabled = !state.busy && state.task.trim().length >= 10, modifier = Modifier.fillMaxWidth()) { Text("Run engineering review") }
        if (state.busy) { CircularProgressIndicator(); Text("Engineering Guru is checking assumptions, units and risks…") }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        state.result?.let { result -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Engineering review", style = MaterialTheme.typography.titleLarge); val displayContent = cleanEngineeringText(result.content); Text(displayContent)
            val status = when (result.safetyStatus) { "professional_review_required" -> "Professional verification required"; else -> "Safety review status: ${result.safetyStatus.replace('_', ' ')}" }
            Text("Status: $status", color = MaterialTheme.colorScheme.primary)
            result.limitations.forEach { Text("• $it") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ clipboard.setText(AnnotatedString(displayContent)) }) { Text("Copy") }
                Button({ val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Sfumato Engineering review"); putExtra(Intent.EXTRA_TEXT, displayContent) }; context.startActivity(Intent.createChooser(share, "Share engineering review")) }) { Text("Share") }
            }
        } } }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun EngineeringDropdown(label: String, value: String, expanded: Boolean, onExpand: () -> Unit, onDismiss: () -> Unit, options: Map<String, String>, onSelect: (String) -> Unit) {
    Column { Text(label, style = MaterialTheme.typography.labelLarge); Box { OutlinedButton(onExpand, modifier = Modifier.fillMaxWidth()) { Text(value) }; DropdownMenu(expanded, onDismissRequest = onDismiss) { options.forEach { (key, name) -> DropdownMenuItem(text = { Text(name) }, onClick = { onSelect(key) }) } } } }
}