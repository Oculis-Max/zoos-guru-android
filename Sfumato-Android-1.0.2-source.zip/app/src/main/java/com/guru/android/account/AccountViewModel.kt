package com.guru.android.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.FirebaseFirestoreException
import com.guru.android.billing.BillingRepository
import com.guru.android.billing.VoucherRedemptionRequest
import com.guru.android.domain.AccountProfile
import com.guru.android.domain.AccountSession
import com.guru.android.network.NetworkMonitor
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException

data class AccountUiState(
    val session: AccountSession = AccountSession.Loading,
    val profile: AccountProfile? = null,
    val profileLoaded: Boolean = false,
    val isEmailVerified: Boolean = false,
    val securityLoaded: Boolean = false,
    val planTier: String = "free",
    val planLoaded: Boolean = false,
    val planActive: Boolean = false,
    val autonomousCoding: Boolean = false,
    val planSource: String? = null,
    val sponsor: String? = null,
    val sponsoredUntil: String? = null,
    val isOnline: Boolean = true,
    val isWorking: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

@HiltViewModel
class AccountViewModel @Inject constructor(
    private val repository: FirebaseAccountRepository,
    private val networkMonitor: NetworkMonitor,
    private val billingRepository: BillingRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(AccountUiState())
    val uiState: StateFlow<AccountUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.session.collect { session ->
                val current = _uiState.value
                val currentUid = (current.session as? AccountSession.SignedIn)?.user?.uid
                val nextUid = (session as? AccountSession.SignedIn)?.user?.uid
                val sameSignedInUser = currentUid != null && currentUid == nextUid
                _uiState.value = if (session is AccountSession.SignedIn) {
                    current.copy(
                        session = session,
                        profile = if (sameSignedInUser) current.profile else null,
                        profileLoaded = if (sameSignedInUser) current.profileLoaded else false,
                        planLoaded = if (sameSignedInUser) current.planLoaded else false,
                    )
                } else {
                    current.copy(
                        session = session,
                        profile = null,
                        profileLoaded = false,
                        isEmailVerified = false,
                        securityLoaded = false,
                        planTier = "free",
                        planActive = false,
                        autonomousCoding = false,
                        planLoaded = false,
                        planSource = null,
                        sponsor = null,
                        sponsoredUntil = null,
                    )
                }
                if (session is AccountSession.SignedIn) {
                    if (!sameSignedInUser || !_uiState.value.profileLoaded) loadProfile()
                    refreshSecurity()
                    refreshPlan()
                }
            }
        }
        viewModelScope.launch {
            networkMonitor.observeNetworkStatus().collect { online ->
                _uiState.value = _uiState.value.copy(isOnline = online)
            }
        }
    }

    fun createAccount(email: String, password: String, confirmPassword: String, displayName: String, acceptedTerms: Boolean) {
        val error = AuthInputValidator.emailError(email)
            ?: AuthInputValidator.passwordError(password)
            ?: AuthInputValidator.passwordConfirmationError(password, confirmPassword)
            ?: AuthInputValidator.displayNameError(displayName)
            ?: AuthInputValidator.termsError(acceptedTerms)
        if (error != null) return showError(error)
        launchOperation { repository.createAccount(email, password, displayName) }
    }

    fun signIn(email: String, password: String) {
        val error = AuthInputValidator.emailError(email) ?: AuthInputValidator.passwordError(password)
        if (error != null) return showError(error)
        launchOperation { repository.signIn(email, password) }
    }

    fun sendPasswordReset(email: String) {
        val error = AuthInputValidator.emailError(email)
        if (error != null) return showError(error)
        launchOperation(successNotice = "Password reset instructions were sent if that account exists.") {
            repository.sendPasswordReset(email)
        }
    }

    fun saveProfile(displayName: String, countryCode: String, schoolLevel: String) {
        val session = _uiState.value.session as? AccountSession.SignedIn ?: return
        val error = AuthInputValidator.displayNameError(displayName)
        if (error != null) return showError(error)
        launchOperation(successNotice = "Profile saved.") {
            val existing = _uiState.value.profile
            val profile = AccountProfile(
                uid = session.user.uid, email = session.user.email, displayName = displayName.trim(),
                countryCode = countryCode.trim(), schoolLevel = schoolLevel.trim(), institution = existing?.institution.orEmpty(),
                grade = existing?.grade.orEmpty(), curriculum = existing?.curriculum.orEmpty(), subjects = existing?.subjects.orEmpty(),
                accountType = existing?.accountType ?: "free", role = existing?.role.orEmpty(), organisation = existing?.organisation.orEmpty(),
                industry = existing?.industry.orEmpty(), focusAreas = existing?.focusAreas.orEmpty(), onboardingVersion = existing?.onboardingVersion ?: 0,
                onboardingComplete = existing?.onboardingComplete ?: false,
            )
            repository.saveAccountProfile(profile)
            _uiState.value = _uiState.value.copy(profile = profile)
        }
    }

    fun completeOnboarding(selectedPlan: String, selectedPath: String = selectedPlan, voucherCode: String?, institution: String,
        educationLevel: String, grade: String, curriculum: String, subjectsText: String, role: String, organisation: String,
        industry: String, focusText: String) {
        val session = _uiState.value.session as? AccountSession.SignedIn ?: return
        val subjects = subjectsText.split(',').map(String::trim).filter(String::isNotBlank).distinct().take(12)
        val focusAreas = focusText.split(',').map(String::trim).filter(String::isNotBlank).distinct().take(12)
        val profilePath = when {
            institution.isNotBlank() || grade.isNotBlank() || subjects.isNotEmpty() -> "student"
            organisation.isNotBlank() || industry.isNotBlank() -> "business"
            selectedPath == "developer" && (role.isNotBlank() || focusAreas.isNotEmpty()) -> "developer"
            selectedPath == "professional" -> "professional"
            else -> "professional"
        }
        OnboardingRules.validationError(profilePath, institution, educationLevel, grade, subjects, role, organisation, focusAreas)?.let { return showError(it) }
        val profile = AccountProfile(session.user.uid, session.user.email, session.user.displayName, "ZA",
            if (profilePath == "student") educationLevel.trim() else "Professional", institution.trim(), grade.trim(), curriculum.trim(), subjects,
            selectedPlan, role.trim(), organisation.trim(), industry.trim(), focusAreas, OnboardingRules.CURRENT_VERSION, true)
        launchOperation(successNotice = "Your Sfumato experience is ready.") {
            if (!voucherCode.isNullOrBlank()) {
                val redemption = billingRepository.redeemVoucher(VoucherRedemptionRequest(voucherCode.trim(), profile.institution, profile.schoolLevel, profile.grade, profile.curriculum, profile.subjects))
                _uiState.value = _uiState.value.copy(planTier = redemption.tier, planLoaded = true, planActive = redemption.status == "active",
                    autonomousCoding = false, planSource = "sponsored_voucher", sponsor = redemption.sponsor, sponsoredUntil = redemption.sponsoredUntil)
            }
            repository.saveAccountProfile(profile)
            _uiState.value = _uiState.value.copy(profile = profile, profileLoaded = true)
            if (voucherCode.isNullOrBlank()) refreshPlan()
        }
    }

    fun refreshPlan() {
        viewModelScope.launch {
            runCatching { billingRepository.entitlement() }
                .onSuccess { entitlement ->
                    val resolved = EntitlementRules.resolve(entitlement)
                    _uiState.value = _uiState.value.copy(
                        planTier = resolved.tier, planLoaded = true, planActive = resolved.active,
                        autonomousCoding = resolved.autonomousCoding, planSource = resolved.source,
                        sponsor = resolved.sponsor, sponsoredUntil = resolved.sponsoredUntil,
                    )
                }
                .onFailure {
                    // A transient network/token/backend failure must not downgrade or erase an already
                    // verified entitlement. Keep the last good state and only remain unloaded when no
                    // entitlement has ever been resolved for this signed-in session.
                    if (!_uiState.value.planLoaded) {
                        _uiState.value = _uiState.value.copy(planLoaded = false)
                    }
                }
        }
    }

    fun restartOnboarding() {
        val profile = _uiState.value.profile ?: return
        launchOperation {
            val editable = profile.copy(onboardingComplete = false, onboardingVersion = 0)
            repository.saveAccountProfile(editable)
            _uiState.value = _uiState.value.copy(profile = editable, profileLoaded = true)
        }
    }

    fun sendVerificationEmail() { launchOperation(successNotice = "Verification request accepted. Check your inbox and spam folder; delivery may take a few minutes.") { repository.sendEmailVerification() } }
    fun refreshSecurity() { viewModelScope.launch { runCatching { repository.isEmailVerified() }.onSuccess { verified -> _uiState.value = _uiState.value.copy(isEmailVerified = verified, securityLoaded = true) }.onFailure { error -> _uiState.value = _uiState.value.copy(securityLoaded = true, error = error.toFriendlyMessage()) } } }
    fun signOut() { launchOperation { repository.signOut() } }
    fun clearMessage() { _uiState.value = _uiState.value.copy(error = null, notice = null) }
    private fun loadProfile() { viewModelScope.launch { runCatching { repository.loadProfile() }.onSuccess { profile -> _uiState.value = _uiState.value.copy(profile = profile, profileLoaded = true) }.onFailure { error -> _uiState.value = _uiState.value.copy(error = error.toFriendlyMessage(), profileLoaded = true) } } }
    private fun launchOperation(successNotice: String? = null, block: suspend () -> Unit) { if (_uiState.value.isWorking) return; viewModelScope.launch { _uiState.value = _uiState.value.copy(isWorking = true, error = null, notice = null); runCatching { block() }.onSuccess { _uiState.value = _uiState.value.copy(isWorking = false, notice = successNotice) }.onFailure { error -> _uiState.value = _uiState.value.copy(isWorking = false, error = error.toFriendlyMessage()) } } }
    private fun showError(message: String) { _uiState.value = _uiState.value.copy(error = message, notice = null) }
}

internal fun Throwable.toFriendlyMessage(): String = when (this) {
    is HttpException -> when (code()) { 400 -> "This voucher is invalid, expired or already used by another learner. Check the code or contact your institution."; 401 -> "Your secure session expired. Sign in again."; 429 -> "Too many voucher attempts. Wait a moment and try again."; else -> "Sfumato could not verify the voucher right now. Please try again." }
    is FirebaseNetworkException -> "No internet connection. Reconnect and try again."
    is FirebaseFirestoreException -> when (code) { FirebaseFirestoreException.Code.UNAVAILABLE -> "Profile sync is temporarily unavailable. Your saved details are still safe."; FirebaseFirestoreException.Code.PERMISSION_DENIED -> "Sfumato could not access this profile. Sign in again and retry."; else -> "Profile sync could not be completed. Please try again." }
    is FirebaseAuthUserCollisionException -> "An account already exists for this email."
    is FirebaseAuthInvalidUserException -> "No active account was found for these details."
    is FirebaseAuthInvalidCredentialsException -> "The email or password is incorrect."
    is FirebaseTooManyRequestsException -> "Too many attempts. Wait a moment and try again."
    else -> "Something went wrong. Please try again."
}
