package com.guru.android.learning

import android.Manifest
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.Locale
import com.guru.android.R
import com.guru.android.homework.HomeworkAttachmentButton
import com.guru.android.domain.AccountProfile

private val tutorModes = listOf("diagnostic", "lesson", "practice", "revision")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TutorScreen(
    profile: AccountProfile? = null,
    viewModel: LearningViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    var subject by remember(profile?.uid) { mutableStateOf(profile?.subjects?.firstOrNull().orEmpty()) }
    var topic by remember { mutableStateOf("") }
    var grade by remember(profile?.uid) { mutableStateOf(profile?.grade.orEmpty()) }
    val curriculum = profile?.curriculum?.takeIf(String::isNotBlank)
    var mode by remember { mutableStateOf("diagnostic") }
    var learnerMessage by remember { mutableStateOf("") }
    var homeworkName by remember { mutableStateOf<String?>(null) }
    var homeworkText by remember { mutableStateOf<String?>(null) }
    var homeworkError by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var tutorSpeech by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) tutorSpeech?.language = Locale.getDefault()
        }
        tutorSpeech = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            tutorSpeech = null
        }
    }
    val tutorVoiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()?.takeIf { it.isNotBlank() }
                ?.let { learnerMessage = it }
        }
    }
    val launchTutorVoice = {
        tutorVoiceLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask your Sfumato Tutor")
        })
    }
    val tutorMicrophonePermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) launchTutorVoice() }

    LearningPage(
        title = "AI Tutor",
        subtitle = "Personal lessons that adapt as you learn.",
        state = state,
    ) {
        if (state.tutorTurns.isEmpty()) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Build your session", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Subject") },
                            placeholder = { Text("Mathematics") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp),
                        )
                        OutlinedTextField(
                            value = grade,
                            onValueChange = { grade = it },
                            label = { Text("Level") },
                            placeholder = { Text("10") },
                            singleLine = true,
                            modifier = Modifier.width(108.dp),
                            shape = RoundedCornerShape(18.dp),
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("What should we learn?") },
                        placeholder = { Text("Algebra, photosynthesis, essay writing…") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        HomeworkAttachmentButton(
                            onLoaded = { source ->
                                homeworkName = source.name
                                homeworkText = source.text
                                homeworkError = null
                                if (topic.isBlank()) topic = "Homework from " + source.name
                            },
                            onError = { message ->
                                homeworkName = null
                                homeworkText = null
                                homeworkError = message
                            },
                        )
                        Text(homeworkName ?: "Upload PDF, photo, or scan homework")
                    }
                    homeworkError?.let {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                    Spacer(Modifier.height(14.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(tutorModes) { value ->
                            FilterChip(
                                selected = mode == value,
                                onClick = { mode = value },
                                label = { Text(value.replaceFirstChar { it.uppercase() }) },
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val homework = homeworkText?.take(3_500)
                            val tutorTopic = if (homework.isNullOrBlank()) {
                                topic
                            } else {
                                topic + "\n\nStudent homework:\n" + homework
                            }
                            viewModel.startTutor(mode, subject, tutorTopic, grade.ifBlank { null }, curriculum)
                        },
                        enabled = !state.isWorking && subject.isNotBlank() && topic.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                    ) {
                        if (state.isWorking) {
                            CircularProgressIndicator(modifier = Modifier.height(22.dp))
                        } else {
                            Text("Start learning")
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "Choose a mode",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                when (mode) {
                    "diagnostic" -> "Find your level with a short skills check."
                    "lesson" -> "Learn the topic step by step with examples."
                    "practice" -> "Work through questions that become more challenging."
                    else -> "Create a focused revision guide and quick quiz."
                },
                style = MaterialTheme.typography.bodyLarge,
            )
        } else {
            Text("Active session", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            state.tutorTurns.forEach { turn ->
                val learner = turn.role == "learner"
                Text(
                    text = if (learner) "You" else "Sfumato Tutor",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (learner) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = if (learner) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                ) {
                    Text(
                        text = cleanAiText(turn.content),
                        modifier = Modifier.padding(18.dp),
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
                if (!learner) {
                    Row {
                        TextButton(
                            onClick = { clipboard.setText(AnnotatedString(cleanAiText(turn.content))) },
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Tutor answer")
                            Spacer(Modifier.width(6.dp))
                            Text("Copy")
                        }
                        TextButton(
                            onClick = {
                                tutorSpeech?.speak(
                                    cleanAiText(turn.content),
                                    TextToSpeech.QUEUE_FLUSH,
                                    null,
                                    "higuru-tutor-answer",
                                )
                            },
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Read Tutor answer")
                            Spacer(Modifier.width(6.dp))
                            Text("Read aloud")
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            Text("Quick learning actions", style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(
                    listOf(
                        "Explain more simply" to "Please explain that more simply.",
                        "Show an example" to "Please show me another worked example.",
                        "Quiz me" to "Quiz me with one question and wait for my answer.",
                        "Check my answer" to "Check my latest answer and show where my reasoning can improve.",
                    )
                ) { action ->
                    OutlinedButton(
                        onClick = {
                            viewModel.continueTutor(
                                mode, subject, topic, grade.ifBlank { null }, curriculum, action.second
                            )
                        },
                        enabled = !state.isWorking && state.tutorResult == null,
                    ) { Text(action.first) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                tonalElevation = 2.dp,
            ) {
                Row(
                    modifier = Modifier.padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    HomeworkAttachmentButton(
                        onLoaded = { source ->
                            homeworkName = source.name
                            homeworkText = source.text
                            homeworkError = null
                            learnerMessage = "Please help me solve this homework from " +
                                source.name + ":\n\n" + source.text.take(3_500)
                        },
                        onError = { message ->
                            homeworkName = null
                            homeworkText = null
                            homeworkError = message
                        },
                    )
                    FilledIconButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO,
                                ) == PackageManager.PERMISSION_GRANTED
                            ) launchTutorVoice()
                            else tutorMicrophonePermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        enabled = !state.isWorking,
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Ask Tutor by voice")
                    }
                    OutlinedTextField(
                        value = learnerMessage,
                        onValueChange = { learnerMessage = it },
                        placeholder = { Text("Answer or ask your Tutor…") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(22.dp),
                        maxLines = 4,
                    )
                    FilledIconButton(
                        onClick = {
                            viewModel.continueTutor(
                                mode = mode,
                                subject = subject,
                                topic = topic,
                                grade = grade.ifBlank { null },
                                curriculum = curriculum,
                                learnerMessage = learnerMessage,
                            )
                            learnerMessage = ""
                        },
                        enabled = !state.isWorking && learnerMessage.isNotBlank(),
                    ) {
                        if (state.isWorking) {
                            CircularProgressIndicator(modifier = Modifier.height(20.dp))
                        } else {
                            Icon(Icons.Default.Send, contentDescription = "Send to Tutor")
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            state.tutorResult?.let { result ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            "Mastery " + (state.tutorMastery ?: 0) + "/100",
                            style = MaterialTheme.typography.headlineSmall,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(cleanAiText(result))
                    }
                }
            }
            Button(
                onClick = {
                    if (state.tutorResult == null) {
                        viewModel.finishTutor(mode, subject, topic, grade.ifBlank { null }, curriculum)
                    } else {
                        viewModel.resetTutor()
                        subject = ""
                        topic = ""
                        grade = profile?.grade.orEmpty()
                        learnerMessage = ""
                    }
                },
                enabled = !state.isWorking &&
                    (state.tutorResult != null || state.tutorTurns.any { it.role == "learner" }),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (state.tutorResult == null) "Finish and check mastery" else "Start a new session")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArenaScreen(viewModel: LearningViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    var topic by remember { mutableStateOf("") }
    var position by remember { mutableStateOf("for") }
    var selectedStage by remember { mutableIntStateOf(1) }
    var debateMessage by remember { mutableStateOf("") }
    var showTextFallback by remember { mutableStateOf(false) }
    var lastSpokenOpponent by remember { mutableStateOf("") }
    var autoSpeakOpponent by remember { mutableStateOf(true) }
    var voiceSpeed by remember { mutableStateOf(1.0f) }
    var voiceStatus by remember { mutableStateOf("Preparing enhanced voice…") }
    var isOpponentSpeaking by remember { mutableStateOf(false) }
    var liveVoiceActive by remember { mutableStateOf(false) }
    var isListening by remember { mutableStateOf(false) }
    val unlocked = state.arenaStatus.highestUnlockedStage
    val learnerRounds = state.debateTurns.count { it.role == "learner" }
    val coachPrompts = listOf(
        "My strongest evidence is ",
        "That argument assumes ",
        "A fair counterpoint is ",
        "My rebuttal is ",
    )
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var textToSpeech by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine.language = Locale.getDefault()
                val preferredVoice = engine.voices
                    ?.filter { voice -> voice.locale.language == Locale.getDefault().language }
                    ?.sortedWith(
                        compareByDescending<android.speech.tts.Voice> { voice -> voice.quality }
                            .thenBy { voice -> voice.latency }
                            .thenBy { voice -> voice.isNetworkConnectionRequired },
                    )
                    ?.firstOrNull()
                if (preferredVoice != null && engine.setVoice(preferredVoice) == TextToSpeech.SUCCESS) {
                    voiceStatus = if (preferredVoice.isNetworkConnectionRequired) {
                        "Enhanced online voice · device voice used offline"
                    } else {
                        "Enhanced device voice ready"
                    }
                } else {
                    voiceStatus = "Device voice ready"
                }
            } else {
                voiceStatus = "Voice unavailable · captions remain on"
            }
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            private val mainHandler = Handler(Looper.getMainLooper())

            override fun onStart(utteranceId: String?) {
                mainHandler.post { isOpponentSpeaking = true }
            }

            override fun onDone(utteranceId: String?) {
                mainHandler.post { isOpponentSpeaking = false }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                mainHandler.post { isOpponentSpeaking = false }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mainHandler.post { isOpponentSpeaking = false }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                mainHandler.post {
                    isOpponentSpeaking = false
                    voiceStatus = "Voice paused · tap Replay to try again"
                }
            }
        })
        textToSpeech = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            textToSpeech = null
        }
    }
    val latestOpponent = state.debateTurns
        .lastOrNull { it.role != "learner" }
        ?.content
        ?.let(::cleanAiText)
        .orEmpty()
    fun speakOpponent(content: String) {
        if (content.isBlank()) return
        val stagePace = when (selectedStage) {
            1 -> 0.94f
            2 -> 0.98f
            3 -> 1.0f
            4 -> 1.04f
            else -> 1.08f
        }
        textToSpeech?.setSpeechRate((voiceSpeed * stagePace).coerceIn(0.75f, 1.30f))
        textToSpeech?.setPitch(if (selectedStage >= 4) 0.96f else 1.0f)
        val result = textToSpeech?.speak(
            content,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "higuru-live-opponent",
        )
        if (result == TextToSpeech.ERROR) {
            isOpponentSpeaking = false
            voiceStatus = "Voice unavailable · captions remain on"
        }
    }
    LaunchedEffect(latestOpponent, autoSpeakOpponent) {
        if (!liveVoiceActive && autoSpeakOpponent && latestOpponent.isNotBlank() && latestOpponent != lastSpokenOpponent) {
            lastSpokenOpponent = latestOpponent
            speakOpponent(latestOpponent)
        }
    }
    var recognitionTarget by remember { mutableStateOf("argument") }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    DisposableEffect(context) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            voiceStatus = "Speech recognition unavailable · use the keyboard"
            onDispose { }
        } else {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    voiceStatus = "Sfumato is listening…"
                }

                override fun onBeginningOfSpeech() {
                    voiceStatus = "Listening to your argument…"
                }

                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    isListening = false
                    voiceStatus = "Preparing your words…"
                }

                override fun onError(error: Int) {
                    isListening = false
                    voiceStatus = if (error == SpeechRecognizer.ERROR_NO_MATCH) {
                        "I didn't catch that · tap the microphone and try again"
                    } else {
                        "Voice paused · use the keyboard or try again"
                    }
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                    if (spoken.isNullOrBlank()) {
                        voiceStatus = "I didn't catch that · tap the microphone and try again"
                        return
                    }
                    voiceStatus = "Sfumato voice ready"
                    if (recognitionTarget == "topic") {
                        topic = spoken
                    } else {
                        debateMessage = spoken
                        if (state.debateTurns.isNotEmpty() && !state.isWorking) {
                            viewModel.continueDebate(
                                topic = topic,
                                stage = selectedStage,
                                position = position,
                                learnerArgument = spoken,
                            )
                        }
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.takeIf { it.isNotBlank() }
                        ?.let { partial ->
                            if (recognitionTarget == "topic") topic = partial else debateMessage = partial
                        }
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            speechRecognizer = recognizer
            onDispose {
                recognizer.cancel()
                recognizer.destroy()
                speechRecognizer = null
            }
        }
    }
    fun launchHiGuruSpeech(target: String) {
        textToSpeech?.stop()
        isOpponentSpeaking = false
        recognitionTarget = target
        isListening = true
        voiceStatus = if (target == "topic") {
            "Sfumato is listening for your topic…"
        } else {
            "Sfumato is listening…"
        }
        speechRecognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        })
    }
    val microphonePermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) launchHiGuruSpeech("argument") else isListening = false
    }
    val topicMicrophonePermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) launchHiGuruSpeech("topic")
    }
    val enochState = when {
        state.isWorking -> "Thinking"
        isListening -> "Listening"
        isOpponentSpeaking -> "Speaking"
        else -> "Ready"
    }
    val enochPulse by rememberInfiniteTransition(label = "Enoch pulse").animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isOpponentSpeaking) 360 else 900),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "Enoch scale",
    )

    LearningPage(
        title = "Debate Arena",
        subtitle = "Think clearly. Argue boldly. Master every stage.",
        state = state,
    ) {
        if (state.debateTurns.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "ENOCH",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        "Sfumato Arena Master",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Image(
                        painter = painterResource(R.drawable.enoch_idle),
                        contentDescription = "Enoch is ready",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(190.dp)
                            .graphicsLayer {
                                scaleX = enochPulse
                                scaleY = enochPulse
                            },
                    )
                    Text(
                        "Ready",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        "Choose a topic, side and stage. Enoch will challenge your argument live by voice.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Arena progress", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text("Sfumato score", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "${state.arenaStatus.overallHiGuruScore}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Column {
                        Text("Personal best", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "${state.arenaStatus.bestDebateScore}/100",
                            style = MaterialTheme.typography.headlineMedium,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Highest unlocked: Stage $unlocked — ${stageName(unlocked)}")
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                label = { Text("Debate topic") },
                placeholder = { Text("Say or type the motion") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                enabled = state.debateTurns.isEmpty(),
            )
            FilledIconButton(
                onClick = {
                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO,
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        launchHiGuruSpeech("topic")
                    } else {
                        topicMicrophonePermission.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                modifier = Modifier.size(54.dp),
                enabled = state.debateTurns.isEmpty(),
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Say debate topic")
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = position == "for",
                onClick = { position = "for" },
                label = { Text("I argue For") },
                enabled = state.debateTurns.isEmpty(),
                modifier = Modifier.weight(1f),
            )
            FilterChip(
                selected = position == "against",
                onClick = { position = "against" },
                label = { Text("I argue Against") },
                enabled = state.debateTurns.isEmpty(),
                modifier = Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(12.dp))
        Text("Choose your challenge", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..5).forEach { stage ->
                val locked = stage > unlocked
                FilterChip(
                    selected = selectedStage == stage,
                    onClick = { if (!locked) selectedStage = stage },
                    enabled = !locked && state.debateTurns.isEmpty(),
                    label = {
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Text("Stage $stage — ${stageName(stage)}${if (locked) " · Locked" else ""}")
                            Text(
                                "${stageFocus(stage)} · Pass at ${stagePassScore(stage)}/100",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Selected: ${stageName(selectedStage)}. ${stageFocus(selectedStage)}.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { viewModel.startDebate(topic, selectedStage, position) },
            enabled = !state.isWorking && state.debateTurns.isEmpty() &&
                topic.length >= 3 && selectedStage <= unlocked,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
        ) {
            if (state.isWorking) {
                CircularProgressIndicator(modifier = Modifier.height(22.dp))
            } else {
                Text("Enter Arena")
            }
        }
        if (state.debateTurns.isNotEmpty()) {
            Spacer(Modifier.height(18.dp))
            Text("Live debate", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            state.debateTurns.forEach { turn ->
                val learner = turn.role == "learner"
                Text(
                    if (learner) "Your argument" else "Enoch",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (learner) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                val displayContent = cleanAiText(turn.content)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = if (learner) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text(displayContent, style = MaterialTheme.typography.bodyLarge)
                        if (!learner) {
                            TextButton(
                                onClick = { clipboard.setText(AnnotatedString(displayContent)) },
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy opponent argument")
                                Spacer(Modifier.width(6.dp))
                                Text("Copy argument")
                            }
                            TextButton(
                                onClick = { speakOpponent(displayContent) },
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Read argument aloud")
                                Spacer(Modifier.width(6.dp))
                                Text("Listen")
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "Round ${learnerRounds.coerceAtMost(2)}/2",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        if (learnerRounds < 2) {
                            "Make ${2 - learnerRounds} more argument${if (2 - learnerRounds == 1) "" else "s"} to unlock judging."
                        } else {
                            "Judging is unlocked. Add another rebuttal or finish for your score."
                        },
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Argument coach", style = MaterialTheme.typography.titleMedium)
            Text(
                "Use a starter when you need structure—the ideas must still be yours.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(coachPrompts) { prompt ->
                    FilterChip(
                        selected = false,
                        onClick = {
                            debateMessage = prompt
                            showTextFallback = true
                        },
                        label = { Text(prompt.trim()) },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Live voice round",
                style = MaterialTheme.typography.titleLarge,
            )
            Text(
                if (state.isWorking) {
                    "Your opponent is responding…"
                } else {
                    "Tap the microphone and speak. Your argument is submitted automatically."
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            EnochLivePanel(
                topic = topic,
                stage = selectedStage,
                learnerPosition = position,
                opening = state.debateTurns.firstOrNull { it.role != "learner" }?.content.orEmpty(),
                debateFinished = state.debateResult != null,
                onTurn = viewModel::recordLiveDebateTurn,
                onLiveState = { active, speaking ->
                    liveVoiceActive = active
                    isOpponentSpeaking = speaking
                    isListening = active && !speaking
                    if (active) {
                        autoSpeakOpponent = false
                        textToSpeech?.stop()
                        speechRecognizer?.cancel()
                    }
                },
            )
            Spacer(Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Opponent voice", style = MaterialTheme.typography.titleMedium)
                    Text(
                        voiceStatus,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    FilterChip(
                        selected = autoSpeakOpponent,
                        enabled = !liveVoiceActive,
                        onClick = {
                            autoSpeakOpponent = !autoSpeakOpponent
                            if (!autoSpeakOpponent) {
                                textToSpeech?.stop()
                                isOpponentSpeaking = false
                            }
                        },
                        label = { Text(if (autoSpeakOpponent) "Auto voice on" else "Auto voice off") },
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Voice speed", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(0.85f to "Calm", 1.0f to "Natural", 1.15f to "Fast").forEach { option ->
                            FilterChip(
                                selected = voiceSpeed == option.first,
                                onClick = { voiceSpeed = option.first },
                                label = { Text(option.second) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { speakOpponent(latestOpponent) },
                            enabled = latestOpponent.isNotBlank(),
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Replay")
                        }
                        OutlinedButton(
                            onClick = {
                                textToSpeech?.stop()
                                isOpponentSpeaking = false
                            },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Stop")
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "ENOCH",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        "Sfumato Arena Master · Stage $selectedStage",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Image(
                        painter = painterResource(
                            if (isOpponentSpeaking) R.drawable.enoch_speaking
                            else R.drawable.enoch_idle,
                        ),
                        contentDescription = "Enoch is $enochState",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(230.dp)
                            .graphicsLayer {
                                scaleX = enochPulse
                                scaleY = enochPulse
                                alpha = if (state.isWorking) 0.78f else 1f
                            },
                    )
                    Text(
                        enochState,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    if (latestOpponent.isNotBlank()) {
                        Text(
                            latestOpponent,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 4,
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    FilledIconButton(
                        onClick = {
                            if (isOpponentSpeaking) {
                                textToSpeech?.stop()
                                isOpponentSpeaking = false
                            }
                            if (ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO,
                                ) == PackageManager.PERMISSION_GRANTED
                            ) {
                                launchHiGuruSpeech("argument")
                            } else {
                                microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        enabled = !state.isWorking && !liveVoiceActive,
                        modifier = Modifier.size(72.dp),
                    ) {
                        if (state.isWorking) {
                            CircularProgressIndicator(modifier = Modifier.size(34.dp))
                        } else {
                            Icon(
                                Icons.Default.Mic,
                                contentDescription = if (isOpponentSpeaking) {
                                    "Stop Enoch"
                                } else {
                                    "Speak to Enoch"
                                },
                                modifier = Modifier.size(34.dp),
                            )
                        }
                    }
                    Text(
                        when {
                            liveVoiceActive && isOpponentSpeaking -> "Enoch is speaking live"
                            liveVoiceActive -> "Live microphone is open"
                            isOpponentSpeaking -> "Tap to interrupt"
                            else -> "Tap to speak"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (debateMessage.isNotBlank()) {
                Text("Latest caption", style = MaterialTheme.typography.labelLarge)
                Text(
                    debateMessage,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
            }
            OutlinedButton(
                onClick = { showTextFallback = !showTextFallback },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.Keyboard, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (showTextFallback) "Hide keyboard" else "Accessibility keyboard")
            }
            if (showTextFallback) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = debateMessage,
                    onValueChange = { debateMessage = it },
                    placeholder = { Text("Type an argument…") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    maxLines = 5,
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        viewModel.continueDebate(
                            topic = topic,
                            stage = selectedStage,
                            position = position,
                            learnerArgument = debateMessage,
                        )
                        debateMessage = ""
                    },
                    enabled = !state.isWorking && debateMessage.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Default.Send, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Submit argument")
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(
                onClick = {
                    viewModel.finishDebate(topic, selectedStage, position)
                },
                enabled = !state.isWorking &&
                    state.debateTurns.count { it.role == "learner" } >= 2 &&
                    state.debateResult == null,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
            ) {
                if (state.isWorking) {
                    CircularProgressIndicator(modifier = Modifier.height(20.dp))
                } else {
                    Text("Finish debate and get score")
                }
            }
            state.debateResult?.let { result ->
                Spacer(Modifier.height(14.dp))
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            if (state.debatePassed == true) "Stage passed" else "Rematch recommended",
                            color = if (state.debatePassed == true) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            },
                            style = MaterialTheme.typography.titleLarge,
                        )
                        Text(
                            "${state.debateScore ?: 0}/100 · Target ${stagePassScore(selectedStage)}/100",
                            style = MaterialTheme.typography.headlineMedium,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("Judge's decision", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(cleanAiText(result), style = MaterialTheme.typography.bodyLarge)
                        TextButton(
                            onClick = { clipboard.setText(AnnotatedString(cleanAiText(result))) },
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy debate result")
                            Spacer(Modifier.width(6.dp))
                            Text("Copy result")
                        }
                        Button(
                            onClick = {
                                viewModel.resetDebate()
                                debateMessage = ""
                                showTextFallback = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(if (state.debatePassed == true) "Debate another motion" else "Train and rematch")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LearningPage(
    title: String,
    subtitle: String,
    state: LearningUiState,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(18.dp))
        state.error?.let {
            Snackbar { Text(friendlyLearningMessage(it)) }
            Spacer(Modifier.height(12.dp))
        }
        state.notice?.let {
            Snackbar { Text(it) }
            Spacer(Modifier.height(12.dp))
        }
        content()
        Spacer(Modifier.height(24.dp))
    }
}

private fun friendlyLearningMessage(message: String): String = when {
    message.contains("429") ->
        "Your Guru is busy right now. Please try again in a moment."
    message.contains("404") ->
        "This Guru is being updated. Please try again shortly."
    message.contains("network", ignoreCase = true) ->
        "You appear to be offline. Check your connection and try again."
    else -> "We couldn't start that session. Please try again."
}

private fun cleanAiText(content: String): String =
    content
        .replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        .replace(Regex("(?m)^\\s*[-*+]\\s+"), "• ")
        .replace("**", "")
        .replace("__", "")
        .replace("`", "")
        .replace("\\\\rightarrow", "→")
        .replace("\\\\Rightarrow", "⇒")
        .replace("\\\\times", "×")
        .replace("\\\\div", "÷")
        .replace("\\\\(", "")
        .replace("\\\\)", "")
        .replace("\\\\[", "")
        .replace("\\\\]", "")
        .replace("$", "")
        .replace(Regex("\\n{3,}"), "\\n\\n")
        .trim()
