package com.guru.android.data.remote

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface AiService {
    @POST("chat")
    suspend fun getChatCompletion(
        @Header("Authorization") firebaseBearerToken: String,
        @Body request: ChatRequest,
    ): ChatResponse
}
