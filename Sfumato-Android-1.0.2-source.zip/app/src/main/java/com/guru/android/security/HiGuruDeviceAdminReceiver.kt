package com.guru.android.security

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class HiGuruDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Sfumato remote lock enabled", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        RemoteLockPreferences(context).clearRegistration()
        Toast.makeText(context, "Sfumato remote lock disabled", Toast.LENGTH_SHORT).show()
    }
}
