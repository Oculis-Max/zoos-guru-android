# Sfumato for Android

Sfumato is a Kotlin/Jetpack Compose Android application backed by the Sfumato API.

## Build

Use JDK 17 and the included Gradle wrapper:

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug
```

Production release builds require the signing values documented in
`.github/workflows/android-apk.yml`. The workflow publishes the signed artifact as
`Sfumato-release.apk`.

## Release 1.0.2

- Prevented an Enoch Live connection from reopening after the user stops it while connecting.
- Made live-voice cancellation clean up partial sessions and keep Debate Arena UI state consistent.
- Retained the existing production backend, onboarding, plan entitlements, uploads, cyber safety,
  and autonomous coding workflows.
