# HiGURU Enoch Advanced Business Assistant

## Purpose

Enoch is the Business-plan administration and decision-support workspace in HiGURU. It helps an organisation analyse work, coordinate departments, prepare professional documents, assign owners, identify risk, and produce approval-ready plans.

Business plan price: **R5,000 per month**.

Enoch does not silently operate a business. It prepares and coordinates work. Consequential actions remain under human control.

## Operating modes

### Standard Mode

The default mode for daily administration.

- analyses requests and missing information
- prepares documents and recommendations
- organises tasks, owners, dates, dependencies and follow-ups
- monitors risks and unresolved decisions
- does not execute consequential actions

### Advanced Mode

For complex or high-volume work spanning several departments.

- coordinates relevant business functions in parallel
- builds a prioritised execution plan
- identifies dependencies, blockers and decision owners
- drafts the complete administration pack required for implementation
- defines KPIs, reporting cadence and review dates
- executes nothing consequential without explicit human approval and an authorised connector

### Emergency / Damage Control Mode

For cybersecurity incidents, outages, fraud, legal threats, financial distress, operational failures, health and safety incidents, or public-relations crises.

- separates confirmed facts from assumptions
- recommends immediate containment
- creates a decision and incident log
- prepares executive, legal, security, employee, customer and media briefings
- identifies mandatory escalation and professional advice
- defines recovery, continuity and post-incident review actions
- never publishes, pays, deletes, files, dismisses staff or changes security by itself

## Complete business-administration coverage

| Area | Administration covered |
|---|---|
| Executive management | strategy, objectives, board packs, decision briefs, governance, agendas, minutes, performance dashboards |
| General administration | correspondence, calendars, meeting packs, task registers, office procedures, filing and follow-up |
| Operations | SOPs, capacity, quality, service delivery, workflow design, inventory, continuity and improvement |
| Finance and accounting | budgets, cash-flow briefs, cost controls, management reporting, invoice follow-up, forecasts and audit preparation |
| Human resources | job descriptions, recruitment packs, onboarding, policies, performance plans, training, leave and employee-case briefs |
| Sales | pipeline plans, proposals, quotations briefs, account plans, targets, scripts, forecasting and reviews |
| Marketing | research, positioning, campaigns, calendars, content briefs, channel plans, budgets and measurement |
| Customer service | response drafts, complaint handling, service standards, escalation, retention and feedback analysis |
| Procurement | requirements, supplier comparisons, due diligence, evaluation criteria, purchase briefs and contract checkpoints |
| Projects | charters, plans, milestones, resources, RAID logs, status reports, change control and closure reviews |
| Legal and compliance | compliance checklists, contract issue spotting, policy alignment, evidence packs and professional-advice escalation |
| Risk management | risk registers, controls, owners, indicators, treatment plans, fraud and continuity planning |
| IT and cybersecurity | requirements, access reviews, incident briefs, asset and vendor risk, recovery and security-policy drafts |
| Records and documentation | file plans, naming standards, retention schedules, version control, document registers and audit trails |

Legal, tax, accounting, medical, labour and regulatory outputs are decision support and must be reviewed by a qualified professional when appropriate.

## Documents Enoch can prepare

- business plans and strategic plans
- proposals and executive reports
- policies and standard operating procedures
- meeting agendas, minutes and action registers
- professional emails and internal memoranda
- project plans and status reports
- budget and cash-flow briefs
- risk registers and compliance checklists
- job descriptions, onboarding packs and performance plans
- marketing and sales plans
- customer-service responses
- procurement and supplier-evaluation briefs
- cybersecurity and emergency incident briefs

Every deliverable should clearly distinguish facts, assumptions, missing information, recommendations, owners, deadlines, risks, approvals and next review.

## Mandatory approval boundary

Enoch must obtain human approval before any system is allowed to:

1. send external communications;
2. spend, transfer or commit money;
3. sign contracts or accept legal terms;
4. hire, dismiss, discipline or change payroll;
5. submit tax, regulatory or legal filings;
6. delete records or change access and security controls;
7. publish public statements or crisis communications.

Current implementation is **draft only**. No external action is performed.

## Privacy and data handling

- Only business information deliberately entered by the signed-in user is sent to Gemini.
- Users should avoid unnecessary personal, payment, health or credential data.
- API keys, passwords, card information and authentication secrets must never be entered.
- Runs are user-scoped and logged to provide an explainable decision trail.
- HiGURU must never claim an action occurred when it only generated a draft.
- Future connectors must be separately authorised, least-privilege, revocable and auditable.

## Standard workflow

1. Select Standard, Advanced or Emergency mode.
2. Select the responsible business area.
3. Select the required document or output.
4. Enter only the organisation context needed for the task.
5. Describe the task and success criteria.
6. Enoch creates an approval-ready draft.
7. Copy or share the draft for internal review.
8. A responsible human approves, rejects or edits it.
9. Any future external execution occurs only through an explicitly authorised connector.
10. Record the outcome and next review.

## Example cross-department workflows

### New product launch

Executive + Finance + Marketing + Sales + Operations + Legal + Customer Service:

- business case and launch decision
- budget and pricing assumptions
- campaign and sales plan
- operational readiness and support scripts
- contract, privacy and compliance review
- KPI dashboard and launch review

### Hiring and onboarding

HR + Finance + Department Manager + IT + Compliance:

- approved role and budget
- job description and interview pack
- offer and policy review
- equipment and access checklist
- onboarding schedule and training
- probation and performance milestones

### Cybersecurity incident

Emergency mode coordinates Executive + IT/Security + Legal + Operations + HR + Communications:

- containment and evidence preservation
- incident log and decision owners
- affected systems and business impact
- regulatory and customer-notification assessment
- recovery and continuity actions
- executive brief and post-incident review

## Quality and acceptance requirements

A Business Assistant release is acceptable only when:

- Business entitlement is verified server-side;
- Standard, Advanced and Emergency modes are available;
- all listed administration areas are selectable;
- professional drafts can be copied and shared;
- user-provided context is not sent without deliberate submission;
- consequential actions are labelled as requiring approval;
- output never claims external execution;
- each run receives a user-scoped audit record;
- authentication, rate-limit and provider failures are understandable;
- Android and backend CI pass.

## Future authorised execution

Email, calendar, document storage, accounting, CRM, HR, ticketing and collaboration connectors may be added later. Each connector must define:

- exact scopes and data accessed;
- permitted draft and execution actions;
- actions requiring confirmation;
- audit records;
- revocation and token protection;
- rollback or recovery where technically possible.

Enoch remains the coordinating intelligence layer. Human owners retain final authority.
