# Progress Hub

Progress Hub lets a HiGURU member deliberately share limited study or work progress with a parent or employer.

## Consent model

- The student or employee creates the access grant.
- Access is bound to the invited viewer's signed-in email address.
- The member chooses the categories visible to that viewer.
- The member can revoke access immediately.
- A viewer cannot forward access to another account.
- Employers and parents cannot create access for themselves.

For minors, a production institution rollout must add age-appropriate consent, guardian verification, and South African POPIA handling before schools rely on this feature.

## Visible information

The dashboard may show approved totals and timestamps for:

- AI Tutor sessions
- Debate Arena sessions
- scholarships tracked
- autonomous coding runs
- business-assistant tasks

The API deliberately does not return prompts, AI answers, chat messages, debate arguments, code, document text, grades entered into private conversations, or uploaded files.

## Roles

The initial viewer roles are `parent` and `employer`. A parent dashboard defaults to learning, debate and scholarship categories. An employer dashboard can be limited to coding and business activity.

This is an activity dashboard, not employee surveillance, academic grading, attendance certification, or productivity scoring.

## Security and privacy

- Firebase authentication is required.
- Viewer email matching is performed server-side.
- Share records remain subject-owned.
- Revoked shares return access denied.
- Store only the minimum metadata needed for counts and recent activity.
- Never expose another user's identifier or data through client-selected paths.
- Avoid sponsor or institution reporting at individual level unless the member explicitly granted access.
- Aggregate institution reporting must be anonymized and use minimum cohort thresholds.

## Future institution phase

The next safe expansion can add verified school/company organizations, managed seats, guardian workflows, weekly summaries, goals and milestones, aggregate analytics, and export/deletion controls. External notifications require separate user approval and communication preferences.
