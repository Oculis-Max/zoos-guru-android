# Sfumato secure Render beta

This is a review-only deployment guide. The repository contains no Firebase
service-account credentials, OpenRouter keys, or Render credentials.

## Architecture

The Android app sends `POST /chat` to the configured Sfumato backend and
includes the signed-in Firebase user's ID token as `Authorization: Bearer ...`.
The backend verifies that token with Firebase Admin before calling OpenRouter.
Provider credentials exist only on the backend.

## Render free beta setup

1. In Render, create a Blueprint from this repository and review
   `render.yaml`.
2. Keep the service on the **Free** plan. Free services can sleep when idle and
   are suitable for beta testing, not a production SLA.
3. In Firebase/Google Cloud IAM, create a least-privilege service account for
   token verification. Download its JSON once.
4. In the Render service, add that JSON as a **Secret File** named
   `firebase-service-account.json`. Render mounts it at
   `/etc/secrets/firebase-service-account.json`, matching
   `GOOGLE_APPLICATION_CREDENTIALS`.
5. Add `HIGURU_OPENROUTER_API_KEY` as a secret environment variable. Never
   paste it into Android, GitHub source, logs, issues, or pull requests.
6. Deploy and verify:
   - `GET /health` returns HTTP 200.
   - `POST /chat` without a Firebase Bearer token returns HTTP 401.
   - A signed-in beta user can send one chat message successfully.
7. Set the Android build property or Actions environment variable
   `HIGURU_BACKEND_BASE_URL=https://<service>.onrender.com/`, then rebuild the
   APK.

## Local verification

Use Application Default Credentials outside tests:

```bash
export GOOGLE_APPLICATION_CREDENTIALS=/safe/path/firebase-service-account.json
export HIGURU_FIREBASE_PROJECT_ID=higuru-production
export HIGURU_OPENROUTER_API_KEY=<set-in-your-shell-secret-store>
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

The backend runs in demo mode when `HIGURU_OPENROUTER_API_KEY` is absent, but
`/chat` still requires a valid Firebase ID token.

## Security notes

- Do not commit or upload the service-account JSON as an ordinary repository
  file.
- Do not log Authorization headers, Firebase tokens, prompts, answers, or
  provider keys.
- Rotate any credential immediately if it appears in a screenshot or commit.
- Before production launch, move from a free sleeping service to a deployment
  with an approved SLA, monitoring, budgets, and key rotation.
