# Scholarship Guru

Scholarship Guru helps students assess readiness, discover opportunities from official sources, and privately track applications.

## Product rules

- The finder accepts only government, university, foundation, or established corporate programme sources.
- Every opportunity stores its official URL, deadline, status, and last verification date.
- Expired opportunities are hidden by default and may be shown as closed for reference.
- HiGURU never describes a readiness score as a guarantee, acceptance prediction, or official eligibility decision.
- Users must confirm every requirement and submit applications on the provider's official website.
- No paid placement, invented partnership, or unverified user-submitted listing may appear as verified.

## Initial coverage

The first registry focuses on South Africa. Regional expansion order is Botswana, Namibia, Lesotho, then Eswatini. Each country launch requires a source-review pass before listings go live.

Initial official sources:

- NSFAS: https://www.nsfas.org.za/
- Funza Lushaka: https://www.education.gov.za/Programmes/FunzaLushaka.aspx
- Mandela Rhodes Foundation: https://www.mandelarhodes.org/scholarship/apply/
- Allan Gray Orbis Foundation: https://allangrayorbis.org/

## Readiness score

The score is deterministic and transparent:

| Factor | Weight |
| --- | ---: |
| Grades | 25% |
| Study consistency | 15% |
| Leadership | 15% |
| Community service | 10% |
| Digital skills | 10% |
| Certificates | 5% |
| Career goal | 10% |
| Personal statement | 10% |

The three lowest inputs below 80 become suggested improvement areas.

## Access and privacy

Browsing verified opportunities is public. Readiness scoring and application tracking require an active Student Pro or Business entitlement. Application records are scoped to the authenticated user. Collect only information needed for readiness and tracking; do not request identity documents in this workflow.

Student-status proof is a separate account-verification control and must not be represented as implemented until secure upload, reviewer access, retention, deletion, and appeal handling are complete.

## Application lifecycle

Supported states are: saved, preparing, submitted, interview, awarded, and unsuccessful. Tracking never submits an application, contacts a provider, or changes an external record.

## Operations

Review official sources regularly. Update `last_verified`, deadline, and status together. A listing with an uncertain deadline must not be shown as open.
