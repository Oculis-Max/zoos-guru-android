# Sfumato scholarship source policy

Sfumato only publishes opportunities after an editor verifies the record against an official programme page. Search results hide expired and unverified records by default.

## Initial South African sources

| Programme | Official source | Coverage | Review cadence |
|---|---|---|---|
| NSFAS | https://www.nsfas.org.za/content/how-to-apply.html | Public university and TVET funding | Weekly during application cycles |
| Funza Lushaka | https://www.funzalushaka.doe.gov.za/ | Teacher-education bursaries | Weekly during application cycles |
| DSTI-NRF | https://www.nrf.ac.za/nrf-for-post-graduate-students/bursaries-scholarships/ | Postgraduate research funding | Weekly |
| ISFAP | https://www.isfap.org.za/ | High-demand undergraduate programmes | Weekly during application cycles |

These are source catalog entries, not a claim that applications are currently open. Every imported opportunity must include its own deadline, official source URL, and `source_verified_at` timestamp.

## Editorial ingestion rules

1. Read the official programme page; do not rely on aggregator summaries.
2. Record the exact deadline and the programme's official application URL.
3. Mark the record verified only through `ScholarshipStore.upsert_verified`.
4. Re-check records weekly while open and immediately after a programme announcement.
5. Let expired records disappear from normal search; retain them only for audit/history views.
6. Never collect application credentials or submit applications on a student's behalf.

There is intentionally no public ingestion endpoint. A future editor tool must require a privileged Firebase role and an audit log before it can write production scholarship data.
