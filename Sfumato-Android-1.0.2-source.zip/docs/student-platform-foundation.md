# Sfumato student platform foundation

This phase adds provider-neutral foundations for accounts, scholarships, analytics, and entitlements. It deliberately does not claim that authentication, analytics, billing, or persistence is live.

## Accounts

- `POST /v1/identities/guest` creates an offline-friendly guest identity.
- Profile APIs collect only eligibility fields needed for matching.
- The process-local store is an MVP boundary, not production persistence.
- A future auth provider must support guest-to-account migration, data export/deletion, and secure server-side sessions.

## Scholarship journey

- Search filters cover country, school level, subject, and deadline.
- Bookmarks and application status use: discovered, eligible, preparing, submitted, result.
- Match Score is transparent: academic 30, residency 20, subject 20, financial need 15, readiness 10, deadline 5.
- Every response includes factor explanations and a no-guarantee disclaimer.
- Scholarship records require an official source URL. Importing and verifying real opportunities remains an owner/editor workflow.

## Privacy-safe analytics

The default sink is local only. It accepts an event allow-list and short categorical dimensions. Prompts, model answers, names, email addresses, phone numbers, documents, essays, access tokens, and other PII are rejected by design.

## Payments and entitlements

The app and backend expose entitlement interfaces and a free default plan. There are no Play products, charges, credentials, purchase verification, or live subscriptions in this phase. Google Play Billing must later use server-side verification, restore purchases, clear cancellation terms, and policy review.

## Production decisions still required

1. Authentication and database vendors, region, retention, and deletion policy.
2. Scholarship data sources, verification ownership, and update frequency.
3. Analytics/crash vendor, consent policy, and event-retention limits.
4. Play product IDs, pricing, eligible countries, sponsored-access rules, and server-side receipt verification.
5. Threat model, abuse controls, rate limits, backups, and migration from process-local stores.
