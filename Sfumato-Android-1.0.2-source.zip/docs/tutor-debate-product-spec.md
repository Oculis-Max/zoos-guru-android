# Sfumato Tutor and Debate Arena product specification

## Product principles

- Optimize for learning progress and durable retention, not compulsive use.
- Never make ranking depend on payment, raw screen time, or message volume.
- Preserve user work when quotas are reached.
- Give clear explanations for scores and unlock decisions.
- Use healthy stopping points and avoid punitive streak loss.

## AI Tutor

The Tutor is a structured learning experience separate from open chat. It supports
diagnostic, lesson, practice, and revision modes; subject/topic mastery; hints before
answers; quizzes with explanations; spaced revision; and offline drafts.

## Debate Arena

The Arena has five stages: Foundation, Challenger, Advanced, Expert, and Grandmaster.
Each stage increases rebuttal strength, evidence requirements, cross-examination, and
the independence of the AI opponent. Grandmaster uses the strongest approved model
and a separate judging pass. It is difficult but must remain fair and explainable.

Debate scoring totals 100: reasoning 25, evidence 20, rebuttal 15, understanding the
opposing view 15, clarity 10, cross-examination 10, and civility 5.

The overall Sfumato score weights debate mastery 40%, tutor mastery 20%, scholarship
readiness 15%, completed goals 10%, research quality 10%, and responsible
participation 5%. Paid status is never a scoring input.

Stage 5 requires a prior debate score of at least 90 and an overall score of at least
80. Server-side scoring and an audit record are required before public leaderboards.

## Safety and integrity

- The opponent critiques ideas, never the student.
- Public user-to-user chat is excluded from the first release.
- Claims and citations must be checked; fabricated evidence is penalized.
- Age-appropriate topic controls and reporting are required.
- The AI opponent and final judge use separate prompts and outputs.
