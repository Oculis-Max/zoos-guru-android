# Journalist Studio

Journalist Studio records interviews locally on Android and, only after explicit confirmation, sends the selected recording to Gemini for transcription and structured note generation.

## Workflow

1. The journalist confirms that participants were informed and consented where legally required.
2. Android requests microphone permission.
3. The interview is recorded as AAC audio in the app's private files directory.
4. The journalist stops and reviews the local filename and size.
5. The journalist deliberately selects **Create transcript and notes**.
6. The authenticated backend validates entitlement, consent, format, and size.
7. The backend temporarily uploads the audio to Gemini.
8. Gemini returns a transcript, summary, verbatim key quotes, facts to verify, follow-up questions, article outline and headline suggestions.
9. The backend attempts to delete the temporary Gemini file in a `finally` block.
10. Generated notes are stored in the journalist's private HiGURU collection; the local audio stays on the phone until deleted by the journalist.

## Privacy and safety

- Never begin recording merely by opening the screen.
- Consent confirmation is required in both Android and the backend.
- Do not claim that HiGURU determines whether recording is lawful; the journalist remains responsible for applicable law and newsroom policy.
- Audio is limited to supported formats and 40 MB in this first release.
- The backend never places the Gemini API key in the Android application.
- Temporary provider deletion is attempted even when transcription fails.
- Generated quotes must be checked against the recording before publication.
- AI summaries, speaker labels and facts may contain errors and require editorial review.
- Original audio is not added to model-training datasets.
- Journalist data must not be exposed through Progress Hub.

## Production activation

Interview uploads are disabled by default. Enable Cloud Billing and confirm the applicable Gemini paid-service data terms before setting `HIGURU_JOURNALIST_AUDIO_ENABLED=true` on the backend. Do not place this switch in the Android client.

## Access

The first release uses the active Business entitlement. A separate Journalist plan or annual add-on can be introduced later without changing the recording architecture.

## Future live transcription

The current reliable workflow records first and transcribes after stopping. Real-time captions require a dedicated streaming Speech-to-Text connection, reconnect handling, partial-result reconciliation and newsroom cost controls. Local recording must remain the source of truth when live captions are added.
